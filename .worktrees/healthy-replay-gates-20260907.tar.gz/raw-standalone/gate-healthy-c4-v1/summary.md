# Experiment tiered-oracle-rec-a-c4

Run: `gate-healthy-c4-v1`  
Attempt: `attempt-01`  
SandboxTask UID: `healthy-c4-v1`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `e59df8b293081e59884a5433` | tool-static-resident | 4 | succeeded | 552.643 | 0 | 0 |
