# Experiment tiered-oracle-rec-a-c1

Run: `gate-healthy-c1-v1`  
Attempt: `attempt-01`  
SandboxTask UID: `healthy-c1-v1`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `6ed4c3ce97f1c1b9c1d20d2d` | tool-static-resident | 1 | succeeded | 317.899 | 0 | 0 |
