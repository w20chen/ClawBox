# Experiment tiered-oracle-rec-a-c1

Run: `gate-rec-a-c1-20260907-r15`  
Attempt: `attempt-01`  
SandboxTask UID: `task-r15`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `7d7dcda4e8b1d5e074bb511c` | tool-static-resident | 1 | failed | 296.840 | 0 | 0 |
