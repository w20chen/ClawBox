# Experiment tiered-oracle-rec-a-c1

Run: `gate-rec-a-c1-20260907-r1`  
Attempt: `attempt-gate-rec-a-c1-20260907-r1`  
SandboxTask UID: `task-gate-rec-a-c1-20260907-r1`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `5a5e5824fef20a5abadfc43c` | tool-static-resident | 1 | failed | 62.431 | 0 | 0 |
