# Experiment tiered-oracle-rec-a-c1

Run: `gate-rec-a-c1-20260907-r2`  
Attempt: `gate-rec-a-c1-20260907-r2-attempt`  
SandboxTask UID: `gate-rec-a-c1-20260907-r2-task`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `a38d7cf2d94ef15057a52f5e` | tool-static-resident | 1 | failed | 63.046 | 0 | 0 |
