# Experiment tiered-oracle-rec-a-c1

Run: `gate-rec-a-c1-20260907-r5`  
Attempt: `gate-rec-a-c1-20260907-r5-attempt`  
SandboxTask UID: `gate-rec-a-c1-20260907-r5-task`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `7d7dcda4e8b1d5e074bb511c` | tool-static-resident | 1 | failed | 65.121 | 0 | 0 |
