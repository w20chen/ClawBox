# Experiment tiered-oracle-rec-a-c1

Run: `gate-rec-a-c1-20260907-r3`  
Attempt: `gate-rec-a-c1-20260907-r3-attempt`  
SandboxTask UID: `gate-rec-a-c1-20260907-r3-task`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `74603bebbfc0899177813d82` | tool-static-resident | 1 | failed | 66.233 | 0 | 0 |
