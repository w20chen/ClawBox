# Experiment tiered-oracle-rec-a-c1

Run: `gate-rec-a-c1-20260907-r4`  
Attempt: `gate-rec-a-c1-20260907-r4-attempt`  
SandboxTask UID: `gate-rec-a-c1-20260907-r4-task`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `f7b1f77b5e21e962889f7a65` | tool-static-resident | 1 | failed | 65.284 | 0 | 0 |
