from pathlib import Path

import pytest

from clawbox.experiments.priority import PriorityDomain, physical_cluster_groups


def fake_topology(root: Path) -> Path:
    for cpu in range(16):
        topology = root / f'cpu{cpu}' / 'topology'
        topology.mkdir(parents=True)
        cluster = '0-7' if cpu < 8 else '8-15'
        sibling = f'{cpu//2*2}-{cpu//2*2+1}'
        (topology/'cluster_cpus_list').write_text(cluster)
        (topology/'thread_siblings_list').write_text(sibling)
    return root


def test_cluster_groups_use_distinct_physical_cores(tmp_path):
    assert physical_cluster_groups('0-15', group_size=4, sysfs=fake_topology(tmp_path)) == (
        '0,2,4,6', '8,10,12,14',
    )


def test_runtime_and_tool_spread_across_cluster_groups(monkeypatch):
    monkeypatch.setattr(
        'clawbox.experiments.priority.physical_cluster_groups',
        lambda cpus, group_size: ('0,2,4,6', '8,10,12,14'),
    )
    events = []
    domain = PriorityDomain(
        Path('/sys/fs/cgroup/cube_sandbox/sandbox'), concurrency=2, repetition=0,
        placements={0: ('0-15', 0), 1: ('0-15', 0)}, legacy=False,
        topology_mode='cluster_adaptive', emit=events.append,
    )
    assert domain._fine_masks == {
        (0, 'runtime'): '0,2,4,6', (0, 'tool'): '8,10,12,14',
        (1, 'runtime'): '0,2,4,6', (1, 'tool'): '8,10,12,14',
    }
    assert all(event['action'] == 'assign' for event in events)


def test_topology_placement_requires_real_choice(monkeypatch):
    monkeypatch.setattr(
        'clawbox.experiments.priority.physical_cluster_groups',
        lambda cpus, group_size: ('0,2,4,6',),
    )
    with pytest.raises(RuntimeError, match='at least two'):
        PriorityDomain(
            Path('/sys/fs/cgroup/cube_sandbox/sandbox'), concurrency=1, repetition=0,
            placements={0: ('0-7', 0)}, legacy=False,
            topology_mode='cluster_static',
        )


def test_adaptive_placement_expands_after_two_pressure_samples(monkeypatch, tmp_path):
    monkeypatch.setattr(
        'clawbox.experiments.priority.physical_cluster_groups',
        lambda cpus, group_size: ('0,2,4,6', '8,10,12,14'),
    )
    domain = PriorityDomain(
        tmp_path, concurrency=1, repetition=0, placements={0: ('0-15', 0)},
        legacy=False, topology_mode='cluster_adaptive', topology_pressure_ratio=.1,
        topology_cooldown_seconds=1,
    )
    leaf = tmp_path/'runtime'
    leaf.mkdir()
    (leaf/'cgroup.procs').write_text('100')
    (leaf/'cpu.pressure').write_text('some avg10=0 avg60=0 avg300=0 total=0')
    domain.leaves[0, 'runtime'] = leaf
    applied = []
    monkeypatch.setattr(
        domain, '_apply_thread_affinity',
        lambda index, role, cpus, strict=False: applied.append((index, role, cpus)) or [
            {'tid': 100, 'name': 'vcpu0', 'cpus_allowed': cpus},
        ],
    )
    times = iter((1.0, 2.0, 3.0))
    monkeypatch.setattr('clawbox.experiments.priority.time.monotonic', lambda: next(times))

    assert domain.sample_topology_placement() == []
    (leaf/'cpu.pressure').write_text('some avg10=0 avg60=0 avg300=0 total=200000')
    assert domain.sample_topology_placement() == []
    (leaf/'cpu.pressure').write_text('some avg10=0 avg60=0 avg300=0 total=400000')
    changes = domain.sample_topology_placement()

    assert applied == [(0, 'runtime', '0-15')]
    assert changes[0]['reason'] == 'cpu_pressure'
    assert changes[0]['pressure_ratio'] == .2
