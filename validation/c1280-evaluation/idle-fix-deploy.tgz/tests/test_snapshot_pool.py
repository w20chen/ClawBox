from concurrent.futures import ThreadPoolExecutor
from threading import Event

import pytest

from clawbox.experiments.snapshot_pool import (
    SnapshotKey, WarmAdmissionRejected, WarmCapacityError, WarmSnapshotPool,
    WarmSnapshotTooLarge,
)


def key(index: int) -> SnapshotKey:
    return SnapshotKey(f"session-{index}", "tool", 1)


def commit(pool: WarmSnapshotPool, index: int, size: int) -> None:
    pool.reserve(key(index), size)
    pool.commit(key(index), path=f"/warm/{index}", logical_bytes=size,
                allocated_bytes=size, transferred_bytes=size)


def test_snapshot_aware_rejects_lower_value_candidate_without_spilling():
    pool = WarmSnapshotPool(100, snapshot_aware=True)
    pool.reserve(key(1), 100)
    pool.commit(key(1), path="/warm/1", logical_bytes=100,
                allocated_bytes=100, transferred_bytes=100,
                retention_value_seconds=10)
    with pytest.raises(WarmAdmissionRejected):
        pool.reserve_for_admission(
            key(2), 100, timeout_s=.01, retention_value_seconds=5,
        )
    assert pool.manifest(key(1)).path == "/warm/1"


def test_snapshot_aware_spills_lower_value_state_and_reports_base_refs():
    pool = WarmSnapshotPool(100, snapshot_aware=True)
    pool.reserve(key(1), 100)
    spilled=[]
    pool.commit(key(1), path="/warm/1", logical_bytes=150,
                allocated_bytes=100, transferred_bytes=100,
                retention_value_seconds=2, template_id="tpl-a",
                shared_base_identity="base-a", private_delta_bytes=100,
                dependency_count=1, spiller=spilled.append)
    pool.reserve_for_admission(
        key(2), 100, timeout_s=.01, retention_value_seconds=8,
    )
    assert [item.key for item in spilled] == [key(1)]
    assert pool.snapshot()["shared_base_references"] == {}


def test_reservation_and_commit_never_double_count() -> None:
    pool = WarmSnapshotPool(100)
    pool.reserve(key(1), 60)
    assert (pool.reserved_bytes, pool.committed_bytes) == (60, 0)
    pool.commit(key(1), path="/warm/1", logical_bytes=55,
                allocated_bytes=50, transferred_bytes=55)
    assert (pool.reserved_bytes, pool.committed_bytes) == (0, 50)


def test_live_borrow_and_snapshots_share_one_capacity() -> None:
    pool = WarmSnapshotPool(128, borrow_capacity_bytes=64)
    pool.reserve_borrow("vm-a", 60)
    assert pool.borrowed_bytes == 60
    pool.reserve(key(1), 68)
    with pytest.raises(WarmCapacityError, match="shared NUMA capacity"):
        pool.reserve_borrow("vm-b", 1)
    pool.abort(key(1))
    assert pool.release_borrow("vm-a") == 60
    assert pool.snapshot()["borrowed_bytes"] == 0


def test_live_borrow_cannot_exceed_half_pool_limit() -> None:
    pool = WarmSnapshotPool(128, borrow_capacity_bytes=64)
    pool.reserve_borrow("vm-a", 64)
    with pytest.raises(WarmCapacityError, match="live-borrow"):
        pool.reserve_borrow("vm-b", 1)


def test_retained_lineage_is_not_spillable_and_commit_counts_only_new_pages():
    pool = WarmSnapshotPool(100)
    commit(pool, 1, 60)
    pool.retain_for_vm(key(1))
    with pytest.raises(WarmCapacityError):
        pool.lru_victims(50)
    successor = SnapshotKey(key(1).session_id, "tool", 2)
    pool.reserve(successor, 30)
    pool.commit(successor, path="/warm/delta", logical_bytes=60,
                allocated_bytes=80, transferred_bytes=20, replaces=key(1))
    assert pool.reserved_bytes == 0
    assert pool.committed_bytes == 80
    assert len(pool.snapshot()["manifests"]) == 1
    assert not pool.manifest(successor).retained_by_vm


def test_failed_successor_commit_preserves_retained_baseline():
    pool = WarmSnapshotPool(100)
    commit(pool, 1, 60)
    pool.retain_for_vm(key(1))
    successor = SnapshotKey(key(1).session_id, "tool", 2)
    pool.reserve(successor, 30)
    with pytest.raises(RuntimeError, match="exceed reservation"):
        pool.commit(successor, path="/warm/delta", logical_bytes=60,
                    allocated_bytes=95, transferred_bytes=35, replaces=key(1))
    pool.abort(successor)
    assert pool.committed_bytes == 60
    assert pool.manifest(key(1)).retained_by_vm


def test_oversize_and_capacity_pressure_fail_closed() -> None:
    pool = WarmSnapshotPool(100)
    with pytest.raises(WarmSnapshotTooLarge):
        pool.reserve(key(1), 101)
    commit(pool, 1, 70)
    with pytest.raises(WarmCapacityError):
        pool.reserve(key(2), 40)


def test_lru_victims_are_pinned_and_deterministic() -> None:
    pool = WarmSnapshotPool(100, clock=lambda: 1.0)
    commit(pool, 2, 30)
    commit(pool, 1, 30)
    victims = pool.lru_victims(60)
    assert [item.key for item in victims] == [key(1)]
    with pytest.raises(RuntimeError, match="pinned"):
        pool.remove(key(1))
    for item in victims:
        pool.unpin(item.key)
        pool.remove(item.key)
    pool.reserve(key(3), 60)


def test_concurrent_reservations_conserve_capacity() -> None:
    pool = WarmSnapshotPool(64)

    def reserve(index: int) -> bool:
        try:
            pool.reserve(key(index), 16)
            return True
        except WarmCapacityError:
            return False

    with ThreadPoolExecutor(max_workers=16) as executor:
        accepted = list(executor.map(reserve, range(16)))
    assert sum(accepted) == 4
    assert pool.reserved_bytes == 64


def test_spill_for_admission_relocates_lru_and_reclaims_accounting() -> None:
    pool = WarmSnapshotPool(100, clock=lambda: 1.0)
    spilled: list[SnapshotKey] = []
    for index in (1, 2):
        item_key = key(index)
        pool.reserve(item_key, 50)
        pool.commit(
            item_key, path=f"/warm/{index}", logical_bytes=50,
            allocated_bytes=50, transferred_bytes=50,
            spiller=lambda item: spilled.append(item.key),
        )
    victims = pool.spill_for_admission(50)
    assert [item.key for item in victims] == [key(1)]
    assert spilled == [key(1)]
    assert pool.committed_bytes == 50


def test_oversized_admission_never_spills_or_pins_existing_snapshots() -> None:
    pool = WarmSnapshotPool(100)
    spilled: list[SnapshotKey] = []
    pool.reserve(key(1), 100)
    pool.commit(
        key(1), path="/warm/1", logical_bytes=100, allocated_bytes=100,
        transferred_bytes=100, spiller=lambda item: spilled.append(item.key),
    )
    before = pool.snapshot()
    with pytest.raises(WarmSnapshotTooLarge):
        pool.spill_for_admission(101)
    assert spilled == []
    assert pool.snapshot() == before


def test_consumer_pin_excludes_spill_and_can_retire_snapshot() -> None:
    pool = WarmSnapshotPool(100)
    commit(pool, 1, 100)
    with pool.consume_guard(key(1)) as item:
        assert item is not None and item.pinned == 1
        with pytest.raises(WarmCapacityError):
            pool.spill_for_admission(1)
        pool.remove(key(1), consume_pinned=True)
    assert pool.committed_bytes == 0


def test_consumer_waits_for_inflight_spill() -> None:
    pool = WarmSnapshotPool(100)
    entered, release, consumed = Event(), Event(), Event()

    def spill(item):
        entered.set()
        assert release.wait(5)

    pool.reserve(key(1), 100)
    pool.commit(key(1), path="/warm/1", logical_bytes=100,
                allocated_bytes=100, transferred_bytes=100, spiller=spill)

    def consume():
        with pool.consume_guard(key(1)) as item:
            consumed.set()
            return item

    with ThreadPoolExecutor(max_workers=2) as executor:
        spilling = executor.submit(pool.spill_for_admission, 100)
        assert entered.wait(5)
        consuming = executor.submit(consume)
        try:
            assert not consumed.wait(0.1)
        finally:
            release.set()
        assert len(spilling.result(timeout=5)) == 1
        assert consuming.result(timeout=5) is None
    assert pool.committed_bytes == 0


def test_consumer_failure_releases_pin_without_retiring_snapshot() -> None:
    pool = WarmSnapshotPool(100)
    commit(pool, 1, 100)
    with pytest.raises(ValueError):
        with pool.consume_guard(key(1)):
            raise ValueError("restore failed")
    assert pool.committed_bytes == 100
    assert pool.snapshot()["manifests"][0]["pinned"] == 0


def test_atomic_admission_waits_for_uncommitted_writer() -> None:
    pool = WarmSnapshotPool(100)
    pool.reserve(key(1), 100)
    admitted = Event()

    def admit():
        pool.reserve_for_admission(key(2), 100, timeout_s=5)
        admitted.set()

    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(admit)
        assert not admitted.wait(0.1)
        pool.commit(key(1), path="/warm/1", logical_bytes=100,
                    allocated_bytes=100, transferred_bytes=100, spiller=lambda _: None)
        future.result(timeout=5)
    assert pool.reserved_bytes == 100 and pool.committed_bytes == 0
