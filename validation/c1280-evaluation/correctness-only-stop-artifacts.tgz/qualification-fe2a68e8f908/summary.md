# Experiment actual-idle-c320-l384-full-20261018-qualification

Run: `qualification-fe2a68e8f908`  
Attempt: `attempt-e4d2cac67a67`  
SandboxTask UID: `qualification-fe2a68e8f908`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `72e78eec8ea44d601e574d04` | full | 2 | failed | 0.000 | 0 | 0 |
