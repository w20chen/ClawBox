# Experiment idle-actual-wait-verification-20261018-qualification

Run: `qualification-3ff1ef31ab25`  
Attempt: `attempt-472258b73b0b`  
SandboxTask UID: `qualification-3ff1ef31ab25`

| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |
|---|---|---:|---|---:|---:|---:|
| `d5c510ebca0d482ad365e51e` | wait-pair | 8 | succeeded | 65.313 | 0 | 0 |
