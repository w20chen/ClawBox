"""Idempotent OpenAI-compatible gateway for in-guest OpenClaw experiments."""

from __future__ import annotations

import base64
import hashlib
import inspect
import json
import sys
import threading
import time
from dataclasses import asdict, dataclass, field, replace
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

import httpx

from .trace import ReplayAction, load_trace
from .process_sessions import bind_process_sessions, rebind_process_sessions


DEFERRED_TOOL_TIMEOUT_PREFIX = "CLAWBOX_DEFERRED_TOOL_TIMEOUT_SECONDS="


@dataclass(slots=True)
class GatewayRequest:
    request_id: str
    replay_index: int | None
    request_namespace: str = "default"
    request_fingerprint: str = ""
    ready: bool = False
    status_code: int = 0
    content_type: str = "application/json"
    response_b64: str = ""
    error: str = ""
    started_unix_s: float = 0.0
    model_generated_unix_s: float = 0.0
    response_released_unix_s: float = 0.0
    completed_unix_s: float = 0.0
    delivered_unix_s: float = 0.0
    request_payload: dict[str, Any] = field(default_factory=dict)
    admission: dict[str, Any] = field(default_factory=dict)
    http_attempts: int = 0
    reconnect_attempts: int = 0
    delivery_failures: int = 0
    delivered: bool = False
    production_attempts: int = 0
    replay_process_sessions: dict[str, dict[str, str]] = field(default_factory=dict)


class ModelGateway:
    """Keep the guest API identical while switching replay and real upstreams."""

    def __init__(self, store_path: Path, *, mode: str, trace: Path | None = None,
                 time_scale: float = 1.0, upstream_base_url: str | None = None,
                 upstream_api_key: str | None = None, upstream_model: str | None = None,
                 timeout_s: float = 600.0,
                 tool_transport_timeout_s: float | None = None,
                 max_model_steps: int | None = None,
                 request_namespace: str = "default",
                 on_request_started: Callable[[], None] | None = None,
                 before_response_ready: Callable[[int | None, dict[str, Any]], dict[str, Any]] | None = None) -> None:
        if mode not in {"replay", "api"}:
            raise ValueError("mode must be replay or api")
        if time_scale < 0:
            raise ValueError("time_scale must be non-negative")
        if mode == "replay" and trace is None:
            raise ValueError("replay mode requires a trace")
        if mode == "api" and (not upstream_base_url or not upstream_api_key or not upstream_model):
            raise ValueError("api mode requires upstream URL, key, and model")
        self.store_path = store_path
        self.mode = mode
        self.actions = [] if trace is None else [a for a in load_trace(trace) if a.kind == "llm"]
        if max_model_steps is not None and (
            mode != "replay" or type(max_model_steps) is not int or max_model_steps < 1
        ):
            raise ValueError("max_model_steps requires replay and a positive integer")
        self.max_model_steps = max_model_steps
        self._prefix_stop: dict[str, Any] | None = None
        self.time_scale = time_scale
        self.upstream_base_url = (upstream_base_url or "").rstrip("/")
        self.upstream_api_key = upstream_api_key or ""
        self.upstream_model = upstream_model or ""
        self.timeout_s = timeout_s
        self.tool_transport_timeout_s = tool_transport_timeout_s
        self.request_namespace = str(request_namespace).strip()
        if not self.request_namespace:
            raise ValueError("request_namespace must not be empty")
        self.on_request_started = on_request_started
        self.before_response_ready = before_response_ready
        self._requests: dict[str, GatewayRequest] = {}
        self._replay_failure: str | None = None
        self._process_sessions: dict[str, dict[str, str]] = {}
        self._lock = threading.Lock()
        self._changed = threading.Condition(self._lock)
        self._flush_lock = threading.Lock()
        self._persistence_revision = 0
        self._persisted_revision = -1
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self, host: str, port: int = 18081) -> str:
        gateway = self

        class Handler(BaseHTTPRequestHandler):
            def do_GET(self) -> None:  # noqa: N802
                if self.path == "/healthz":
                    self._send(HTTPStatus.OK, "application/json", b'{"ok":true}')
                else:
                    self.send_error(HTTPStatus.NOT_FOUND)

            def do_POST(self) -> None:  # noqa: N802
                if self.path.rstrip("/") != "/v1/chat/completions":
                    self.send_error(HTTPStatus.NOT_FOUND)
                    return
                request_id: str | None = None
                try:
                    payload = json.loads(self.rfile.read(int(self.headers.get("Content-Length", "0"))))
                    status, content_type, body, request_id = gateway._complete_with_identity(
                        payload, http_attempt=True,
                    )
                    self._send(status, content_type, body)
                    gateway.mark_delivery(request_id, delivered=True)
                except (TypeError, ValueError, json.JSONDecodeError) as exc:
                    print(
                        f"model gateway rejected request: {type(exc).__name__}: {exc}",
                        file=sys.stderr, flush=True,
                    )
                    self._send(HTTPStatus.BAD_REQUEST, "application/json", json.dumps({"error": str(exc)}).encode())
                except (BrokenPipeError, ConnectionResetError):
                    if request_id is not None:
                        gateway.mark_delivery(request_id, delivered=False)

            def _send(self, status: int, content_type: str, body: bytes) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, _format: str, *_args: object) -> None:
                return

        class Server(ThreadingHTTPServer):
            request_queue_size = 4096
            daemon_threads = True
            allow_reuse_address = True

        self._server = Server((host, port), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return f"http://{host}:{self._server.server_port}/v1"

    def close(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None
        self.flush()

    def complete(self, payload: dict[str, Any]) -> tuple[int, str, bytes]:
        status, content_type, body, _request_id = self._complete_with_identity(
            payload, http_attempt=False,
        )
        return status, content_type, body

    def complete_http(self, payload: dict[str, Any]) -> tuple[int, str, bytes, str]:
        """Complete an HTTP request and retain its request identity."""
        return self._complete_with_identity(payload, http_attempt=True)

    def _persist_replay_rejection(
        self, *, index: int, actual: Any, expected: Any, reason: str,
    ) -> None:
        """Persist fail-closed replay evidence, including trace exhaustion."""
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        rejection = self.store_path.with_name(
            f"{self.store_path.stem}.rejected-request-{index:04d}.json"
        )
        temporary = rejection.with_name(rejection.name + ".next")
        temporary.write_text(json.dumps({
            "actual": actual,
            "expected": expected,
            "model_step": index,
            "reason": reason,
            "replay_process_sessions": self._process_sessions,
        }, sort_keys=True))
        temporary.replace(rejection)

    def _complete_with_identity(
        self, payload: dict[str, Any], *, http_attempt: bool,
    ) -> tuple[int, str, bytes, str]:
        if not isinstance(payload.get("messages"), list):
            raise ValueError("messages must be an array")
        canonical = dict(payload)
        canonical.pop("model", None)
        fingerprint = hashlib.sha256(json.dumps(
            canonical, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        ).encode()).hexdigest()
        started_event: dict[str, Any] | None = None
        with self._changed:
            if self._replay_failure is not None:
                raise ValueError(
                    f"replay session already diverged: {self._replay_failure}"
                )
            matching = [
                item for item in self._requests.values()
                if item.request_fingerprint == fingerprint
            ]
            # An undelivered response may be retried after a broken connection.
            # Once delivered, an identical payload is a new logical model step.
            request = matching[-1] if matching and not matching[-1].delivered else None
            if request is None and self.mode == "replay":
                undelivered = [
                    item for item in self._requests.values() if not item.delivered
                ]
                if undelivered and _checkpoint_retry_matches(
                    undelivered[-1].request_payload, canonical,
                ):
                    request = undelivered[-1]
            if request is None:
                index = len(self._requests) if self.mode == "replay" else None
                if (index is not None and self.max_model_steps is not None
                        and self.max_model_steps <= len(self.actions)
                        and index >= self.max_model_steps):
                    # A harness control response ends OpenClaw only after it
                    # has executed the final selected round's tools. It is not
                    # a recorded model response or a measured model step.
                    if self._prefix_stop is None:
                        self._prefix_stop = {
                            "kind": "experiment_prefix_stop", "synthetic": True,
                            "selected_model_steps": self.max_model_steps,
                            "source_model_steps": len(self.actions),
                            "request_payload": canonical, "delivered": False,
                        }
                    self._persist_prefix_stop()
                    stop = ReplayAction("control", "experiment-prefix-stop", 0, 0, 0,
                        "clawbox-experiment-control",
                        output={"content": "ClawBox experiment stopped at the configured replay round limit. This is not a task-completion result."})
                    return (*_replay_response(stop, bool(payload.get("stream"))),
                            "experiment-prefix-stop")
                if index is not None and index >= len(self.actions):
                    self._replay_failure = "trace_exhausted"
                    self._persist_replay_rejection(
                        index=index, actual=canonical, expected=None,
                        reason="trace_exhausted",
                    )
                    raise ValueError("OpenClaw made more model calls than the replay trace contains")
                if index is not None:
                    # Recorded model responses drive OpenClaw in order. Tool
                    # outputs remain actual guest outputs, not replay assertions.
                    try:
                        self._process_sessions = bind_process_sessions(
                            self.actions[index].input, canonical["messages"],
                            self._process_sessions,
                        )
                    except ValueError:
                        self._replay_failure = "process_session_identity_mismatch"
                        self._persist_replay_rejection(
                            index=index, actual=canonical["messages"],
                            expected=self.actions[index].input,
                            reason=self._replay_failure,
                        )
                        raise
                occurrence = len(matching)
                request_id = hashlib.sha256(
                    f"{self.request_namespace}\0{fingerprint}\0{occurrence}".encode()
                ).hexdigest()
                request = GatewayRequest(
                    request_id, index, started_unix_s=time.time(),
                    request_namespace=self.request_namespace,
                    request_fingerprint=fingerprint,
                    request_payload=canonical,
                    replay_process_sessions=dict(self._process_sessions),
                )
                self._requests[request_id] = request
                self._persist()
                started_event = {
                    "request_id": request_id,
                    "replay_index": index,
                    "request_started_at": request.started_unix_s,
                    "request_fingerprint": fingerprint,
                }
                if self.mode == "replay":
                    assert index is not None
                    started_event.update({
                        "oracle_model_wait_seconds": max(
                            0.0, self.actions[index].duration_s * self.time_scale,
                        ),
                        "oracle_model_wait_source": "held_out_replay_trace",
                    })
            else:
                request_id = request.request_id
            if http_attempt:
                request.http_attempts += 1
                if request.http_attempts > 1:
                    request.reconnect_attempts += 1
                self._persist()
        # Lifecycle notification is deliberately outside the gateway condition
        # lock. The callback must only enqueue work and return immediately.
        if started_event is not None:
            self._emit_request_started(started_event)
            threading.Thread(
                target=self._produce, args=(request_id, payload), daemon=True,
            ).start()
        with self._changed:
            request = self._requests[request_id]
            deadline = time.monotonic() + self.timeout_s
            while not request.ready:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    # A timed-out logical request is terminal.  Leaving it in
                    # the pending state makes an identical HTTP retry wait for
                    # another full timeout and lets a late producer publish a
                    # response after the experiment has already failed.
                    now = time.time()
                    request.status_code = int(HTTPStatus.GATEWAY_TIMEOUT)
                    request.content_type = "application/json"
                    request.response_b64 = ""
                    request.error = "model gateway request timed out"
                    request.ready = True
                    request.response_released_unix_s = now
                    request.completed_unix_s = now
                    self._persist()
                    self._changed.notify_all()
                    raise TimeoutError(request.error)
                self._changed.wait(timeout=remaining)
            if request.error:
                raise RuntimeError(request.error)
            return (
                request.status_code, request.content_type,
                base64.b64decode(request.response_b64), request_id,
            )

    def _emit_request_started(self, event: dict[str, Any]) -> None:
        callback = self.on_request_started
        if callback is None:
            return
        try:
            if len(inspect.signature(callback).parameters) == 0:
                callback()
            else:
                callback(dict(event))
        except Exception as exc:
            # Do not turn a lifecycle observer failure into an inference
            # failure. Preserve the error as non-sensitive provenance.
            with self._changed:
                request = self._requests.get(str(event["request_id"]))
                if request is not None:
                    request.admission["request_event_error"] = (
                        f"{type(exc).__name__}: {exc}"
                    )
                    self._persist()

    def mark_delivery(self, request_id: str, *, delivered: bool) -> None:
        """Record whether a host response write survived a guest disconnect."""
        with self._changed:
            if request_id == "experiment-prefix-stop" and self._prefix_stop is not None:
                self._prefix_stop["delivered"] = self._prefix_stop["delivered"] or delivered
                self._persist_prefix_stop()
                return
            request = self._requests.get(request_id)
            if request is None:
                raise KeyError(f"unknown gateway request {request_id}")
            if delivered:
                if request.delivered_unix_s <= 0:
                    delivered_at = time.time()
                    # Small append-only evidence survives a worker cutoff without
                    # rewriting the full conversation ledger on the response path.
                    path = self.store_path.with_suffix('.deliveries.jsonl')
                    path.parent.mkdir(parents=True, exist_ok=True)
                    with path.open('a', encoding='utf-8') as stream:
                        stream.write(json.dumps({'request_id': request_id,
                            'status_code': request.status_code,
                            'delivered_unix_s': delivered_at}) + '\n')
                    request.delivered_unix_s = delivered_at
                request.delivered = True
            else:
                request.delivery_failures += 1
            self._persist()

    def _persist_prefix_stop(self) -> None:
        path = self.store_path.with_suffix(".prefix-stop.json")
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + ".next")
        temporary.write_text(json.dumps(self._prefix_stop, indent=2), encoding="utf-8")
        temporary.replace(path)

    def records(self) -> list[dict[str, Any]]:
        with self._lock:
            records: list[dict[str, Any]] = []
            for item in self._requests.values():
                record = asdict(item)
                # Stable semantic names for campaign analysis; retain the
                # *_unix_s fields for compatibility with the original CLI.
                record.update({
                    "request_started_at": item.started_unix_s,
                    "model_generated_at": item.model_generated_unix_s,
                    "response_released_at": item.response_released_unix_s,
                    "response_delivered_at": item.delivered_unix_s,
                    "pure_model_latency_seconds": (
                        item.model_generated_unix_s - item.started_unix_s
                        if item.model_generated_unix_s else None
                    ),
                    "policy_induced_response_hold_seconds": (
                        item.response_released_unix_s - item.model_generated_unix_s
                        if item.response_released_unix_s and item.model_generated_unix_s else None
                    ),
                    "delivery_latency_seconds": (
                        item.delivered_unix_s - item.response_released_unix_s
                        if item.delivered_unix_s and item.response_released_unix_s else None
                    ),
                    "runtime_visible_model_wait_seconds": (
                        item.delivered_unix_s - item.started_unix_s
                        if item.delivered_unix_s else None
                    ),
                    "lifecycle_events": [
                        {"event": name, "unix_s": timestamp}
                        for name, timestamp in (
                            ("ModelRequestStarted", item.started_unix_s),
                            ("ModelResponseGenerated", item.model_generated_unix_s),
                            ("ModelResponseReleased", item.response_released_unix_s),
                            ("ModelResponseDelivered", item.delivered_unix_s),
                        ) if timestamp > 0
                    ],
                })
                records.append(record)
            return records

    def logical_model_steps(self) -> int:
        """Count accepted logical model requests, excluding HTTP retries."""
        with self._lock:
            return len(self._requests)

    def replay_completeness(self, *, require_delivery: bool = True) -> dict[str, Any]:
        """Return a strict, auditable completion verdict for this session."""
        records = self.records()
        expected = len(self.actions) if self.mode == "replay" else None
        prefix = (
            expected is not None
            and self.max_model_steps is not None
            and self.max_model_steps <= expected
        )
        if prefix:
            expected = self.max_model_steps
        incomplete = [
            item["request_id"] for item in records
            if not item.get("ready") or item.get("error") or item.get("status_code") != 200
            or (require_delivery and not item.get("delivered"))
        ]
        consumed = (
            sorted(item["replay_index"] for item in records
                   if item.get("replay_index") is not None)
            if self.mode == "replay" else []
        )
        expected_indices = list(range(expected or 0))
        complete = (
            self.mode != "replay" or (
                len(records) == expected
                and consumed == expected_indices
                and self._replay_failure is None
            )
        ) and not incomplete and (not prefix or bool(self._prefix_stop and self._prefix_stop["delivered"]))
        return {
            "mode": self.mode,
            "scope": "prefix" if prefix else "full",
            "source_model_steps": len(self.actions) if self.mode == "replay" else None,
            "prefix_stop_delivered": bool(self._prefix_stop and self._prefix_stop["delivered"]),
            "observed_logical_model_steps": len(records),
            "expected_replay_model_steps": expected,
            "replay_indices": consumed,
            "replay_entries_consumed_exactly_once": (
                self.mode != "replay" or consumed == expected_indices
            ),
            "tool_output_comparison": "not_performed",
            "replay_failure": self._replay_failure,
            "required_responses_delivered": not incomplete,
            "retry_http_attempts": sum(
                max(0, int(item.get("http_attempts", 0)) - 1) for item in records
            ),
            "missing_or_failed_request_ids": incomplete,
            "complete": complete,
        }

    def pending_records(self) -> list[dict[str, Any]]:
        """Return only fields needed by checkpoint scheduling.

        Copying every accumulated request payload at the 50 ms controller poll
        rate becomes quadratic in conversation length and can starve response
        admission at c40.  Scheduler decisions need no message content.
        """
        with self._lock:
            return [
                {
                    "request_id": item.request_id,
                    "replay_index": item.replay_index,
                    "started_unix_s": item.started_unix_s,
                    "ready": item.ready,
                }
                for item in self._requests.values()
                if not item.ready
            ]

    def _produce(self, request_id: str, payload: dict[str, Any]) -> None:
        with self._changed:
            self._requests[request_id].production_attempts += 1
            self._persist()
        try:
            if self.mode == "replay":
                request = self._requests[request_id]
                assert request.replay_index is not None
                action = self.actions[request.replay_index]
                action = replace(action, output=rebind_process_sessions(
                    action.output, request.replay_process_sessions,
                ))
                time.sleep(action.duration_s * self.time_scale)
                status, content_type, body = _replay_response(action, bool(payload.get("stream")))
            else:
                forwarded = dict(payload)
                forwarded["model"] = self.upstream_model
                with httpx.Client(trust_env=False, timeout=self.timeout_s) as client:
                    response = client.post(
                        self.upstream_base_url + "/chat/completions",
                        headers={"Authorization": f"Bearer {self.upstream_api_key}"},
                        json=forwarded,
                    )
                status = response.status_code
                content_type = response.headers.get("content-type", "application/json")
                body = response.content
            if self.tool_transport_timeout_s is not None and 200 <= int(status) < 300:
                body = _defer_exec_tool_timeouts(
                    content_type, body, self.tool_transport_timeout_s,
                )
            # Capture the pure model/replay completion before any policy or
            # restore operation. ``completed_unix_s`` remains the legacy
            # response-release timestamp for old consumers.
            model_generated = time.time()
            with self._changed:
                request = self._requests[request_id]
                request.model_generated_unix_s = model_generated
                self._persist()
            admission = {}
            error = ""
            if not 200 <= int(status) < 300:
                # Preserve the actual upstream status. Do not attempt to parse
                # an OpenAI message from an authentication/rate-limit/error
                # object, which would mask the provider failure as KeyError.
                error = f"upstream model returned HTTP {status}"
            elif self.before_response_ready is not None:
                event = {
                    "request_id": request_id,
                    "replay_index": self._requests[request_id].replay_index,
                    "request_started_at": self._requests[request_id].started_unix_s,
                    "model_generated_at": model_generated,
                }
                message = _response_message(content_type, body)
                callback = self.before_response_ready
                if len(inspect.signature(callback).parameters) >= 3:
                    admission = callback(
                        self._requests[request_id].replay_index, message, event,
                    )
                else:
                    admission = callback(
                        self._requests[request_id].replay_index, message,
                    )
        except Exception as exc:  # surfaced to the waiting guest request
            status, content_type, body, error, admission = 500, "application/json", b"", str(exc), {}
        with self._changed:
            request = self._requests[request_id]
            # The waiter may have made this request terminal while an
            # upstream call or lifecycle callback was still running.  Never
            # overwrite that timeout with a late response.
            if request.ready:
                return
            request.status_code = status
            request.content_type = content_type
            request.response_b64 = base64.b64encode(body).decode()
            request.error = error
            request.admission = admission
            request.ready = True
            request.response_released_unix_s = time.time()
            request.completed_unix_s = request.response_released_unix_s
            self._persist()
            self._changed.notify_all()


    def _persist(self) -> None:
        """Mark the in-memory ledger dirty without blocking response delivery.

        A request carries the complete conversation, and the ledger retains
        every prior request. Rewriting that whole structure at every state
        transition made replay persistence quadratic and put JSON encoding and
        filesystem I/O directly on the model-response critical path. The
        managed gateway flushes one atomic final snapshot when the session
        drains; ``close`` does the same for the standalone gateway.
        """
        self._persistence_revision += 1

    def flush(self) -> None:
        """Atomically persist one consistent ledger snapshot if it changed."""
        with self._flush_lock:
            with self._lock:
                revision = self._persistence_revision
                if revision == self._persisted_revision and self.store_path.is_file():
                    return
                snapshot = [asdict(item) for item in self._requests.values()]
            encoded = json.dumps(snapshot, sort_keys=True)
            self.store_path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.store_path.with_name(self.store_path.name + ".next")
            temporary.write_text(encoded, encoding="utf-8")
            temporary.replace(self.store_path)
            with self._lock:
                if self._persistence_revision == revision:
                    self._persisted_revision = revision

def _checkpoint_retry_duplicate_message(
    previous: dict[str, Any], current: dict[str, Any],
) -> Any | None:
    """Return the sole adjacent user-message insertion in a reconnect request."""
    left, right = previous, current
    if not isinstance(left, dict) or not isinstance(right, dict):
        return None
    left_messages = left.get("messages")
    right_messages = right.get("messages")
    if not isinstance(left_messages, list) or not isinstance(right_messages, list):
        return None
    if ({key: value for key, value in left.items() if key != "messages"}
            != {key: value for key, value in right.items() if key != "messages"}):
        return None
    if len(right_messages) != len(left_messages) + 1:
        return None
    for index in range(1, len(right_messages)):
        duplicate = right_messages[index]
        if duplicate != right_messages[index - 1]:
            continue
        if not isinstance(duplicate, dict) or duplicate.get("role") != "user":
            continue
        if right_messages[:index] + right_messages[index + 1:] == left_messages:
            return duplicate
    return None


def _checkpoint_retry_matches(previous: dict[str, Any], current: dict[str, Any]) -> bool:
    """Recognize OpenClaw's narrow retry shape after a Runtime checkpoint.

    When an in-flight TCP connection disappears, OpenClaw retries the same
    turn by inserting one duplicate adjacent user message. Only an undelivered
    request is eligible for this equivalence, and every other request field
    must remain identical. The insertion can precede already-recorded assistant
    and Tool messages on later turns.
    """
    return _checkpoint_retry_duplicate_message(previous, current) is not None


def _replay_response(action: ReplayAction, stream: bool) -> tuple[int, str, bytes]:
    message = action.output
    if isinstance(message, dict) and set(message) == {"content"} and isinstance(message["content"], dict):
        message = message["content"]
    if isinstance(message, str):
        message = {"content": message}
    if not isinstance(message, dict):
        raise ValueError(f"replay action {action.action_id} has no OpenAI-compatible response")
    message = {"role": "assistant", **message}
    finish = "tool_calls" if message.get("tool_calls") else "stop"
    response_id = f"replay-{action.action_id}"
    if not stream:
        body = {"id": response_id, "object": "chat.completion", "created": 0,
                "model": action.name, "choices": [{"index": 0, "message": message,
                "finish_reason": finish}], "usage": {"prompt_tokens": 0,
                "completion_tokens": 0, "total_tokens": 0}}
        return 200, "application/json", json.dumps(body, separators=(",", ":")).encode()
    chunk = {"id": response_id, "object": "chat.completion.chunk", "created": 0,
             "model": action.name, "choices": [{"index": 0, "delta": message,
             "finish_reason": finish}]}
    body = f"data: {json.dumps(chunk, separators=(',', ':'))}\n\ndata: [DONE]\n\n".encode()
    return 200, "text/event-stream", body


def _rewrite_exec_tool_calls(message: dict[str, Any], transport_timeout_s: float) -> bool:
    """Move an exec timeout behind admission while preserving it in-band."""
    rendered_transport = max(1, int(transport_timeout_s))
    changed = False
    for tool_call in message.get("tool_calls") or []:
        function = tool_call.get("function") or {}
        if function.get("name") != "exec":
            continue
        encoded = function.get("arguments")
        if not isinstance(encoded, str):
            continue
        try:
            arguments = json.loads(encoded)
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        timeout = arguments.get("timeout")
        command = arguments.get("command")
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                or timeout <= 0 or not isinstance(command, str)):
            continue
        if command.startswith(DEFERRED_TOOL_TIMEOUT_PREFIX):
            continue
        rendered_actual = max(1, int(timeout))
        arguments["command"] = (
            f"{DEFERRED_TOOL_TIMEOUT_PREFIX}{rendered_actual}\n{command}"
        )
        arguments["timeout"] = rendered_transport
        function["arguments"] = json.dumps(
            arguments, ensure_ascii=False, separators=(",", ":"),
        )
        changed = True
    return changed


def _defer_exec_tool_timeouts(
    content_type: str, body: bytes, transport_timeout_s: float,
) -> bytes:
    """Keep OpenClaw's transport alive; the SSH shim starts timeout after ADMIT."""
    if "text/event-stream" not in content_type.lower():
        response = json.loads(body)
        for choice in response.get("choices") or []:
            message = choice.get("message")
            if isinstance(message, dict):
                _rewrite_exec_tool_calls(message, transport_timeout_s)
        return json.dumps(response, ensure_ascii=False, separators=(",", ":")).encode()

    chunks: list[dict[str, Any]] = []
    for raw_line in body.decode("utf-8").splitlines():
        if not raw_line.startswith("data:"):
            continue
        encoded = raw_line[5:].strip()
        if not encoded or encoded == "[DONE]":
            continue
        chunks.append(json.loads(encoded))
    if not chunks:
        return body
    message = _response_message(content_type, body)
    if not _rewrite_exec_tool_calls(message, transport_timeout_s):
        return body
    template = {key: value for key, value in chunks[0].items() if key != "choices"}
    finish_reason = next((
        choice.get("finish_reason")
        for chunk in reversed(chunks)
        for choice in chunk.get("choices") or []
        if choice.get("finish_reason") is not None
    ), "tool_calls")
    template["choices"] = [{
        "index": 0, "delta": message, "finish_reason": finish_reason,
    }]
    return (
        "data: " + json.dumps(template, ensure_ascii=False, separators=(",", ":"))
        + "\n\ndata: [DONE]\n\n"
    ).encode()


def _response_message(content_type: str, body: bytes) -> dict[str, Any]:
    if "text/event-stream" not in content_type.lower():
        message = json.loads(body)["choices"][0]["message"]
        if not isinstance(message, dict):
            raise ValueError("model response message is not an object")
        return {key: value for key, value in message.items() if key != "role"}
    content: list[str] = []
    tool_calls: dict[int, dict[str, Any]] = {}
    for raw_line in body.decode("utf-8").splitlines():
        if not raw_line.startswith("data:"):
            continue
        encoded = raw_line[5:].strip()
        if not encoded or encoded == "[DONE]":
            continue
        for choice in json.loads(encoded).get("choices", []):
            delta = choice.get("delta") or {}
            if isinstance(delta.get("content"), str):
                content.append(delta["content"])
            for position, fragment in enumerate(delta.get("tool_calls") or []):
                # Recorded non-streaming responses contain complete tool calls
                # without the per-fragment ``index`` required by OpenAI's
                # streaming format.  _replay_response emits those complete
                # calls in one SSE delta, so preserve their array positions
                # instead of accidentally merging every call into slot zero.
                index = int(fragment.get("index", position))
                target = tool_calls.setdefault(
                    index, {"id": "", "type": "function",
                            "function": {"name": "", "arguments": ""}},
                )
                if fragment.get("id"):
                    target["id"] += str(fragment["id"])
                if fragment.get("type"):
                    target["type"] = fragment["type"]
                function = fragment.get("function") or {}
                target["function"]["name"] += str(function.get("name") or "")
                target["function"]["arguments"] += str(function.get("arguments") or "")
    message: dict[str, Any] = {"content": "".join(content)}
    if tool_calls:
        message["tool_calls"] = [tool_calls[index] for index in sorted(tool_calls)]
    return message
