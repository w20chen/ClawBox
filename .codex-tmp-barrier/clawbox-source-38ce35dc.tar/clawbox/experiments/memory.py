from __future__ import annotations

import shutil
import time
from dataclasses import dataclass
from pathlib import Path
from threading import Event, Lock, Thread
from collections.abc import Callable


def cgroup_memory_evidence(root: Path) -> dict:
    """Raw kernel counters; absent optional interfaces are unknown, never zero.

    file includes shmem. RSS and memory.current are not interchangeable, and
    PSI totals are cumulative microseconds, not bytes or utilization samples.
    """
    def scalar(name):
        path = root / name
        if not path.exists():
            return None
        raw = path.read_text().strip()
        return raw if raw == "max" else int(raw)

    def counters(name):
        path = root / name
        if not path.exists():
            return None
        return {key: int(value) for key, value in
                (line.split() for line in path.read_text().splitlines())}

    pressure = root / "memory.pressure"
    psi = None
    if pressure.exists():
        psi = {}
        for line in pressure.read_text().splitlines():
            kind, *values = line.split()
            psi[kind] = {k: int(v) if k == "total" else float(v)
                         for k, v in (item.split("=") for item in values)}
    return {"scope": str(root), "current_bytes": scalar("memory.current"),
            "peak_bytes": scalar("memory.peak"),
            "peak_scope": "cgroup lifetime; not reset by the experiment",
            "max_bytes": scalar("memory.max"), "high_bytes": scalar("memory.high"),
            "swap_current_bytes": scalar("memory.swap.current"),
            "swap_max_bytes": scalar("memory.swap.max"),
            "stat": counters("memory.stat"), "events": counters("memory.events"),
            "pressure": psi}


def read_meminfo(path: Path) -> tuple[int, int]:
    if not path.exists():
        import psutil
        memory = psutil.virtual_memory()
        return int(memory.total), int(memory.available)
    values: dict[str, int] = {}
    for line in path.read_text(encoding="ascii").splitlines():
        key, _, rest = line.partition(":")
        if key in {"MemTotal", "MemAvailable"}:
            values[key] = int(rest.split()[0]) * 1024
    return values["MemTotal"], values["MemAvailable"]


def read_vmstat_counter(path: Path, key: str) -> int:
    if not path.exists():
        return 0
    for line in path.read_text(encoding="ascii").splitlines():
        name, _, raw = line.partition(" ")
        if name == key:
            return int(raw.strip())
    return 0


def read_numa_meminfo(path: Path) -> tuple[int, int]:
    values: dict[str, int] = {}
    for line in path.read_text(encoding="ascii").splitlines():
        fields = line.split()
        if len(fields) >= 4 and fields[2] in {"MemTotal:", "MemFree:"}:
            values[fields[2].removesuffix(":")] = int(fields[3]) * 1024
    if set(values) != {"MemTotal", "MemFree"}:
        raise ValueError(f"incomplete NUMA meminfo: {path}")
    return values["MemTotal"], values["MemFree"]


def read_numa_allocation_counters(
    root: Path = Path("/host/sys/devices/system/node"),
) -> dict[str, dict[str, int]] | None:
    """Read kernel NUMA allocation counters without calling them traffic.

    ``node*/numastat`` counts allocation decisions in pages.  In particular,
    ``numa_miss``/``numa_foreign``/``other_node`` are useful diagnostics, but
    they do not measure cache-line or memory-controller interconnect bytes.
    Missing or partially unreadable sysfs data is reported as unavailable.
    """
    if not root.exists():
        fallback = Path("/sys/devices/system/node")
        root = fallback if fallback.exists() else root
    result: dict[str, dict[str, int]] = {}
    try:
        paths = sorted(root.glob("node[0-9]*/numastat"))
    except OSError:
        return None
    for path in paths:
        try:
            values = {}
            for line in path.read_text(encoding="ascii").splitlines():
                name, raw = line.split(None, 1)
                values[name] = int(raw)
        except (OSError, ValueError):
            return None
        result[path.parent.name] = values
    return result or None


def numa_allocation_counter_deltas(
    before: dict[str, dict[str, int]] | None,
    after: dict[str, dict[str, int]] | None,
) -> dict[str, dict[str, int]] | None:
    """Return monotonic per-node page-event deltas, or unavailable."""
    if before is None or after is None or before.keys() != after.keys():
        return None
    result: dict[str, dict[str, int]] = {}
    for node in before:
        if before[node].keys() != after[node].keys():
            return None
        if any(after[node][name] < value for name, value in before[node].items()):
            return None
        result[node] = {
            name: after[node][name] - before[node][name]
            for name in before[node]
        }
    return result


@dataclass(frozen=True, slots=True)
class MemorySummary:
    mem_total_bytes: int
    baseline_used_bytes: int
    mean_used_delta_bytes: float
    peak_used_delta_bytes: int
    memory_time_integral_byte_seconds: float
    minimum_available_bytes: int
    storage_used_delta_bytes: int
    host_oom_kill_events: int
    host_baseline_used_bytes: int | None
    host_mean_used_delta_bytes: float | None
    host_peak_used_delta_bytes: int | None
    host_min_used_delta_bytes: int | None
    host_memory_time_integral_byte_seconds: float | None
    numa_allocation_event_deltas: dict[str, dict[str, int]] | None


class NodeMemorySampler:
    sample_hook: Callable[[int, int], None] | None = None

    def __init__(self, *, meminfo: Path = Path("/host/proc/meminfo"),
                 vmstat: Path = Path("/host/proc/vmstat"),
                 storage: Path = Path("/data/cubelet"), interval_s: float = 0.2) -> None:
        self.meminfo = meminfo if meminfo.exists() else Path("/proc/meminfo")
        self.vmstat = vmstat if vmstat.exists() else Path("/proc/vmstat")
        self.storage = storage
        self.interval_s = interval_s
        self._stop = Event()
        self._lock = Lock()
        self._samples: list[tuple[float, int, int]] = []
        self._thread: Thread | None = None
        total, available = read_meminfo(self.meminfo)
        self.host_mem_total = total
        self.host_baseline_used = total - available
        self.total = total
        self.baseline_used = total - available
        self.storage_used_before = self._storage_used()
        self.oom_kill_before = read_vmstat_counter(self.vmstat, "oom_kill")
        self.numa_allocation_root = Path("/host/sys/devices/system/node")
        self.numa_allocation_before = read_numa_allocation_counters(
            self.numa_allocation_root
        )

    def current(self) -> tuple[int, int]:
        total, available = read_meminfo(self.meminfo)
        return max(0, total - available - self.baseline_used), available

    def observe(self) -> dict[str, int | str]:
        """Return an explicit host-memory observation for lifecycle evidence.

        ``host_used_bytes`` is whole-host physical memory in use, whereas
        ``experiment_used_delta_bytes`` is relative to the arm baseline used
        by admission control.  Neither value is guest Tool cgroup memory.
        """
        total, available = read_meminfo(self.meminfo)
        used = max(0, total - available)
        return {
            "metric": "host_meminfo_memavailable",
            "host_mem_total_bytes": total,
            "host_used_bytes": used,
            "host_available_bytes": available,
            "experiment_used_delta_bytes": max(0, used - self.baseline_used),
        }

    def start(self) -> None:
        self._sampling_error = None
        delta, available = self.current()
        with self._lock:
            self._samples.append((time.monotonic(), delta, available))
        self._thread = Thread(target=self._run, name="node-memory-sampler", daemon=True)
        self._thread.start()

    def stop(self) -> MemorySummary:
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
        if getattr(self, "_sampling_error", None) is not None:
            raise RuntimeError("memory evidence sampling failed") from self._sampling_error
        delta, available = self.current()
        with self._lock:
            self._samples.append((time.monotonic(), delta, available))
            samples = list(self._samples)
        if not samples:
            delta, available = self.current()
            samples = [(time.monotonic(), delta, available)]
        integral = sum((samples[index][0] - samples[index - 1][0]) *
                       (samples[index][1] + samples[index - 1][1]) / 2
                       for index in range(1, len(samples)))
        host_deltas = None
        host_integral = None
        if self.host_mem_total is not None and self.host_baseline_used is not None:
            host_deltas = [
                self.host_mem_total - item[2] - self.host_baseline_used
                for item in samples
            ]
            host_integral = sum(
                (samples[index][0] - samples[index - 1][0])
                * (host_deltas[index] + host_deltas[index - 1]) / 2
                for index in range(1, len(samples))
            )
        duration = samples[-1][0] - samples[0][0]
        return MemorySummary(
            self.total, self.baseline_used,
            integral / (samples[-1][0] - samples[0][0])
            if samples[-1][0] > samples[0][0] else float(samples[-1][1]),
            max(item[1] for item in samples), integral,
            min(item[2] for item in samples), self._storage_used() - self.storage_used_before,
            max(
                0,
                read_vmstat_counter(self.vmstat, "oom_kill") - self.oom_kill_before,
            ),
            self.host_baseline_used,
            (host_integral / duration if host_deltas is not None and duration > 0
             else float(host_deltas[-1]) if host_deltas is not None else None),
            max(host_deltas) if host_deltas is not None else None,
            min(host_deltas) if host_deltas is not None else None,
            host_integral,
            numa_allocation_counter_deltas(
                self.numa_allocation_before,
                read_numa_allocation_counters(self.numa_allocation_root),
            ),
        )

    def samples(self) -> list[dict[str, int | float]]:
        with self._lock:
            return [{"monotonic_s": stamp, "used_bytes": used,
                     "available_bytes": available}
                    for stamp, used, available in self._samples]

    def _run(self) -> None:
        try:
            while not self._stop.wait(self.interval_s):
                delta, available = self.current()
                with self._lock:
                    self._samples.append((time.monotonic(), delta, available))
                if self.sample_hook is not None:
                    self.sample_hook(delta, available)
        except Exception as exc:
            self._sampling_error = exc

    def _storage_used(self) -> int:
        try:
            usage = shutil.disk_usage(self.storage)
        except OSError:
            return 0
        return usage.total - usage.free


class NumaNodeMemorySampler(NodeMemorySampler):
    """Admission sampler scoped to the configured LOCAL NUMA node."""

    def __init__(self, node: int, *, sys_root: Path = Path("/host/sys"),
                 vmstat: Path = Path("/host/proc/vmstat"),
                 storage: Path = Path("/data/cubelet"), interval_s: float = 0.2) -> None:
        if node < 0:
            raise ValueError("NUMA node must be non-negative")
        host_path = sys_root / "devices/system/node" / f"node{node}" / "meminfo"
        fallback = Path("/sys/devices/system/node") / f"node{node}" / "meminfo"
        self.numa_meminfo = host_path if host_path.exists() else fallback
        if not self.numa_meminfo.exists():
            raise FileNotFoundError(f"NUMA meminfo is unavailable for node {node}")
        self.numa_node = node
        self.meminfo = self.numa_meminfo
        self.vmstat = vmstat if vmstat.exists() else Path("/proc/vmstat")
        self.storage = storage
        self.interval_s = interval_s
        self._stop = Event()
        self._lock = Lock()
        self._samples: list[tuple[float, int, int]] = []
        self._thread = None
        total, free = read_numa_meminfo(self.numa_meminfo)
        self.host_mem_total = None
        self.host_baseline_used = None
        self.total = total
        self.baseline_used = total - free
        self.storage_used_before = self._storage_used()
        self.oom_kill_before = read_vmstat_counter(self.vmstat, "oom_kill")
        self.numa_allocation_root = sys_root / "devices/system/node"
        self.numa_allocation_before = read_numa_allocation_counters(
            self.numa_allocation_root
        )

    def current(self) -> tuple[int, int]:
        total, free = read_numa_meminfo(self.numa_meminfo)
        return max(0, total - free - self.baseline_used), free

    def observe(self) -> dict[str, int | str]:
        total, free = read_numa_meminfo(self.numa_meminfo)
        used = max(0, total - free)
        return {
            "metric": "numa_node_memfree",
            "numa_node": self.numa_node,
            "host_mem_total_bytes": total,
            "host_used_bytes": used,
            "host_available_bytes": free,
            "experiment_used_delta_bytes": max(0, used - self.baseline_used),
        }


class CgroupMemorySampler(NodeMemorySampler):
    """Absolute LOCAL charges, including VM overhead and retained page cache.

    Host available memory remains the independent emergency guard. No arm
    baseline is subtracted from the enforced cgroup's admission usage.
    """

    def __init__(self, cgroup: Path, *, capacity_bytes: int,
                 numa_node: int | None = None, physical_limit_bytes: int | None = None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.cgroup = cgroup
        limit = (cgroup / "memory.max").read_text().strip()
        expected_limit = physical_limit_bytes if physical_limit_bytes is not None else capacity_bytes
        if capacity_bytes > expected_limit:
            raise ValueError('logical memory budget exceeds physical cgroup limit')
        if limit != str(expected_limit):
            raise ValueError(f"LOCAL memory.max {limit} does not match {expected_limit}")
        if numa_node is not None:
            nodes = (cgroup / "cpuset.mems.effective").read_text().strip()
            if nodes != str(numa_node):
                raise ValueError(f"LOCAL cpuset {nodes} does not match node {numa_node}")
        self.total = capacity_bytes
        self.baseline_used = 0

    def current(self) -> tuple[int, int]:
        _, available = read_meminfo(self.meminfo)
        return int((self.cgroup / "memory.current").read_text()), available

    def reclaim_file_cache(self, maximum_bytes: int = 8 * 1024**3) -> dict[str, int | str]:
        """Ask the kernel to reclaim charged cache; never discount it on paper.

        Size the request from file minus shmem; memory.reclaim itself does not
        select particular pages. EAGAIN means partial reclamation, not a failed
        run. Effective swap policy is recorded separately, not assumed here.
        """
        import errno
        stats = dict(line.split() for line in (self.cgroup / "memory.stat").read_text().splitlines())
        requested = min(maximum_bytes, max(0, int(stats.get("file", 0)) - int(stats.get("shmem", 0))))
        before, _ = self.current()
        status = "no_file_cache"
        if requested:
            try:
                (self.cgroup / "memory.reclaim").write_text(str(requested))
                status = "requested"
            except OSError as exc:
                if exc.errno != errno.EAGAIN:
                    raise
                status = "partial_EAGAIN"
        after, _ = self.current()
        return {"requested_bytes": requested, "before_bytes": before,
                "after_bytes": after, "observed_net_reclaimed_bytes": max(0, before - after),
                "status": status}

    def observe(self) -> dict[str, int | str]:
        observation = super().observe()
        used, _ = self.current()
        observation.update({
            "metric": "cgroup_v2_memory_current",
            "local_memory_cgroup": str(self.cgroup),
            "local_capacity_bytes": self.total,
            "local_used_bytes": used,
            "local_memory_events": (self.cgroup / "memory.events").read_text().strip()
            if (self.cgroup / "memory.events").exists() else "unavailable",
            "experiment_used_delta_bytes": used,
            "cgroup_memory": cgroup_memory_evidence(self.cgroup),
        })
        return observation


class NumaCgroupMemorySampler(CgroupMemorySampler):
    """Measure LOCAL and live-borrowed pages separately in one VM cgroup."""

    def __init__(self, cgroup: Path, *, local_capacity_bytes: int,
                 total_capacity_bytes: int, local_numa_node: int,
                 local_numa_nodes: tuple[int, ...] = (),
                 shared_numa_node: int | None, **kwargs) -> None:
        NodeMemorySampler.__init__(self, **kwargs)
        self.cgroup = cgroup
        limit = (cgroup / "memory.max").read_text().strip()
        if limit != str(total_capacity_bytes):
            raise ValueError(
                f"combined live memory.max {limit} does not match {total_capacity_bytes}"
            )
        nodes = (cgroup / "cpuset.mems.effective").read_text().strip()
        granted: set[int] = set()
        for part in nodes.split(","):
            start, separator, end = part.partition("-")
            granted.update(range(int(start), int(end) + 1) if separator else (int(start),))
        self.local_numa_nodes = local_numa_nodes or (local_numa_node,)
        required = set(self.local_numa_nodes)
        if shared_numa_node is not None:
            required.add(shared_numa_node)
        if not required.issubset(granted):
            raise ValueError(
                f"VM cgroup cpuset {nodes} does not include LOCAL/shared nodes "
                f"{local_numa_node},{shared_numa_node}"
            )
        self.total = local_capacity_bytes
        self.baseline_used = 0
        self.local_numa_node = local_numa_node
        self.shared_numa_node = shared_numa_node

    def tier_usage(self) -> tuple[int, int, int]:
        from .numa_borrow import read_numa_lru_bytes
        resident, unattributed = read_numa_lru_bytes(self.cgroup)
        local = sum(resident.get(n, 0) for n in self.local_numa_nodes) + unattributed
        shared = resident.get(self.shared_numa_node, 0)
        total = int((self.cgroup / "memory.current").read_text())
        return local, shared, total

    def current(self) -> tuple[int, int]:
        _, available = read_meminfo(self.meminfo)
        local, _, _ = self.tier_usage()
        return local, available

    def observe(self) -> dict[str, int | str]:
        observation = NodeMemorySampler.observe(self)
        local, shared, total = self.tier_usage()
        observation.update({
            "metric": "cgroup_v2_numa_tier_memory",
            "local_memory_cgroup": str(self.cgroup),
            "local_numa_node": self.local_numa_node,
            "local_numa_nodes": list(self.local_numa_nodes),
            "shared_numa_node": self.shared_numa_node,
            "local_capacity_bytes": self.total,
            "local_used_bytes": local,
            "shared_live_used_bytes": shared,
            "combined_live_used_bytes": total,
            "cgroup_memory": cgroup_memory_evidence(self.cgroup),
            "experiment_used_delta_bytes": local,
            "local_memory_events": (self.cgroup / "memory.events").read_text().strip(),
        })
        return observation

    def node_usage(self) -> dict:
        from .numa_borrow import read_numa_lru_bytes
        resident, unattributed = read_numa_lru_bytes(self.cgroup)
        return {"resident_bytes_by_numa": resident, "unattributed_bytes": unattributed}


def sandbox_process_rss_bytes(sandbox_id: str, *,
                              proc_root: Path = Path("/proc"),
                              process_paths: tuple[Path, ...] | None = None) -> int | None:
    """Sum host RSS for Cube processes whose argv contains ``sandbox_id``."""
    total = 0
    matched = False
    try:
        entries = process_paths if process_paths is not None else tuple(proc_root.iterdir())
    except OSError:
        return None
    for entry in entries:
        if not entry.name.isdigit():
            continue
        try:
            command = (entry / "cmdline").read_bytes()
            if sandbox_id.encode() not in command:
                continue
            for line in (entry / "status").read_text(encoding="ascii").splitlines():
                if line.startswith("VmRSS:"):
                    total += int(line.split()[1]) * 1024
                    matched = True
                    break
        except (FileNotFoundError, PermissionError, ProcessLookupError, ValueError):
            continue
    return total if matched else None


def sandbox_process_fault_counters(
    sandbox_id: str, process_paths: tuple[Path, ...],
) -> dict[tuple[str, int], dict[str, int | None]] | None:
    """Read VMM host faults and I/O, retaining PID start time against reuse.

    These are host process counters, not Guest page faults or a direct count
    of deferred snapshot loads. Ordinary VM activity also contributes.
    """
    if not process_paths:
        return None
    result = {}
    for entry in process_paths:
        try:
            if sandbox_id.encode() not in (entry / "cmdline").read_bytes():
                return None
            fields = (entry / "stat").read_text(encoding="ascii").rsplit(")", 1)[1].split()
            counters = {
                "minor_faults": int(fields[7]),
                "major_faults": int(fields[9]),
                "disk_read_bytes": None,
            }
            try:
                io = dict(line.split(":", 1) for line in
                          (entry / "io").read_text(encoding="ascii").splitlines())
                counters["disk_read_bytes"] = int(io["read_bytes"])
            except (OSError, ValueError, KeyError):
                pass
            result[(entry.name, int(fields[19]))] = counters
        except (OSError, ValueError, IndexError):
            return None
    return result


def sandbox_process_counter_deltas(before, after) -> dict[str, int | None]:
    """Missing/restarted processes make a delta unavailable, never zero."""
    result = {}
    for name in ("minor_faults", "major_faults", "disk_read_bytes"):
        delta = None
        if before and after and before.keys() == after.keys():
            pairs = [(before[key][name], after[key][name]) for key in before]
            if all(a is not None and b is not None and b >= a for a, b in pairs):
                delta = sum(b - a for a, b in pairs)
        result[f"host_vm_{name}_delta"] = delta
    return result


class SandboxRSSSampler:
    """Execution-window host RSS sampler for one CubeSandbox microVM."""

    def __init__(self, sandbox_id: str, *, proc_root: Path = Path("/proc"),
                 interval_s: float = 0.05, cgroup: Path | None = None) -> None:
        self.sandbox_id = sandbox_id
        self.cgroup = cgroup
        self.charge_baseline = int((cgroup/'memory.current').read_text()) if cgroup else None
        self.charge_peak = self.charge_baseline
        self.charge_last = self.charge_baseline
        self.charge_samples = 0
        self.charge_error = None
        self.proc_root = proc_root
        self.interval_s = interval_s
        self._stop = Event()
        self._lock = Lock()
        self._samples: list[int] = []
        self._thread: Thread | None = None
        # A Tool is pinned resident for the execution window. Discover its
        # processes once, not with a host-wide /proc scan every 50 ms per tool.
        # The RSS reader still checks argv on each sample (including PID reuse).
        paths = []
        entries = (tuple(proc_root / pid for pid in (cgroup/'cgroup.procs').read_text().split())
                   if cgroup is not None else proc_root.iterdir())
        for entry in entries:
            if entry.name.isdigit():
                try:
                    if sandbox_id.encode() in (entry / "cmdline").read_bytes():
                        paths.append(entry)
                except (FileNotFoundError, PermissionError, ProcessLookupError):
                    continue
        self._process_paths = tuple(paths)
        self._counter_baseline = sandbox_process_fault_counters(
            sandbox_id, self._process_paths,
        )
        self.baseline_bytes = sandbox_process_rss_bytes(
            sandbox_id, proc_root=proc_root, process_paths=self._process_paths,
        )

    def start(self) -> None:
        self._sample()
        self._thread = Thread(
            target=self._run, name=f"sandbox-rss-{self.sandbox_id[:8]}", daemon=True,
        )
        self._thread.start()

    def stop(self) -> dict[str, int | str | None]:
        self._stop.set()
        if self._thread is not None:
            self._thread.join()
        self._sample()
        with self._lock:
            samples = tuple(self._samples)
        peak = max(samples) if samples else self.baseline_bytes
        increment = (
            max(0, peak - self.baseline_bytes)
            if peak is not None and self.baseline_bytes is not None else None
        )
        return {
            "metric": "host_proc_vm_rss",
            "host_cgroup_metric": "host_cgroup_memory_current_increment",
            "host_cgroup_baseline_bytes": self.charge_baseline,
            "host_cgroup_peak_bytes": self.charge_peak,
            "host_cgroup_final_bytes": self.charge_last,
            "host_cgroup_sample_count": self.charge_samples,
            "host_cgroup_error": self.charge_error,
            "host_cgroup_execution_increment_bytes": (
                max(0, self.charge_peak - self.charge_baseline)
                if self.charge_peak is not None and not self.charge_error else None),
            "host_vm_rss_baseline_bytes": self.baseline_bytes,
            "host_vm_rss_peak_bytes": peak,
            "host_vm_rss_execution_increment_bytes": increment,
            "sample_count": len(samples),
            "validity": "valid" if increment is not None else "unavailable",
            **sandbox_process_counter_deltas(
                self._counter_baseline,
                sandbox_process_fault_counters(self.sandbox_id, self._process_paths),
            ),
            "fault_counter_scope": "host_vm_processes_execution_window",
        }

    def _run(self) -> None:
        while not self._stop.wait(self.interval_s):
            self._sample()

    def _sample(self) -> None:
        if self.cgroup is not None:
            try:
                charge = int((self.cgroup/'memory.current').read_text())
                self.charge_last = charge
                self.charge_peak = max(self.charge_peak, charge)
                self.charge_samples += 1
            except (OSError, ValueError) as exc:
                self.charge_error = str(exc)
        value = sandbox_process_rss_bytes(
            self.sandbox_id, proc_root=self.proc_root, process_paths=self._process_paths,
        )
        if value is not None:
            with self._lock:
                self._samples.append(value)
