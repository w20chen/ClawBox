"""Canonical schema-v2 experiment primitives."""

from .baselines import (
    ACTIVE_BASELINES, BASELINES, Baseline, ensure_supported_experiment,
    resolve_baseline,
)
from .results import FailureCategory, ResultEnvelope, RunStatus, failure_category_for
from .spec import (
    AdmissionPolicy, AgentDriver, ArrivalSchedule, EvictionPolicy, ExperimentArm, ExperimentSpec,
    InferenceBackend, PolicySpec, ReclamationPolicy, RestorePolicy, WorkloadCase,
    SessionAssignment, WorkloadSource, expand_matrix, load_experiment,
    load_workload_cases, spec_digest,
)

__all__ = [
    "ACTIVE_BASELINES", "AdmissionPolicy", "AgentDriver", "ArrivalSchedule",
    "BASELINES", "Baseline",
    "EvictionPolicy", "ExperimentArm",
    "ExperimentSpec", "FailureCategory", "InferenceBackend", "PolicySpec",
    "ReclamationPolicy", "RestorePolicy", "ResultEnvelope", "RunStatus",
    "SessionAssignment", "WorkloadCase", "WorkloadSource", "expand_matrix",
    "failure_category_for",
    "ensure_supported_experiment", "load_experiment", "load_workload_cases",
    "resolve_baseline", "spec_digest",
]
