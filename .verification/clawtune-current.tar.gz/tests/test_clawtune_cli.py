from __future__ import annotations

import importlib.util
import json
import runpy
import subprocess
import sys
import types
from pathlib import Path
from typing import Any

import pytest

from tools.check_ebpf import run_check


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "clawtune.py"
SPEC = importlib.util.spec_from_file_location("clawtune_cli", SCRIPT)
assert SPEC is not None and SPEC.loader is not None
clawtune = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(clawtune)


def test_scheduler_declares_python_310_typing_extensions_dependency() -> None:
    pyproject = SCRIPT.parents[1] / "services" / "sidecar" / "pyproject.toml"
    assert '"typing-extensions>=4.12"' in pyproject.read_text(encoding="utf-8")


def test_legacy_scheduler_setup_declares_runtime_metadata(monkeypatch) -> None:
    captured: dict[str, Any] = {}
    fake_setuptools = types.ModuleType("setuptools")
    setattr(fake_setuptools, "setup", lambda **kwargs: captured.update(kwargs))
    setattr(fake_setuptools, "find_packages", lambda **kwargs: [])
    monkeypatch.setitem(sys.modules, "setuptools", fake_setuptools)
    fake_build = types.ModuleType("setuptools.command.build_py")
    fake_build.build_py = type("build_py", (), {})
    monkeypatch.setitem(sys.modules, "setuptools.command.build_py", fake_build)
    fake_sdist = types.ModuleType("setuptools.command.sdist")
    fake_sdist.sdist = type("sdist", (), {})
    monkeypatch.setitem(sys.modules, "setuptools.command.sdist", fake_sdist)

    runpy.run_path(str(SCRIPT.parents[1] / "services" / "sidecar" / "setup.py"))

    assert captured["name"] == "clawtune-sidecar"
    assert "typing-extensions>=4.12" in captured["install_requires"]
    assert "dev" in captured["extras_require"]
    assert "setuptools>=68" in captured["extras_require"]["dev"]
    assert set(captured["cmdclass"]) == {"build_py", "sdist"}
    assert "tool_time" in captured["package_data"]


def test_create_venv_probes_runtime_dependencies(tmp_path, monkeypatch) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    venv_python = venv / "bin" / "python"
    venv_python.touch()
    calls: list[tuple[tuple[str, ...], dict[str, Any]]] = []

    def fake_run(command, **kwargs):
        rendered = tuple(str(item) for item in command)
        calls.append((rendered, kwargs))
        return subprocess.CompletedProcess(rendered, 0, "", "")

    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "python_has_bcc", lambda _python: True)
    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.create_venv(Path("/usr/bin/python3"))

    assert calls[0][0][-2:] == ("-e", "services/sidecar[dev]")
    assert calls[0][1]["env"]["PYTHONNOUSERSITE"] == "1"
    assert "typing_extensions" in calls[1][0][-1]
    assert "pkg_ver = version('clawtune-sidecar')" in calls[1][0][-1]
    assert "assert pkg_ver == '0.1.0'" in calls[1][0][-1]
    assert calls[1][1]["env"]["PYTHONNOUSERSITE"] == "1"


def test_create_venv_rejects_incomplete_runtime(tmp_path, monkeypatch) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    venv_python = venv / "bin" / "python"
    venv_python.touch()
    calls = 0

    def fake_run(command, **_kwargs):
        nonlocal calls
        calls += 1
        return subprocess.CompletedProcess(
            command,
            0 if calls == 1 else 1,
            "",
            "No module named 'typing_extensions'",
        )

    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "python_has_bcc", lambda _python: True)
    monkeypatch.setattr(clawtune, "run", fake_run)

    with pytest.raises(clawtune.SetupError, match="runtime dependencies"):
        clawtune.create_venv(Path("/usr/bin/python3"))


def test_privileged_command_disables_root_user_site(monkeypatch, tmp_path) -> None:
    kernel = tmp_path / "kernel-build"
    kernel.mkdir()
    monkeypatch.setattr(clawtune, "kernel_build", lambda: kernel)
    monkeypatch.setattr(clawtune.shutil, "which", lambda _name: None)

    command = clawtune.privileged_command(["python", "-m", "example"])

    assert "PYTHONNOUSERSITE=1" in command


def test_package_manager_prefers_dnf(monkeypatch) -> None:
    monkeypatch.setattr(
        clawtune.shutil,
        "which",
        lambda name: f"/usr/bin/{name}" if name in {"dnf", "apt-get"} else None,
    )
    assert clawtune.package_manager() == "dnf"


def test_package_manager_uses_apt_when_dnf_is_absent(monkeypatch) -> None:
    monkeypatch.setattr(
        clawtune.shutil,
        "which",
        lambda name: "/usr/bin/apt-get" if name == "apt-get" else None,
    )
    assert clawtune.package_manager() == "apt"


def test_kernel_build_honors_explicit_bcc_source(tmp_path, monkeypatch) -> None:
    configured = tmp_path / "kernel-build"
    configured.mkdir()
    monkeypatch.setenv("BCC_KERNEL_SOURCE", str(configured))

    assert clawtune.kernel_build() == configured.resolve()


def test_bcc_probe_requires_the_real_runtime_api(monkeypatch) -> None:
    commands = []

    def fake_run(command, **_kwargs):
        commands.append(tuple(map(str, command)))
        return subprocess.CompletedProcess(command, 0)

    monkeypatch.setattr(clawtune, "run", fake_run)

    assert clawtune.python_has_bcc(Path("/usr/bin/python3")) is True
    probe = commands[0][-1]
    assert "import_module" in probe
    assert all(name in probe for name in ("BPF", "PerfSWConfig", "PerfType"))


def test_doctor_does_not_report_ready_without_cgroup_v2(
    tmp_path,
    monkeypatch,
    capsys,
) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    venv_python = venv / "bin" / "python"
    venv_python.touch()
    kernel = tmp_path / "kernel-build"
    kernel.mkdir()
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(clawtune, "kernel_build", lambda: kernel)
    monkeypatch.setattr(clawtune, "bcc_pythons", lambda: [venv_python])
    monkeypatch.setattr(clawtune, "python_has_bcc", lambda _python: True)
    monkeypatch.setattr(clawtune, "required_commands", lambda: [])
    monkeypatch.setattr(clawtune, "cgroup_v2_available", lambda: False)
    monkeypatch.setattr(clawtune, "sidecar_health", lambda: {"running": False})
    monkeypatch.setattr(clawtune.shutil, "which", lambda name: f"/usr/bin/{name}")

    assert clawtune.doctor() == 1
    assert '"cgroup_v2"' in capsys.readouterr().out


def test_runtime_config_accepts_user_facing_ebpf_name() -> None:
    from swe_rebench.config import RuntimeConfig

    config = RuntimeConfig.from_dict(
        {"mode": "host-openclaw", "ebpf_required": False}
    )
    assert config.ebpf_required is False


def test_runtime_config_uses_ebpf_name() -> None:
    from swe_rebench.config import RuntimeConfig

    config = RuntimeConfig.from_dict(
        {"mode": "host-openclaw", "ebpf_required": True}
    )
    assert config.ebpf_required is True


def test_runtime_config_can_be_constructed_with_ebpf_requirement() -> None:
    from swe_rebench.config import RuntimeConfig

    constructed = RuntimeConfig(ebpf_required=False)

    assert constructed.ebpf_required is False


def test_ebpf_check_presents_stable_user_facing_readiness(monkeypatch) -> None:
    monkeypatch.setattr(
        "tools.check_ebpf.run_preflight",
        lambda: {
            "ebpf_ready": True,
            "platform": "linux",
            "python": "/repo/.venv/bin/python",
            "bcc_import": {"ok": True, "module": "bpfcc"},
            "kernel_header_roots": ["/lib/modules/current/build"],
            "bpf_runtime": {"cgroup_v2": True},
            "semantic_smoke": {"ok": True},
            "error": None,
        },
    )

    report = run_check()

    assert report["ready"] is True
    assert report["bcc"]["module"] == "bpfcc"
    assert "ebpf_ready" not in report


def test_plugin_install_repairs_stale_clawtune_link(tmp_path, monkeypatch) -> None:
    config = tmp_path / "openclaw.json"
    original = (
        '{"plugins": {"load": {"paths": ['
        '"/home/user/clawtune/packages/clawtune-plugin", "/opt/another-plugin"'
        ']}}}'
    )
    config.write_text(original, encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))

    calls: list[tuple[str, ...]] = []
    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        calls.append(rendered)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin: plugin path not found: "
                    "/home/user/clawtune/packages/clawtune-plugin",
                )
            # On retry the stale path has already been removed.
            current = json.loads(config.read_text(encoding="utf-8"))
            assert current["plugins"]["load"]["paths"] == [
                "/opt/another-plugin"
            ]
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.install_openclaw_plugin(
        "/usr/bin/openclaw",
        Path("/home/user/ClawTune/packages/clawtune-plugin"),
    )

    assert install_attempts == 2
    # After removing the stale path we run config validate so
    # OpenClaw updates its last-known-good backup.
    assert ("/usr/bin/openclaw", "config", "validate") in calls
    assert ("/usr/bin/openclaw", "doctor", "--fix") not in calls
    backups = list(tmp_path.glob("openclaw.json.clawtune-backup-*"))
    assert len(backups) == 1
    assert backups[0].read_text(encoding="utf-8") == original
    repaired = json.loads(config.read_text(encoding="utf-8"))
    assert repaired["plugins"]["load"]["paths"] == ["/opt/another-plugin"]


def test_plugin_install_only_retries_once_after_repair(
    tmp_path, monkeypatch,
) -> None:
    """After remove_stale_clawtune_plugin_paths we validate the
    now-clean config so OpenClaw updates its last-known-good backup,
    then retry the install.  doctor --fix is not needed when the
    stale path was found in plugins.load.paths."""
    config = tmp_path / "openclaw.json"
    original = (
        '{"plugins": {"load": {"paths": ['
        '"/home/user/clawtune/packages/clawtune-plugin", "/opt/another-plugin"'
        ']}}}'
    )
    config.write_text(original, encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))

    calls: list[tuple[str, ...]] = []
    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        calls.append(rendered)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin: plugin path not found: "
                    "/home/user/clawtune/packages/clawtune-plugin",
                )
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.install_openclaw_plugin(
        "/usr/bin/openclaw",
        Path("/home/user/ClawTune/packages/clawtune-plugin"),
    )

    assert install_attempts == 2
    assert ("/usr/bin/openclaw", "config", "validate") in calls
    assert ("/usr/bin/openclaw", "doctor", "--fix") not in calls
    repaired = json.loads(config.read_text(encoding="utf-8"))
    assert repaired["plugins"]["load"]["paths"] == ["/opt/another-plugin"]


def test_plugin_install_removes_stale_path_even_when_it_exists_on_disk(
    tmp_path, monkeypatch,
) -> None:
    """A stale clawtune-plugin directory that still exists on disk
    (old checkout not deleted) must still be removed from
    plugins.load.paths — otherwise openclaw config validate fails,
    doctor --fix auto-restores a last-known-good backup that also
    contains the stale path, and the repair loop is dead."""

    stale_dir = tmp_path / "old-claw" / "packages" / "clawtune-plugin"
    stale_dir.mkdir(parents=True)
    stale_path = str(stale_dir)

    config = tmp_path / "openclaw.json"
    document = {
        "plugins": {
            "load": {"paths": [stale_path, "/opt/another-plugin"]},
        },
    }
    original = json.dumps(document)
    config.write_text(original, encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))

    calls: list[tuple[str, ...]] = []
    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        calls.append(rendered)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin: plugin path not found: "
                    f"{stale_path}",
                )
            # On retry the stale path has already been removed.
            current = json.loads(config.read_text(encoding="utf-8"))
            assert current["plugins"]["load"]["paths"] == [
                "/opt/another-plugin"
            ]
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.install_openclaw_plugin(
        "/usr/bin/openclaw",
        Path("/home/user/ClawTune/packages/clawtune-plugin"),
    )

    assert install_attempts == 2
    assert ("/usr/bin/openclaw", "config", "validate") in calls
    assert ("/usr/bin/openclaw", "doctor", "--fix") not in calls
    repaired = json.loads(config.read_text(encoding="utf-8"))
    assert repaired["plugins"]["load"]["paths"] == ["/opt/another-plugin"]


def test_plugin_install_removes_stale_dict_format_path_entries(
    tmp_path, monkeypatch,
) -> None:
    """OpenClaw may store plugins.load.paths entries as objects
    with a `path` key, not as plain strings.  The repair must
    also recognise and remove those."""
    config = tmp_path / "openclaw.json"
    document = {
        "plugins": {
            "load": {
                "paths": [
                    {"path": "/home/user/clawtune/packages/clawtune-plugin"},
                    "/opt/another-plugin",
                ],
            },
        },
    }
    original = json.dumps(document)
    config.write_text(original, encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))

    calls: list[tuple[str, ...]] = []
    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        calls.append(rendered)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin: plugin path not found: "
                    "/home/user/clawtune/packages/clawtune-plugin",
                )
            # On retry, only the string entry should remain.
            current = json.loads(config.read_text(encoding="utf-8"))
            assert current["plugins"]["load"]["paths"] == [
                "/opt/another-plugin"
            ]
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.install_openclaw_plugin(
        "/usr/bin/openclaw",
        Path("/home/user/ClawTune/packages/clawtune-plugin"),
    )

    assert install_attempts == 2


def test_plugin_install_does_not_repair_an_unrelated_invalid_config(monkeypatch) -> None:
    def fake_run(command, **_kwargs):
        rendered = tuple(str(item) for item in command)
        return subprocess.CompletedProcess(
            rendered,
            1,
            "",
            "plugins.load.paths: plugin path not found: /opt/unrelated/plugin",
        )

    monkeypatch.setattr(clawtune, "run", fake_run)

    try:
        clawtune.install_openclaw_plugin(
            "/usr/bin/openclaw",
            Path("/home/user/ClawTune/packages/clawtune-plugin"),
        )
    except clawtune.SetupError as exc:
        assert "OpenClaw" in str(exc)
    else:
        raise AssertionError("unrelated invalid plugin paths must not be auto-repaired")


def test_plugin_install_removes_windows_path_on_posix_host(
    tmp_path, monkeypatch,
) -> None:
    config = tmp_path / "openclaw.json"
    config.write_text(
        json.dumps(
            {
                "plugins": {
                    "load": {
                        "paths": [
                            "C:\\old-claw\\packages\\clawtune-plugin\\",
                            "/opt/another-plugin",
                        ]
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))
    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin path not found: "
                    "C:\\old-claw\\packages\\clawtune-plugin",
                )
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)
    clawtune.install_openclaw_plugin("openclaw", Path("/repo/clawtune-plugin"))

    repaired = json.loads(config.read_text(encoding="utf-8"))
    assert repaired["plugins"]["load"]["paths"] == ["/opt/another-plugin"]


def test_plugin_install_stops_when_repaired_config_is_invalid(
    tmp_path, monkeypatch,
) -> None:
    config = tmp_path / "openclaw.json"
    config.write_text(
        json.dumps(
            {"plugins": {"load": {"paths": ["/old/clawtune-plugin"]}}}
        ),
        encoding="utf-8",
    )
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))
    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            return subprocess.CompletedProcess(
                rendered,
                1,
                "",
                "plugins.load.paths: plugin path not found: /old/clawtune-plugin",
            )
        if "config" in rendered and "validate" in rendered:
            return subprocess.CompletedProcess(rendered, 1, "", "invalid schema")
        return subprocess.CompletedProcess(rendered, 0, "", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    with pytest.raises(clawtune.SetupError, match="rejected the repaired config"):
        clawtune.install_openclaw_plugin("openclaw", Path("/repo/clawtune-plugin"))
    assert install_attempts == 1


def test_plugin_install_falls_back_to_doctor_when_load_paths_are_empty(
    tmp_path, monkeypatch,
) -> None:
    """When plugins.load.paths is empty but OpenClaw still reports a
    stale clawtune-plugin path, the stale reference lives in OpenClaw's
    internal plugin state rather than in plugins.load.paths.  Setup
    falls back to ``openclaw doctor --fix``, which may restore the
    stale path into plugins.load.paths via a last-known-good backup.
    The code then removes it and retries the install."""
    config = tmp_path / "openclaw.json"
    # Empty load paths — stale reference is in OpenClaw's internal state.
    document: dict = {"plugins": {"load": {"paths": []}}}
    original = json.dumps(document)
    config.write_text(original, encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))

    calls: list[tuple[str, ...]] = []
    install_attempts = 0
    doctor_called = False

    def fake_run(command, **_kwargs):
        nonlocal install_attempts, doctor_called
        rendered = tuple(str(item) for item in command)
        calls.append(rendered)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin: plugin path not found: "
                    "/home/user/clawtune/packages/clawtune-plugin",
                )
            # Retry after doctor --fix should succeed.
            return subprocess.CompletedProcess(rendered, 0, "ok", "")
        if "doctor" in rendered and "--fix" in rendered:
            doctor_called = True
            # Simulate doctor restoring the stale path from a
            # last-known-good backup.
            restored = {
                "plugins": {
                    "load": {
                        "paths": [
                            "/home/user/clawtune/packages/clawtune-plugin",
                            "/opt/another-plugin",
                        ],
                    },
                },
            }
            config.write_text(json.dumps(restored), encoding="utf-8")
            return subprocess.CompletedProcess(rendered, 0, "", "")
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.install_openclaw_plugin(
        "/usr/bin/openclaw",
        Path("/home/user/ClawTune/packages/clawtune-plugin"),
    )

    assert install_attempts == 2
    assert doctor_called is True
    # After repair, config validate is called to update last-known-good.
    assert ("/usr/bin/openclaw", "config", "validate") in calls
    # After doctor and second removal, only the unrelated path remains.
    repaired = json.loads(config.read_text(encoding="utf-8"))
    assert repaired["plugins"]["load"]["paths"] == ["/opt/another-plugin"]
    backups = list(tmp_path.glob("openclaw.json.clawtune-backup-*"))
    assert len(backups) == 1
    assert backups[0].read_text(encoding="utf-8") == original


def test_plugin_install_also_removes_stale_clawtune_sidecar_entry(
    tmp_path, monkeypatch,
) -> None:
    """A stale plugins.entries.clawtune entry (plugin not found
    in registry) makes OpenClaw treat the config as invalid and
    auto-restore from last-known-good.  The repair must remove it so
    that config validate can succeed and update the last-known-good
    backup."""
    config = tmp_path / "openclaw.json"
    document = {
        "plugins": {
            "load": {
                "paths": [
                    "/home/user/clawtune/packages/clawtune-plugin",
                    "/opt/another-plugin",
                ],
            },
            "entries": {
                "clawtune": {
                    "enabled": True,
                    "config": {"endpoint": "http://127.0.0.1:8765"},
                },
            },
        },
    }
    original = json.dumps(document)
    config.write_text(original, encoding="utf-8")
    monkeypatch.setenv("OPENCLAW_CONFIG_PATH", str(config))

    install_attempts = 0

    def fake_run(command, **_kwargs):
        nonlocal install_attempts
        rendered = tuple(str(item) for item in command)
        if "plugins" in rendered and "install" in rendered:
            install_attempts += 1
            if install_attempts == 1:
                return subprocess.CompletedProcess(
                    rendered,
                    1,
                    "",
                    "plugins.load.paths: plugin: plugin path not found: "
                    "/home/user/clawtune/packages/clawtune-plugin",
                )
            # Retry: verify both path and entry were cleaned.
            current = json.loads(config.read_text(encoding="utf-8"))
            assert current["plugins"]["load"]["paths"] == [
                "/opt/another-plugin"
            ]
            assert "clawtune" not in current["plugins"].get(
                "entries", {}
            )
        return subprocess.CompletedProcess(rendered, 0, "ok", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.install_openclaw_plugin(
        "/usr/bin/openclaw",
        Path("/home/user/ClawTune/packages/clawtune-plugin"),
    )

    assert install_attempts == 2
    repaired = json.loads(config.read_text(encoding="utf-8"))
    assert repaired["plugins"]["load"]["paths"] == ["/opt/another-plugin"]
    assert "clawtune" not in repaired["plugins"].get("entries", {})
    backups = list(tmp_path.glob("openclaw.json.clawtune-backup-*"))
    assert len(backups) == 1
    assert backups[0].read_text(encoding="utf-8") == original


def test_sidecar_health_reports_ready_loopback_service(monkeypatch) -> None:
    class Response:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def read(self, _limit):
            return (
                b'{"schema_version":"clawtune.health.v1",'
                b'"service":"clawtune-sidecar","ready":true}'
            )

    monkeypatch.setattr(clawtune, "urlopen", lambda *_args, **_kwargs: Response())

    health = clawtune.sidecar_health()

    assert health["running"] is True
    assert health["status"] == 200


def test_sidecar_health_rejects_an_unrelated_service(monkeypatch) -> None:
    class Response:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def read(self, _limit):
            return b'{"ready":true}'

    monkeypatch.setattr(clawtune, "urlopen", lambda *_args, **_kwargs: Response())

    health = clawtune.sidecar_health()

    assert health["running"] is False
    assert "compatible ClawTune sidecar" in health["error"]


def test_sidecar_health_explains_connection_refusal(monkeypatch) -> None:
    def refuse(*_args, **_kwargs):
        raise ConnectionRefusedError("connection refused")

    monkeypatch.setattr(clawtune, "urlopen", refuse)

    health = clawtune.sidecar_health()

    assert health["running"] is False
    assert "connection refused" in health["error"]


def test_agent_reuses_preexisting_sidecar(tmp_path, monkeypatch) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").touch()
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(
        clawtune.shutil,
        "which",
        lambda name: "/usr/bin/openclaw" if name == "openclaw" else None,
    )
    monkeypatch.setattr(
        clawtune,
        "sidecar_health",
        lambda: {"running": True},
    )
    commands = []
    monkeypatch.setattr(
        clawtune,
        "run",
        lambda command, **_kwargs: commands.append(tuple(map(str, command))),
    )

    clawtune.agent(["--local", "--message", "hello"])

    assert commands == [
        ("/usr/bin/openclaw", "agent", "--local", "--message", "hello")
    ]


def test_agent_starts_waits_and_cleans_up_managed_sidecar(tmp_path, monkeypatch) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").touch()
    monkeypatch.setattr(clawtune, "ROOT", tmp_path)
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(
        clawtune.shutil,
        "which",
        lambda name: f"/usr/bin/{name}",
    )
    health = iter(({"running": False}, {"running": True}))
    monkeypatch.setattr(clawtune, "sidecar_health", lambda: next(health))

    class Child:
        pid = 123

        def poll(self):
            return None

    child = Child()
    popen_commands = []

    def fake_popen(command, **_kwargs):
        popen_commands.append(tuple(map(str, command)))
        return child

    monkeypatch.setattr(clawtune.subprocess, "Popen", fake_popen)
    openclaw_commands = []
    monkeypatch.setattr(
        clawtune,
        "run",
        lambda command, **_kwargs: openclaw_commands.append(tuple(map(str, command))),
    )
    stopped = []
    monkeypatch.setattr(clawtune, "stop_managed_sidecar", stopped.append)

    clawtune.agent(["--local", "--message", "hello"])

    assert popen_commands
    assert "sudo" in popen_commands[0]
    assert openclaw_commands == [
        ("/usr/bin/openclaw", "agent", "--local", "--message", "hello")
    ]
    assert stopped == [child]


def test_managed_root_sidecar_is_stopped_through_sudo(tmp_path, monkeypatch) -> None:
    class Child:
        pid = 321

        def poll(self):
            return None

        def wait(self, timeout):
            assert timeout == 5
            return 0

    monkeypatch.setattr(clawtune, "ROOT", tmp_path)
    monkeypatch.setattr(clawtune.platform, "system", lambda: "Linux")
    monkeypatch.setattr(clawtune.shutil, "which", lambda name: f"/usr/bin/{name}")
    commands = []

    def fake_run(command, **_kwargs):
        rendered = tuple(map(str, command))
        commands.append(rendered)
        return subprocess.CompletedProcess(rendered, 0)

    monkeypatch.setattr(clawtune.subprocess, "run", fake_run)

    clawtune.stop_managed_sidecar(Child())

    assert commands == [
        ("sudo", "-n", "/usr/bin/kill", "-TERM", "--", "-321")
    ]


def test_benchmark_preserves_narrow_environment_without_secret_in_argv(
    tmp_path,
    monkeypatch,
) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").touch()
    config = tmp_path / "swe_rebench" / "config.yaml"
    config.parent.mkdir()
    config.write_text("", encoding="utf-8")
    monkeypatch.setattr(clawtune, "ROOT", tmp_path)
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(clawtune, "kernel_build", lambda: Path("/kernel/build"))
    monkeypatch.setattr(clawtune, "host_arch", lambda: "aarch64")
    monkeypatch.setenv("LLM_API_KEY", "super-secret-value")
    monkeypatch.setenv("AGENT_TEST_BENCH_ROOT", "/data/bench")
    monkeypatch.delenv("SWE_REBENCH_DOCKER_PLATFORM", raising=False)
    monkeypatch.setattr(clawtune, "ensure_runtime_emulation", lambda *a: None)
    commands = []
    monkeypatch.setattr(
        clawtune,
        "run",
        lambda command, **_kwargs: commands.append(tuple(map(str, command))),
    )

    clawtune.benchmark(["--sample", "1"])

    assert len(commands) == 1
    command = commands[-1]
    preserve = next(item for item in command if item.startswith("--preserve-env="))
    names = preserve.split("=", 1)[1].split(",")
    assert "LLM_API_KEY" in names
    assert "AGENT_TEST_BENCH_ROOT" in names
    assert "super-secret-value" not in command
    assert "SWE_REBENCH_DOCKER_PLATFORM=linux/amd64" in command


def test_benchmark_keeps_explicit_platform_override(tmp_path, monkeypatch) -> None:
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin" / "python").touch()
    config = tmp_path / "swe_rebench" / "config.yaml"
    config.parent.mkdir()
    config.write_text("", encoding="utf-8")
    monkeypatch.setattr(clawtune, "ROOT", tmp_path)
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(clawtune, "kernel_build", lambda: Path("/kernel/build"))
    monkeypatch.setattr(clawtune, "host_arch", lambda: "aarch64")
    monkeypatch.setenv("SWE_REBENCH_DOCKER_PLATFORM", "linux/arm64")
    commands = []
    monkeypatch.setattr(
        clawtune,
        "run",
        lambda command, **_kwargs: commands.append(tuple(map(str, command))),
    )

    clawtune.benchmark([])

    command = commands[0]
    preserve = next(item for item in command if item.startswith("--preserve-env="))
    assert "SWE_REBENCH_DOCKER_PLATFORM" in preserve.split("=", 1)[1].split(",")
    assert "SWE_REBENCH_DOCKER_PLATFORM=linux/amd64" not in command
    assert "linux/arm64" not in command


def test_openclaw_config_enables_gated_privileged_sidecar(monkeypatch) -> None:
    monkeypatch.setattr(clawtune.shutil, "which", lambda _name: "/usr/bin/openclaw")
    monkeypatch.setattr(clawtune, "install_openclaw_plugin", lambda *_args: None)
    patches = []
    commands = []

    def fake_run(command, **kwargs):
        rendered = tuple(map(str, command))
        commands.append(rendered)
        if rendered[-3:] == ("config", "patch", "--stdin"):
            patches.append(kwargs["input_text"])
        return subprocess.CompletedProcess(rendered, 0, "", "")

    monkeypatch.setattr(clawtune, "run", fake_run)

    clawtune.configure_openclaw()

    assert len(patches) == 1
    import json

    entry = json.loads(patches[0])["plugins"]["entries"]["clawtune"]
    assert entry["hooks"] == {"allowConversationAccess": True}
    assert "hooks" not in entry["config"]
    assert entry["config"]["autoStartSidecar"] is True
    assert entry["config"]["sidecarCommand"] == ""
    assert str(clawtune.ROOT) not in entry["config"]["sidecarCommand"]
    assert ("/usr/bin/openclaw", "config", "validate") in commands


def test_privileged_runtime_keeps_default_user_docker_config(tmp_path, monkeypatch):
    monkeypatch.delenv("DOCKER_CONFIG", raising=False)
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    command = clawtune.privileged_command(["python", "-m", "example"])
    assert f"DOCKER_CONFIG={(tmp_path / '.docker').resolve()}" in command


def test_key_file_alone_works_with_shipped_benchmark_template(tmp_path, monkeypatch):
    from swe_rebench.config import RunnerConfig
    monkeypatch.delenv("LLM_API_KEY", raising=False)
    monkeypatch.delenv("LLM_API_KEY_FILE", raising=False)
    (tmp_path / "configs").mkdir()
    (tmp_path / "configs" / "llm_api_key.txt").write_text("test-key-only-in-file\n")
    template = SCRIPT.parents[1] / "configs" / "benchmark.example.yaml"
    config = RunnerConfig.from_yaml(template, repo_root=tmp_path)
    assert config.llm.api_key == "test-key-only-in-file"


def test_setup_fails_when_collector_check_fails(tmp_path, monkeypatch):
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(clawtune.os, "geteuid", lambda: 1000, raising=False)
    monkeypatch.setattr(clawtune, "kernel_build", lambda: tmp_path)
    monkeypatch.setattr(clawtune, "bcc_pythons", lambda: [Path("/usr/bin/python3")])
    monkeypatch.setattr(clawtune, "find_bcc_python", lambda **kw: Path("/usr/bin/python3"))
    monkeypatch.setattr(clawtune.shutil, "which", lambda name: "/usr/bin/" + name)
    monkeypatch.setattr(clawtune, "cgroup_v2_available", lambda: True)
    for name in ("create_venv", "copy_defaults", "build_plugin", "check_docker", "setup_qemu_if_needed", "configure_openclaw", "check_mvdan_adapter", "run"):
        monkeypatch.setattr(clawtune, name, lambda *a, **kw: None)
    def fail(*a):
        raise subprocess.CalledProcessError(1, ["collector-check"])
    monkeypatch.setattr(clawtune, "check_ebpf", fail)
    with pytest.raises(subprocess.CalledProcessError):
        clawtune.setup(types.SimpleNamespace(no_system_install=True, skip_qemu=False, skip_ebpf_check=False))


def test_setup_uses_checkout_launcher_instead_of_old_path_install(tmp_path, monkeypatch):
    venv = tmp_path / ".venv"
    launcher = venv / "bin/clawtune-launch"
    launcher.parent.mkdir(parents=True)
    launcher.touch()
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "ROOT", tmp_path)
    monkeypatch.setattr(clawtune.shutil, "which", lambda name: "/old/bin/" + name)
    monkeypatch.setattr(clawtune, "install_openclaw_plugin", lambda *a: None)
    inputs = []
    monkeypatch.setattr(clawtune, "run", lambda *a, **kw: inputs.append(kw.get("input_text")))
    clawtune.configure_openclaw()
    patch = json.loads(next(text for text in inputs if text))
    assert patch["plugins"]["entries"]["clawtune"]["config"]["launcherPath"] == str(launcher.resolve())


def test_benchmark_does_not_override_explicit_yaml_platform(tmp_path, monkeypatch):
    venv = tmp_path / ".venv"
    (venv / "bin").mkdir(parents=True)
    (venv / "bin/python").touch()
    config = tmp_path / "native.yaml"
    config.write_text("docker:\n  platform: linux/arm64\n")
    monkeypatch.setattr(clawtune, "ROOT", tmp_path)
    monkeypatch.setattr(clawtune, "VENV", venv)
    monkeypatch.setattr(clawtune, "require_linux", lambda: None)
    monkeypatch.setattr(clawtune, "host_arch", lambda: "aarch64")
    monkeypatch.delenv("SWE_REBENCH_DOCKER_PLATFORM", raising=False)
    commands = []
    monkeypatch.setattr(clawtune, "run", lambda command, **kw: commands.append(list(map(str, command))))
    clawtune.benchmark(["--config", str(config)])
    assert len(commands) == 1
    assert not any(value.startswith("SWE_REBENCH_DOCKER_PLATFORM=") for value in commands[0])


@pytest.mark.parametrize("status,repair", [("", True), ("enabled\nflags: POC", True), ("enabled\nflags: POCF", False)])
def test_runtime_repairs_missing_or_incomplete_binfmt(monkeypatch, status, repair):
    monkeypatch.setattr(clawtune, "host_arch", lambda: "aarch64")
    monkeypatch.delenv("SWE_REBENCH_DOCKER_PLATFORM", raising=False)
    monkeypatch.setattr(clawtune, "Path", lambda *a: types.SimpleNamespace(exists=lambda: bool(status), read_text=lambda: status))
    calls = []
    monkeypatch.setattr(clawtune, "setup_qemu_if_needed", lambda skip: calls.append(skip))
    clawtune.ensure_runtime_emulation()
    assert calls == ([False] if repair else [])
