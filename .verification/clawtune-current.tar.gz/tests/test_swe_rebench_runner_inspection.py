from __future__ import annotations

import json
import time

import pytest
from pathlib import Path

from swe_rebench.docker import ContainerResult
from swe_rebench.config import RunnerConfig
from swe_rebench.task_source import TaskDef
import swe_rebench.host_openclaw as host_openclaw
import swe_rebench.runner as runner
from swe_rebench.runner import (
    _agent_diagnostics,
    _inspect_tool_resource_artifacts,
    _inspect_trace,
    _required_telemetry_error,
    _resource_summary,
    _ebpf_call_lifecycle_complete,
)


def test_parallel_kb_merge_does_not_ingest_fourth_snapshot_as_telemetry(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from clawtune_sidecar.predictors.edge_kappa import EdgeKappaRuntime

    artifact_dir = tmp_path / "task" / "tool-resource"
    artifact_dir.mkdir(parents=True)
    snapshot = EdgeKappaRuntime.fit([], (100, 500, 2000, 10000)).to_snapshot()
    (artifact_dir / "edge-kappa-kb.json").write_text(json.dumps(snapshot))
    monkeypatch.setattr(runner, "_task_trace_dir", lambda *args: artifact_dir.parent)
    # With no actual trace inputs, the merge must not initialize or publish a KB.
    runner._merge_parallel_task_kbs(None, [SimpleNamespace(instance_id="task")], tmp_path / "shared")
    assert not (tmp_path / "shared").exists()


@pytest.mark.parametrize("fourth_baseline", [False, True])
@pytest.mark.parametrize("missing_input", ["telemetry", "empty_directory", "missing_directory"])
def test_parallel_merge_rejects_missing_feedback_before_publication(tmp_path, fourth_baseline, missing_input):
    from types import SimpleNamespace
    from clawtune_kb.store import write_json
    from clawtune_sidecar.predictors.edge_kappa import EdgeKappaRuntime
    from tool_resource.runtime_kb import ClauseResourceKB, RuntimeToolResourceKB
    from tool_time.lattice_kb import LatticeTimeKB

    shared = tmp_path / "shared"
    snapshots = {
        "clause-resource-kb.json": ClauseResourceKB().to_json_obj(),
        "runtime-tool-resource-kb.json": RuntimeToolResourceKB().to_json_obj(),
        "clause-lattice-time-kb.json": LatticeTimeKB().to_json_obj(),
    }
    edge = EdgeKappaRuntime.fit([], (100, 500, 2000, 10000)).to_snapshot()
    if fourth_baseline:
        snapshots["edge-kappa-kb.json"] = edge
    for name, payload in snapshots.items():
        write_json(shared / name, payload)
    # Also require all task feedback when a legacy baseline was upgraded by
    # another task, not just when the shared baseline already has four KBs.
    if not fourth_baseline:
        write_json(tmp_path / "a" / "tool-resource" / "edge-kappa-kb.json", edge)
    missing = tmp_path / "b" / "tool-resource"
    if missing_input != "missing_directory":
        missing.mkdir(parents=True)
    if missing_input == "telemetry":
        write_json(missing / "call.json", {
            "version": 2, "mode": "clause", "replay_execution": "completed", "cleanup": "ok",
            "status_model": "call_granular_v1", "telemetry_quality": "ok",
            "collection_validity": "valid", "formal_completeness": "complete",
            "integrity": {"status": "ok"}, "calls": [{
                "eligible_for_kb": True, "command": "python job.py", "clauses": [{
                    "bin": "python", "argv": ["python", "job.py"],
                    "ts_start": 30., "ts_end": 31., "latency_ms": 50.,
                    "availability": {"latency": "ok"},
                }],
            }],
        })
    tasks = [SimpleNamespace(instance_id=name) for name in (("b",) if fourth_baseline else ("a", "b"))]
    config = SimpleNamespace(runtime=SimpleNamespace(kb_frozen=False),
                             output=SimpleNamespace(trace_root=tmp_path))
    before = {path.name: path.read_bytes() for path in shared.iterdir()}
    with pytest.raises(host_openclaw.KnowledgeBaseSyncError, match="missing task EdgeKappa snapshot") as error:
        runner._merge_parallel_task_kbs(config, tasks, shared)
    assert str(missing / "edge-kappa-kb.json") in str(error.value)
    assert {path.name: path.read_bytes() for path in shared.iterdir()} == before


@pytest.mark.parametrize("different_parents", [False, True])
def test_parallel_merge_publishes_both_tasks_gradients_and_is_retry_safe(tmp_path, monkeypatch, different_parents):
    from types import SimpleNamespace
    from clawtune_kb.store import write_json
    from clawtune_sidecar.predictors.edge_kappa import EdgeKappaRuntime
    from clawtune_sidecar.predictors.tool_resource import ToolResourcePredictor
    from tool_resource.runtime_kb import ClauseObservation, ClauseResourceKB, RuntimeToolResourceKB
    from tool_time.lattice_kb import LatticeTimeKB

    def observation(i, ms, argv=("python", "job.py")):
        return ClauseObservation(repo="repo", bin="python", argv=argv,
                                 ts_start=i * 10., ts_end=i * 10. + 1, latency_ms=ms)

    training = [observation(0, 50, ("python",))]
    if not different_parents:
        training.append(observation(1, 600))
    baseline = EdgeKappaRuntime.fit(training, (100, 500, 2000, 10000))
    shared = tmp_path / "shared"
    for name, payload in {
        "clause-resource-kb.json": ClauseResourceKB().to_json_obj(),
        "runtime-tool-resource-kb.json": RuntimeToolResourceKB().to_json_obj(),
        "clause-lattice-time-kb.json": LatticeTimeKB().to_json_obj(),
        "edge-kappa-kb.json": baseline.to_snapshot(),
    }.items():
        write_json(shared / name, payload)
    expected = EdgeKappaRuntime.from_snapshot(baseline.to_snapshot())
    tasks = [SimpleNamespace(instance_id=name) for name in ("b", "a")]
    for i, name in enumerate(("a", "b"), 3):
        task = EdgeKappaRuntime.from_snapshot(baseline.to_snapshot())
        if different_parents and name == "a":
            task.predict_load_samples("repo", [{"argv": ["python", "job.py"]}], 10, call_id="a-first")
            task.complete_call("a-first", [observation(1, 600)], commit_time=12)
        argv = ("python", "job.py", "--verbose") if different_parents else ("python", "job.py")
        task.predict_load_samples("repo", [{"argv": list(argv)}], 20, call_id=name)
        task.complete_call(name, [observation(i, 50, argv)], commit_time=60)
        write_json(tmp_path / name / "tool-resource" / "edge-kappa-kb.json", task.to_snapshot())
        (tmp_path / name / "trace.jsonl").write_text("")
        expected.merge_feedback(task)
    monkeypatch.setattr(runner, "_task_trace_dir", lambda config, task: tmp_path / task.instance_id)
    original = ToolResourcePredictor.from_traces
    loaded = []
    def load(**kwargs):
        # Assert feedback is already present before the raw-history loader runs.
        loaded.append(json.loads((kwargs["artifact_dir"] / "edge-kappa-kb.json").read_text()))
        assert len(kwargs["openclaw_trace_paths"]) == 2
        kwargs["openclaw_trace_paths"] = ()
        return original(**kwargs)
    monkeypatch.setattr(ToolResourcePredictor, "from_traces", load)
    config = SimpleNamespace(runtime=SimpleNamespace(kb_frozen=False))
    for _ in range(2):
        runner._merge_parallel_task_kbs(config, tasks, shared)
        saved = json.loads((shared / "edge-kappa-kb.json").read_text())
        assert saved["generation"] == expected.kb.generation == 4
        assert saved["edges"] == expected.kb.to_snapshot()["edges"]
    assert all(snapshot["generation"] == 4 for snapshot in loaded)


def _ebpf_call_provenance(root_pid: int = 1234) -> dict:
    return {
        "command_tree": {
            "status": "ok",
            "reason": None,
            "entry_pid": root_pid,
            "root_pids": [root_pid],
            "identity_anchor": {
                "kind": "launcher_started",
                "host_pid": root_pid,
            },
        },
        "event_isolation": {
            "mode": "trusted_execution_root",
            "trusted_root_pid": root_pid,
        },
    }


def _ebpf_pid_namespace_remap_provenance(
    root_pid: int = 612345,
    claimed_root_pid: int = 1234,
) -> dict:
    provenance = _ebpf_call_provenance(root_pid)
    provenance["event_isolation"] = {
        "mode": "trusted_execution_root_pid_namespace_remap",
        "trusted_root_pid": root_pid,
        "claimed_trusted_root_pid": claimed_root_pid,
        "remap_evidence": "exact_registered_root_shell",
        "selected_pid_count": 2,
        "raw_window_event_count": 12,
        "selected_event_count": 8,
    }
    return provenance


def _ebpf_artifact(
    call_id: str,
    *,
    quality: str = "ok",
    eligible_for_kb: bool = True,
    invalid_reasons: list[dict] | None = None,
    clauses: list[dict] | None = None,
) -> dict:
    return {
        "schema": "clause_telemetry_v2",
        "version": 2,
        "mode": "clause",
        "status_model": "call_granular_v1",
        "telemetry_quality": quality,
        "collection_validity": "valid" if quality == "ok" else "invalid",
        "formal_completeness": "complete" if quality == "ok" else "partial",
        "integrity": {"status": "ok" if quality == "ok" else "failed"},
        "cleanup": "ok",
        "replay_execution": "completed",
        "container_id": "container-1",
        "cgroup_id": 42,
        "ring_loss_total": 0,
        "telemetry_loss_total": {"total": 0},
        "collector": {
            "health": "healthy",
            "state_before_close": "active",
            "state": "closed",
            "disabled_reason": None,
            "kprobe_total_hits": 10,
        },
        "calls": [
            {
                "tool_call_id": call_id,
                "tool_trace_ref": call_id,
                "command": "printf hi",
                "telemetry_quality": quality,
                "eligible_for_kb": eligible_for_kb,
                "invalid_reasons": invalid_reasons or [],
                "provenance": _ebpf_call_provenance(),
                "clauses": clauses or [],
                "no_runtime_exec": [],
            }
        ],
    }


def test_ebpf_lifecycle_accepts_strict_pid_namespace_remap() -> None:
    call = {
        "tool_call_id": "call-remapped",
        "tool_trace_ref": "call-remapped",
        "provenance": _ebpf_pid_namespace_remap_provenance(),
    }

    assert _ebpf_call_lifecycle_complete(call) is True

    invalid_mutations = [
        ("claimed_trusted_root_pid", None),
        ("claimed_trusted_root_pid", 612345),
        ("claimed_trusted_root_pid", True),
        ("remap_evidence", "argv_heuristic"),
        ("selected_pid_count", 0),
        ("raw_window_event_count", 0),
        ("selected_event_count", 0),
        ("selected_event_count", 13),
    ]
    for field, value in invalid_mutations:
        invalid_call = json.loads(json.dumps(call))
        invalid_call["provenance"]["event_isolation"][field] = value
        assert _ebpf_call_lifecycle_complete(invalid_call) is False


def _ebpf_clause(bin_: str = "printf", exit_code: int = 0) -> dict:
    return {
        "bin": bin_,
        "status": {
            "state": "exited",
            "exit_code": exit_code,
            "signal": None,
            "succeeded": exit_code == 0,
            "reason": None,
            "source": "root_exec_chain_terminal",
        },
    }


def _ebpf_span_end(call_id: str, *, status: str = "invalid") -> dict:
    return {
        "record_type": "span_end",
        "span_id": call_id,
        "kind": "tool",
        "name": "exec",
        "status": {"code": "ok"},
        "output": {"exit_code": 0},
        "execution": {
            "mode": "launcher",
            "execution_id": call_id,
            "tool_resource": {
                "status": status,
                "started": True,
                "execution_id": call_id,
                "tool_call_id": call_id,
                "artifact_path": f"/tmp/tool-resource/{call_id}.json",
                "artifact_summary": {
                    "schema": "clause_telemetry_v2",
                    "call_count": 1,
                    "collector": {"health": "healthy"},
                },
                "call_telemetry": {
                    "tool_call_id": call_id,
                    "telemetry_quality": status,
                },
                "kb_observations_added": 0,
            },
        },
        "resources": {
            "scope": "cgroup",
            "monitor_source": "cgroup-v2",
            "attribution_status": "attributed",
            "sampling_point_count": 1,
            "cpu_time_s": 0.1,
            "rss_peak_bytes": 1024,
            "resource_timeline": [{"available": True}],
        },
    }


def _launcher_cgroup_span_end(
    execution_id: str | None,
    cgroup_path: str | None,
    *,
    scope: str = "cgroup",
    attribution_source: str = "exclusive-execution-cgroup",
) -> dict:
    return {
        "record_type": "span_end",
        "kind": "tool",
        "name": "exec",
        "status": {"code": "ok"},
        "output": {"exit_code": 0},
        "execution": {
            "mode": "launcher",
            "execution_id": execution_id,
            "cgroup_path": cgroup_path,
        },
        "resources": {
            "scope": scope,
            "attribution_source": attribution_source,
            "attribution_status": "attributed",
            "sampling_point_count": 1,
            "cpu_time_s": 0.1,
            "rss_peak_bytes": 1024,
            "resource_timeline": [{"available": True}],
        },
    }


def _ebpf_prediction_start() -> dict:
    return {
        "record_type": "span_start",
        "kind": "tool",
        "name": "exec",
        "prediction": {
            "tool_resource": {
                "prediction": {
                    "bucket_id": 0,
                    "probability_by_bucket": [1.0, 0.0],
                    "scope": "repo",
                    "key_kind": "exact_clause",
                    "evidence_count": 1,
                    "fallback_path": ["repo:exact_clause"],
                },
                "continuous_predictions": {
                    target: {
                        "target": target,
                        "conditional_p90": value,
                        "scope": "repo",
                        "key_kind": "exact_command",
                        "evidence_count": 1,
                        "fallback_path": ["repo:exact_command"],
                        "note": None,
                    }
                    for target, value in (
                        ("latency_ms", 10.0),
                        ("peak_cpu_cores", 1.0),
                        ("peak_memory_mb", 32.0),
                    )
                },
            }
        },
    }


def test_empty_llm_response_is_reported_as_agent_failure_before_telemetry(tmp_path):
    trace = tmp_path / "trace.jsonl"
    records = [
        {"record_type": "trace_metadata", "task": "task-1"},
        {
            "record_type": "span_end",
            "kind": "llm",
            "name": "model",
            "status": {"code": "ok"},
            "output": {"content": {"message": {"role": "assistant", "content": ""}}},
        },
    ]
    trace.write_text(
        "\n".join(json.dumps(record) for record in records) + "\n",
        encoding="utf-8",
    )

    inspected = _inspect_trace(trace, "task-1")
    diagnostics = _agent_diagnostics(
        [inspected],
        {
            "agent-stderr.txt": {
                "preview": "empty response retries exhausted: provider=test"
            },
            "model.patch": {"bytes": 0, "has_diff": False},
        },
        {"agent_exit_code": 0, "has_patch": False},
    )

    assert inspected["llm_span_ends"] == 1
    assert inspected["empty_llm_span_ends"] == 1
    assert diagnostics["failure_kind"] == "empty_llm_response"
    assert "never entered the tool-execution phase" in diagnostics["failure"]


def test_trace_inspection_counts_failed_and_unattributed_launcher_spans(tmp_path):
    trace = tmp_path / "trace.jsonl"
    records = [
        {"record_type": "trace_metadata", "task": "task-1"},
        {
            "record_type": "span_end",
            "kind": "tool",
            "name": "exec",
            "status": {"code": "error"},
            "output": {"exit_code": 1},
            "execution": {"mode": "launcher", "tool_resource": None},
            "resources": {
                "scope": "cgroup",
                "attribution_status": "unattributed",
            },
        },
    ]
    trace.write_text("\n".join(json.dumps(record) for record in records) + "\n", encoding="utf-8")

    inspected = _inspect_trace(trace, "task-1")
    summary = _resource_summary([inspected])

    assert inspected["failed_tool_span_ends"] == 1
    assert inspected["unattributed_launcher_tool_span_ends"] == 1
    assert inspected["launcher_tool_resource_span_ends"] == 0
    assert "trace contains failed tool spans" in inspected["warnings"]
    assert "launcher tool spans have no eBPF tool-resource telemetry" in inspected["warnings"]
    assert summary["cgroup_coverage_ratio"] == 1.0
    assert summary["launcher_attribution_ratio"] == 0.0
    assert summary["launcher_tool_resource_ratio"] == 0.0


def test_trace_inspection_accepts_owned_ebpf_without_legacy_timeline(tmp_path):
    trace = tmp_path / "trace.jsonl"
    record = _launcher_cgroup_span_end("exec-1", "/sys/fs/cgroup/task/clawtune-executions/exec-1")
    record["resources"] = {
        "scope": "process_tree", "attribution_status": "pid",
        "attribution_source": "exclusive-execution-cgroup",
        "resource_observation": {
            "backend": "ebpf", "attribution": "exclusive_process_tree",
            "metrics": {"cpu_time": {"available": True, "eligible": True}},
        },
    }
    trace.write_text(json.dumps(record) + "\n", encoding="utf-8")
    report = _inspect_trace(trace, "")
    assert report["launcher_cgroup_tool_span_ends"] == 1
    assert report["launcher_resource_sampled_tool_span_ends"] == 1
    assert report["launcher_attributed_tool_span_ends"] == 1
    record["resources"]["resource_observation"]["attribution"] = "shared_scope"
    trace.write_text(json.dumps(record) + "\n", encoding="utf-8")
    report = _inspect_trace(trace, "")
    assert report["launcher_cgroup_tool_span_ends"] == 0
    assert report["launcher_resource_sampled_tool_span_ends"] == 0


def test_trace_inspection_records_exclusive_and_shared_launcher_cgroups(tmp_path):
    trace = tmp_path / "trace.jsonl"
    container_scope = (
        "/sys/fs/cgroup/system.slice/docker-"
        + ("a" * 64)
        + ".scope"
    )
    execution_cgroup = f"{container_scope}/clawtune-executions/exec-1"
    records = [
        _launcher_cgroup_span_end("exec-1", execution_cgroup),
        _launcher_cgroup_span_end(
            "exec-2",
            container_scope,
            attribution_source="trusted-execution-root-pid",
        ),
    ]
    trace.write_text(
        "\n".join(json.dumps(record) for record in records) + "\n",
        encoding="utf-8",
    )

    inspected = _inspect_trace(trace, "")
    summary = _resource_summary([inspected])

    assert inspected["launcher_execution_ids"] == ["exec-1", "exec-2"]
    assert inspected["launcher_cgroup_paths"] == [
        execution_cgroup,
        container_scope,
    ]
    assert inspected["launcher_execution_cgroup_refs"] == [
        {"execution_id": "exec-1", "cgroup_path": execution_cgroup},
        {"execution_id": "exec-2", "cgroup_path": container_scope},
    ]
    assert inspected["launcher_exclusive_cgroup_tool_span_ends"] == 1
    assert inspected["launcher_docker_container_scope_tool_span_ends"] == 1
    assert (
        "some launcher tool spans lack exclusive execution cgroup attribution"
        in inspected["warnings"]
    )
    assert "launcher tool spans reuse a Docker container cgroup scope" in inspected[
        "warnings"
    ]
    assert summary["launcher_exclusive_cgroup_tool_span_ends"] == 1
    assert summary["launcher_docker_container_scope_tool_span_ends"] == 1
    assert summary["launcher_unique_execution_id_count"] == 2
    assert summary["launcher_unique_cgroup_path_count"] == 2
    assert summary["launcher_execution_cgroup_refs"] == [
        {"execution_id": "exec-1", "cgroup_path": execution_cgroup},
        {"execution_id": "exec-2", "cgroup_path": container_scope},
    ]


def test_launcher_permission_failure_and_invalid_coverage_are_root_diagnostics(tmp_path):
    trace = tmp_path / "trace.jsonl"
    record = {
        "record_type": "span_end",
        "kind": "tool",
        "name": "exec",
        "status": {"code": "error"},
        "output": {
            "exit_code": 126,
            "result": {"details": {"failureKind": "shell-not-executable"}},
        },
        "execution": {"mode": "launcher", "execution_id": "call-1"},
        "resources": {
            "scope": "cgroup",
            "attribution_status": "partially_attributed",
            "coverage_ratio": 4.5,
        },
    }
    trace.write_text(json.dumps(record) + "\n", encoding="utf-8")

    inspected = _inspect_trace(trace, "")
    diagnostics = _agent_diagnostics(
        [inspected],
        {"model.patch": {"bytes": 0, "has_diff": False}},
        {"agent_exit_code": 0, "has_patch": False},
    )

    assert inspected["launcher_not_executable_span_ends"] == 1
    assert inspected["invalid_coverage_ratio_span_ends"] == 1
    assert diagnostics["failure_kind"] == "launcher_not_executable"


def test_launcher_bare_run_failure_is_reported_before_no_patch(tmp_path):
    trace = tmp_path / "trace.jsonl"
    record = {
        "record_type": "span_end",
        "kind": "tool",
        "name": "exec",
        "status": {"code": "error"},
        "output": {
            "exit_code": 127,
            "stderr": "/bin/bash: run: No such file or directory",
            "result": {"details": {"failureKind": "shell-command-not-found"}},
        },
        "execution": {"mode": "launcher", "execution_id": "call-1"},
        "resources": {
            "scope": "cgroup",
            "attribution_status": "attributed",
        },
    }
    trace.write_text(json.dumps(record) + "\n", encoding="utf-8")

    inspected = _inspect_trace(trace, "")
    diagnostics = _agent_diagnostics(
        [inspected],
        {"model.patch": {"bytes": 0, "has_diff": False}},
        {"agent_exit_code": 0, "has_patch": False},
    )
    summary = _resource_summary([inspected])

    assert inspected["launcher_command_not_found_span_ends"] == 1
    assert summary["launcher_command_not_found_span_ends"] == 1
    assert "launcher command was not invoked correctly inside the sandbox" in inspected["warnings"]
    assert diagnostics["failure_kind"] == "launcher_invocation_command_not_found"
    assert diagnostics["launcher_command_not_found_span_ends"] == 1


def test_trace_inspection_reports_ebpf_failures_and_prediction_fallbacks(tmp_path):
    trace = tmp_path / "trace.jsonl"
    records = [
        {"record_type": "trace_metadata", "task": "task-1"},
        {
            "record_type": "span_start",
            "kind": "tool",
            "name": "exec",
                "prediction": {
                    "tool_resource": {
                        "prediction": None,
                        "continuous_predictions": {
                            "latency_ms": {
                                "target": "latency_ms",
                                "conditional_p90": 100.0,
                                "scope": "repo",
                                "key_kind": "exact_command",
                                "evidence_count": 1,
                                "fallback_path": ["repo:exact_command"],
                                "note": None,
                            },
                            "peak_cpu_cores": {
                                "target": "peak_cpu_cores",
                                "conditional_p90": None,
                                "scope": None,
                                "key_kind": None,
                                "evidence_count": 0,
                                "fallback_path": [],
                                "note": "no evidence",
                            },
                        },
                    }
                },
        },
        {
            "record_type": "span_end",
            "kind": "tool",
            "name": "exec",
            "status": {"code": "ok"},
            "output": {"exit_code": 0},
            "execution": {
                "mode": "launcher",
                "tool_resource": {
                    "status": "unavailable",
                    "unavailable_reason": "call_telemetry_unavailable",
                    "artifact_summary": {
                        "collector": {
                            "disabled_reason": "collector attach failed: BPF module compile failed"
                        }
                    },
                },
            },
            "resources": {
                "scope": "cgroup",
                "attribution_status": "attributed",
            },
        },
    ]
    trace.write_text("\n".join(json.dumps(record) for record in records) + "\n", encoding="utf-8")

    inspected = _inspect_trace(trace, "task-1")
    summary = _resource_summary([inspected])

    assert inspected["launcher_tool_resource_unavailable_span_ends"] == 1
    assert inspected["launcher_tool_resource_unavailable_reasons"] == {
        "call_telemetry_unavailable": 1
    }
    assert inspected["launcher_tool_resource_disabled_reasons"] == {
        "collector attach failed: BPF module compile failed": 1
    }
    assert inspected["continuous_prediction_available_span_starts"] == 1
    assert inspected["tool_resource_prediction_available_span_starts"] == 1
    assert inspected["clause_bucket_prediction_available_span_starts"] == 0
    assert inspected[
        "continuous_latency_ms_prediction_available_span_starts"
    ] == 1
    assert inspected[
        "continuous_peak_cpu_cores_prediction_available_span_starts"
    ] == 0
    assert inspected[
        "continuous_peak_memory_mb_prediction_available_span_starts"
    ] == 0
    assert "eBPF tool-resource telemetry is unavailable for some launcher tool spans" in inspected["warnings"]
    assert summary["launcher_tool_resource_unavailable_span_ends"] == 1
    assert summary["tool_resource_prediction_available_ratio"] == 1.0


def test_trace_inspection_accepts_honest_compound_clause_bucket(tmp_path):
    trace = tmp_path / "trace.jsonl"
    bucket = {
        "bucket_id": 1,
        "probability_by_bucket": [0.0, 1.0, 0.0],
        "scope": "public",
        "key_kind": "global",
        "evidence_count": 8,
        "fallback_path": ["public:bin", "public:global"],
    }
    record = {
        "record_type": "span_start",
        "kind": "tool",
        "name": "exec",
        "prediction": {
            "tool_resource": {
                "prediction": None,
                "unavailable_reason": "compound_command_uncomposed",
                "clause_predictions": [
                    {
                        "clause_index": 1,
                        "bin": "python3",
                        "argv": ["python3", "-m", "pytest"],
                        "prediction": bucket,
                        "unavailable_reason": None,
                    }
                ],
                "continuous_predictions": {},
            }
        },
    }
    trace.write_text(json.dumps(record) + "\n", encoding="utf-8")

    inspected = _inspect_trace(trace, "")

    assert inspected["tool_resource_prediction_available_span_starts"] == 1
    assert inspected["clause_bucket_prediction_available_span_starts"] == 1


def test_required_telemetry_audits_launcher_samples_and_async_artifacts(tmp_path):
    trace_dir = tmp_path / "trace"
    artifact_dir = trace_dir / "tool-resource"
    artifact_dir.mkdir(parents=True)
    # Fallback execution IDs are exec-<uuid>, not necessarily call_<id>.
    # The audit must discover artifacts by schema rather than filename prefix.
    (artifact_dir / "exec-async.json").write_text(
        json.dumps(_ebpf_artifact("call_async", clauses=[_ebpf_clause()])),
        encoding="utf-8",
    )
    (artifact_dir / "clause-resource-kb.json").write_text(
        json.dumps({"version": 1, "observations": []}),
        encoding="utf-8",
    )
    (artifact_dir / "runtime-tool-resource-kb.json").write_text(
        json.dumps({"schema": "runtime_tool_resource_kb_v1"}),
        encoding="utf-8",
    )
    artifact_report = _inspect_tool_resource_artifacts(trace_dir)
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n  mode: host-openclaw\n  ebpf_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    config.runtime.kb_frozen = False  # This fixture exercises legacy online traces.
    result = {
        "resource_summary": {
            "tool_span_ends": 2,
            "resource_sampled_tool_span_ends": 1,
            "launcher_resource_sampled_tool_span_ends": 1,
            "cgroup_sampled_tool_span_ends": 2,
            "launcher_tool_span_ends": 1,
            "launcher_cgroup_tool_span_ends": 1,
            "launcher_ebpf_expected_span_ends": 1,
            "launcher_exit_status_span_ends": 1,
            "launcher_tool_resource_span_ends": 1,
            "launcher_ebpf_lifecycle_span_ends": 1,
            "launcher_ebpf_artifact_envelope_span_ends": 1,
            "launcher_ebpf_artifact_refs": [
                {
                    "execution_id": "exec-async",
                    "tool_call_id": "call_async",
                }
            ],
            "launcher_tool_resource_eligible_span_ends": 1,
            "tool_resource_prediction_span_starts": 2,
            "tool_resource_prediction_available_span_starts": 1,
            "clause_bucket_prediction_available_span_starts": 1,
            "continuous_latency_ms_prediction_available_span_starts": 1,
            "continuous_peak_cpu_cores_prediction_available_span_starts": 1,
            "continuous_peak_memory_mb_prediction_available_span_starts": 1,
        },
        "tool_resource_artifacts": artifact_report,
    }

    assert artifact_report["json_file_count"] == 1
    assert artifact_report["artifact_count"] == 1
    assert artifact_report["artifact_envelope_count"] == 1
    assert artifact_report["artifact_identity_count"] == 1
    assert artifact_report["artifact_refs"] == [
        {"execution_id": "exec-async", "tool_call_id": "call_async"}
    ]
    assert artifact_report["collector_healthy_artifact_count"] == 1
    assert artifact_report["healthy_artifact_count"] == 1
    assert artifact_report["kb_eligible_call_count"] == 1
    assert artifact_report["clauses_with_status"] == 1
    assert _required_telemetry_error(config, result) is None

    result["resource_summary"]["launcher_ebpf_artifact_refs"] = [
        {"execution_id": "exec-async", "tool_call_id": "wrong-call"}
    ]
    assert "references are inconsistent" in (
        _required_telemetry_error(config, result) or ""
    )
    result["resource_summary"]["launcher_ebpf_artifact_refs"] = [
        {"execution_id": "exec-async", "tool_call_id": "call_async"}
    ]

    result["resource_summary"]["launcher_ebpf_expected_span_ends"] = 2
    result["resource_summary"]["launcher_exit_status_span_ends"] = 2
    result["resource_summary"]["launcher_tool_resource_span_ends"] = 2
    result["resource_summary"]["launcher_ebpf_lifecycle_span_ends"] = 2
    result["resource_summary"]["launcher_ebpf_artifact_envelope_span_ends"] = 2
    assert "1/2 executed launcher commands" in (
        _required_telemetry_error(config, result) or ""
    )
    result["resource_summary"]["launcher_ebpf_expected_span_ends"] = 1
    result["resource_summary"]["launcher_exit_status_span_ends"] = 1
    result["resource_summary"]["launcher_tool_resource_span_ends"] = 1
    result["resource_summary"]["launcher_ebpf_lifecycle_span_ends"] = 1
    result["resource_summary"]["launcher_ebpf_artifact_envelope_span_ends"] = 1
    result["resource_summary"]["launcher_resource_sampled_tool_span_ends"] = 0
    assert "sampled 0/1 launcher tool spans" in (
        _required_telemetry_error(config, result) or ""
    )


def test_trace_prediction_availability_requires_usable_contract_values(tmp_path):
    trace = tmp_path / "trace.jsonl"
    prediction = _ebpf_prediction_start()
    payload = prediction["prediction"]["tool_resource"]
    payload["prediction"] = {}
    payload["continuous_predictions"] = {
        "latency_ms": {
            "target": "latency_ms",
            "conditional_p90": "10",
            "scope": "repo",
            "key_kind": "exact_command",
            "evidence_count": 1,
            "fallback_path": [],
            "note": None,
        },
        "peak_cpu_cores": {
            "target": "peak_cpu_cores",
            "conditional_p90": float("inf"),
            "scope": "repo",
            "key_kind": "exact_command",
            "evidence_count": 1,
            "fallback_path": [],
            "note": None,
        },
    }
    trace.write_text(
        "\n".join(
            json.dumps(record)
            for record in [
                {"record_type": "trace_metadata", "task": "task-1"},
                prediction,
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    inspected = _inspect_trace(trace, "task-1")

    assert inspected["tool_resource_prediction_span_starts"] == 1
    assert inspected["tool_resource_prediction_available_span_starts"] == 0
    assert inspected["clause_bucket_prediction_available_span_starts"] == 0
    assert inspected["continuous_prediction_available_span_starts"] == 0


def test_required_ebpf_accepts_explicit_semantic_rejections_but_not_for_kb(
    tmp_path,
):
    trace_dir = tmp_path / "trace"
    artifact_dir = trace_dir / "tool-resource"
    artifact_dir.mkdir(parents=True)
    parse_id = "call_parse_failed"
    unmatched_id = "call_unmatched"
    parse_artifact = _ebpf_artifact(
        parse_id,
        quality="invalid",
        eligible_for_kb=False,
        invalid_reasons=[
            {"kind": "parse_failed", "detail": "shell syntax error"}
        ],
    )
    unmatched_artifact = _ebpf_artifact(
        unmatched_id,
        quality="invalid",
        eligible_for_kb=False,
        invalid_reasons=[
            {
                "kind": "unmatched_static_clause",
                "detail": "pip executable was not found",
            }
        ],
        clauses=[_ebpf_clause("tail")],
    )
    (artifact_dir / f"{parse_id}.json").write_text(
        json.dumps(parse_artifact), encoding="utf-8"
    )
    (artifact_dir / f"{unmatched_id}.json").write_text(
        json.dumps(unmatched_artifact), encoding="utf-8"
    )
    trace = trace_dir / "trace.jsonl"
    records = [
        {"record_type": "trace_metadata", "task": "task-1"},
        _ebpf_prediction_start(),
        _ebpf_span_end(parse_id),
        _ebpf_prediction_start(),
        _ebpf_span_end(unmatched_id),
    ]
    trace.write_text(
        "\n".join(json.dumps(record) for record in records) + "\n",
        encoding="utf-8",
    )
    inspected = _inspect_trace(trace, "task-1")
    artifact_report = _inspect_tool_resource_artifacts(trace_dir)
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n  mode: host-openclaw\n  ebpf_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    result = {
        "resource_summary": _resource_summary([inspected]),
        "tool_resource_artifacts": artifact_report,
    }

    assert inspected["launcher_ebpf_lifecycle_span_ends"] == 2
    assert inspected["launcher_ebpf_artifact_envelope_span_ends"] == 2
    assert artifact_report["collector_healthy_artifact_count"] == 2
    assert artifact_report["healthy_artifact_count"] == 2
    assert artifact_report["ok_call_count"] == 0
    assert artifact_report["kb_eligible_call_count"] == 0
    assert artifact_report["explicit_semantic_rejection_call_count"] == 2
    assert artifact_report["semantic_rejection_reason_counts"] == {
        "parse_failed": 1,
        "unmatched_static_clause": 1,
    }
    assert len(artifact_report["semantic_rejections"]) == 2
    assert not any(
        "collector/infrastructure is not healthy" in warning
        for warning in artifact_report["warnings"]
    )
    assert _required_telemetry_error(config, result) is None

    parse_artifact["calls"][0]["invalid_reasons"] = [
        {
            "kind": "analysis_failure",
            "detail": "MvdanClientError: adapter is unavailable",
        }
    ]
    (artifact_dir / f"{parse_id}.json").write_text(
        json.dumps(parse_artifact), encoding="utf-8"
    )
    analysis_failure_report = _inspect_tool_resource_artifacts(trace_dir)
    result["tool_resource_artifacts"] = analysis_failure_report
    assert analysis_failure_report["collector_healthy_artifact_count"] == 2
    assert analysis_failure_report["analysis_failure_call_count"] == 1
    assert analysis_failure_report["analysis_failure_reason_counts"] == {
        "analysis_failure": 1,
    }

    assert analysis_failure_report["explicit_semantic_rejection_call_count"] == 1
    assert analysis_failure_report["semantic_rejection_reason_counts"] == {
        "unmatched_static_clause": 1,
    }
    assert len(analysis_failure_report["analysis_failures"]) == 1
    assert "analysis is incomplete" in (
        _required_telemetry_error(config, result) or ""
    )

    parse_artifact["calls"][0]["invalid_reasons"] = []
    (artifact_dir / f"{parse_id}.json").write_text(
        json.dumps(parse_artifact), encoding="utf-8"
    )
    missing_reason_report = _inspect_tool_resource_artifacts(trace_dir)
    result["tool_resource_artifacts"] = missing_reason_report
    assert "lack explicit reasons" in (
        _required_telemetry_error(config, result) or ""
    )

    parse_artifact["calls"][0]["invalid_reasons"] = [
        {"kind": "parse_failed", "detail": "shell syntax error"}
    ]
    parse_artifact["calls"][0]["eligible_for_kb"] = True
    (artifact_dir / f"{parse_id}.json").write_text(
        json.dumps(parse_artifact), encoding="utf-8"
    )
    incorrectly_eligible_report = _inspect_tool_resource_artifacts(trace_dir)
    result["tool_resource_artifacts"] = incorrectly_eligible_report
    assert "KB-withheld contract" in (
        _required_telemetry_error(config, result) or ""
    )

    parse_artifact["calls"][0]["telemetry_quality"] = "mystery"
    parse_artifact["calls"][0]["eligible_for_kb"] = False
    (artifact_dir / f"{parse_id}.json").write_text(
        json.dumps(parse_artifact), encoding="utf-8"
    )
    unknown_quality_report = _inspect_tool_resource_artifacts(trace_dir)
    result["tool_resource_artifacts"] = unknown_quality_report
    assert unknown_quality_report["unaccounted_semantic_call_count"] == 1
    assert _required_telemetry_error(config, result) is not None

    parse_artifact["calls"][0]["telemetry_quality"] = "invalid"
    parse_artifact["calls"][0].pop("eligible_for_kb")
    (artifact_dir / f"{parse_id}.json").write_text(
        json.dumps(parse_artifact), encoding="utf-8"
    )
    missing_eligibility_report = _inspect_tool_resource_artifacts(trace_dir)
    result["tool_resource_artifacts"] = missing_eligibility_report
    assert missing_eligibility_report["unaccounted_semantic_call_count"] == 1
    assert _required_telemetry_error(config, result) is not None


def test_required_ebpf_still_fails_real_collector_infrastructure_failure(
    tmp_path,
):
    trace_dir = tmp_path / "trace"
    artifact_dir = trace_dir / "tool-resource"
    artifact_dir.mkdir(parents=True)
    call_id = "call_collector_failed"
    artifact = _ebpf_artifact(
        call_id,
        quality="unavailable",
        eligible_for_kb=False,
    )
    artifact["collector"].update(
        {
            "health": "unavailable",
            "state_before_close": "disabled",
            "disabled_reason": "collector attach failed",
            "kprobe_total_hits": 0,
        }
    )
    artifact["calls"][0]["unavailable_reason"] = "collector_attach_failed"
    (artifact_dir / f"{call_id}.json").write_text(
        json.dumps(artifact), encoding="utf-8"
    )
    trace = trace_dir / "trace.jsonl"
    trace.write_text(
        "\n".join(
            json.dumps(record)
            for record in [
                {"record_type": "trace_metadata", "task": "task-1"},
                _ebpf_prediction_start(),
                _ebpf_span_end(call_id, status="unavailable"),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    inspected = _inspect_trace(trace, "task-1")
    artifact_report = _inspect_tool_resource_artifacts(trace_dir)
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n  mode: host-openclaw\n  ebpf_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    error = _required_telemetry_error(
        config,
        {
            "resource_summary": _resource_summary([inspected]),
            "tool_resource_artifacts": artifact_report,
        },
    )

    assert artifact_report["artifact_envelope_count"] == 1
    assert artifact_report["collector_healthy_artifact_count"] == 0
    assert artifact_report["collector_failure_reason_counts"]["collector_health"] == 1
    assert any(
        "collector/infrastructure is not healthy" in warning
        for warning in artifact_report["warnings"]
    )
    assert "collector/infrastructure health is incomplete" in (error or "")


def _host_prediction_result():
    resources = {
        "tool_span_ends": 1,
        "resource_sampled_tool_span_ends": 1,
        "launcher_resource_sampled_tool_span_ends": 1,
        "launcher_tool_span_ends": 1,
        "launcher_cgroup_tool_span_ends": 1,
        "launcher_ebpf_expected_span_ends": 1,
        "launcher_exit_status_span_ends": 1,
        "launcher_tool_resource_span_ends": 1,
        "launcher_ebpf_lifecycle_span_ends": 1,
        "launcher_ebpf_artifact_envelope_span_ends": 1,
        "launcher_ebpf_artifact_refs": [
            {"execution_id": "exec-1", "tool_call_id": "call-1"}
        ],
        "launcher_tool_resource_eligible_span_ends": 1,
        "tool_resource_prediction_span_starts": 0,
        "tool_resource_prediction_available_span_starts": 0,
        "clause_bucket_prediction_available_span_starts": 0,
        "continuous_latency_ms_prediction_available_span_starts": 0,
        "continuous_peak_cpu_cores_prediction_available_span_starts": 0,
        "continuous_peak_memory_mb_prediction_available_span_starts": 0,
    }
    artifacts = {
        "artifact_count": 1,
        "artifact_envelope_count": 1,
        "artifact_identity_count": 1,
        "artifact_refs": [
            {"execution_id": "exec-1", "tool_call_id": "call-1"}
        ],
        "collector_healthy_artifact_count": 1,
        "healthy_artifact_count": 1,
        "call_count": 1,
        "lifecycle_healthy_call_count": 1,
        "ok_call_count": 1,
        "kb_eligible_call_count": 1,
        "invalid_call_count": 0,
        "unavailable_call_count": 0,
        "non_ok_call_with_reason_count": 0,
        "explicit_semantic_rejection_call_count": 0,
        "unexplained_non_ok_call_count": 0,
        "unaccounted_semantic_call_count": 0,
        "clause_count": 1,
        "clauses_with_status": 1,
    }
    return {"resource_summary": resources, "tool_resource_artifacts": artifacts}


def test_host_openclaw_required_telemetry_requires_predictions(tmp_path):
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n  mode: host-openclaw\n  ebpf_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    config.runtime.kb_frozen = False  # This fixture exercises legacy online traces.
    result = _host_prediction_result()
    resources = result["resource_summary"]

    assert "prediction coverage is incomplete" in (
        _required_telemetry_error(config, result) or ""
    )
    resources["tool_resource_prediction_span_starts"] = 1
    assert "produced no usable" in (_required_telemetry_error(config, result) or "")
    resources["tool_resource_prediction_available_span_starts"] = 1
    assert "clause latency-bucket" in (
        _required_telemetry_error(config, result) or ""
    )
    resources["clause_bucket_prediction_available_span_starts"] = 1
    assert "latency_ms,peak_cpu_cores,peak_memory_mb" in (
        _required_telemetry_error(config, result) or ""
    )
    resources["continuous_latency_ms_prediction_available_span_starts"] = 1
    resources["continuous_peak_cpu_cores_prediction_available_span_starts"] = 1
    resources["continuous_peak_memory_mb_prediction_available_span_starts"] = 1
    assert _required_telemetry_error(config, result) is None


def _canonical_prediction():
    from clawtune_sidecar.prediction_config import load_bucket_edges
    from clawtune_sidecar.predictors.call_load import predict_call_load
    from tool_resource.runtime_kb import ClauseResourceKB, RuntimeToolResourceKB, ToolCallQuery, CompletedCall
    from tool_time.lattice_kb import LatticeTimeKB

    # Explicit test-only call evidence; release bootstrap intentionally has
    # no whole-call samples and must not carry a synthetic read_file prior.
    runtime = RuntimeToolResourceKB.fit_public([
        CompletedCall("", "read_file", None, 0, .1),
    ])
    runtime.freeze()
    query = ToolCallQuery("review", "read_file", None, 1)
    assert runtime.query(query)["cpu_peak_cores"].conditional_p90 is None
    prediction, _ = predict_call_load(
        runtime=runtime, trie=ClauseResourceKB(), lattice=LatticeTimeKB(), query=query,
        edges=load_bucket_edges((100, 500, 2000, 10000)),
    )
    assert prediction.targets["duration_ms"].status == "available"
    assert prediction.targets["cpu_peak_cores"].status == "unavailable"
    return prediction.model_dump()


def _inspect_call_prediction(tmp_path, prediction):
    trace = tmp_path / "canonical.jsonl"
    # Include apparently healthy old diagnostics: they must not rescue an
    # invalid canonical prediction or supply the new coverage counters.
    record = _ebpf_prediction_start()
    record["prediction"]["call_prediction"] = prediction
    trace.write_text(json.dumps(record) + "\n", encoding="utf-8")
    summary = _resource_summary([_inspect_trace(trace, "task-1")])
    return {key: value for key, value in summary.items() if key.startswith("call_prediction_")}


@pytest.mark.parametrize("frozen", [True, False])
def test_canonical_gate_accepts_migrated_seed_and_checks_update_accounting(tmp_path, frozen):
    config_path = tmp_path / "config.yaml"
    config_path.write_text("runtime:\n  mode: host-openclaw\n  ebpf_required: true\n", encoding="utf-8")
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    assert config.runtime.kb_frozen is True
    config.runtime.kb_frozen = frozen
    result = _host_prediction_result()
    resources = result["resource_summary"]
    resources["launcher_tool_resource_eligible_span_ends"] = 0 if frozen else 1
    resources.update(_inspect_call_prediction(tmp_path, _canonical_prediction()))
    assert resources["call_prediction_target_available_span_starts"] == {"duration_ms": 1}
    # No legacy prediction coverage, CPU peak, or memory prior is required.
    assert _required_telemetry_error(config, result) is None
    resources["launcher_tool_resource_eligible_span_ends"] = 1 if frozen else 0
    assert "KB update accounting" in _required_telemetry_error(config, result)


def test_eligible_command_lookup_failure_needs_no_clause_kb_update(tmp_path):
    trace_dir = tmp_path / "trace"
    artifact_dir = trace_dir / "tool-resource"
    artifact_dir.mkdir(parents=True)
    artifact = _ebpf_artifact("call-1", clauses=[])
    artifact["calls"][0]["no_runtime_exec"] = [
        {"bin": "unzip", "mapping_evidence": "shell_command_lookup_failure_exact_head"}
    ]
    (artifact_dir / "exec-1.json").write_text(json.dumps(artifact), encoding="utf-8")
    inspected = _inspect_tool_resource_artifacts(trace_dir)
    assert inspected["kb_eligible_call_count"] == 1
    assert inspected["kb_eligible_no_runtime_exec_count"] == 1

    config_path = tmp_path / "config.yaml"
    config_path.write_text("runtime:\n  mode: host-openclaw\n  ebpf_required: true\n", encoding="utf-8")
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    config.runtime.kb_frozen = False
    result = _host_prediction_result()
    result["tool_resource_artifacts"] = inspected
    result["resource_summary"]["launcher_tool_resource_eligible_span_ends"] = 0
    result["resource_summary"].update(_inspect_call_prediction(tmp_path, _canonical_prediction()))
    assert _required_telemetry_error(config, result) is None


@pytest.mark.parametrize("damage", ["schema", "missing_target", "units", "histogram", "missing_envelope", "all_unavailable"])
def test_canonical_gate_rejects_invalid_but_accepts_unavailable_predictions(tmp_path, damage):
    from clawtune_sidecar.prediction_config import load_bucket_edges
    from clawtune_sidecar.predictors.call_load import compose

    prediction = _canonical_prediction()
    if damage == "schema":
        prediction["schema_version"] = "call_load.v999"
    elif damage == "missing_target":
        del prediction["targets"]["cpu_peak_cores"]
    elif damage == "units":
        prediction["targets"]["duration_ms"]["unit"] = "bytes"
    elif damage == "histogram":
        prediction["targets"]["duration_ms"]["buckets"]["probabilities"] = [0, 0]
    elif damage == "missing_envelope":
        del prediction["scope"]
    else:
        prediction = compose("trie", (), load_bucket_edges((100, 500))).model_dump()
    result = _host_prediction_result()
    resources = result["resource_summary"]
    resources.update(_inspect_call_prediction(tmp_path, prediction))
    resources["launcher_tool_resource_eligible_span_ends"] = 0
    config_path = tmp_path / "config.yaml"
    config_path.write_text("runtime:\n  mode: host-openclaw\n  ebpf_required: true\n", encoding="utf-8")
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    error = _required_telemetry_error(config, result)
    if damage == "all_unavailable":
        assert error is None
    else:
        assert "coverage is incomplete or invalid" in error


def test_canonical_summary_requires_coverage_of_every_tool_call(tmp_path):
    prediction = _canonical_prediction()
    record = _ebpf_prediction_start()
    record["prediction"]["call_prediction"] = prediction
    path = tmp_path / "mixed.jsonl"
    path.write_text(json.dumps(record) + "\n" + json.dumps(_ebpf_prediction_start()), encoding="utf-8")
    summary = _resource_summary([_inspect_trace(path, "task-1")])
    assert summary["call_prediction_span_starts"] == 1
    result = _host_prediction_result()
    resources = result["resource_summary"]
    resources.update({key: value for key, value in summary.items() if key.startswith("call_prediction_")})
    resources.update(tool_span_ends=2, resource_sampled_tool_span_ends=2,
                     launcher_tool_resource_eligible_span_ends=0)
    config_path = tmp_path / "config.yaml"
    config_path.write_text("runtime:\n  mode: host-openclaw\n  ebpf_required: true\n", encoding="utf-8")
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    assert "coverage is incomplete or invalid" in _required_telemetry_error(config, result)


def test_container_mode_honors_explicit_ebpf_requirement(tmp_path):
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n  mode: container-openclaw\n  ebpf_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    config.runtime.kb_frozen = False  # This fixture exercises legacy online traces.

    assert _required_telemetry_error(
        config,
        {
            "resource_summary": {
                "tool_span_ends": 1,
                "resource_sampled_tool_span_ends": 0,
                "launcher_resource_sampled_tool_span_ends": 0,
                "launcher_tool_span_ends": 1,
                "cgroup_sampled_tool_span_ends": 0,
                "launcher_ebpf_expected_span_ends": 1,
            },
            "tool_resource_artifacts": {
                "artifact_count": 0,
                "healthy_artifact_count": 0,
                "call_count": 0,
                "ok_call_count": 0,
                "clause_count": 0,
                "clauses_with_status": 0,
            },
        },
    ) == "required resource telemetry is incomplete: sampled 0/1 launcher tool spans"

    assert _required_telemetry_error(
        config,
        {
            "resource_summary": {
                "tool_span_ends": 1,
                "resource_sampled_tool_span_ends": 1,
                "launcher_resource_sampled_tool_span_ends": 1,
                "launcher_tool_span_ends": 1,
                "launcher_cgroup_tool_span_ends": 1,
                "launcher_ebpf_expected_span_ends": 1,
                "launcher_tool_resource_span_ends": 1,
                "launcher_tool_resource_eligible_span_ends": 1,
            },
            "tool_resource_artifacts": {
                "artifact_count": 1,
                "artifact_envelope_count": 1,
                "collector_healthy_artifact_count": 1,
                "call_count": 1,
                "ok_call_count": 1,
                "kb_eligible_call_count": 1,
                "invalid_call_count": 0,
                "unavailable_call_count": 0,
                "non_ok_call_with_reason_count": 0,
                "explicit_semantic_rejection_call_count": 0,
                "unexplained_non_ok_call_count": 0,
                "unaccounted_semantic_call_count": 0,
                "clause_count": 1,
                "clauses_with_status": 1,
            },
        },
    ) is None


def test_launcher_per_pid_attribution_passes_gate(tmp_path):
    """Per-PID process-tree attribution is the documented fallback when the
    host does not delegate a writable cgroup subtree (execution_started
    degrades to _verified_host_pid_scope).  Fully attributed launcher spans
    (even without cgroup-v2) satisfy the required-telemetry gate; only
    unattributed spans are a real loss."""
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n"
        "  mode: host-openclaw\n"
        "  ebpf_required: true\n"
        "docker:\n"
        "  cgroup_required: false\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    config.runtime.kb_frozen = False  # This fixture exercises legacy online traces.
    resources = {
        "tool_span_ends": 1,
        "resource_sampled_tool_span_ends": 1,
        "launcher_resource_sampled_tool_span_ends": 1,
        "launcher_tool_span_ends": 1,
        "launcher_cgroup_tool_span_ends": 0,
        "launcher_attributed_tool_span_ends": 1,
        "unattributed_launcher_tool_span_ends": 0,
        "launcher_ebpf_expected_span_ends": 1,
        "launcher_exit_status_span_ends": 1,
        "launcher_tool_resource_span_ends": 1,
        "launcher_ebpf_lifecycle_span_ends": 1,
        "launcher_ebpf_artifact_envelope_span_ends": 1,
        "launcher_ebpf_artifact_refs": [
            {"execution_id": "exec-1", "tool_call_id": "call-1"}
        ],
        "launcher_tool_resource_eligible_span_ends": 1,
        "tool_resource_prediction_span_starts": 1,
        "tool_resource_prediction_available_span_starts": 1,
        "clause_bucket_prediction_available_span_starts": 1,
        "continuous_latency_ms_prediction_available_span_starts": 1,
        "continuous_peak_cpu_cores_prediction_available_span_starts": 1,
        "continuous_peak_memory_mb_prediction_available_span_starts": 1,
    }
    artifacts = {
        "artifact_count": 1,
        "artifact_envelope_count": 1,
        "artifact_identity_count": 1,
        "artifact_refs": [
            {"execution_id": "exec-1", "tool_call_id": "call-1"}
        ],
        "collector_healthy_artifact_count": 1,
        "healthy_artifact_count": 1,
        "call_count": 1,
        "lifecycle_healthy_call_count": 1,
        "ok_call_count": 1,
        "kb_eligible_call_count": 1,
        "invalid_call_count": 0,
        "unavailable_call_count": 0,
        "non_ok_call_with_reason_count": 0,
        "explicit_semantic_rejection_call_count": 0,
        "unexplained_non_ok_call_count": 0,
        "unaccounted_semantic_call_count": 0,
        "clause_count": 1,
        "clauses_with_status": 1,
    }
    result = {
        "resource_summary": resources,
        "tool_resource_artifacts": artifacts,
    }

    # cgroup-v2 unavailable but every launcher span is per-PID attributed:
    # the gate passes (the telemetry is complete and attributed).
    assert _required_telemetry_error(config, result) is None


def test_host_openclaw_cgroup_required_audits_exclusive_unique_paths(tmp_path):
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n"
        "  mode: host-openclaw\n"
        "  ebpf_required: false\n"
        "docker:\n"
        "  cgroup_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    container_scope = (
        "/sys/fs/cgroup/system.slice/docker-"
        + ("b" * 64)
        + ".scope"
    )

    def inspect(records: list[dict], filename: str) -> dict:
        trace = tmp_path / filename
        trace.write_text(
            "\n".join(json.dumps(record) for record in records) + "\n",
            encoding="utf-8",
        )
        return _resource_summary([_inspect_trace(trace, "")])

    valid_resources = inspect(
        [
            _launcher_cgroup_span_end(
                "exec-1",
                f"{container_scope}/clawtune-executions/exec-1",
            ),
            _launcher_cgroup_span_end(
                "exec-2",
                f"{container_scope}/clawtune-executions/exec-2",
            ),
        ],
        "valid.jsonl",
    )
    assert _required_telemetry_error(
        config,
        {"resource_summary": valid_resources},
    ) is None

    shared_resources = inspect(
        [
            _launcher_cgroup_span_end(
                "exec-1",
                container_scope,
                attribution_source="trusted-execution-root-pid",
            ),
            _launcher_cgroup_span_end(
                "exec-2",
                container_scope,
                attribution_source="trusted-execution-root-pid",
            ),
        ],
        "shared.jsonl",
    )
    shared_error = _required_telemetry_error(
        config,
        {"resource_summary": shared_resources},
    )
    assert shared_error is not None
    assert (
        "attribution_source=exclusive-execution-cgroup for 0/2"
        in shared_error
    )
    assert "unique cgroup paths=1/2" in shared_error
    assert "shared docker-<container-id>.scope paths=2" in shared_error

    wrong_scope = json.loads(json.dumps(valid_resources))
    wrong_scope["launcher_cgroup_tool_span_ends"] = 1
    # eBPF process_tree collection still has verified exclusive cgroup identity.
    assert _required_telemetry_error(config, {"resource_summary": wrong_scope}) is None

    duplicate_execution = json.loads(json.dumps(valid_resources))
    duplicate_execution["launcher_execution_cgroup_refs"][1][
        "execution_id"
    ] = "exec-1"
    assert "unique execution IDs=1/2" in (
        _required_telemetry_error(
            config,
            {"resource_summary": duplicate_execution},
        )
        or ""
    )


def test_launcher_unattributed_spans_fail_gate_with_diagnostics(tmp_path):
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "runtime:\n  mode: host-openclaw\n  ebpf_required: true\n",
        encoding="utf-8",
    )
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)

    trace_dir = tmp_path / "trace"
    trace_dir.mkdir(parents=True, exist_ok=True)
    (trace_dir / "sandbox_scope_discovery_last_error.txt").write_text(
        "docker inspect failed\n",
        encoding="utf-8",
    )

    def result_dict() -> dict:
        return {
            "trace_dir": str(trace_dir),
            "resource_summary": {
                "tool_span_ends": 2,
                "resource_sampled_tool_span_ends": 2,
                "launcher_resource_sampled_tool_span_ends": 2,
                "launcher_tool_span_ends": 2,
                "launcher_cgroup_tool_span_ends": 0,
                "launcher_attributed_tool_span_ends": 1,
                "unattributed_launcher_tool_span_ends": 1,
                "launcher_ebpf_expected_span_ends": 2,
            },
            "tool_resource_artifacts": {"artifact_count": 2},
        }

    error = _required_telemetry_error(config, result_dict())
    assert error is not None
    assert (
        "required launcher resource attribution is incomplete: "
        "1/2 launcher tool spans are unattributed" in error
    )
    # The gate failure must explain WHY attribution is missing so the
    # operator can tell process-tree attribution from no attribution at all.
    assert "launcher scope breakdown: cgroup=0, attributed=1, unattributed=1" in error
    assert "sandbox scope: NOT discovered" in error
    assert "sandbox-scope discovery last error: docker inspect failed" in error

    # A discovered sandbox scope flips the diagnostic.
    (trace_dir / "sandbox_scope.json").write_text("{}", encoding="utf-8")
    discovered_error = _required_telemetry_error(config, result_dict())
    assert discovered_error is not None
    assert "sandbox scope: discovered" in discovered_error
    assert "sandbox-scope discovery last error" not in discovered_error


def test_wait_process_exit_tolerates_keyboard_interrupt():
    import subprocess

    proc = subprocess.Popen(
        ["python", "-c", "import time; time.sleep(30)"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    try:
        real_wait = proc.wait

        def interrupt_wait(timeout):
            raise KeyboardInterrupt

        # Simulate a user Ctrl+C landing while the harness waits for the
        # process: the wait must not raise and must report the current state.
        proc.wait = interrupt_wait  # type: ignore[method-assign]
        assert host_openclaw._wait_process_exit(proc, timeout=5) is False
        assert proc.poll() is None

        # Restoring the real wait, SIGTERM still reaps the process.
        proc.wait = real_wait  # type: ignore[method-assign]
        proc.terminate()
        assert host_openclaw._wait_process_exit(proc, timeout=5) is True
        assert proc.poll() is not None
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=5)


def test_stop_process_raises_when_process_never_exits():
    import subprocess

    class _NeverExits:
        def poll(self) -> None:
            # Explicit None is the "still running" sentinel (never exits).
            return None

        def terminate(self) -> None:
            pass

        def kill(self) -> None:
            pass

        def wait(self, timeout: float = 5) -> None:
            raise subprocess.TimeoutExpired("cmd", timeout)

    try:
        host_openclaw._stop_process(_NeverExits())  # type: ignore[arg-type]
    except RuntimeError as exc:
        assert "sidecar did not exit after terminate and kill" in str(exc)
    else:
        raise AssertionError("expected RuntimeError for a process that never exits")


def _runner_config(tmp_path: Path, parallelism: int) -> RunnerConfig:
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        "\n".join(
            [
                "runtime:",
                "  mode: host-openclaw",
                "  ebpf_required: false",
                "batch:",
                f"  parallelism: {parallelism}",
                "output:",
                "  trace_root: traces",
                "  report_path: report.json",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return RunnerConfig.from_yaml(config_path, repo_root=tmp_path)


def _fake_task_result(task: TaskDef, trace_dir: Path, started: float) -> ContainerResult:
    trace_dir.mkdir(parents=True, exist_ok=True)
    return ContainerResult(
        task_id=task.instance_id,
        image=task.image,
        exit_code=0,
        error=None,
        trace_dir=trace_dir,
        trace_files=[],
        duration_seconds=time.monotonic() - started,
    )


def test_run_batch_parallel_tasks_share_one_sidecar_endpoint(tmp_path, monkeypatch):
    config = _runner_config(tmp_path, parallelism=2)
    tasks = [
        TaskDef("owner__repo-1", "image:1"),
        TaskDef("owner__repo-2", "image:2"),
    ]
    events: list[tuple[str, str | None]] = []

    monkeypatch.setattr(runner, "get_docker_client", lambda _config: object())
    monkeypatch.setattr(
        runner,
        "_prepare_batch_tool_resource_kb",
        lambda shared_kb_dir, _config: shared_kb_dir.mkdir(parents=True),
    )
    monkeypatch.setattr(host_openclaw, "_free_port", lambda: 19090)

    class Sidecar:
        poll = None  # noqa: A003 (return None → process still running)

    monkeypatch.setattr(
        host_openclaw,
        "_start_sidecar",
        lambda **_kwargs: events.append(("sidecar-start", None)) or Sidecar(),
    )
    monkeypatch.setattr(
        host_openclaw,
        "_stop_process",
        lambda _process: events.append(("sidecar-stop", None)),
    )
    monkeypatch.setattr(
        runner,
        "_stop_process",
        lambda _process: events.append(("sidecar-stop", None)),
    )

    def fake_execute_one(**kwargs):
        events.append((kwargs["task"].instance_id, str(kwargs["shared_sidecar_port"])))
        time.sleep(0.02)
        return _fake_task_result(
            kwargs["task"],
            kwargs["trace_dir"],
            time.monotonic() - 0.01,
        )

    monkeypatch.setattr(runner, "_execute_one", fake_execute_one)

    report = runner.run_batch(config, tasks, tmp_path / "assets")

    endpoints = {entry["sidecar_endpoint"] for entry in report.results}
    assert endpoints == {"http://127.0.0.1:19090"}
    assert {event for event in events if event[0].startswith("owner__")} == {
        ("owner__repo-1", "19090"),
        ("owner__repo-2", "19090"),
    }
    assert events[-1] == ("sidecar-stop", None)


def test_run_batch_parallelism_one_keeps_single_worker_path(tmp_path, monkeypatch):
    config = _runner_config(tmp_path, parallelism=1)
    task = TaskDef("owner__repo-1", "image:1")
    calls: list[str] = []

    monkeypatch.setattr(runner, "get_docker_client", lambda _config: object())
    monkeypatch.setattr(
        runner,
        "_prepare_batch_tool_resource_kb",
        lambda shared_kb_dir, _config: shared_kb_dir.mkdir(parents=True),
    )
    monkeypatch.setattr(host_openclaw, "_free_port", lambda: 19091)
    monkeypatch.setattr(host_openclaw, "_start_sidecar", lambda **_kwargs: object())
    monkeypatch.setattr(host_openclaw, "_stop_process", lambda _process: None)
    monkeypatch.setattr(runner, "_stop_process", lambda _process: None)

    def fake_execute_one(**kwargs):
        calls.append(kwargs["task"].instance_id)
        return _fake_task_result(
            kwargs["task"],
            kwargs["trace_dir"],
            time.monotonic() - 0.01,
        )

    monkeypatch.setattr(runner, "_execute_one", fake_execute_one)

    report = runner.run_batch(config, [task], tmp_path / "assets")

    assert calls == ["owner__repo-1"]
    assert report.completed == 1
    assert report.failed == 0
    assert report.results[0]["sidecar_endpoint"] == "http://127.0.0.1:19091"


def test_run_batch_keeps_snapshotted_trace_when_task_cleanup_raises(
    tmp_path,
    monkeypatch,
):
    config = _runner_config(tmp_path, parallelism=1)
    task = TaskDef("owner__repo-1", "image:1")

    monkeypatch.setattr(runner, "get_docker_client", lambda _config: object())
    monkeypatch.setattr(
        runner,
        "_prepare_batch_tool_resource_kb",
        lambda shared_kb_dir, _config: shared_kb_dir.mkdir(parents=True),
    )
    monkeypatch.setattr(host_openclaw, "_free_port", lambda: 19092)
    monkeypatch.setattr(host_openclaw, "_start_sidecar", lambda **_kwargs: object())
    monkeypatch.setattr(host_openclaw, "_stop_process", lambda _process: None)
    monkeypatch.setattr(runner, "_stop_process", lambda _process: None)

    def fail_after_trace_snapshot(**kwargs):
        trace_path = kwargs["trace_dir"] / "runtime__session_run.jsonl"
        trace_path.write_text(
            json.dumps(
                {
                    "schema_version": 6,
                    "record_type": "trace_metadata",
                    "trace_format_version": 6,
                    "scaffold": "openclaw",
                    "mode": "collect",
                }
            )
            + "\n",
            encoding="utf-8",
        )
        raise RuntimeError("runtime drain failed")

    monkeypatch.setattr(runner, "_execute_one", fail_after_trace_snapshot)

    report = runner.run_batch(config, [task], tmp_path / "assets")

    assert report.completed == 0
    assert report.failed == 1
    assert report.results[0]["error"] == "runtime drain failed"
    assert report.results[0]["trace_lines"] == 1
    assert len(report.results[0]["trace_files"]) == 1


def test_trace_counts_each_independent_prediction_without_filling_missing_models(tmp_path):
    from clawtune_sidecar.predictors.call_load import summarize
    from clawtune_sidecar.contracts.load_prediction import CallLoadPrediction, TARGET_UNITS
    from clawtune_sidecar.prediction_config import load_bucket_edges
    edges = load_bucket_edges((100, 500, 2000, 10000))
    def prediction(backend, target):
        return CallLoadPrediction(targets={
            name: summarize(name, edges[name], backend, [1] if name == target else [])
            for name in TARGET_UNITS
        }).model_dump()
    trace = tmp_path / "trace.jsonl"
    trace.write_text(json.dumps({"record_type": "span_start", "kind": "tool", "prediction": {
        "tool": prediction("runtime", "duration_ms"),
        "trie": prediction("trie", "cpu_time_seconds"),
    }}) + "\n", encoding="utf-8")
    report = _inspect_trace(trace, "")
    summary = _resource_summary([report, report])["prediction_models"]
    assert summary["tool"]["target_available_span_starts"] == {"duration_ms": 2}
    assert summary["trie"]["target_available_span_starts"] == {"cpu_time_seconds": 2}
    assert summary["lattice"]["span_starts"] == 0
    assert summary["lattice"]["target_available_span_starts"] == {}


@pytest.mark.parametrize("case", ["cold_seed", "all_unavailable", "missing_tool", "missing_trie",
                                  "null_lattice", "bad_tool", "bad_trie", "bad_lattice",
                                  "partial_coverage", "bad_alias"])
def test_independent_prediction_audit_allows_cold_start_but_requires_each_model(tmp_path, case):
    from clawtune_kb import FILES, validate_seed
    from tool_resource.runtime_kb import RuntimeToolResourceKB, ClauseResourceKB, ToolCallQuery
    from tool_time.lattice_kb import LatticeTimeKB
    from clawtune_sidecar.predictors.call_load import predict_call_load, compose
    from clawtune_sidecar.prediction_config import load_bucket_edges

    seed = Path(__file__).resolve().parents[1] / "seeds/bootstrap-v1"
    validate_seed(seed)
    trie, tool, lattice = [json.loads((seed / name).read_text(encoding="utf-8")) for name in FILES]
    edges = load_bucket_edges((100, 500, 2000, 10000))
    result, diagnostics = predict_call_load(
        runtime=RuntimeToolResourceKB.from_json_obj(tool),
        trie=ClauseResourceKB.from_json_obj(trie), lattice=LatticeTimeKB.from_json_obj(lattice),
        query=ToolCallQuery("new-repo", "exec", "find .", 1), edges=edges,
        parsed_clauses=[{"bin": "find", "argv": ["find", "."]}],
    )
    assert all(t.status == "unavailable" for t in result.targets.values())
    assert diagnostics.backends["trie"].targets["duration_ms"].status == "unavailable"
    record = _ebpf_prediction_start()
    record["prediction"].update({
        "tool": result.model_dump(), "trie": diagnostics.backends["trie"].model_dump(),
        "lattice": diagnostics.backends["lattice"].model_dump(),
        "call_prediction": result.model_dump(),
    })
    expected_model = None
    if case == "all_unavailable":
        for name, backend in (("tool", "runtime"), ("trie", "trie"), ("lattice", "lattice")):
            record["prediction"][name] = compose(backend, (), edges).model_dump()
    elif case.startswith("missing_"):
        expected_model = case.removeprefix("missing_")
        del record["prediction"][expected_model]
    elif case == "null_lattice":
        expected_model = "lattice"
        record["prediction"]["lattice"] = None
    elif case.startswith("bad_"):
        name = case.removeprefix("bad_")
        if name == "alias":
            record["prediction"]["call_prediction"] = {"schema_version": "invalid"}
        else:
            expected_model = name
            del record["prediction"][name]["targets"]["cpu_time_seconds"]
            # A healthy compatibility alias cannot rescue a broken formal model.
            record["prediction"]["call_prediction"] = _canonical_prediction()
    records = [record]
    if case == "partial_coverage":
        records.append(_ebpf_prediction_start())
        expected_model = "tool"
    trace = tmp_path / "independent.jsonl"
    trace.write_text("".join(json.dumps(r) + "\n" for r in records), encoding="utf-8")
    summary = _resource_summary([_inspect_trace(trace, "")])
    audited = _host_prediction_result()
    resources = audited["resource_summary"]
    resources.update(prediction_models=summary["prediction_models"],
                     launcher_tool_resource_eligible_span_ends=0,
                     tool_span_ends=len(records), resource_sampled_tool_span_ends=len(records))
    resources.update({k: v for k, v in summary.items() if k.startswith("call_prediction_")})
    config_path = tmp_path / "config.yaml"
    config_path.write_text("runtime:\n  mode: host-openclaw\n  ebpf_required: true\n", encoding="utf-8")
    config = RunnerConfig.from_yaml(config_path, repo_root=tmp_path)
    error = _required_telemetry_error(config, audited)
    if expected_model:
        assert f"required {expected_model} prediction coverage is incomplete or invalid" in error
    else:
        assert error is None
    if case == "cold_seed":
        assert summary["prediction_models"]["tool"]["target_available_span_starts"] == {}
        assert summary["prediction_models"]["trie"]["target_available_span_starts"] == {}
