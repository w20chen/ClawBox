"""
SWE-Rebench task discovery and dataset generation.

Generates a tasks JSON file that ``runner.py --dataset`` can consume.
Sources (tried in order):

1. Local ``agent-test-bench`` checkout — uses its ``inspect_swebench.py``
   or the ``datasets`` library if available.
2. Direct HuggingFace download — requires ``pip install datasets``.
3. Manual image list — if you already know the Docker image names.

Usage::

    # Discover from agent-test-bench
    python -m swe_rebench.discover --bench-root ~/agent-test-bench --out tasks.json

    # Download from HuggingFace
    python -m swe_rebench.discover --out tasks.json --sample 10

    # Generate from known images
    python -m swe_rebench.discover --images images.txt --out tasks.json
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from swe_rebench.task_source import (
    filter_tasks,
    load_tasks_from_swebench_dataset,
    parse_instance_ids,
    tasks_from_records,
)


REPO_ROOT = Path(__file__).resolve().parents[1]
HF_DATASET = "nebius/SWE-rebench"
HF_SPLIT = "filtered"
DEFAULT_BENCH_ROOT_ENV = "AGENT_TEST_BENCH_ROOT"
DEFAULT_BENCH_ROOT = REPO_ROOT.parent / "agent-test-bench"


def discover_from_agent_test_bench(
    bench_root: Path,
    sample: int = 0,
) -> list[dict[str, Any]]:
    """Load tasks from a local agent-test-bench checkout when available.

    agent-test-bench prepares SWE-Rebench tasks at
    ``data/swe-rebench/tasks.json``. Prefer that file because it matches the
    benchmark harness examples and avoids network access. If it is absent,
    fall back to the HuggingFace loader.
    """
    if not bench_root.exists():
        raise FileNotFoundError(
            f"agent-test-bench not found at {bench_root}. "
            f"Set AGENT_TEST_BENCH_ROOT or use --bench-root."
        )

    tasks_path = bench_root / "data" / "swe-rebench" / "tasks.json"
    if tasks_path.exists():
        loaded = load_tasks_from_swebench_dataset(tasks_path)
        tasks = [_task_to_record(task) for task in loaded]
        return tasks[:sample] if sample > 0 else tasks

    return _load_from_huggingface(sample)


def _load_from_huggingface(sample: int = 0) -> list[dict[str, Any]]:
    """Load tasks from HuggingFace parquet files via subprocess.

    Uses ``huggingface_hub`` + ``pyarrow`` to read the raw parquet files
    directly — avoids the ``datasets`` library entirely because its 3.x
    release has breaking schema changes (List→LargeList, type mismatches)
    that prevent loading older-format datasets like SWE-rebench.
    """
    code = f'''
import json, sys, os

# ── Step 1: List parquet files for the requested split ──────────
try:
    from huggingface_hub import list_repo_files, hf_hub_download
except ImportError:
    print(json.dumps({{"error": "huggingface_hub not installed. Run: pip install huggingface_hub"}}))
    sys.exit(1)

repo = "{HF_DATASET}"
split = "{HF_SPLIT}"

try:
    files = list(list_repo_files(repo, repo_type="dataset"))
except Exception as e:
    print(json.dumps({{"error": f"Failed to list repo files: {{e}}"}}))
    sys.exit(1)

# Find parquet files: data/<split>-*.parquet
parquet_files = sorted(
    f for f in files
    if f.startswith(f"data/{{split}}-") and f.endswith(".parquet")
)
if not parquet_files:
    print(json.dumps({{"error": f"No parquet files found for split '{{split}}' in {{repo}}. Files: {{files[:20]}}"}}))
    sys.exit(1)

# ── Step 2: Download and read parquet files ──────────────────────
try:
    import pyarrow.parquet as pq
except ImportError:
    print(json.dumps({{"error": "pyarrow not installed. Run: pip install pyarrow"}}))
    sys.exit(1)

sample_limit = {sample}
tasks = []
for pf in parquet_files:
    if sample_limit > 0 and len(tasks) >= sample_limit:
        break
    local_path = hf_hub_download(repo, pf, repo_type="dataset")
    table = pq.read_table(local_path)
    for batch in table.to_batches(max_chunksize=1000):
        rows = batch.to_pylist()
        for row in rows:
            if sample_limit > 0 and len(tasks) >= sample_limit:
                break
            # Normalize: convert numpy/pyarrow types to plain Python
            task = {{}}
            for k, v in row.items():
                if v is None:
                    task[k] = None
                elif hasattr(v, 'tolist'):
                    task[k] = v.tolist()
                elif hasattr(v, 'item'):
                    task[k] = v.item()
                else:
                    task[k] = v
            tasks.append({{
                "instance_id": str(task.get("instance_id", "")),
                "image": str(task.get("docker_image", "")),
                "problem_statement": str(task.get("problem_statement", "")),
                "repo": str(task.get("repo", "")),
                "base_commit": str(task.get("base_commit", "")),
                "FAIL_TO_PASS": task.get("FAIL_TO_PASS", []),
                "PASS_TO_PASS": task.get("PASS_TO_PASS", []),
            }})
        if sample_limit > 0 and len(tasks) >= sample_limit:
            break

if not tasks:
    print(json.dumps({{"error": f"No tasks loaded from {{len(parquet_files)}} parquet file(s)"}}))
    sys.exit(1)

print(json.dumps(tasks, ensure_ascii=False))
'''
    _log(f"Loading {HF_DATASET} (split={HF_SPLIT}) from parquet...")
    result = subprocess.run(
        [sys.executable, "-c", code],
        capture_output=True,
        text=True,
        timeout=600,
    )
    if result.returncode != 0:
        stderr = result.stderr.strip()
        stdout = result.stdout.strip()
        try:
            err_data = json.loads(stdout)
            msg = err_data.get("error", stdout or stderr)
        except (json.JSONDecodeError, TypeError):
            msg = stderr or stdout or "unknown error"
        raise RuntimeError(f"Failed to load dataset: {msg}")

    try:
        tasks_raw = json.loads(result.stdout)
    except json.JSONDecodeError:
        raise RuntimeError(
            f"Failed to parse dataset output. stderr: {result.stderr[:500]}"
        )

    tasks: list[dict[str, Any]] = []
    for raw in tasks_raw:
        if isinstance(raw, dict):
            tasks.append(raw)

    _log(f"Loaded {len(tasks)} tasks from {HF_DATASET}")
    return tasks


def discover_from_images(image_file: Path) -> list[dict[str, Any]]:
    """Generate task stubs from a list of Docker images (one per line)."""
    text = _read_text_file(image_file)
    tasks: list[dict[str, Any]] = []
    for line in text.splitlines():
        image = line.strip()
        if not image or image.startswith("#"):
            continue
        # Derive task ID from image name
        # e.g. swerebench/sweb.eval.x86_64.django__django-12345:latest
        #   -> django__django-12345
        iid = _derive_task_id(image)
        tasks.append({
            "instance_id": iid,
            "image": image,
            "problem_statement": "",
            "repo": "",
            "base_commit": "",
        })
    return tasks


def discover_single(image: str, task_id: str = "", problem: str = "") -> list[dict[str, Any]]:
    """Create a single task definition."""
    return [{
        "instance_id": task_id or _derive_task_id(image),
        "image": image,
        "problem_statement": problem,
        "repo": "",
        "base_commit": "",
    }]


def _task_to_record(task: Any) -> dict[str, Any]:
    return {
        "instance_id": task.instance_id,
        "image": task.image,
        "docker_image": task.image,
        "problem_statement": task.problem_statement,
        "repo": task.repo,
        "base_commit": task.base_commit,
        "hint_text": task.hint_text,
        "environment": task.extra_env,
    }


def _derive_task_id(image: str) -> str:
    """Derive a task ID from a Docker image name.

    >>> _derive_task_id('swerebench/sweb.eval.x86_64.django__django-12345:latest')
    'django__django-12345'
    >>> _derive_task_id('swerebench/sweb.eval.x86_64.django:latest')
    'django'
    """
    # Strip the tag (everything after the last ':')
    if ":" in image:
        image = image.rsplit(":", 1)[0]
    # Take the last path component
    parts = image.split("/")
    last = parts[-1]
    # Remove common swe-rebench prefixes
    for prefix in ("sweb.eval.x86_64.", "sweb.eval.arm64.", "sweb.eval.", "sweb."):
        if last.startswith(prefix):
            last = last[len(prefix):]
            break
    return last or "unknown"


def _read_text_file(path: Path) -> str:
    """Read a text file, trying UTF-8 first then UTF-16 (Windows)."""
    for encoding in ("utf-8", "utf-16", "utf-16-le", "latin-1"):
        try:
            return path.read_text(encoding=encoding)
        except (UnicodeDecodeError, UnicodeError):
            continue
    return path.read_text(encoding="utf-8", errors="replace")


def _log(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


# ── CLI ───────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Discover SWE-Rebench tasks and generate a tasks JSON file.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--out", default="swe-bench-tasks.json",
        help="Output JSON file (default: swe-bench-tasks.json)",
    )
    parser.add_argument("--sample", type=int, default=0, help="Limit to first N tasks (0=all)")
    parser.add_argument("--skip", type=int, default=0,
                        help="Skip the first N selected tasks before --sample")
    parser.add_argument("--instance-ids", default=None,
                        help="Comma-separated instance IDs to include")
    parser.add_argument("--repo", default=None,
                        help="Only include tasks from this repo, e.g. django/django")
    parser.add_argument("--bench-root", default=None,
                        help="Path to agent-test-bench checkout")
    parser.add_argument("--images", default=None,
                        help="File with Docker images (one per line)")
    parser.add_argument("--image", default=None,
                        help="Single Docker image (use with --task-id, --problem)")
    parser.add_argument("--task-id", default=None)
    parser.add_argument("--problem", default=None)

    args = parser.parse_args()

    tasks: list[dict[str, Any]] = []

    if args.image:
        tasks = discover_single(args.image, args.task_id or "", args.problem or "")
    elif args.images:
        tasks = discover_from_images(Path(args.images))
    else:
        # Try agent-test-bench first, then HuggingFace
        bench_root = Path(args.bench_root) if args.bench_root else Path(
            os.getenv(DEFAULT_BENCH_ROOT_ENV, str(DEFAULT_BENCH_ROOT))
        )
        try:
            discovery_sample = (
                args.sample
                if args.sample > 0 and args.skip <= 0 and not args.repo and not args.instance_ids
                else 0
            )
            tasks = discover_from_agent_test_bench(bench_root, sample=discovery_sample)
        except (FileNotFoundError, ImportError, RuntimeError) as exc:
            _log(f"[warn] Cannot load from agent-test-bench: {exc}")
            _log("[warn] Trying direct HuggingFace download...")
            try:
                discovery_sample = (
                    args.sample
                    if args.sample > 0 and args.skip <= 0 and not args.repo and not args.instance_ids
                    else 0
                )
                tasks = _load_from_huggingface(sample=discovery_sample)
            except (ImportError, RuntimeError) as exc2:
                _log(f"[error] {exc2}")
                _log("[error] Cannot discover tasks. Options:")
                _log("[error]   1. pip install datasets  (download from HuggingFace)")
                _log("[error]   2. --images images.txt    (provide Docker image list)")
                _log("[error]   3. --image <img> --task-id <id> --problem <text>")
                sys.exit(1)

    if not tasks:
        _log("No tasks discovered.")
        sys.exit(1)

    task_defs = tasks_from_records(tasks)
    task_defs = filter_tasks(
        task_defs,
        sample=args.sample,
        skip=max(0, args.skip),
        instance_ids=parse_instance_ids(args.instance_ids),
        repo=args.repo,
    )
    tasks = [_task_to_record(task) for task in task_defs]

    if not tasks:
        _log("No tasks matched the requested filters.")
        sys.exit(1)

    # Write output
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(
        json.dumps(tasks, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    _log(f"Wrote {len(tasks)} tasks to {out_path}")

    # Print summary
    print(f"\nDiscovered {len(tasks)} tasks -> {out_path}")
    for i, t in enumerate(tasks[:5]):
        iid = t.get("instance_id", "?")
        img = t.get("image", "?")
        prob = t.get("problem_statement", "")
        print(f"  [{i+1}] {iid}")
        print(f"       image: {img}")
        if prob:
            print(f"       problem: {prob[:100]}...")
    if len(tasks) > 5:
        print(f"  ... and {len(tasks) - 5} more")


if __name__ == "__main__":
    main()
