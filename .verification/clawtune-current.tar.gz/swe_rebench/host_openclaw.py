"""Host OpenClaw + OpenClaw Docker sandbox runner for SWE-Rebench.

This mode keeps OpenClaw, the plugin, and ClawTune Sidecar on the host.
The SWE-Rebench task repository is copied out of the task image into a host
workspace, then OpenClaw's own Docker sandbox executes tools against that
workspace.
"""

from __future__ import annotations

import errno
import hashlib
import json
import math
import os
import signal
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Sequence

from swe_rebench.config import RunnerConfig
from swe_rebench.console import follow_agent_output
from swe_rebench.cancellation import TaskCancelled, check_cancelled, wait_process, run_command
from swe_rebench.docker import ContainerCleanupError, ContainerResult, local_image_available
from swe_rebench.sandbox import sandbox_container_prefix
from swe_rebench.task_source import TaskDef, task_repo_key

# 鈹€鈹€ thread-safe console logging 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
_print_lock = threading.Lock()
_plugin_build_lock = threading.Lock()
_built_plugin_dirs: set[Path] = set()


# SWE-bench evaluation images keep the task environment under
# /opt/miniconda3/envs/testbed.  Retain the older /opt/conda layout as a
# fallback because some SWE-Rebench images use that prefix.  OpenClaw passes
# this value directly into its Docker sandbox, so omitting the actual testbed
# prefix silently falls back to /usr/bin/python3 and loses the task's installed
# dependencies.
_SANDBOX_TASK_PATH = ":".join(
    (
        "/workspace/.clawtune/bin",
        "/opt/miniconda3/envs/testbed/bin",
        "/opt/conda/envs/testbed/bin",
        "/opt/miniconda3/condabin",
        "/opt/miniconda3/bin",
        "/opt/conda/bin",
        "/usr/local/sbin",
        "/usr/local/bin",
        "/usr/sbin",
        "/usr/bin",
        "/sbin",
        "/bin",
    )
)

# OpenClaw talks only to the loopback ClawTune proxy in host-openclaw mode.
# Keep the real upstream credential exclusively in the sidecar environment.
_LOCAL_PROXY_API_KEY = "clawtune-local-proxy"
_RUNTIME_PROXY_API_KEY_PREFIX = "clawtune-runtime."
_BENCHMARK_GATEWAY_ID = "swe-rebench"


def _gateway_id(config: RunnerConfig | None) -> str:
    """Return the run's benchmark identity, preserving direct-run defaults."""
    value = getattr(config, "benchmark_gateway_id", None) if config is not None else None
    return value if isinstance(value, str) and value else _BENCHMARK_GATEWAY_ID

_TOOL_RESOURCE_KB_SCHEMAS = {
    "runtime-tool-resource-kb.json": "runtime_tool_resource_kb_v4",
    "clause-resource-kb.json": "runtime_clause_resource_kb_v7",
    "clause-lattice-time-kb.json": "clause_lattice_kb_v4",
}
_OPTIONAL_TOOL_RESOURCE_KB_SCHEMAS = {"edge-kappa-kb.json": "edge-kappa-kb.v1"}


def _kb_snapshot_names(directory: Path) -> tuple[str, ...]:
    return (*_TOOL_RESOURCE_KB_SCHEMAS, *(
        name for name in _OPTIONAL_TOOL_RESOURCE_KB_SCHEMAS
        if (directory / name).exists()
    ))


_TASK_CLEANUP_TIMEOUT_SECONDS = 15.0
_DISCOVERY_COMMAND_TIMEOUT_SECONDS = 5.0
_SUBPROCESS_POPEN_TYPE = subprocess.Popen


class KnowledgeBaseSyncError(RuntimeError):
    """A shared KB generation could not be copied or published safely."""


class TaskDeadlineExceeded(TimeoutError):
    """The whole-task wall-clock budget expired."""


def _task_deadline(config: RunnerConfig, started: float) -> float | None:
    seconds = config.batch.task_timeout_seconds
    return started + seconds if seconds > 0 else None


def _remaining_task_seconds(
    deadline: float | None,
    *,
    phase: str,
) -> float | None:
    check_cancelled()
    if deadline is None:
        return None
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TaskDeadlineExceeded(
            f"task timed out during {phase}; whole-task wall-clock budget exhausted"
        )
    return remaining


def _log(msg: str) -> None:
    with _print_lock:
        print(msg, file=sys.stderr, flush=True)


def run_host_openclaw_task(
    *,
    task: TaskDef,
    trace_dir: Path,
    config: RunnerConfig,
    runtime_assets_dir: Path,
    shared_kb_dir: Path | None = None,
    sidecar_port: int | None = None,
    shared_sidecar_trace_dir: Path | None = None,
    manage_sidecar: bool = True,
    post_sandbox_scope: bool = True,
) -> ContainerResult:
    """Run one task with host OpenClaw and OpenClaw Docker sandbox.

    The runner, never the OpenClaw plugin, owns the sidecar lifecycle.  With
    ``manage_sidecar=True`` this function owns a task-local sidecar.  Otherwise
    the batch runner owns the supplied shared sidecar and this function only
    drains and snapshots its runtime-specific output.
    """
    started = time.monotonic()
    gateway_id = _gateway_id(config)
    deadline = _task_deadline(config, started)
    trace_dir.mkdir(parents=True, exist_ok=True)
    workspace = _task_workspace(config, task)
    if not manage_sidecar and shared_sidecar_trace_dir is not None:
        _write_runtime_case_map(
            shared_sidecar_trace_dir,
            _runtime_id(workspace),
            task.instance_id,
        )
    openclaw_home = _task_openclaw_home(trace_dir)
    sidecar_port = sidecar_port or _free_port()
    sidecar = None
    sandbox_image: str | None = None
    exit_code = -1
    error: str | None = None
    agent_stopped = threading.Event()
    agent_cancelled = False

    try:
        _write_host_tool_resource_preflight(trace_dir, config, deadline=deadline)
        _remaining_task_seconds(deadline, phase="host telemetry preflight")
        _reset_directory(
            workspace,
            docker_cleanup_image=task.image,
            docker_platform=config.docker.platform,
            deadline=deadline,
        )
        _reset_directory(openclaw_home, deadline=deadline)
        _remaining_task_seconds(deadline, phase="workspace reset")
        _export_testbed_from_image(
            task.image,
            workspace,
            config.docker.pull_policy,
            config.docker.platform,
            deadline=deadline,
        )
        _make_sandbox_workspace_writable(workspace)
        _install_sandbox_runtime(workspace, runtime_assets_dir)
        _write_task_inputs(
            trace_dir,
            task,
            config,
            workspace,
            runtime_assets_dir,
            shared_kb_dir=shared_kb_dir,
        )
        sandbox_image = _ensure_openclaw_sandbox_image(
            task.image,
            trace_dir,
            config.docker.platform,
            runtime_id=_runtime_id(workspace),
            deadline=deadline,
        )
        _verify_sandbox_launcher(
            trace_dir,
            workspace,
            config.docker.platform,
            sandbox_image=sandbox_image,
            deadline=deadline,
        )
        _verify_sandbox_task_environment(
            trace_dir,
            workspace,
            config.docker.platform,
            sandbox_image=sandbox_image,
            deadline=deadline,
        )
        _remaining_task_seconds(deadline, phase="sandbox preflight")

        if manage_sidecar:
            _seed_runtime_tool_resource_kb(
                trace_dir,
                config,
                source_dir=shared_kb_dir,
            )

        if manage_sidecar:
            sidecar = _start_sidecar(
                trace_dir=trace_dir,
                port=sidecar_port,
                config=config,
                workspace=workspace,
                repo=task_repo_key(task),
                deadline=deadline,
            )
        _configure_openclaw(
            trace_dir=trace_dir,
            openclaw_home=openclaw_home,
            sidecar_port=sidecar_port,
            workspace=workspace,
            sandbox_image=sandbox_image,
            config=config,
            deadline=deadline,
        )
        cleanup_budget = _remaining_task_seconds(
            deadline,
            phase="pre-agent sandbox cleanup",
        )
        _cleanup_openclaw_sandbox_containers(
            trace_dir,
            workspace,
            timeout_seconds=min(
                _TASK_CLEANUP_TIMEOUT_SECONDS,
                cleanup_budget or _TASK_CLEANUP_TIMEOUT_SECONDS,
            ),
            strict=True,
        )
        _remaining_task_seconds(deadline, phase="agent setup")
        exit_code = _run_openclaw_agent(
            trace_dir=trace_dir,
            openclaw_home=openclaw_home,
            workspace=workspace,
            sidecar_port=sidecar_port,
            task=task,
            config=config,
            task_deadline=deadline,
            post_sandbox_scope=post_sandbox_scope,
            stopped_event=agent_stopped,
        )
        agent_stopped.set()
        timeout_record = _read_json_object(trace_dir / "task-timeout.json")
        if exit_code == 124 and isinstance(timeout_record, dict):
            error = str(timeout_record.get("message") or "task timed out")
        if exit_code != 124:
            # The recorded agent timeout owns the deadline. Every remaining
            # step would raise immediately (and overwrite its message), so
            # keep the first record instead of re-attributing the overrun.
            _remaining_task_seconds(deadline, phase="result collection")
            _cleanup_runtime_artifacts(workspace, deadline=deadline)
            _collect_patch(trace_dir, workspace, task, deadline=deadline)
    except TaskDeadlineExceeded as exc:
        exit_code = 124
        error = str(exc)
        _write_timeout_record(
            trace_dir,
            scope="task",
            message=error,
            configured_seconds=config.batch.task_timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        exit_code = 124
        error = (
            "task timed out while waiting for a setup subprocess: "
            f"{exc.cmd!r}"
        )
        _write_timeout_record(
            trace_dir,
            scope="task",
            message=error,
            configured_seconds=config.batch.task_timeout_seconds,
        )
    except TaskCancelled as exc:
        agent_cancelled = True
        error = str(exc)
        _write_text(trace_dir / "host_openclaw_error.txt", traceback.format_exc())
    except ContainerCleanupError:
        # The task-local sidecar/agent may still be able to mutate its KB.
        # Propagate instead of returning a result that _run_one would publish.
        raise
    except Exception as exc:
        error = str(exc)
        _write_text(trace_dir / "host_openclaw_error.txt", traceback.format_exc())
    except KeyboardInterrupt:
        agent_cancelled = True
        error = "interrupted by user"
        raise
    finally:
        cleanup_error: BaseException | None = None
        sandbox_stopped = False
        try:
            _cleanup_openclaw_sandbox_containers(
                trace_dir, workspace, timeout_seconds=_TASK_CLEANUP_TIMEOUT_SECONDS, strict=True,
            )
            sandbox_stopped = True
        except BaseException as exc:
            cleanup_error = exc
        if sandbox_stopped and agent_stopped.is_set() and (exit_code == 124 or agent_cancelled):
            try:
                _abort_runtime(
                    sidecar_port, _runtime_id(workspace), gateway_id=gateway_id,
                    reason=("cancelled" if agent_cancelled else "task_timeout"),
                    trace_dir=trace_dir,
                )
            except Exception as exc:
                _record_observation_issue(trace_dir, "runtime_finalization", exc)
        if not manage_sidecar and shared_sidecar_trace_dir is not None:
            runtime_id = _runtime_id(workspace)
            try:
                _drain_runtime(
                    sidecar_port,
                    runtime_id,
                    gateway_id=gateway_id,
                    flush_kb=getattr(config, "flush_kb_on_task_drain", True),
                )
            except Exception as exc:
                # A failed drain means the snapshot may be incomplete, but it
                # must not make already durable telemetry disappear.  This is
                # especially important when one shared sidecar serves many
                # concurrent runtimes: the batch owner remains alive and the
                # per-runtime JSONL files are still the best diagnostic record.
                _record_observation_issue(trace_dir, "runtime_drain", exc)
            try:
                _collect_runtime_traces(
                    shared_sidecar_trace_dir,
                    trace_dir,
                    runtime_id,
                    task_label=_safe_trace_label(task.instance_id),
                )
                _collect_runtime_ebpf_artifacts(
                    shared_kb_dir,
                    trace_dir,
                )
            except Exception as exc:
                _record_observation_issue(trace_dir, "trace_snapshot", exc)
            finally:
                _delete_runtime_scope(
                    sidecar_port,
                    runtime_id,
                    gateway_id=gateway_id,
                )
        try:
            if not sandbox_stopped:
                _cleanup_openclaw_sandbox_containers(
                    trace_dir, workspace, timeout_seconds=_TASK_CLEANUP_TIMEOUT_SECONDS, strict=True,
                )
        except BaseException as exc:
            cleanup_error = cleanup_error or exc
        finally:
            try:
                if sidecar is not None:
                    _stop_process(sidecar)
            except BaseException as exc:
                cleanup_error = cleanup_error or exc
            if sandbox_image is not None:
                _remove_sandbox_image(sandbox_image)
            if cleanup_error is not None and error is None:
                error = f"task cleanup failed: {cleanup_error}"
            _write_result_summary(trace_dir, task, workspace, exit_code, error)
        if cleanup_error is not None:
            raise cleanup_error

    return ContainerResult(
        task_id=task.instance_id,
        image=task.image,
        exit_code=exit_code,
        error=error,
        trace_dir=trace_dir,
        trace_files=sorted(trace_dir.glob("*.jsonl")),
        duration_seconds=time.monotonic() - started,
    )


def run_host_openclaw_replay_task(
    *,
    task: TaskDef,
    trace_dir: Path,
    config: RunnerConfig,
    runtime_assets_dir: Path,
    source_trace: Path,
    timing: str = "exact",
    timing_scale: float = 1.0,
) -> ContainerResult:
    """Replay one trace using the normal host-openclaw topology.

    The task image is exported and configured exactly like a normal benchmark
    case. Only the model endpoint is replaced by a local deterministic replay
    server; OpenClaw, its Docker sandbox, the plugin, sidecar, launcher, cgroup
    scope, and eBPF collector remain the normal production path.
    """
    from swe_rebench.replay import ReplayLLMServer, load_replay_plan, write_replay_manifest

    started = time.monotonic()
    deadline = _task_deadline(config, started)
    trace_dir.mkdir(parents=True, exist_ok=True)
    workspace = _task_workspace(config, task).with_name(
        _task_workspace(config, task).name + "-replay"
    )
    openclaw_home = _task_openclaw_home(trace_dir)
    sidecar = None
    sandbox_image: str | None = None
    server = None
    exit_code = -1
    error: str | None = None
    agent_stopped = threading.Event()
    agent_cancelled = False
    try:
        plan = load_replay_plan(source_trace)
        if plan.incomplete_tool_count:
            _log(
                f"[replay] source has {plan.incomplete_tool_count} incomplete tool spans; "
                "replaying only complete causal model responses"
            )
        _write_host_tool_resource_preflight(trace_dir, config, deadline=deadline)
        _reset_directory(
            workspace,
            docker_cleanup_image=task.image,
            docker_platform=config.docker.platform,
            deadline=deadline,
        )
        _reset_directory(openclaw_home, deadline=deadline)
        _export_testbed_from_image(
            task.image,
            workspace,
            config.docker.pull_policy,
            config.docker.platform,
            deadline=deadline,
        )
        _make_sandbox_workspace_writable(workspace)
        _install_sandbox_runtime(workspace, runtime_assets_dir)
        _write_task_inputs(
            trace_dir,
            task,
            config,
            workspace,
            runtime_assets_dir,
            shared_kb_dir=None,
        )
        _write_text(
            trace_dir / "replay_prompt.txt",
            "Replay mode: reproduce the recorded SWE-Rebench interaction. "
            "Use the tools requested by the model and do not contact external services.\n",
        )
        sandbox_image = _ensure_openclaw_sandbox_image(
            task.image,
            trace_dir,
            config.docker.platform,
            runtime_id=_runtime_id(workspace),
            deadline=deadline,
        )
        _verify_sandbox_launcher(
            trace_dir,
            workspace,
            config.docker.platform,
            sandbox_image=sandbox_image,
            deadline=deadline,
        )
        _verify_sandbox_task_environment(
            trace_dir,
            workspace,
            config.docker.platform,
            sandbox_image=sandbox_image,
            deadline=deadline,
        )
        _seed_runtime_tool_resource_kb(trace_dir, config)
        sidecar_port = _free_port()
        sidecar = _start_sidecar(
            trace_dir=trace_dir,
            port=sidecar_port,
            config=config,
            workspace=workspace,
            repo=task_repo_key(task),
            deadline=deadline,
        )
        server = ReplayLLMServer(plan, timing=timing, scale=timing_scale)
        server.start()
        _configure_openclaw(
            trace_dir=trace_dir,
            openclaw_home=openclaw_home,
            sidecar_port=sidecar_port,
            workspace=workspace,
            sandbox_image=sandbox_image,
            config=config,
            deadline=deadline,
            model_endpoint=server.base_url,
            model_api_key="clawtune-replay",
            model_id=plan.model,
        )
        _cleanup_openclaw_sandbox_containers(
            trace_dir,
            workspace,
            timeout_seconds=_TASK_CLEANUP_TIMEOUT_SECONDS,
            strict=True,
        )
        exit_code = _run_openclaw_agent(
            trace_dir=trace_dir,
            openclaw_home=openclaw_home,
            workspace=workspace,
            sidecar_port=sidecar_port,
            task=task,
            config=config,
            task_deadline=deadline,
            post_sandbox_scope=True,
            prompt_path=trace_dir / "replay_prompt.txt",
            model_ref=plan.model,
            stopped_event=agent_stopped,
        )
        _remaining_task_seconds(deadline, phase="replay result collection")
        _cleanup_runtime_artifacts(workspace, deadline=deadline)
        _collect_patch(trace_dir, workspace, task, deadline=deadline)
        write_replay_manifest(
            trace_dir / "replay_manifest.json",
            plan=plan,
            task_id=task.instance_id,
            image=task.image,
            timing=timing,
            scale=timing_scale,
            requests=server.requests if server is not None else None,
            result={"exit_code": exit_code, "error": error},
        )
    except TaskDeadlineExceeded as exc:
        exit_code = 124
        error = str(exc)
        _write_timeout_record(
            trace_dir,
            scope="replay",
            message=error,
            configured_seconds=config.batch.task_timeout_seconds,
        )
    except TaskCancelled as exc:
        agent_cancelled = True
        error = str(exc)
        _write_text(trace_dir / "replay_error.txt", traceback.format_exc())
    except Exception as exc:
        error = str(exc)
        _write_text(trace_dir / "replay_error.txt", traceback.format_exc())
    finally:
        if server is not None:
            server.close()
        sandbox_stopped = False
        try:
            _cleanup_openclaw_sandbox_containers(
                trace_dir,
                workspace,
                timeout_seconds=_TASK_CLEANUP_TIMEOUT_SECONDS,
                strict=True,
            )
            sandbox_stopped = True
        except Exception as exc:
            if error is None:
                error = f"replay sandbox cleanup failed: {exc}"
        if sandbox_stopped and agent_stopped.is_set() and (exit_code == 124 or agent_cancelled):
            try:
                _abort_runtime(
                    sidecar_port,
                    _runtime_id(workspace),
                    gateway_id=_gateway_id(config),
                    reason="cancelled" if agent_cancelled else "task_timeout",
                    trace_dir=trace_dir,
                )
            except Exception as exc:
                _record_observation_issue(trace_dir, "runtime_finalization", exc)
        if sidecar is not None:
            _stop_process(sidecar)
        if sandbox_image is not None:
            _remove_sandbox_image(sandbox_image)
        _write_result_summary(trace_dir, task, workspace, exit_code, error)

    return ContainerResult(
        task_id=task.instance_id,
        image=task.image,
        exit_code=exit_code,
        error=error,
        trace_dir=trace_dir,
        trace_files=sorted(trace_dir.glob("*.jsonl")),
        duration_seconds=time.monotonic() - started,
    )


def _task_workspace(config: RunnerConfig, task: TaskDef) -> Path:
    safe_id = getattr(config, "task_directory", None) or task.instance_id.replace("/", "_").replace(":", "_")
    return config.output.trace_root.parent / "workspaces" / safe_id


def _export_testbed_from_image(
    image: str,
    workspace: Path,
    pull_policy: str,
    platform: str = "",
    *,
    deadline: float | None = None,
) -> None:
    docker = _require_executable("docker")
    if pull_policy != "never":
        pull = [docker, "pull", *_docker_platform_args(platform), image]
        if pull_policy == "missing" and local_image_available(
            None, image, platform, docker_executable=docker,
            timeout=_remaining_task_seconds(deadline, phase="task image inspection"),
        ):
            pull = []
        if pull:
            if deadline is None:
                _run_checked(pull, "docker_pull")
            else:
                _run_checked(
                    pull,
                    "docker_pull",
                    timeout=_remaining_task_seconds(deadline, phase="task image pull"),
                )

    create = subprocess.run(
        [docker, "create", *_docker_platform_args(platform), image],
        capture_output=True,
        text=True,
        check=True,
        timeout=_remaining_task_seconds(deadline, phase="task container creation"),
    )
    container_id = create.stdout.strip()
    try:
        copy_command = [docker, "cp", f"{container_id}:/testbed/.", str(workspace)]
        if deadline is None:
            _run_checked(copy_command, "docker_cp_testbed")
        else:
            _run_checked(
                copy_command,
                "docker_cp_testbed",
                timeout=_remaining_task_seconds(deadline, phase="repository export"),
            )
    finally:
        try:
            subprocess.run(
                [docker, "rm", "-f", container_id],
                capture_output=True,
                text=True,
                timeout=_TASK_CLEANUP_TIMEOUT_SECONDS,
            )
        except subprocess.TimeoutExpired as exc:
            raise ContainerCleanupError(
                f"timed out removing export container {container_id}"
            ) from exc


def _make_sandbox_workspace_writable(workspace: Path) -> None:
    """Expose a sudo-exported repository to OpenClaw's unprivileged uid.

    ``docker cp`` preserves image ownership, while this runner normally runs
    as root for BPF. OpenClaw's tool container must still be able to traverse
    and edit the isolated task tree.
    """

    workspace.chmod(workspace.stat().st_mode | 0o777)
    for path in workspace.rglob("*"):
        # Do not follow a repository symlink and chmod a target outside this
        # isolated workspace.
        if path.is_symlink():
            continue
        if path.is_dir():
            path.chmod(path.stat().st_mode | 0o777)
        elif path.is_file():
            path.chmod(path.stat().st_mode | 0o666)


def _ensure_openclaw_sandbox_image(
    task_image: str,
    trace_dir: Path,
    platform: str = "",
    *,
    runtime_id: str | None = None,
    deadline: float | None = None,
) -> str:
    """Create a runtime-private tag for the OpenClaw sandbox image.

    A global ``openclaw-sandbox:bookworm-slim`` tag is unsafe: concurrent
    cases can retag it to different task images between configuration and
    container creation.  The runtime ID is unique per isolated workspace.
    """
    if runtime_id is None:
        runtime_id = "image-" + hashlib.sha256(
            task_image.encode("utf-8")
        ).hexdigest()[:20]
    sandbox_image = f"clawtune-sandbox:{runtime_id}"
    docker = _require_executable("docker")

    log_path = trace_dir / "sandbox-image-build.log"
    with log_path.open("w", encoding="utf-8") as log:
        result = subprocess.run(
            [docker, "tag", task_image, sandbox_image],
            stdout=log,
            stderr=log,
            text=True,
            timeout=_remaining_task_seconds(deadline, phase="sandbox image tagging"),
        )
    if result.returncode != 0:
        raise RuntimeError(
            f"openclaw_sandbox_image_tag_failed exit={result.returncode}: "
            f"{_tail_text(log_path, 2000)}"
        )
    return sandbox_image


def _remove_sandbox_image(sandbox_image: str) -> None:
    docker = shutil.which("docker")
    if docker is None or not sandbox_image.startswith("clawtune-sandbox:"):
        return
    try:
        subprocess.run(
            [docker, "image", "rm", sandbox_image],
            capture_output=True,
            text=True,
            timeout=_TASK_CLEANUP_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired):
        pass


def _verify_sandbox_launcher(
    trace_dir: Path,
    workspace: Path,
    platform: str = "",
    *,
    sandbox_image: str = "openclaw-sandbox:bookworm-slim",
    deadline: float | None = None,
) -> None:
    """Verify launcher mode and the environment its payload will inherit."""

    docker = _require_executable("docker")
    log_path = trace_dir / "launcher-preflight.log"
    container_name = (
        f"{_sandbox_container_prefix(workspace)}launcher-preflight-"
        f"{os.getpid()}-{threading.get_ident()}"
    )
    result = run_command(
        [
            docker,
            "run",
            "--rm",
            "--name",
            container_name,
            *_docker_platform_args(platform),
            "--network",
            "none",
            "--env",
            "CLAWTUNE_LAUNCH_MODE=fork-exec",
            "--user",
            "65534:65534",
            "--mount",
            f"type=bind,src={workspace},dst=/workspace",
            "--workdir",
            "/workspace",
            "--entrypoint",
            "/bin/sh",
            sandbox_image,
            "/workspace/.clawtune/bin/clawtune-launch",
            "diagnose",
        ],
        capture_output=True,
        text=True,
        timeout=_remaining_task_seconds(deadline, phase="launcher preflight"),
    )
    _write_text(log_path, (result.stdout or "") + (result.stderr or ""))
    if result.returncode != 0:
        raise RuntimeError(
            "sandbox_launcher_preflight_failed: the mounted clawtune-launch must "
            "be readable and select a supported fork-exec runtime in the "
            f"sandbox: {_tail_text(log_path, 2000)}"
        )
    python_markers = ("pyproject.toml", "setup.py", "setup.cfg", "requirements.txt")
    if not any((workspace / marker).is_file() for marker in python_markers):
        return
    try:
        diagnostics = json.loads((result.stdout or "").strip().splitlines()[-1])
    except (json.JSONDecodeError, IndexError):
        diagnostics = {}
    python3 = diagnostics.get("payload_python3")
    if not (
        isinstance(python3, str)
        and python3.startswith(
            (
                "/opt/miniconda3/envs/testbed/bin/",
                "/opt/conda/envs/testbed/bin/",
            )
        )
        and diagnostics.get("payload_pip") == "/workspace/.clawtune/bin/pip"
        and diagnostics.get("payload_pip3") == "/workspace/.clawtune/bin/pip3"
    ):
        raise RuntimeError(
            "sandbox_launcher_payload_environment_failed: managed-wrapper "
            "payload must resolve testbed python and mounted pip wrappers: "
            f"{_tail_text(log_path, 2000)}"
        )


def _verify_sandbox_task_environment(
    trace_dir: Path,
    workspace: Path,
    platform: str = "",
    *,
    sandbox_image: str = "openclaw-sandbox:bookworm-slim",
    deadline: float | None = None,
) -> None:
    """Fail early when a Python task would fall back outside its testbed env."""

    python_markers = (
        "pyproject.toml",
        "setup.py",
        "setup.cfg",
        "requirements.txt",
    )
    if not any((workspace / marker).is_file() for marker in python_markers):
        return
    docker = _require_executable("docker")
    log_path = trace_dir / "sandbox-runtime-preflight.log"
    container_name = (
        f"{_sandbox_container_prefix(workspace)}runtime-preflight-"
        f"{os.getpid()}-{threading.get_ident()}"
    )
    script = (
        "set -eu\n"
        "printf 'PATH=%s\\n' \"$PATH\"\n"
        "printf 'python3=%s\\n' \"$(command -v python3)\"\n"
        "python3 -c 'import sys; print(sys.executable)'\n"
        "python3 -m pip --version\n"
        "printf 'pip=%s\\n' \"$(command -v pip)\"\n"
        "pip --version\n"
        "printf 'pip3=%s\\n' \"$(command -v pip3)\"\n"
        "pip3 --version\n"
    )
    with log_path.open("w", encoding="utf-8") as log:
        result = subprocess.run(
            [
                docker,
                "run",
                "--rm",
                "--name",
                container_name,
                *_docker_platform_args(platform),
                "--network",
                "none",
                "--env",
                f"PATH={_SANDBOX_TASK_PATH}",
                "--user",
                "65534:65534",
                "--mount",
                f"type=bind,src={workspace},dst=/workspace",
                "--workdir",
                "/workspace",
                "--entrypoint",
                "/bin/sh",
                sandbox_image,
                "-c",
                script,
            ],
            stdout=log,
            stderr=log,
            text=True,
            timeout=_remaining_task_seconds(
                deadline,
                phase="sandbox runtime preflight",
            ),
        )
    if result.returncode != 0:
        raise RuntimeError(
            "sandbox_task_environment_preflight_failed: the Python task image "
            "must expose its testbed python and pip to the OpenClaw sandbox: "
            f"{_tail_text(log_path, 2000)}"
        )


def _install_sandbox_runtime(workspace: Path, runtime_assets_dir: Path) -> None:
    """Stage the launcher and Sidecar sources used inside a tool sandbox."""

    sidecar_src = runtime_assets_dir / "sidecar" / "src"
    target_src = workspace / ".clawtune" / "sidecar" / "src"
    target_bin = workspace / ".clawtune" / "bin"
    if not sidecar_src.exists():
        raise FileNotFoundError(
            f"sidecar source not found in runtime assets: {sidecar_src}"
        )
    if target_src.parent.exists():
        shutil.rmtree(target_src.parent)
    shutil.copytree(sidecar_src, target_src)
    target_bin.mkdir(parents=True, exist_ok=True)
    launcher = target_bin / "clawtune-launch"
    launcher.write_text(
        "#!/bin/sh\n"
        f'export PATH="{_SANDBOX_TASK_PATH}"\n'
        "export CLAWTUNE_LAUNCHER_PYTHONPATH=/workspace/.clawtune/sidecar/src\n"
        "export PYTHONPATH=\"$CLAWTUNE_LAUNCHER_PYTHONPATH${PYTHONPATH:+:$PYTHONPATH}\"\n"
        # Prefer a modern system interpreter but support images whose only
        # Python is under /usr/local or a Conda prefix.  The payload itself
        # still inherits _SANDBOX_TASK_PATH.
        "_CLAWTUNE_LAUNCHER_PYTHON=\n"
        "for _candidate in \"${CLAWTUNE_LAUNCHER_PYTHON:-}\" /usr/bin/python3 "
        "/usr/local/bin/python3 \"$(command -v python3 2>/dev/null || true)\"; do\n"
        "  [ -n \"$_candidate\" ] && [ -x \"$_candidate\" ] || continue\n"
        "  if \"$_candidate\" -c 'import sys; assert sys.version_info >= (3, 10)' "
        ">/dev/null 2>&1; then _CLAWTUNE_LAUNCHER_PYTHON=$_candidate; break; fi\n"
        "done\n"
        "if [ -z \"$_CLAWTUNE_LAUNCHER_PYTHON\" ]; then "
        "echo 'clawtune-launch: Python >=3.10 is unavailable' >&2; exit 127; fi\n"
        "exec \"$_CLAWTUNE_LAUNCHER_PYTHON\" -m clawtune_sidecar.launcher \"$@\"\n",
        encoding="utf-8",
    )
    # The runner is commonly invoked through ``sudo -E`` for BPF access.
    # A restrictive root umask can otherwise leave the intermediate .clawtune
    # directories at 0700 and this script at 0711.  The sandbox user then
    # cannot traverse/read the interpreted script and every exec fails with
    # exit 126 before clawtune-launch can claim the execution.  Use explicit
    # container-facing permissions instead of merely adding execute bits.
    _make_sandbox_runtime_readable(workspace / ".clawtune", target_src)
    launcher.chmod(0o755)
    for pip_name in ("pip", "pip3"):
        pip_wrapper = target_bin / pip_name
        pip_wrapper.write_text(
            "#!/bin/sh\nexec python3 -m pip \"$@\"\n",
            encoding="utf-8",
        )
        pip_wrapper.chmod(0o755)


def _make_sandbox_runtime_readable(runtime_root: Path, sidecar_src: Path) -> None:
    """Make the mounted launcher runtime readable by the sandbox uid.

    Only the private ``.clawtune`` runtime is changed.  Task repository modes are
    preserved, and regular sidecar source files do not gain execute bits.
    """

    for directory in (
        runtime_root,
        runtime_root / "sidecar",
        sidecar_src,
        runtime_root / "bin",
    ):
        directory.chmod(directory.stat().st_mode | 0o555)
    for path in sidecar_src.rglob("*"):
        if path.is_dir():
            path.chmod(path.stat().st_mode | 0o555)
        elif path.is_file():
            path.chmod(path.stat().st_mode | 0o444)


def _task_openclaw_home(trace_dir: Path) -> Path:
    """Keep agent session state outside exported experiment traces."""
    return trace_dir.parent.parent / "runtime" / trace_dir.name / "openclaw-home"


def _start_sidecar(
    *,
    trace_dir: Path,
    port: int,
    config: RunnerConfig,
    workspace: Path,
    repo: str,
    artifact_dir: Path | None = None,
    sandbox_container_prefix: str | None = None,
    deadline: float | None = None,
    trace_paths: dict[str, Path] | None = None,
) -> subprocess.Popen[str]:
    env = os.environ.copy()
    if trace_paths is None and sandbox_container_prefix != "":
        trace_paths = {_runtime_id(workspace): trace_dir / "trace.jsonl"}
    env["CLAWTUNE_TRACE_RUNTIME_PATHS"] = json.dumps({
        json.dumps([_gateway_id(config), runtime], separators=(",", ":")): str(path.resolve())
        for runtime, path in (trace_paths or {}).items()
    })
    scheduler_src = str(config.repo_root / "services" / "sidecar" / "src")
    existing_pythonpath = env.get("PYTHONPATH")
    env.update(
        {
            "PYTHONPATH": (
                scheduler_src
                if not existing_pythonpath
                else scheduler_src + os.pathsep + existing_pythonpath
            ),
            "CLAWTUNE_DB_PATH": str(trace_dir / "sidecar.sqlite3"),
            "CLAWTUNE_TRACE_DIR": str(trace_dir),
            "CLAWTUNE_LLM_UPSTREAM_BASE_URL": config.llm.upstream_base_url,
            "CLAWTUNE_LLM_UPSTREAM_API_KEY": config.llm.api_key,
            "CLAWTUNE_LLM_PROXY_ENABLED": "true",
            "CLAWTUNE_LLM_PROXY_EXPOSE_MODEL": config.llm.model,
            "CLAWTUNE_LLM_PROXY_UPSTREAM_MODEL": config.llm.model,
            "CLAWTUNE_POLICY": "observe-only",
            "CLAWTUNE_DOCKER_EXEC_OBSERVER": "true",
            "CLAWTUNE_DOCKER_EXEC_CONTAINER_PREFIX": (
                _sandbox_container_prefix(workspace)
                if sandbox_container_prefix is None
                else sandbox_container_prefix
            ),
            "CLAWTUNE_TOOL_RESOURCE_EBPF_REQUIRED": (
                "true" if config.runtime.ebpf_required else "false"
            ),
            "CLAWTUNE_TOOL_RESOURCE_REPO": repo,
            "CLAWTUNE_TOOL_RESOURCE_FROZEN": "true" if config.runtime.kb_frozen else "false",
            "CLAWTUNE_TOOL_RESOURCE_ARTIFACT_DIR": str(
                artifact_dir or trace_dir / "tool-resource"
            ),
        }
    )
    stdout = (trace_dir / "sidecar-stdout.txt").open("w", encoding="utf-8")
    stderr = (trace_dir / "sidecar-stderr.txt").open("w", encoding="utf-8")
    try:
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "clawtune_sidecar.main",
                "--host",
                "0.0.0.0",
                "--port",
                str(port),
            ],
            cwd=str(config.repo_root / "services" / "sidecar"),
            env=env,
            stdout=stdout,
            stderr=stderr,
            text=True,
        )
    finally:
        # Popen duplicates/inherits these handles.  The parent must not retain
        # two descriptors per task across a long serial benchmark.
        stdout.close()
        stderr.close()
    stderr_path = trace_dir / "sidecar-stderr.txt"
    try:
        if deadline is None:
            _wait_ready(port, process=process, stderr_path=stderr_path)
        else:
            remaining = _remaining_task_seconds(deadline, phase="sidecar startup")
            if remaining is not None and remaining < 60.0:
                _wait_ready(
                    port,
                    timeout_seconds=remaining,
                    process=process,
                    stderr_path=stderr_path,
                )
            else:
                _wait_ready(port, process=process, stderr_path=stderr_path)
    except BaseException:
        # Do not let an unreturned process keep mutating this task's KB while
        # the batch runner publishes it for the next task.
        _stop_process(process)
        raise
    return process


def _prepare_batch_tool_resource_kb(
    shared_kb_dir: Path,
    config: RunnerConfig,
) -> None:
    """Initialize one run-scoped shared KB from the tracked cold-start seed."""

    source_dir = config.repo_root / "seeds" / "bootstrap-v1"
    try:
        _validate_kb_snapshot_pair(source_dir)
        shared_kb_dir.mkdir(parents=True, exist_ok=False)
        for filename in _kb_snapshot_names(source_dir):
            _atomic_copy(source_dir / filename, shared_kb_dir / filename)
        if config.runtime.kb_frozen:
            for name in ("seed-manifest.json", "split-manifest.json", "test-tasks.json"):
                if (source_dir / name).is_file():
                    _atomic_copy(source_dir / name, shared_kb_dir / name)
        _validate_kb_snapshot_pair(shared_kb_dir)
    except KnowledgeBaseSyncError:
        raise
    except Exception as exc:
        raise KnowledgeBaseSyncError(
            f"failed to initialize shared KB {shared_kb_dir}: {exc}"
        ) from exc


def _seed_runtime_tool_resource_kb(
    trace_dir: Path,
    config: RunnerConfig,
    *,
    source_dir: Path | None = None,
) -> None:
    """Copy the repo's pre-seeded predictor KBs to the task trace directory.

    The release seed contains small generic TrieKB/LatticeKB priors and an
    empty ToolKB. Whole-call/PMU evidence accumulates online; clause priors
    must not be relabeled as observed whole-call measurements.
    """
    dest_dir = trace_dir / "tool-resource"
    dest_dir.mkdir(parents=True, exist_ok=True)
    source_dir = source_dir or config.repo_root / "seeds" / "bootstrap-v1"
    try:
        _validate_kb_snapshot_pair(source_dir)
        for filename in _kb_snapshot_names(source_dir):
            dest = dest_dir / filename
            source = source_dir / filename
            if config.runtime.kb_frozen or not dest.exists():
                _atomic_copy(source, dest)
        if config.runtime.kb_frozen:
            for name in _OPTIONAL_TOOL_RESOURCE_KB_SCHEMAS:
                if not (source_dir / name).exists():
                    (dest_dir / name).unlink(missing_ok=True)
            for name in ("seed-manifest.json", "split-manifest.json", "test-tasks.json"):
                if (source_dir / name).is_file():
                    _atomic_copy(source_dir / name, dest_dir / name)
        _validate_kb_snapshot_pair(dest_dir)
    except KnowledgeBaseSyncError:
        raise
    except Exception as exc:
        raise KnowledgeBaseSyncError(
            f"failed to seed task KB {dest_dir} from {source_dir}: {exc}"
        ) from exc


def _publish_tool_resource_kb(trace_dir: Path, shared_kb_dir: Path) -> None:
    """Publish a completed task's valid KB generation for the next serial task."""

    source_dir = trace_dir / "tool-resource"
    # Stage and validate every file before committing any one. Preserve a
    # complete rollback generation so an I/O failure during replace cannot
    # expose a mixed generation to the next task.
    try:
        _validate_kb_snapshot_pair(source_dir)
        _validate_kb_snapshot_pair(shared_kb_dir)
        source_names = _kb_snapshot_names(source_dir)
        backup_names = _kb_snapshot_names(shared_kb_dir)
        if set(backup_names) - set(source_names):
            raise KnowledgeBaseSyncError("task KB generation is missing an existing optional snapshot")
        with tempfile.TemporaryDirectory(
            prefix=".kb-publish-",
            dir=shared_kb_dir.parent,
        ) as temporary_root:
            root = Path(temporary_root)
            staged_dir = root / "staged"
            backup_dir = root / "backup"
            staged_dir.mkdir()
            backup_dir.mkdir()
            for filename in source_names:
                _atomic_copy(source_dir / filename, staged_dir / filename)
            for filename in backup_names:
                _atomic_copy(shared_kb_dir / filename, backup_dir / filename)
            _validate_kb_snapshot_pair(staged_dir)
            _validate_kb_snapshot_pair(backup_dir)
            try:
                for filename in source_names:
                    os.replace(staged_dir / filename, shared_kb_dir / filename)
                _validate_kb_snapshot_pair(shared_kb_dir)
            except Exception as commit_exc:
                try:
                    for filename in backup_names:
                        _atomic_copy(backup_dir / filename, shared_kb_dir / filename)
                    for filename in set(source_names) - set(backup_names):
                        (shared_kb_dir / filename).unlink(missing_ok=True)
                    _validate_kb_snapshot_pair(shared_kb_dir)
                except Exception as rollback_exc:
                    raise KnowledgeBaseSyncError(
                        "shared KB publish and rollback both failed: "
                        f"publish={commit_exc}; rollback={rollback_exc}"
                    ) from rollback_exc
                raise KnowledgeBaseSyncError(
                    f"shared KB publish failed and was rolled back: {commit_exc}"
                ) from commit_exc
    except KnowledgeBaseSyncError:
        raise
    except Exception as exc:
        raise KnowledgeBaseSyncError(
            f"failed to publish task KB {source_dir} to {shared_kb_dir}: {exc}"
        ) from exc


def _validate_kb_snapshot_pair(directory: Path) -> None:
    schemas = {**_TOOL_RESOURCE_KB_SCHEMAS, **_OPTIONAL_TOOL_RESOURCE_KB_SCHEMAS}
    for filename in _kb_snapshot_names(directory):
        schema_prefix = schemas[filename]
        path = directory / filename
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError as exc:
            raise KnowledgeBaseSyncError(
                f"required KB snapshot is missing: {path}"
            ) from exc
        except (OSError, json.JSONDecodeError) as exc:
            raise KnowledgeBaseSyncError(
                f"invalid KB snapshot {path}: {exc}"
            ) from exc
        schema = payload.get("schema") if isinstance(payload, dict) else None
        if schema != schema_prefix:
            raise KnowledgeBaseSyncError(
                f"invalid KB snapshot schema in {path}: {schema!r}; "
                f"expected {schema_prefix!r}"
            )
        if filename == "edge-kappa-kb.json":
            try:
                from clawtune_kb.contracts import validate
                from clawtune_sidecar.predictors.edge_kappa import EdgeKappaRuntime
                validate(payload, "edge-kappa-kb.schema.json")
                EdgeKappaRuntime.from_snapshot(payload)
            except Exception as exc:
                raise KnowledgeBaseSyncError(
                    f"scheduler rejected KB snapshot {path}: {exc}"
                ) from exc
            continue
        if filename == "clause-lattice-time-kb.json":
            _validate_lattice_time_kb_snapshot(path, payload)
        else:
            if payload.get("max_prefix_depth") != 4:
                raise KnowledgeBaseSyncError(
                    f"invalid KB snapshot max_prefix_depth in {path}: "
                    f"{payload.get('max_prefix_depth')!r}"
                )
            for field in ("public", "repo"):
                if not isinstance(payload.get(field), dict):
                    raise KnowledgeBaseSyncError(
                        f"invalid KB snapshot {path}: {field!r} must be an object"
                    )
        if not isinstance(payload.get("pending"), list):
            raise KnowledgeBaseSyncError(
                f"invalid KB snapshot {path}: 'pending' must be an array"
            )
        try:
            # Use the scheduler's own deserializer as the final authority so a
            # snapshot accepted here is guaranteed to be loadable by sidecar.
            from tool_resource.runtime_kb import (
                ClauseResourceKB,
                RuntimeToolResourceKB,
            )
            if filename == "runtime-tool-resource-kb.json":
                RuntimeToolResourceKB.from_json_obj(payload)
            elif filename == "clause-resource-kb.json":
                ClauseResourceKB.from_json_obj(payload)
        except Exception as exc:
            raise KnowledgeBaseSyncError(
                f"scheduler rejected KB snapshot {path}: {exc}"
            ) from exc


def _validate_lattice_time_kb_snapshot(path: Path, payload: dict[str, Any]) -> None:
    """Validate the portable flat-lattice snapshot without scheduler imports.

    The benchmark runner is also imported from environments that expose the
    installed ``tool_resource`` package but not this checkout's new
    ``tool_time`` module.  Keep the atomic hand-off validator self-contained;
    the sidecar still uses ``LatticeTimeKB.from_json_obj`` when it loads the
    snapshot.
    """

    expected_generation = {
        "mode": "bounded",
        "max_optional_features": 6,
        "min_partial_support": 1,
        "max_nodes_per_signature": 4_096,
        "node_occurrence_budget": 20_000,
        "max_shrinkage_candidates": 512,
    }
    generation = payload.get("node_generation")
    if not isinstance(generation, dict) or (
        {key: value for key, value in generation.items()
         if key != "subset_coverage"} != expected_generation
        or ("subset_coverage" in generation
            and type(generation["subset_coverage"]) is not bool)
    ):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB node_generation in {path}: "
            f"{payload.get('node_generation')!r}"
        )
    observations = payload.get("observations")
    if not isinstance(observations, list):
        raise KnowledgeBaseSyncError(
            f"invalid KB snapshot {path}: 'observations' must be an array"
        )
    pending = payload.get("pending")
    if not isinstance(pending, list):
        raise KnowledgeBaseSyncError(
            f"invalid KB snapshot {path}: 'pending' must be an array"
        )
    for collection_name, rows in (("observations", observations), ("pending", pending)):
        for index, row in enumerate(rows):
            _validate_lattice_time_observation(
                path,
                row,
                location=f"{collection_name}[{index}]",
                allow_resource_only=payload.get("schema") == "clause_lattice_kb_v4",
            )
    last_query_ts = payload.get("last_query_ts")
    if last_query_ts is not None and not _is_finite_number(last_query_ts):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB last_query_ts in {path}: {last_query_ts!r}"
        )


def _validate_lattice_time_observation(
    path: Path,
    row: Any,
    *,
    location: str,
    allow_resource_only: bool = False,
) -> None:
    if not isinstance(row, dict):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: must be an object"
        )
    allowed = {
        "repo",
        "bin",
        "argv",
        "ts_start",
        "ts_end",
        "latency_ms",
        "cpu_peak_cores",
        "sampled_peak_rss_mb",
        "cpu_ns_cumulative",
        "in_loop",
        "in_pipe",
        "in_subst",
        "pipeline_position",
        "stdin_from_pipe",
        "memory_baseline_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes",
        "memory_measurement", "memory_environment_id", "memory_eligible",
    }
    unknown = sorted(row.keys() - allowed)
    if unknown:
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            f"unknown fields {unknown!r}"
        )
    required = {"repo", "bin", "argv", "ts_start", "ts_end", "latency_ms"}
    missing = sorted(required - row.keys())
    if missing:
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            f"missing {missing!r}"
        )
    if (
        not isinstance(row["repo"], str)
        or not isinstance(row["bin"], str)
        or not row["bin"]
    ):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            "repo must be a string and bin must be a non-empty string"
        )
    argv = row["argv"]
    if not isinstance(argv, list) or not argv or not all(
        isinstance(value, str) for value in argv
    ):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            "argv must be a non-empty string array"
        )
    ts_start = row["ts_start"]
    ts_end = row["ts_end"]
    if not (_is_finite_number(ts_start) and _is_finite_number(ts_end)):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            "timestamps must be finite numbers"
        )
    if float(ts_end) < float(ts_start):
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            "ts_end precedes ts_start"
        )
    resource_fields = ("cpu_ns_cumulative", "cpu_peak_cores", "sampled_peak_rss_mb", "memory_baseline_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes")
    if row.get("stdin_from_pipe") is not None and not isinstance(row["stdin_from_pipe"], bool):
        raise KnowledgeBaseSyncError(f"invalid lattice stdin_from_pipe in {path}: must be boolean or null")
    for field in resource_fields:
        value = row.get(field)
        if value is not None and (not _is_finite_number(value) or value < 0):
            raise KnowledgeBaseSyncError(f"invalid lattice resource {field} in {path}")
    if allow_resource_only and row.get("latency_ms") in (None, 0) and not isinstance(row.get("latency_ms"), bool) and any(
        _is_finite_number(row.get(field)) for field in resource_fields
    ):
        return
    latency_ms = row.get("latency_ms")
    if not _is_finite_number(latency_ms) or float(latency_ms) <= 0.0:
        raise KnowledgeBaseSyncError(
            f"invalid lattice KB observation {location} in {path}: "
            "latency_ms must be a positive finite number"
        )


def _is_finite_number(value: Any) -> bool:
    return (
        isinstance(value, (int, float))
        and not isinstance(value, bool)
        and math.isfinite(value)
    )


def _atomic_copy(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(
        f".{destination.name}.{os.getpid()}.{threading.get_ident()}.tmp"
    )
    try:
        shutil.copy2(source, temporary)
        os.replace(temporary, destination)
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def _write_host_tool_resource_preflight(
    trace_dir: Path,
    config: RunnerConfig,
    *,
    deadline: float | None = None,
) -> None:
    scheduler_src = str(config.repo_root / "services" / "sidecar" / "src")
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = (
        scheduler_src
        if not existing_pythonpath
        else scheduler_src + os.pathsep + existing_pythonpath
    )
    code = r"""
import json
import os
import platform
import shutil
import sys
from pathlib import Path

payload = {
    "mode": "host-openclaw",
    "platform": platform.system().lower(),
    "euid": os.geteuid() if hasattr(os, "geteuid") else None,
    "python": sys.executable,
    "pythonpath": os.environ.get("PYTHONPATH", ""),
    "docker": shutil.which("docker"),
    "clang": shutil.which("clang"),
    "llc": shutil.which("llc"),
    "bpftool": shutil.which("bpftool"),
    "cgroup_v2": Path("/sys/fs/cgroup/cgroup.controllers").is_file(),
    "lib_modules_exists": Path("/lib/modules").exists(),
}
try:
    from tool_resource.mvdan_client import ensure_compatible_adapter
    from tool_resource.telemetry import (
        _bpf_runtime_diagnostics,
        _ensure_bcc_importable,
        validate_clause_telemetry_smoke,
        validate_clause_telemetry_runtime,
    )
    bcc = _ensure_bcc_importable()
    payload["bcc_import"] = {
        "ok": True,
        "module": getattr(bcc, "__name__", None),
        "path": getattr(bcc, "__file__", None),
    }
    payload["bpf_runtime"] = _bpf_runtime_diagnostics()
    try:
        adapter_path = ensure_compatible_adapter()
        payload["mvdan_adapter"] = {
            "ok": True,
            "path": str(adapter_path),
            "architecture": platform.machine(),
        }
        validate_clause_telemetry_runtime(
            container_executable="docker",
            concurrency=1,
            workers=1,
        )
        payload["semantic_smoke"] = validate_clause_telemetry_smoke()
    except Exception as exc:
        if "mvdan_adapter" not in payload:
            payload["mvdan_adapter"] = {
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
            }
        payload["ebpf_ready"] = False
        payload["ebpf_disabled_reason"] = f"{type(exc).__name__}: {exc}"
    else:
        payload["ebpf_ready"] = True
        payload["ebpf_disabled_reason"] = None
        payload["bpf_module_load"] = {"ok": True}
except Exception as exc:
    payload["bcc_import"] = {"ok": False, "error": f"{type(exc).__name__}: {exc}"}
    payload["ebpf_ready"] = False
    payload["ebpf_disabled_reason"] = f"{type(exc).__name__}: {exc}"
print(json.dumps(payload, indent=2))
"""
    result = run_command(
        [sys.executable, "-c", code],
        capture_output=True,
        text=True,
        env=env,
        cwd=str(config.repo_root / "services" / "sidecar"),
        timeout=_remaining_task_seconds(deadline, phase="host telemetry preflight"),
    )
    output = result.stdout
    if result.stdout.strip() and result.stderr.strip():
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError:
            output = result.stdout.rstrip() + "\n\n[stderr]\n" + result.stderr
        else:
            if isinstance(payload, dict):
                payload["preflight_stderr"] = result.stderr.rstrip()
                output = json.dumps(payload, indent=2)
    elif not result.stdout.strip():
        output = result.stderr
    if not output.strip():
        output = json.dumps(
            {
                "mode": "host-openclaw",
                "error": "host tool-resource preflight produced no output",
                "returncode": result.returncode,
            },
            indent=2,
        )
    _write_text(trace_dir / "tool_resource_preflight_host.json", output.rstrip() + "\n")
    if not config.runtime.ebpf_required:
        return
    try:
        payload = json.loads(output)
    except json.JSONDecodeError as exc:
        raise RuntimeError(
            "eBPF preflight returned invalid JSON; see "
            f"{trace_dir / 'tool_resource_preflight_host.json'}"
        ) from exc
    if result.returncode != 0 or payload.get("ebpf_ready") is not True:
        reason = payload.get("ebpf_disabled_reason") or payload.get("error") or (
            f"preflight exited with status {result.returncode}"
        )
        raise RuntimeError(
            "eBPF telemetry is required but the host preflight failed: "
            f"{reason}. Run the host-openclaw command as root (for example, "
            "`sudo -E env \"PATH=$PATH\" \"$(command -v python3)\" "
            "-m swe_rebench.runner run ...`) and inspect "
            f"{trace_dir / 'tool_resource_preflight_host.json'}."
        )


def _configure_openclaw(
    *,
    trace_dir: Path,
    openclaw_home: Path,
    sidecar_port: int,
    workspace: Path,
    sandbox_image: str = "openclaw-sandbox:bookworm-slim",
    config: RunnerConfig,
    deadline: float | None = None,
    model_endpoint: str | None = None,
    model_api_key: str | None = None,
    model_id: str | None = None,
) -> None:
    openclaw = _require_executable("openclaw")
    env = _openclaw_env(openclaw_home, sidecar_port, config, workspace)
    plugin_dir = config.repo_root / config.runtime_assets.plugin_source
    if deadline is None:
        _ensure_plugin_built(trace_dir, plugin_dir)
    else:
        _ensure_plugin_built(trace_dir, plugin_dir, deadline=deadline)
    plugin_install_dir = _stage_plugin_for_openclaw_if_needed(
        trace_dir=trace_dir,
        plugin_dir=plugin_dir,
    )
    tools_manifest = getattr(config, "benchmark_tools_manifest", None)
    if tools_manifest:
        plugin_install_dir = _stage_benchmark_tool_contracts(
            plugin_dir=plugin_install_dir, trace_dir=trace_dir,
            tools_manifest=Path(tools_manifest),
        )
    _remaining_task_seconds(deadline, phase="plugin staging")
    endpoint_host = f"http://127.0.0.1:{sidecar_port}"
    endpoint_sandbox = f"http://host.docker.internal:{sidecar_port}"
    sandbox_config = _openclaw_config(
        endpoint_host=endpoint_host,
        endpoint_sandbox=endpoint_sandbox,
        workspace=workspace,
        sandbox_image=sandbox_image,
        config=config,
    )

    phase_log = trace_dir / "phase3.log"
    with phase_log.open("w", encoding="utf-8") as log:
        _run_logged_before_deadline(
            [
                openclaw,
                "onboard",
                "--non-interactive",
                "--accept-risk",
                "--skip-health",
                "--mode",
                "local",
                "--auth-choice",
                "vllm",
                "--custom-base-url",
                model_endpoint or f"{endpoint_host}/v1",
                "--custom-api-key",
                model_api_key or _runtime_proxy_api_key(workspace),
                "--custom-model-id",
                model_id or config.llm.model,
            ],
            env,
            log,
            "openclaw_onboard",
            deadline,
        )
        _run_logged_before_deadline(
            [openclaw, "plugins", "install", "--link", str(plugin_install_dir)],
            env,
            log,
            "plugin_install",
            deadline,
        )
        _run_logged_before_deadline(
            [openclaw, "plugins", "enable", "clawtune"],
            env,
            log,
            "plugin_enable",
            deadline,
        )
        patch = run_command(
            [openclaw, "config", "patch", "--stdin"],
            input=sandbox_config,
            stdout=log,
            stderr=log,
            text=True,
            env=env,
            timeout=_remaining_task_seconds(deadline, phase="OpenClaw config patch"),
        )
        if patch.returncode != 0:
            raise RuntimeError(
                f"openclaw_config_patch_failed exit={patch.returncode}: "
                f"{_tail_text(phase_log, 2000)}"
            )


def _openclaw_uses_agent_flag(openclaw: str, *, deadline: float | None = None) -> bool:
    """True when ``openclaw agent`` selects the agent via ``--agent <id>``.

    OpenClaw 2026.7.x uses ``--agent main``.  Newer builds moved the agent id
    to a positional subcommand (``openclaw agent main ...``) and reject the
    flag, surfacing as a "Too many arguments" CLI error like the one seen on
    this branch's benchmark runs.  Probe ``agent main --help``: a positional
    build answers with exit 0 and a real subcommand usage line
    (``Usage: openclaw agent main ...``) on stdout, while a flag build
    answers with the parent ``agent`` usage or the "Too many arguments ...
    Try: openclaw agent main --help" error.  Because that error hint itself
    contains the literal text "agent main", the probe must not trust stderr;
    only the exact stdout usage line with exit 0 proves the positional form.
    """
    _log(
        f"[openclaw-syntax] probe openclaw={openclaw} "
        f"HOME={os.environ.get('HOME')!r} "
        f"OPENCLAW_HOME={os.environ.get('OPENCLAW_HOME')!r}"
    )
    remaining = _remaining_task_seconds(deadline, phase="OpenClaw syntax probe")
    try:
        probe = run_command(
            [openclaw, "agent", "main", "--help"],
            capture_output=True,
            text=True,
            timeout=min(30, remaining) if remaining is not None else 30,
        )
    except (TaskCancelled, ContainerCleanupError):
        raise
    except Exception:
        # Best-effort probe: any failure (missing binary, timeout, or a
        # Popen stand-in without a context manager in tests) falls back to
        # the long-documented flag form.
        _remaining_task_seconds(deadline, phase="OpenClaw syntax probe")
        return True
    positional = (
        probe.returncode == 0
        and "Usage: openclaw agent main" in (probe.stdout or "")
    )
    _log(
        f"[openclaw-syntax] probe rc={probe.returncode} "
        f"stdout={probe.stdout[:160]!r} stderr={probe.stderr[:160]!r} "
        f"=> {'positional' if positional else 'flag'}"
    )
    return not positional


def _openclaw_agent_argv(
    openclaw: str,
    *,
    model_ref: str,
    prompt_path: Path,
    extra_args: Sequence[str],
    deadline: float | None = None,
) -> list[str]:
    """Build the ``openclaw agent`` argv for the installed CLI syntax."""
    if _openclaw_uses_agent_flag(openclaw, deadline=deadline):
        argv = [
            openclaw,
            "agent",
            "--local",
            "--agent",
            "main",
            "--model",
            model_ref,
            "--message-file",
            str(prompt_path),
            *extra_args,
        ]
    else:
        argv = [
            openclaw,
            "agent",
            "main",
            "--local",
            "--model",
            model_ref,
            "--message-file",
            str(prompt_path),
            *extra_args,
        ]
    _log(f"[openclaw-syntax] agent argv={' '.join(map(str, argv))}")
    return argv


def _run_openclaw_agent(
    *,
    trace_dir: Path,
    openclaw_home: Path,
    workspace: Path,
    sidecar_port: int,
    task: TaskDef,
    config: RunnerConfig,
    task_deadline: float | None = None,
    post_sandbox_scope: bool = True,
    prompt_path: Path | None = None,
    model_ref: str | None = None,
    stopped_event: threading.Event | None = None,
) -> int:
    _remaining_task_seconds(task_deadline, phase="agent startup")
    openclaw = _require_executable("openclaw")
    env = _openclaw_env(openclaw_home, sidecar_port, config, workspace)
    env["OPENCLAW_TRAJECTORY"] = "0"
    env["OPENCLAW_CACHE_TRACE"] = "0"
    env["CLAWTUNE_PLUGIN_TRACE_DIR"] = ""
    env["CLAWTUNE_CONSOLE_MODE"] = "quiet"
    env.update(
        {
            "TASK_INSTANCE_ID": task.instance_id,
            # This environment belongs to the host OpenClaw/plugin process.
            # Sandbox commands receive their own host.docker.internal endpoint
            # through sandbox.docker.env in the generated OpenClaw config.
            "CLAWTUNE_ENDPOINT": f"http://127.0.0.1:{sidecar_port}",
            "CLAWTUNE_EXEC_WORKDIR": "/workspace",
            "CLAWTUNE_SANDBOX_HOST_WORKSPACE": str(workspace),
            "CLAWTUNE_SANDBOX_CONTAINER_WORKSPACE": "/workspace",
            "CLAWTUNE_ENABLE_CGROUP": "1",
            "CLAWTUNE_LAUNCH_MODE": "fork-exec",
            "CLAWTUNE_LAUNCH_DEBUG": "0",
            "CLAWTUNE_REPO_KEY": getattr(config, "kb_repo", task_repo_key(task)),
            **({"CLAWTUNE_KB_OWNER": config.kb_owner} if getattr(config, "kb_owner", None) else {}),
        }
    )
    prompt_path = prompt_path or trace_dir / "agent_prompt.txt"
    stderr_path = trace_dir / "agent-stderr.txt"
    # Final model content is already in the canonical trace.
    stdout_file = open(os.devnull, "w", encoding="utf-8")
    stderr_file = stderr_path.open("w", encoding="utf-8")
    _log(f"[agent] starting (trace: {trace_dir})")

    stop_discovery = threading.Event()
    discovery = (
        threading.Thread(
            target=_discover_sandbox_scope_loop,
            kwargs={
                "trace_dir": trace_dir,
                "openclaw_home": openclaw_home,
                "sidecar_port": sidecar_port,
                "config": config,
                "workspace": workspace,
                "stop_event": stop_discovery,
            },
            daemon=True,
        )
        if post_sandbox_scope
        else None
    )
    try:
        agent_argv = _openclaw_agent_argv(
            openclaw, model_ref=model_ref or config.llm.openclaw_model_ref,
            prompt_path=prompt_path, extra_args=config.agent.extra_args,
            deadline=task_deadline,
        )
        _remaining_task_seconds(task_deadline, phase="agent process launch")
        supervised = sys.platform == "linux"
        if supervised:
            agent_argv = [sys.executable, str(Path(__file__).with_name("process_supervisor.py")), "--", *agent_argv]
        process = subprocess.Popen(
            agent_argv,
            cwd=str(config.repo_root),
            env=env,
            stdout=stdout_file,
            stderr=stderr_file,
            text=True,
            start_new_session=(os.name == "posix"),
        )
        if supervised and isinstance(process, _SUBPROCESS_POPEN_TYPE):
            process._clawtune_supervised = True
    except BaseException:
        stdout_file.close()
        stderr_file.close()
        raise
    if discovery is not None:
        discovery.start()

    # 鈹€鈹€ Tee agent output to trace files + console 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
    # Persist complete streams; only compact time-bucket rows reach the console.
    stop_output = threading.Event()

    def _tee(log_file: Any, tag: str) -> None:
        try:
            follow_agent_output(Path(log_file.name), stop_output, lambda line: _log(f"[{tag}] {line}"))
        except (ValueError, OSError):
            pass

    tee_stderr = threading.Thread(
        target=_tee,
        args=(stderr_file, "agent:err"),
        daemon=True,
    )
    tee_stderr.start()

    try:
        timeout = (
            max(0.001, task_deadline - time.monotonic())
            if task_deadline is not None
            else None
        )
        code = wait_process(process, timeout)
        if getattr(process, "_clawtune_supervised", False) and code == 125:
            raise ContainerCleanupError("agent supervisor reported incomplete descendant cleanup")
        if stopped_event is not None:
            stopped_event.set()
        return code
    except subprocess.TimeoutExpired:
        _kill_agent_process_and_confirm(process)
        if stopped_event is not None:
            stopped_event.set()
        scope = "task"
        configured_seconds = config.batch.task_timeout_seconds
        message = (
            f"{scope} timed out after {configured_seconds}s"
            if configured_seconds > 0
            else f"{scope} timed out"
        )
        _write_timeout_record(
            trace_dir,
            scope=scope,
            message=message,
            configured_seconds=configured_seconds,
        )
        return 124
    except (KeyboardInterrupt, TaskCancelled):
        # Ctrl-C is also fail-closed: do not publish a KB snapshot unless the
        # agent process group has definitely stopped.
        _kill_agent_process_and_confirm(process)
        if stopped_event is not None:
            stopped_event.set()
        raise
    finally:
        # All cleanup steps are protected from secondary interrupts so
        # Ctrl-C never leaves the process in an unreachable zombie state.
        stop_discovery.set()
        if discovery is not None:
            _join_thread_safe(discovery, timeout=2)

        # Descendants may inherit stdout/stderr. Regular log files avoid a
        # buffered pipe close waiting forever on a reader's lock or on EOF.
        stop_output.set()
        _join_thread_safe(tee_stderr, timeout=2)

        for f in (stdout_file, stderr_file):
            try:
                f.close()
            except OSError:
                pass


def _openclaw_config(
    *,
    endpoint_host: str,
    endpoint_sandbox: str,
    workspace: Path,
    sandbox_image: str = "openclaw-sandbox:bookworm-slim",
    config: RunnerConfig,
) -> str:
    return json.dumps(
        {
            "agents": {
                "defaults": {
                    # Preserve OpenClaw's own turn timeout. The benchmark
                    # supervisor owns only the whole-task deadline.
                    "workspace": str(workspace),
                    "repoRoot": str(workspace),
                    "sandbox": {
                        "mode": "all",
                        "backend": "docker",
                        "scope": "session",
                        "workspaceAccess": "rw",
                        "docker": {
                            "image": sandbox_image,
                            "containerPrefix": _sandbox_container_prefix(workspace),
                            "workdir": "/workspace",
                            "network": "bridge",
                            "extraHosts": ["host.docker.internal:host-gateway"],
                            "dangerouslyAllowExternalBindSources": True,
                        },
                    },
                },
            },
            "tools": {
                # Task-owned bridge tools are registered by the ClawTune
                # plugin. The default coding profile filters unknown tools
                # before the explicit allowlist is applied.
                "profile": "full",
                # Background process sessions split one logical command across
                # exec/process calls and therefore cannot provide an exact
                # one-call/one-process resource lifecycle.  Keep this required
                # telemetry route synchronous.
                "deny": ["process"],
                "exec": {
                    # Preserve OpenClaw/LLM per-tool timeout policy.
                    # OpenClaw's supported sandbox-exec PATH extension.  The
                    # launcher repeats the complete value so the forked shell
                    # also inherits it regardless of gateway sanitisation.
                    "pathPrepend": _SANDBOX_TASK_PATH.split(":"),
                },
            },
            "plugins": {
                "entries": {
                    "clawtune": {
                        "enabled": True,
                        # Required for the external plugin's agent_end
                        # lifecycle hook. The handler does not persist the
                        # final conversation payload.
                        "hooks": {"allowConversationAccess": True},
                        "config": {
                            "endpoint": endpoint_host,
                            # The benchmark runner owns either the task-local
                            # sidecar or the batch-wide shared sidecar. A
                            # short-lived plugin instance must never own and
                            # terminate that host service on process exit.
                            "autoStartSidecar": False,
                            "sidecarCommand": "",
                            "mode": "observe",
                            "decisionTimeoutMs": 10000,
                            "reportTimeoutMs": 10000,
                            "failOpen": True,
                            "logLevel": "warn",
                            "consoleMode": "quiet",
                            "executionBackend": "managed-wrapper",
                            "launcherPath": "/workspace/.clawtune/bin/clawtune-launch",
                            "launcherInterpreter": "/bin/sh",
                            "instrumentHosts": ["gateway", "*"],
                            "instrumentTools": ["exec"],
                            "enableCgroup": True,
                            "enableAffinity": False,
                            "enableNuma": False,
                            "profilingMode": "off",
                            "securityBoundaryAccepted": True,
                            "trace": {
                                "schema_version": 6,
                                "include_raw_events": False,
                                "include_llm_messages": True,
                                "include_tool_outputs": True,
                                "redact_sensitive_data": True,
                                "flush_span_start": True,
                                "max_string_bytes": 16384,
                                "max_messages_bytes": 131072,
                                "max_tool_output_bytes": 65536,
                                "trace_dir": "",
                            },
                        },
                    },
                },
            },
            "env": {
                "CLAWTUNE_ENDPOINT": endpoint_sandbox,
                "CLAWTUNE_EXEC_WORKDIR": "/workspace",
                "CLAWTUNE_SANDBOX_HOST_WORKSPACE": str(workspace),
                "CLAWTUNE_SANDBOX_CONTAINER_WORKSPACE": "/workspace",
                "CLAWTUNE_ENABLE_CGROUP": "1",
                "CLAWTUNE_CGROUP_REQUIRED": (
                    "1" if config.docker.cgroup_required else "0"
                ),
                "CLAWTUNE_LAUNCH_MODE": "fork-exec",
                "CLAWTUNE_LAUNCH_DEBUG": "0",
            },
        },
        indent=2,
    )


def _sandbox_container_prefix(workspace: Path) -> str:
    return sandbox_container_prefix(workspace)


def _docker_platform_args(platform: str) -> list[str]:
    return ["--platform", platform] if platform else []


def _cleanup_openclaw_sandbox_containers(
    trace_dir: Path,
    workspace: Path,
    *,
    timeout_seconds: float = _TASK_CLEANUP_TIMEOUT_SECONDS,
    strict: bool = False,
) -> None:
    """Remove stale OpenClaw sandbox containers for this task workspace.

    OpenClaw scopes sandbox containers by prefix.  Reusing a stale container can
    leave Docker exec stuck with a host workspace cwd that is outside the
    container mount namespace, so start each SWE-Rebench task from a fresh
    sandbox container.
    """
    docker = _require_executable("docker")
    prefix = _sandbox_container_prefix(workspace)
    log_path = trace_dir / "sandbox-container-cleanup.log"
    cleanup_deadline = time.monotonic() + max(0.001, timeout_seconds)
    try:
        listed = subprocess.run(
            [docker, "ps", "-aq", "--filter", f"name={prefix}"],
            capture_output=True,
            text=True,
            timeout=max(0.001, cleanup_deadline - time.monotonic()),
        )
    except subprocess.TimeoutExpired as exc:
        _write_text(log_path, f"docker_ps_timed_out prefix={prefix}\n")
        if strict:
            raise ContainerCleanupError(
                f"timed out listing sandbox containers for prefix {prefix}"
            ) from exc
        return
    if listed.returncode != 0:
        _write_text(
            log_path,
            f"docker_ps_failed exit={listed.returncode}\n{listed.stdout}{listed.stderr}",
        )
        if strict:
            raise ContainerCleanupError(
                f"failed to list sandbox containers for prefix {prefix}"
            )
        return

    container_ids = [line.strip() for line in listed.stdout.splitlines() if line.strip()]
    if not container_ids:
        _write_text(log_path, f"no stale containers for prefix {prefix}\n")
        return

    try:
        removed = subprocess.run(
            [docker, "rm", "-f", *container_ids],
            capture_output=True,
            text=True,
            timeout=max(0.001, cleanup_deadline - time.monotonic()),
        )
    except subprocess.TimeoutExpired as exc:
        _write_text(
            log_path,
            f"docker_rm_timed_out prefix={prefix}\n"
            f"containers={json.dumps(container_ids)}\n",
        )
        if strict:
            raise ContainerCleanupError(
                f"timed out removing sandbox containers for prefix {prefix}"
            ) from exc
        return
    _write_text(
        log_path,
        f"prefix={prefix}\ncontainers={json.dumps(container_ids)}\n"
        f"exit={removed.returncode}\n{removed.stdout}{removed.stderr}",
    )
    if strict and removed.returncode != 0:
        raise ContainerCleanupError(
            f"failed to remove sandbox containers for prefix {prefix}: "
            f"exit={removed.returncode}"
        )


def _ensure_plugin_built(
    trace_dir: Path,
    plugin_dir: Path,
    *,
    deadline: float | None = None,
) -> None:
    with _plugin_build_lock:
        plugin_key = plugin_dir.resolve()
        if plugin_key in _built_plugin_dirs:
            return
        package_json = plugin_dir / "package.json"
        if not package_json.exists():
            raise FileNotFoundError(f"plugin package.json not found: {package_json}")

        npm = _require_executable("npm")
        log_path = trace_dir / "plugin-build.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("w", encoding="utf-8") as log:
            result = run_command(
                [npm, "run", "build"],
                cwd=str(plugin_dir),
                stdout=log,
                stderr=log,
                text=True,
                timeout=_remaining_task_seconds(deadline, phase="plugin build"),
            )
        if result.returncode != 0:
            raise RuntimeError(
                f"plugin_build_failed exit={result.returncode}: "
                f"{_tail_text(log_path, 2000)}"
            )
        _built_plugin_dirs.add(plugin_key)


def _stage_plugin_for_openclaw_if_needed(*, trace_dir: Path, plugin_dir: Path) -> Path:
    """Use a root-owned linked plugin path when the runner itself is root.

    OpenClaw rejects linked plugins whose ownership does not match the current
    user/root trust boundary. In host-openclaw, users may run the runner
    with sudo only to satisfy eBPF permissions while keeping the repo owned by
    their normal account. Stage a per-run copy instead of asking them to chown
    the source tree.
    """

    if not hasattr(os, "geteuid") or os.geteuid() != 0:
        return plugin_dir
    try:
        if plugin_dir.stat().st_uid == 0:
            return plugin_dir
    except OSError:
        return plugin_dir
    staged = trace_dir / "clawtune-plugin-root-owned"
    if staged.exists():
        shutil.rmtree(staged, onerror=_chmod_and_retry)
    shutil.copytree(plugin_dir, staged, ignore=shutil.ignore_patterns("node_modules", "test", "tests", ".git"))
    return staged


def _stage_benchmark_tool_contracts(*, plugin_dir: Path, trace_dir: Path, tools_manifest: Path) -> Path:
    """Declare task-owned dynamic tools without mutating the shared plugin."""
    from clawtune_kb.contracts import validate
    bridge = json.loads(tools_manifest.read_text(encoding="utf-8"))
    validate(bridge, "tool-bridge.schema.json")
    staged = trace_dir / "clawtune-benchmark-plugin"
    shutil.copytree(plugin_dir, staged, ignore=shutil.ignore_patterns("node_modules", "test", "tests", ".git"))
    manifest_path = staged / "openclaw.plugin.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest.setdefault("contracts", {})["tools"] = [tool["name"] for tool in bridge["tools"]]
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return staged


def _openclaw_env(
    openclaw_home: Path,
    sidecar_port: int,
    config: RunnerConfig,
    workspace: Path | None = None,
) -> dict[str, str]:
    env = os.environ.copy()
    # The benchmark runner is the external sidecar owner. Plugin environment
    # overrides take precedence over openclaw.json, so scrub stale settings
    # that could make one short-lived OpenClaw process launch/own a sidecar,
    # connect to a different endpoint, or write a competing local trace.
    for name in (
        "CLAWTUNE_AUTO_START_SIDECAR",
        "CLAWTUNE_SIDECAR_COMMAND",
        "CLAWTUNE_ENDPOINT",
        "CLAWTUNE_LAUNCHER_ENDPOINT",
        "CLAWTUNE_TRACE_DIR",
        "CLAWTUNE_PLUGIN_TRACE_DIR",
        "CLAWTUNE_BENCHMARK_TOOLS",
    ):
        env.pop(name, None)
    # A sudo -E benchmark must not inherit credentials/targets for the user's
    # long-running gateway. This run creates an isolated OPENCLAW_HOME; any
    # stale gateway variable can make sessions_spawn announce to the local
    # gateway with a mismatched token even though ``openclaw agent --local`` is
    # healthy.
    for name in [key for key in env if key.startswith("OPENCLAW_GATEWAY_")]:
        env.pop(name, None)
    # OpenClaw communicates with the local ClawTune proxy.  It must not pass
    # the real upstream credential to its own process or Docker sandbox.
    env.pop("CLAWTUNE_LLM_UPSTREAM_API_KEY", None)
    env.update(
        {
            "OPENCLAW_HOME": str(openclaw_home),
            "OPENCLAW_STATE_DIR": str(openclaw_home / ".openclaw"),
            "OPENCLAW_CONFIG_PATH": str(
                openclaw_home / ".openclaw" / "openclaw.json"
            ),
            "OPENCLAW_WORKSPACE_DIR": str(
                workspace
                if workspace is not None
                else openclaw_home / ".openclaw" / "workspace"
            ),
            "VLLM_API_KEY": (
                _runtime_proxy_api_key(workspace)
                if workspace is not None
                else _LOCAL_PROXY_API_KEY
            ),
            "LLM_API_KEY": (
                _runtime_proxy_api_key(workspace)
                if workspace is not None
                else _LOCAL_PROXY_API_KEY
            ),
            # The plugin runs on the host.  Only its Docker-sandbox children
            # need host.docker.internal (configured separately in
            # _openclaw_config); using it here overrides the plugin config and
            # makes host-side sidecar requests fail on Linux.
            "CLAWTUNE_ENDPOINT": f"http://127.0.0.1:{sidecar_port}",
            "CLAWTUNE_LAUNCHER_ENDPOINT": (
                f"http://host.docker.internal:{sidecar_port}"
            ),
            "CLAWTUNE_EXEC_WORKDIR": "/workspace",
            "CLAWTUNE_SANDBOX_HOST_WORKSPACE": str(workspace) if workspace is not None else "",
            "CLAWTUNE_SANDBOX_CONTAINER_WORKSPACE": "/workspace",
            "CLAWTUNE_ENABLE_CGROUP": "1",
            "CLAWTUNE_CGROUP_REQUIRED": (
                "1" if config.docker.cgroup_required else "0"
            ),
            "CLAWTUNE_LAUNCH_MODE": "fork-exec",
            "CLAWTUNE_LAUNCH_DEBUG": "0",
            "CLAWTUNE_RUNTIME_ID": _runtime_id(workspace) if workspace is not None else "",
            "CLAWTUNE_GATEWAY_ID": _gateway_id(config),
            "CLAWTUNE_REPO_KEY": _runtime_id(workspace) if workspace is not None else "openclaw",
        }
    )
    if config.docker.platform:
        # OpenClaw 2026.7.x rejects ``sandbox.docker.platform``.  Its Docker
        # CLI subprocess inherits this standard Docker setting, while every
        # runner-owned pull/create/run still gets an explicit ``--platform``.
        env["DOCKER_DEFAULT_PLATFORM"] = config.docker.platform
    benchmark_tools_manifest = getattr(config, "benchmark_tools_manifest", None)
    if benchmark_tools_manifest:
        env["CLAWTUNE_BENCHMARK_TOOLS"] = str(benchmark_tools_manifest)
    env.update(getattr(config, "web_search_env", {}))
    (openclaw_home / ".openclaw").mkdir(parents=True, exist_ok=True)
    return env


def _discover_sandbox_scope_loop(
    *,
    trace_dir: Path,
    openclaw_home: Path,
    sidecar_port: int,
    config: RunnerConfig,
    workspace: Path,
    stop_event: threading.Event,
) -> None:
    openclaw = shutil.which("openclaw") or shutil.which("openclaw.cmd")
    docker = shutil.which("docker") or shutil.which("docker.cmd")
    if openclaw is None or docker is None:
        return
    env = _openclaw_env(openclaw_home, sidecar_port, config, workspace)
    prefix = _sandbox_container_prefix(workspace)
    seen: set[str] = set()
    while not stop_event.is_set():
        try:
            container_ids = _openclaw_sandbox_container_ids(openclaw, env)
            container_ids.extend(_docker_sandbox_container_ids(docker, prefix))
            for container_id in container_ids:
                if container_id in seen:
                    continue
                scope = _docker_container_scope(docker, container_id)
                if scope is None:
                    continue
                _post_sandbox_scope(
                    sidecar_port,
                    scope,
                    runtime_id=_runtime_id(workspace),
                    gateway_id=_gateway_id(config),
                )
                seen.add(container_id)
                _write_text(
                    trace_dir / "sandbox_scope.json",
                    json.dumps(scope, indent=2) + "\n",
                )
        except Exception as exc:
            _write_text(trace_dir / "sandbox_scope_discovery_last_error.txt", str(exc) + "\n")
        stop_event.wait(0.1)


def _openclaw_sandbox_container_ids(openclaw: str, env: dict[str, str]) -> list[str]:
    result = subprocess.run(
        [openclaw, "sandbox", "list", "--json"],
        capture_output=True,
        text=True,
        env=env,
        timeout=_DISCOVERY_COMMAND_TIMEOUT_SECONDS,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return []
    try:
        parsed = json.loads(result.stdout)
    except json.JSONDecodeError:
        return []
    ids: list[str] = []
    for item in _walk_dicts(parsed):
        for key in ("container_id", "containerId", "container", "id"):
            value = item.get(key)
            if isinstance(value, str) and _looks_like_container_id(value):
                ids.append(value)
                break
    return list(dict.fromkeys(ids))


def _docker_sandbox_container_ids(docker: str, prefix: str) -> list[str]:
    result = subprocess.run(
        [docker, "ps", "-q", "--filter", f"name={prefix}"],
        capture_output=True,
        text=True,
        timeout=_DISCOVERY_COMMAND_TIMEOUT_SECONDS,
    )
    if result.returncode != 0:
        return []
    return [
        line.strip()
        for line in result.stdout.splitlines()
        if _looks_like_container_id(line.strip())
    ]


def _docker_container_scope(docker: str, container_id: str) -> dict[str, Any] | None:
    result = subprocess.run(
        [docker, "inspect", "-f", "{{.State.Pid}}", container_id],
        capture_output=True,
        text=True,
        timeout=_DISCOVERY_COMMAND_TIMEOUT_SECONDS,
    )
    if result.returncode != 0:
        return None
    try:
        root_pid = int(result.stdout.strip())
    except ValueError:
        return None
    cgroup_path = _read_host_cgroup_path(root_pid)
    if cgroup_path is None:
        return None
    return {
        "kind": "cgroup-v2",
        "execution_id": None,
        "pid": root_pid,
        "root_pid": root_pid,
        "process_start_time": None,
        "root_starttime_ticks": None,
        "cgroup_path": cgroup_path,
        "pid_namespace_inode": None,
        "container_id": container_id,
        "include_children": True,
        "source": "openclaw-sandbox",
        "attribution_source": "shared-sandbox-container",
    }


def _read_host_cgroup_path(pid: int) -> str | None:
    try:
        text = Path(f"/proc/{pid}/cgroup").read_text(encoding="utf-8")
    except OSError:
        return None
    for line in text.splitlines():
        if not line.startswith("0::"):
            continue
        path = line[3:]
        if not path or path == "/":
            return "/sys/fs/cgroup"
        return f"/sys/fs/cgroup{path}"
    return None


def _post_sandbox_scope(
    sidecar_port: int,
    scope: dict[str, Any],
    *,
    runtime_id: str | None = None,
    gateway_id: str | None = None,
) -> None:
    data = json.dumps(scope).encode("utf-8")
    endpoint = (
        "/v1/runtime/sandbox-scope"
        if runtime_id is None
        else (
            "/v1/gateways/"
            + urllib.parse.quote(gateway_id, safe="")
            + "/runtimes/"
            + urllib.parse.quote(runtime_id, safe="")
            + "/sandbox-scope"
            if gateway_id is not None
            else "/v1/runtime/"
        + urllib.parse.quote(runtime_id, safe="")
        + "/sandbox-scope"
        )
    )
    request = urllib.request.Request(
        f"http://127.0.0.1:{sidecar_port}{endpoint}",
        data=data,
        method="POST",
        headers={"content-type": "application/json"},
    )
    _add_sidecar_auth(request)
    with urllib.request.urlopen(request, timeout=2):
        pass


_OBSERVATION_ISSUE_LOCK = threading.Lock()


def _observe_best_effort(trace_dir: Path, stage: str, action):
    """Diagnostics never replace the task's outcome; process cleanup stays strict."""
    try:
        return action()
    except Exception as exc:
        _record_observation_issue(trace_dir, stage, exc)
        return None


def _record_observation_issue(trace_dir: Path, stage: str, exc: Exception) -> None:
    detail = str(exc)
    if isinstance(exc, urllib.error.HTTPError):
        try:
            detail += ": " + exc.read(4096).decode("utf-8", errors="replace")
        except OSError:
            pass
    issue = {"stage": stage, "error": f"{type(exc).__name__}: {detail[:4096]}"}
    _log(f"[observation] {stage}: {issue['error']}")
    try:
        with _OBSERVATION_ISSUE_LOCK:
            with (trace_dir / "observation-issues.jsonl").open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(issue) + "\n")
    except OSError:
        pass


def _abort_runtime(
    sidecar_port: int,
    runtime_id: str,
    *,
    gateway_id: str,
    reason: str,
    trace_dir: Path,
) -> None:
    """Called only after the owner confirms agent exit and sandbox cleanup."""
    endpoint = (
        f"http://127.0.0.1:{sidecar_port}/v1/gateways/"
        + urllib.parse.quote(gateway_id, safe="") + "/runtimes/"
        + urllib.parse.quote(runtime_id, safe="") + "/abort"
    )
    request = urllib.request.Request(
        endpoint, method="POST", headers={"Content-Type": "application/json"},
        data=json.dumps({"reason": reason, "agent_stopped": True, "sandbox_cleaned": True}).encode(),
    )
    _add_sidecar_auth(request)
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            payload = json.loads(response.read().decode("utf-8"))
        if not isinstance(payload, dict) or payload.get("finalized") is not True:
            raise ValueError(f"unexpected finalization response: {payload!r}")
    except (OSError, ValueError) as exc:
        _record_observation_issue(trace_dir, "runtime_finalization", exc)
        raise RuntimeError(f"failed to finalize stopped runtime {runtime_id}: {exc}") from exc
    summary = {key: value for key, value in payload.items() if key != "pmu_profiles"}
    summary["trace_file"] = "trace.jsonl"
    for issue in payload.get("observation_errors", []):
        _record_observation_issue(trace_dir, "runtime_finalization", RuntimeError(str(issue)))
    _write_text(trace_dir / "runtime-finalization.json", json.dumps(summary, indent=2) + "\n")


def _drain_runtime(
    sidecar_port: int,
    runtime_id: str,
    *,
    timeout_seconds: float = 15.0,
    gateway_id: str | None = None,
    flush_kb: bool = True,
) -> None:
    endpoint = (
        f"http://127.0.0.1:{sidecar_port}"
        + (
            "/v1/gateways/"
            + urllib.parse.quote(gateway_id, safe="")
            + "/runtimes/"
            + urllib.parse.quote(runtime_id, safe="")
            + "/drain"
            if gateway_id is not None
            else "/v1/runtime/"
            + urllib.parse.quote(runtime_id, safe="")
            + "/drain"
        )
    )
    endpoint += (
        "?timeout_seconds="
        + urllib.parse.quote(str(timeout_seconds), safe="")
        + "&flush_kb="
        + ("true" if flush_kb else "false")
    )
    request = urllib.request.Request(endpoint, data=b"", method="POST")
    _add_sidecar_auth(request)
    for attempt in range(2):
        try:
            with urllib.request.urlopen(request, timeout=timeout_seconds + 2.0) as response:
                payload = json.loads(response.read().decode("utf-8"))
            break
        except (OSError, ValueError) as exc:
            # A transport timeout does not say whether the server drained. The
            # request is idempotent; retry once, keeping the same strict barrier.
            if isinstance(exc, TimeoutError) and attempt == 0:
                _log(f"[drain] runtime {runtime_id}: transport timeout; retrying once")
                continue
            raise RuntimeError(
                f"failed to drain shared sidecar runtime {runtime_id}: {exc}"
            ) from exc
    if not isinstance(payload, dict) or payload.get("drained") is not True:
        raise RuntimeError(
            f"shared sidecar runtime {runtime_id} did not drain: {payload!r}"
        )


_RUNTIME_CASE_MAP_LOCK = threading.Lock()


def _write_runtime_case_map(
    sidecar_trace_dir: Path,
    runtime_id: str,
    instance_id: str,
) -> None:
    """Record ``runtime_id -> instance_id`` so in-flight sidecar traces are attributable.

    A shared sidecar serves many concurrent tasks and its trace filenames only
    carry the ``clawtune-srb-<hash>`` runtime id, not the SWE-Rebench case name.
    The runner is the only component that knows both, so it publishes one JSON
    map under the sidecar trace dir while the batch runs.  Best-effort: a write
    failure must never fail the task.
    """
    if not runtime_id:
        return
    mapping_path = sidecar_trace_dir / "runtime-case-map.json"
    try:
        sidecar_trace_dir.mkdir(parents=True, exist_ok=True)
        with _RUNTIME_CASE_MAP_LOCK:
            mapping: dict[str, str] = {}
            if mapping_path.exists():
                try:
                    mapping = json.loads(
                        mapping_path.read_text(encoding="utf-8")
                    )
                except (OSError, json.JSONDecodeError):
                    mapping = {}
            mapping[runtime_id] = instance_id
            temporary = mapping_path.with_name(
                f".{mapping_path.name}.tmp-{os.getpid()}"
            )
            temporary.write_text(
                json.dumps(mapping, indent=2, sort_keys=True, ensure_ascii=False)
                + "\n",
                encoding="utf-8",
            )
            os.replace(temporary, mapping_path)
    except Exception:
        # The mapping is best-effort diagnostics; never fail the task on it.
        # Catch broadly so an unexpected error can never take the task down
        # before its try/finally cleanup runs.
        pass


_ALLOWED_LABEL_CHARS = frozenset(
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
)


def _safe_trace_label(instance_id: str) -> str:
    """Return a filesystem-safe case label for trace filenames."""
    safe = "".join(
        ch if ch in _ALLOWED_LABEL_CHARS else "_" for ch in instance_id
    ).strip("._")
    return safe or "task"


def _collect_runtime_traces(
    sidecar_trace_dir: Path,
    task_trace_dir: Path,
    runtime_id: str,
    task_label: str | None = None,
) -> list[Path]:
    """Return the canonical trace; never copy a second experiment log."""
    canonical = task_trace_dir / "trace.jsonl"
    if canonical.exists():
        return [canonical]
    # Read-only compatibility with older sidecars. Their originals remain in
    # place, rather than being duplicated into the task directory.
    return sorted(sidecar_trace_dir.glob(f"{runtime_id}__*.jsonl"))


def _collect_runtime_ebpf_artifacts(
    shared_kb_dir: Path | None,
    task_trace_dir: Path,
) -> list[Path]:
    """Resolve legacy KB artifacts without copying experiment data."""
    if shared_kb_dir is None:
        return []
    copied: list[Path] = []
    referenced: dict[str, Path] = {}
    for trace_file in sorted(task_trace_dir.glob("*.jsonl")):
        for line in trace_file.read_text(encoding="utf-8").splitlines():
            try:
                record = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(record, dict):
                continue
            execution = record.get("execution")
            if not isinstance(execution, dict):
                continue
            tool_resource = execution.get("tool_resource")
            if not isinstance(tool_resource, dict):
                continue
            artifact_path = tool_resource.get("artifact_path")
            if not isinstance(artifact_path, str) or not artifact_path:
                continue
            referenced[Path(artifact_path).name] = Path(artifact_path)
    for name, path in sorted(referenced.items()):
        source = path
        if not source.is_file():
            candidate = shared_kb_dir / name
            if not candidate.is_file():
                continue
            source = candidate
        # Snapshot only complete clause artifacts; a partial final write must
        # not masquerade as a valid artifact during inspection.
        try:
            data = source.read_bytes()
            payload = json.loads(data)
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(payload, dict) or payload.get("mode") != "clause":
            continue
        # The canonical JSONL already embeds this artifact. Keep its original
        # KB path available to legacy callers without making a second copy.
        copied.append(source)
    return copied


def _delete_runtime_scope(
    sidecar_port: int,
    runtime_id: str,
    *,
    gateway_id: str | None = None,
) -> None:
    endpoint = (
        f"http://127.0.0.1:{sidecar_port}"
        + (
            "/v1/gateways/"
            + urllib.parse.quote(gateway_id, safe="")
            + "/runtimes/"
            + urllib.parse.quote(runtime_id, safe="")
            + "/sandbox-scope"
            if gateway_id is not None
            else "/v1/runtime/"
            + urllib.parse.quote(runtime_id, safe="")
            + "/sandbox-scope"
        )
    )
    request = urllib.request.Request(endpoint, method="DELETE")
    _add_sidecar_auth(request)
    try:
        with urllib.request.urlopen(request, timeout=2):
            pass
    except OSError:
        pass


def _add_sidecar_auth(request: urllib.request.Request) -> None:
    bearer = os.getenv("CLAWTUNE_TOKEN")
    if bearer:
        request.add_header("authorization", f"Bearer {bearer}")


def _runtime_id(workspace: Path) -> str:
    """Return the stable per-OpenClaw-runtime identity for one workspace."""

    return _sandbox_container_prefix(workspace).rstrip("-")


def _runtime_proxy_api_key(workspace: Path) -> str:
    """Encode runtime identity in the local-only proxy credential."""

    return _RUNTIME_PROXY_API_KEY_PREFIX + _runtime_id(workspace)


def _walk_dicts(value: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if isinstance(value, dict):
        out.append(value)
        for item in value.values():
            out.extend(_walk_dicts(item))
    elif isinstance(value, list):
        for item in value:
            out.extend(_walk_dicts(item))
    return out


def _looks_like_container_id(value: str) -> bool:
    stripped = value.strip()
    return len(stripped) >= 12 and all(ch.isalnum() or ch in {"_", "-", "."} for ch in stripped)


def _write_task_inputs(
    trace_dir: Path,
    task: TaskDef,
    config: RunnerConfig,
    workspace: Path,
    runtime_assets_dir: Path | None = None,
    *,
    shared_kb_dir: Path | None = None,
) -> None:
    prompt = (
        "You are running a SWE-Rebench task in an OpenClaw Docker sandbox.\n\n"
        "Goal: solve the task by editing the repository in the current workspace.\n\n"
        "Use relative paths for read, edit, write, and apply_patch. For exec, "
        "run commands from the default working directory or use relative paths; "
        "avoid absolute /workspace paths in file-tool calls. Do not request "
        "host/gateway execution or elevated execution; this run is intentionally "
        "sandboxed and those requests will fail.\n\n"
        "Workflow:\n"
        "1. Inspect the repository.\n"
        "2. Edit the source files needed for a minimal fix.\n"
        "3. Run relevant tests or a focused reproduction command.\n"
        "4. Leave the repository modified with your solution.\n\n"
        f"Task instance:\n{task.instance_id}\n\n"
        f"Problem statement:\n{task.problem_statement}\n"
    )
    if task.hint_text:
        prompt += f"\nHint:\n{task.hint_text}\n"
    _write_text(trace_dir / "agent_prompt.txt", prompt)
    _write_text(trace_dir / "agent-cwd.txt", str(workspace) + "\n")
    runtime_assets_fingerprint = _read_json_object(
        runtime_assets_dir / "runtime-assets-source-fingerprint.json"
        if runtime_assets_dir is not None
        else None
    )
    _write_text(
        trace_dir / "task_manifest.json",
        json.dumps(
            {
                "task_id": task.instance_id,
                "repo": task_repo_key(task),
                "image": task.image,
                "base_commit": task.base_commit,
                "model": config.llm.model,
                "openclaw_model_ref": config.llm.openclaw_model_ref,
                "runtime_mode": "host-openclaw",
                "workspace": str(workspace),
                "runner_config": str(config.config_path or ""),
                "shared_kb_dir": str(shared_kb_dir) if shared_kb_dir else None,
                "runtime_assets_source_fingerprint": runtime_assets_fingerprint,
                "problem_statement_bytes": len(task.problem_statement),
                "hint_text_bytes": len(task.hint_text),
            },
            indent=2,
        )
        + "\n",
    )


def _read_json_object(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return value if isinstance(value, dict) else None


_RUNTIME_ARTIFACTS = (
    ".clawtune",
    ".local",
    "AGENTS.md",
    "HEARTBEAT.md",
    "IDENTITY.md",
    "SOUL.md",
    "TOOLS.md",
    "USER.md",
    "openclaw-workspace-state.json",
)


def _cleanup_runtime_artifacts(
    workspace: Path,
    *,
    deadline: float | None = None,
) -> None:
    for name in _RUNTIME_ARTIFACTS:
        _remaining_task_seconds(deadline, phase="runtime artifact cleanup")
        path = workspace / name
        if not path.exists():
            continue
        if _git_tracks_path(workspace, name, deadline=deadline):
            continue
        if path.is_dir():
            shutil.rmtree(path, onerror=_chmod_and_retry)
        else:
            path.unlink()


def _git_tracks_path(
    workspace: Path,
    relative_path: str,
    *,
    deadline: float | None = None,
) -> bool:
    result = subprocess.run(
        ["git", "-C", str(workspace), "ls-files", "--error-unmatch", "--", relative_path],
        capture_output=True,
        text=True,
        timeout=_remaining_task_seconds(deadline, phase="tracked artifact check"),
    )
    return result.returncode == 0


def _collect_patch(
    trace_dir: Path,
    workspace: Path,
    task: TaskDef,
    *,
    deadline: float | None = None,
) -> None:
    status = subprocess.run(
        ["git", "-C", str(workspace), "status", "--short"],
        capture_output=True,
        text=True,
        timeout=_remaining_task_seconds(deadline, phase="git status collection"),
    )
    diff_stat = subprocess.run(
        ["git", "-C", str(workspace), "diff", "--stat"],
        capture_output=True,
        text=True,
        timeout=_remaining_task_seconds(deadline, phase="git diff stat collection"),
    )
    _write_text(
        trace_dir / "repo_status.txt",
        "=== host workspace ===\n"
        f"{workspace}\n\n"
        "=== git status ===\n"
        f"{status.stdout}{status.stderr}\n"
        "=== git diff --stat ===\n"
        f"{diff_stat.stdout}{diff_stat.stderr}\n",
    )
    diff_cmd = ["git", "-C", str(workspace), "diff"]
    if task.base_commit:
        diff_cmd.append(task.base_commit)
    diff_cmd.append("--")
    patch = subprocess.run(
        diff_cmd,
        capture_output=True,
        text=True,
        timeout=_remaining_task_seconds(deadline, phase="model patch collection"),
    )
    _write_text(trace_dir / "model.patch", patch.stdout)


def _write_result_summary(
    trace_dir: Path,
    task: TaskDef,
    workspace: Path,
    exit_code: int,
    error: str | None,
) -> None:
    patch = trace_dir / "model.patch"
    patch_bytes = patch.stat().st_size if patch.exists() else 0
    summary: dict[str, Any] = {
        "task_id": task.instance_id,
        "agent_exit_code": exit_code,
        "testbed_exists": workspace.exists(),
        "patch_bytes": patch_bytes,
        "has_patch": patch_bytes > 0,
        "runtime_mode": "host-openclaw",
    }
    if error is not None:
        summary["error"] = error
    _write_text(trace_dir / "result_summary.json", json.dumps(summary, indent=2) + "\n")


def _write_timeout_record(
    trace_dir: Path,
    *,
    scope: str,
    message: str,
    configured_seconds: int,
) -> None:
    _write_text(
        trace_dir / "task-timeout.json",
        json.dumps(
            {
                "scope": scope,
                "message": message,
                "configured_seconds": configured_seconds,
            },
            indent=2,
        )
        + "\n",
    )


def _wait_ready(
    port: int,
    *,
    timeout_seconds: float | None = None,
    process: subprocess.Popen[str] | None = None,
    stderr_path: Path | None = None,
) -> None:
    task_budget_limited = timeout_seconds is not None
    deadline = time.monotonic() + (
        max(0.001, timeout_seconds) if timeout_seconds is not None else 60.0
    )
    url = f"http://127.0.0.1:{port}/health/ready"
    last_exception: str | None = None
    while time.monotonic() < deadline:
        remaining = deadline - time.monotonic()
        # If the sidecar process exited prematurely, surface its crash details
        # immediately instead of waiting for the full timeout.
        if process is not None:
            return_code = process.poll()
            if return_code is not None:
                detail = ""
                if stderr_path is not None:
                    try:
                        detail = stderr_path.read_text(
                            encoding="utf-8", errors="replace"
                        )[-4000:]
                    except OSError:
                        pass
                raise RuntimeError(
                    f"sidecar crashed (exit {return_code}) before becoming "
                    f"ready on port {port}; stderr tail:\n{detail}"
                )
        try:
            with urllib.request.urlopen(
                url,
                timeout=max(0.001, min(1.0, remaining)),
            ) as response:
                payload = json.loads(response.read().decode("utf-8"))
                if (
                    response.status == 200
                    and isinstance(payload, dict)
                    and payload.get("service") == "clawtune-sidecar"
                    and payload.get("schema_version") == "clawtune.health.v1"
                    and payload.get("ready") is True
                ):
                    return
        except Exception as exc:
            last_exception = str(exc)
            remaining = deadline - time.monotonic()
            if remaining > 0:
                time.sleep(min(0.5, remaining))
    if task_budget_limited:
        raise TaskDeadlineExceeded(
            "task timed out during sidecar startup; whole-task wall-clock "
            "budget exhausted"
        )
    # Collect diagnostic context for the timeout.
    diagnostic_parts = [f"sidecar_not_ready port={port}"]
    if process is not None:
        return_code = process.poll()
        diagnostic_parts.append(
            f"process_status={'exited_' + str(return_code) if return_code is not None else 'still_running'}"
        )
    if last_exception is not None:
        diagnostic_parts.append(f"last_health_error={last_exception}")
    if stderr_path is not None:
        try:
            stderr_tail = stderr_path.read_text(
                encoding="utf-8", errors="replace"
            )[-2000:]
            if stderr_tail.strip():
                diagnostic_parts.append(f"stderr_tail=\n{stderr_tail}")
        except OSError:
            pass
    raise RuntimeError(" ".join(diagnostic_parts))


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def _reset_directory(
    path: Path,
    *,
    docker_cleanup_image: str | None = None,
    docker_platform: str = "",
    deadline: float | None = None,
) -> None:
    if path.exists():
        try:
            shutil.rmtree(path, onerror=_chmod_and_retry)
        except PermissionError:
            if docker_cleanup_image is None:
                raise
            _reset_directory_with_docker(
                path,
                docker_cleanup_image,
                docker_platform,
                deadline=deadline,
            )
    _remaining_task_seconds(deadline, phase="workspace reset")
    path.mkdir(parents=True, exist_ok=True)


def _chmod_and_retry(function: Any, path: str, _exc_info: Any) -> None:
    if function is os.unlink:
        # POSIX unlink needs write permission on the containing directory;
        # making a read-only artifact writable does not permit its removal.
        try:
            os.chmod(os.path.dirname(path), 0o700)
        except OSError:
            pass
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass
    if function is os.open:
        exc = _exc_info[1] if isinstance(_exc_info, tuple) and len(_exc_info) > 1 else None
        if isinstance(exc, BaseException):
            raise exc
        raise PermissionError(path)
    try:
        function(path)
    except OSError as exc:
        if function is os.rmdir and getattr(exc, "errno", None) in {39, errno.ENOTEMPTY}:
            shutil.rmtree(path, onerror=_chmod_and_retry)
            return
        raise


def _reset_directory_with_docker(
    path: Path,
    image: str,
    platform: str = "",
    *,
    deadline: float | None = None,
) -> None:
    docker = _require_executable("docker")
    target = path.resolve()
    parent = target.parent
    parent.mkdir(parents=True, exist_ok=True)
    parent_resolved = parent.resolve()
    if target.parent != parent_resolved:
        target = parent_resolved / target.name
    try:
        target.relative_to(parent_resolved)
    except ValueError as exc:
        raise RuntimeError(f"refusing docker cleanup outside parent: {target}") from exc
    if target.name in {"", ".", ".."} or any(sep in target.name for sep in ("/", "\\")):
        raise RuntimeError(f"refusing unsafe docker cleanup target name: {target.name!r}")

    uid = os.getuid() if hasattr(os, "getuid") else 0
    gid = os.getgid() if hasattr(os, "getgid") else 0
    script = (
        'set -eu\n'
        'case "$TARGET" in ""|"."|".."|*/*) exit 64 ;; esac\n'
        'rm -rf "/host_parent/$TARGET"\n'
        'mkdir -p "/host_parent/$TARGET"\n'
        'chown "$HOST_UID:$HOST_GID" "/host_parent/$TARGET" 2>/dev/null || true\n'
    )
    result = subprocess.run(
        [
            docker,
            "run",
            "--rm",
            *_docker_platform_args(platform),
            "-e",
            f"TARGET={target.name}",
            "-e",
            f"HOST_UID={uid}",
            "-e",
            f"HOST_GID={gid}",
            "-v",
            f"{parent_resolved}:/host_parent",
            image,
            "sh",
            "-c",
            script,
        ],
        capture_output=True,
        text=True,
        timeout=_remaining_task_seconds(deadline, phase="Docker workspace reset"),
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"docker_workspace_cleanup_failed exit={result.returncode} "
            f"stdout={result.stdout!r} stderr={result.stderr!r}"
        )


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _tail_text(path: Path, max_chars: int) -> str:
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return f"cannot read log: {exc}"
    return text[-max_chars:]


def _require_executable(name: str) -> str:
    found = shutil.which(name) or shutil.which(f"{name}.cmd")
    if found is None:
        raise FileNotFoundError(f"required executable not found: {name}")
    return found


def _run_checked(
    cmd: list[str],
    label: str,
    *,
    timeout: float | None = None,
) -> None:
    result = run_command(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"{label}_failed exit={result.returncode} stdout={result.stdout!r} stderr={result.stderr!r}"
        )


def _run_logged_before_deadline(
    cmd: list[str],
    env: dict[str, str],
    log: Any,
    label: str,
    deadline: float | None,
) -> None:
    if deadline is None:
        _run_logged(cmd, env, log, label)
        return
    _run_logged(
        cmd,
        env,
        log,
        label,
        timeout=_remaining_task_seconds(deadline, phase=label),
    )


def _run_logged(
    cmd: list[str],
    env: dict[str, str],
    log: Any,
    label: str,
    *,
    timeout: float | None = None,
) -> None:
    log.write(f"=== {label} ===\n")
    result = run_command(
        cmd,
        stdout=log,
        stderr=log,
        text=True,
        env=env,
        timeout=timeout,
    )
    log.write(f"\nexit={result.returncode}\n\n")
    if result.returncode != 0:
        raise RuntimeError(f"{label}_failed exit={result.returncode}")


def _wait_process_exit(
    process: subprocess.Popen[str], *, timeout: float | None = None
) -> bool:
    """Wait for *process* to exit, tolerating :class:`KeyboardInterrupt`.

    Returns ``True`` when the process has exited, ``False`` when it is
    still running (including after a :class:`KeyboardInterrupt` or
    :class:`~subprocess.TimeoutExpired`).
    """
    try:
        process.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        return False
    except KeyboardInterrupt:
        return False
    return process.poll() is not None


def _join_thread_safe(thread: threading.Thread, *, timeout: float | None = None) -> None:
    """Join a thread, ignoring KeyboardInterrupt so cleanup is never abandoned."""
    try:
        thread.join(timeout=timeout)
    except KeyboardInterrupt:
        pass


def _kill_agent_process_and_confirm(process: subprocess.Popen[str]) -> None:
    if getattr(process, "_clawtune_supervised", False):
        process.terminate()
        try:
            code = process.wait(timeout=8)
        except subprocess.TimeoutExpired as exc:
            raise ContainerCleanupError("agent supervisor could not confirm descendant cleanup") from exc
        if code == 125:
            raise ContainerCleanupError("agent supervisor reported incomplete descendant cleanup")
        return
    try:
        if os.name == "posix" and isinstance(process, _SUBPROCESS_POPEN_TYPE):
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    except ProcessLookupError:
        pass
    except OSError:
        try:
            process.kill()
        except OSError:
            pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired as exc:
        raise ContainerCleanupError(
            "OpenClaw agent process group did not exit within 5s after kill"
        ) from exc


def _stop_process(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    process.terminate()
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            raise RuntimeError("sidecar did not exit after terminate and kill")
    if process.poll() is None:
        raise RuntimeError("sidecar exit could not be confirmed")
