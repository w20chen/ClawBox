import assert from "node:assert/strict";
import {mkdir, mkdtemp, readFile, rm, writeFile} from "node:fs/promises";
import {createServer} from "node:http";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {fileURLToPath} from "node:url";
import test from "node:test";

import {
  buildPrivilegedSidecarLaunch,
  ensureSidecarRunning,
} from "../dist/sidecar-launcher.js";

function shellArgument(value) {
  return `"${value.replaceAll('"', '\\"')}"`;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function waitForAttempt(attemptsPath) {
  const deadline = Date.now() + 2_500;
  while (Date.now() < deadline) {
    try {
      if ((await readFile(attemptsPath, "utf8")) === "attempt\n") return;
    } catch {
      // The fixture has not written its attempt yet.
    }
    await sleep(10);
  }
  throw new Error("sidecar launch fixture did not run within 2.5s");
}

test("privileged sidecar launch resolves the checkout and preserves a narrow environment", async () => {
  const projectRoot = await mkdtemp(join(tmpdir(), "clawtune-sidecar-project-"));
  const kernelSource = join(projectRoot, "kernel-build");
  const venvPython = join(projectRoot, ".venv", "bin", "python");
  const customBin = "/opt/clawtune-custom-bin";
  await mkdir(join(projectRoot, ".venv", "bin"), {recursive: true});
  await mkdir(kernelSource);
  await writeFile(venvPython, "");

  try {
    const proxyValue = "http://credential-must-not-enter-argv@example.invalid";
    const spec = buildPrivilegedSidecarLaunch(
      projectRoot,
      "http://127.0.0.1:9123",
      {
        platform: "linux",
        kernelRelease: "test-kernel",
        env: {
          PATH: `relative-bin:${customBin}`,
          HOME: "/home/clawtune-user",
          BCC_KERNEL_SOURCE: kernelSource,
          HTTPS_PROXY: proxyValue,
          CLAWTUNE_POLICY: "observe-only",
          UNRELATED_VALUE: "not-preserved-by-sudo",
        },
      },
    );

    assert(spec);
    assert.equal(spec.command, "sudo");
    assert(spec.args.includes(venvPython));
    assert(spec.args.includes(
      `PYTHONPATH=${projectRoot}:${join(projectRoot, "services", "sidecar", "src")}`,
    ));
    assert(spec.args.includes("HOME=/home/clawtune-user"));
    assert(spec.args.includes("PYTHONNOUSERSITE=1"));
    assert(spec.args.includes(`BCC_KERNEL_SOURCE=${kernelSource}`));
    assert(spec.args.includes("--host"));
    assert(spec.args.includes("127.0.0.1"));
    assert(spec.args.includes("9123"));
    const preserve = spec.args.find((value) => value.startsWith("--preserve-env="));
    assert(preserve?.includes("HTTPS_PROXY"));
    assert(preserve?.includes("CLAWTUNE_POLICY"));
    assert(!preserve?.includes("HOME"));
    assert(!preserve?.includes("UNRELATED_VALUE"));
    assert(!spec.args.some((value) => value.includes(proxyValue)));
    const pathArg = spec.args.find((value) => value.startsWith("PATH="));
    assert(pathArg?.includes(customBin));
    assert(!pathArg?.includes("relative-bin"));
  } finally {
    await rm(projectRoot, {recursive: true, force: true});
  }
});

test("sidecar auto-start is single-flight and tolerates another launcher winning", async () => {
  let healthy = false;
  const server = createServer((request, response) => {
    if (request.url === "/health/live" && healthy) {
      response.writeHead(200, {"content-type": "application/json"}).end(JSON.stringify({
        schema_version: "clawtune.health.v1",
        service: "clawtune-sidecar",
        live: true,
      }));
    } else {
      response.writeHead(503).end("starting");
    }
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });

  const address = server.address();
  assert(address && typeof address === "object");
  const endpoint = `http://127.0.0.1:${address.port}`;
  const workDir = await mkdtemp(join(tmpdir(), "clawtune-sidecar-launch-"));
  const attemptsPath = join(workDir, "attempts.txt");
  const fixturePath = fileURLToPath(
    new URL("./fixtures/sidecar-launch-attempt.mjs", import.meta.url),
  );
  const command = [process.execPath, fixturePath, attemptsPath]
    .map(shellArgument)
    .join(" ");
  const messages = [];
  const logger = {
    info: (message) => messages.push(["info", message]),
    warn: (message) => messages.push(["warn", message]),
    error: (message) => messages.push(["error", message]),
  };

  try {
    const opts = {
      endpoint,
      command,
      healthPollMs: 20,
      healthTimeoutMs: 2_000,
      logger,
    };
    const launch = Promise.all([
      ensureSidecarRunning(opts),
      ensureSidecarRunning(opts),
    ]);

    // The fixture appends "attempt\n" and then exits immediately. Only report
    // the endpoint healthy once the fixture has actually run so the "another
    // launcher won the startup race" path is deterministic: on a slow CI host
    // the spawned child can otherwise still be alive when the endpoint flips
    // healthy, and ensureSidecarRunning would hand back the live child instead
    // of null.
    await waitForAttempt(attemptsPath);
    healthy = true;

    const [first, second] = await launch;

    assert.notStrictEqual(first, second);
    assert.notStrictEqual(first.cleanup, second.cleanup);
    assert.equal(first.child, null);
    assert.equal(await readFile(attemptsPath, "utf8"), "attempt\n");
    assert.equal(
      messages.filter(([, message]) => message === "joining shared sidecar auto-start").length,
      1,
    );
    assert.equal(
      messages.filter(([, message]) => message.includes("won the startup race")).length,
      1,
    );

    // Each plugin receives a separate release handle for the shared launch.
    first.cleanup();
    second.cleanup();
  } finally {
    await new Promise((resolve) => server.close(resolve));
    await rm(workDir, {recursive: true, force: true});
  }
});
