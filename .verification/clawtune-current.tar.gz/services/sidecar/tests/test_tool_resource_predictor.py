from __future__ import annotations

import concurrent.futures
import json
import shlex
import shutil
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient
from jsonschema import Draft202012Validator
from referencing import Registry, Resource

import clawtune_sidecar.predictors.tool_resource as tool_resource_predictor
from clawtune_sidecar.api.app import create_app
from clawtune_sidecar.api.dependencies import build_state
from clawtune_sidecar.config import SidecarConfig
from clawtune_sidecar.contracts.models import (
    ParamFeatures,
    ResourceScope,
    ToolBeforeRequest,
    ToolCompletedEvent,
    ToolPrediction,
)
from clawtune_sidecar.monitoring.tool_runtime import ToolRuntimeSample
from clawtune_sidecar.predictors.tool_resource import (
    ToolResourcePredictor,
    load_openclaw_trace_observations,
)
from tool_resource.runtime_kb import (
    ClauseLatencyBucketPrediction,
    ClauseObservation,
    ClauseResourceKB,
    CompletedCall,
    LatencyBuckets,
    RuntimeToolResourceKB,
    ToolCallQuery,
)
import tool_resource.runtime_kb as tool_resource_runtime_kb


def test_lattice_prediction_uses_configured_guest_memory_measurement(monkeypatch) -> None:
    from tool_time.lattice_kb import LatticeTimeKB
    monkeypatch.setenv("CLAWTUNE_TOOL_RESOURCE_MEMORY_MEASUREMENT", "guest_memtotal_minus_memavailable")
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(), ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)), repo="repo-1",
    )
    predictor.lattice_kb = LatticeTimeKB.fit([ClauseObservation(
        repo="repo-1", bin="python", argv=("python", "job.py"),
        ts_start=0, ts_end=1, latency_ms=1000,
        memory_baseline_bytes=100, memory_total_peak_bytes=150,
        memory_extra_peak_bytes=50, memory_eligible=True,
        memory_environment_id="cube:boot-1", memory_measurement="guest_memtotal_minus_memavailable",
    )])
    try:
        result = predictor.predict(_tool_request("evt-memory", "call-memory", "python job.py"))
    finally:
        predictor.close()
    assert result.lattice.memory_measurement == "guest_memtotal_minus_memavailable"
    assert result.lattice.targets["memory_extra_peak_bytes"].p90 == 50
    assert result.lattice.targets["memory_extra_peak_bytes"].backend == "lattice"


def test_normalize_clause_preserves_pipeline_structure() -> None:
    clause = tool_resource_predictor._normalize_clause(
        {
            "bin": "grep",
            "argv": ["grep", "needle"],
            "in_loop": False,
            "in_pipe": True,
            "in_subst": False,
            "pipeline_position": 1,
        }
    )
    assert clause is not None
    assert clause["in_pipe"] is True
    assert clause["pipeline_position"] == 1


def _test_parse_command(command: str) -> dict:
    clauses = []
    offset = 0
    for part in command.split("&&"):
        argv = shlex.split(part.strip(), posix=True)
        if not argv:
            continue
        start = command.index(part.strip(), offset)
        end = start + len(part.strip())
        clauses.append({"bin": Path(argv[0]).name, "argv": argv, "span": (start, end)})
        offset = end
    return {"clauses": clauses, "parse_failed": not clauses}


def test_ebpf_workload_result_preserves_masked_lookup_diagnostic() -> None:
    workload = tool_resource_predictor._ebpf_workload_result(
        {
            "content": [{"type": "text", "text": "/bin/sh: 1: pip: not found"}],
            "details": {
                "aggregated": "/bin/sh: 1: pip: not found",
                "exitCode": 0,
            },
        },
        exit_code=0,
        signal=None,
        succeeded=True,
    )

    assert workload == {
        "exit_code": 0,
        "signal": None,
        "ok": True,
        "result": "/bin/sh: 1: pip: not found",
        "stderr": "",
    }


class _FakeToolResourceSDK:
    def __init__(self) -> None:
        self.started: list[tuple[str | None, str, str]] = []
        self.contexts: list[object] = []

    def start_command(self, context, tool_call_id: str, command: str):
        self.contexts.append(context)
        self.started.append((context.container_id, tool_call_id, command))
        return SimpleNamespace(
            tool_call_id=tool_call_id,
            _observer=SimpleNamespace(
                telemetry_available=True,
                unavailable_reason=None,
            ),
        )


@pytest.fixture(autouse=True)
def _native_parser_fixture(monkeypatch) -> None:
    monkeypatch.setattr("clawtune_sidecar.predictors.call_load.parse_command_clauses", _test_parse_command)
    monkeypatch.setattr(tool_resource_predictor, "parse_command_clauses", _test_parse_command)
    monkeypatch.setattr(tool_resource_runtime_kb, "parse_command_clauses", _test_parse_command)


def _write_trace(
    path: Path,
    *,
    command: str = "python -m pytest tests -q",
    memory_rss_bytes_before: int | None = None,
    attribution_source: str | None = None,
) -> None:
    resources = {
        "cpu_utilization_avg_cores": 1.5,
        "rss_peak_bytes": 104857600,
        "sampling_quality": "ok",
        "sampling_point_count": 2,
        "coverage_ratio": 1.0,
    }
    if memory_rss_bytes_before is not None:
        resources["memory_rss_bytes_before"] = memory_rss_bytes_before
    if attribution_source is not None:
        resources["attribution_source"] = attribution_source
    records = [
        {
            "schema_version": 6,
            "record_type": "trace_metadata",
            "trace_format_version": 6,
            "scaffold": "openclaw",
            "mode": "collect",
            "created_at": "2026-07-24T17:29:43.615462Z",
        },
        {
            "schema_version": 6,
            "record_type": "span_start",
            "trace_id": "run-1",
            "span_id": "call-1",
            "parent_span_id": None,
            "session_id": "session-1",
            "run_id": "run-1",
            "agent_id": "main",
            "sequence_no": 1,
            "kind": "tool",
            "name": "exec",
            "wall_time_ns": "1000000000000",
            "monotonic_time_ns": "1",
            "input": {"requested_args": {"command": command}},
            "execution": {"mode": "launcher", "execution_id": "call-1"},
        },
        {
            "schema_version": 6,
            "record_type": "span_end",
            "trace_id": "run-1",
            "span_id": "call-1",
            "parent_span_id": None,
            "session_id": "session-1",
            "run_id": "run-1",
            "agent_id": "main",
            "sequence_no": 1,
            "kind": "tool",
            "name": "exec",
            "wall_time_ns": "1001200000000",
            "monotonic_time_ns": "2",
            "duration_ns": "1200000000",
            "status": {"code": "ok", "message": None},
            "output": {"exit_code": 0, "result": None},
            "execution": {"mode": "launcher", "execution_id": "call-1", "tool_resource": {
                "call_telemetry": {"eligible_for_kb": True, "clauses": [{"ts_start": 0., "ts_end": 1.2}]}}},
            "resources": resources,
        },
    ]
    path.write_text(
        "\n".join(json.dumps(record, separators=(",", ":")) for record in records) + "\n",
        encoding="utf-8",
    )


def test_predictor_retries_ebpf_after_container_id_arrives(tmp_path: Path) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
        artifact_dir=tmp_path / "tool-resource",
    )
    fake_sdk = _FakeToolResourceSDK()
    predictor._sdk = fake_sdk  # type: ignore[assignment]

    assert not predictor.begin_execution(
        execution_id="exec-1",
        tool_call_id="call-1",
        command="echo hi && true",
        container_id=None,
        repo="repo-1",
    )
    assert predictor.begin_execution(
        execution_id="exec-1",
        tool_call_id="call-1",
        command="echo hi && true",
        container_id="a" * 64,
        repo="repo-1",
    )

    assert fake_sdk.started == [("a" * 64, "call-1", "echo hi && true")]


def test_predictor_starts_host_ebpf_from_trusted_pid_and_cgroup(
    tmp_path: Path,
) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
        artifact_dir=tmp_path / "tool-resource",
    )
    fake_sdk = _FakeToolResourceSDK()
    predictor._sdk = fake_sdk  # type: ignore[assignment]
    cgroup = tmp_path / "host-cgroup"
    cgroup.mkdir()

    assert predictor.begin_execution(
        execution_id="exec-host",
        tool_call_id="call-host",
        command="python -c 'print(1)'",
        container_id=None,
        cgroup_path=str(cgroup),
        trusted_root_pid=4242,
        repo="repo-1",
    )

    assert fake_sdk.started == [(None, "call-host", "python -c 'print(1)'")]
    context = fake_sdk.contexts[0]
    assert context.cgroup_path == str(cgroup)
    assert context.trusted_root_pid == 4242


def test_predictor_passes_and_rebinds_trusted_execution_root(tmp_path: Path) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
        artifact_dir=tmp_path / "tool-resource",
    )
    bound_roots: list[int] = []

    class SDK:
        def start_command(self, context, tool_call_id: str, command: str):
            assert context.trusted_root_pid == 4242
            return SimpleNamespace(
                tool_call_id=tool_call_id,
                _observer=SimpleNamespace(
                    telemetry_available=True,
                    unavailable_reason=None,
                    bind_trusted_root=bound_roots.append,
                ),
            )

    predictor._sdk = SDK()  # type: ignore[assignment]

    assert predictor.begin_execution(
        execution_id="exec-1",
        tool_call_id="call-1",
        command="echo hi",
        container_id="a" * 64,
        trusted_root_pid=4242,
        gateway_id="gateway-a",
        runtime_id="runtime-a",
    )
    assert predictor.begin_execution(
        execution_id="exec-1",
        tool_call_id="call-1",
        command="echo hi",
        container_id="a" * 64,
        trusted_root_pid=4242,
        gateway_id="gateway-a",
        runtime_id="runtime-a",
    )
    assert bound_roots == [4242]
    assert predictor.active_execution_ids("runtime-a") == ("exec-1",)
    assert predictor.active_execution_ids("runtime-a", "gateway-a") == ("exec-1",)
    assert predictor.active_execution_ids("runtime-a", "gateway-b") == ()
    assert predictor.active_execution_ids("runtime-b") == ()

    with pytest.raises(ValueError, match="active execution owner changed"):
        predictor.begin_execution(
            execution_id="exec-1",
            tool_call_id="call-1",
            command="echo hi",
            container_id="a" * 64,
            trusted_root_pid=4242,
            gateway_id="gateway-b",
            runtime_id="runtime-a",
        )


def test_concurrent_duplicate_execution_start_attaches_only_once(tmp_path: Path) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
        artifact_dir=tmp_path / "tool-resource",
    )
    starts = 0
    starts_lock = threading.Lock()

    class SDK:
        def start_command(self, _context, tool_call_id: str, _command: str):
            nonlocal starts
            with starts_lock:
                starts += 1
            time.sleep(0.03)
            return SimpleNamespace(
                tool_call_id=tool_call_id,
                _observer=SimpleNamespace(
                    telemetry_available=True,
                    unavailable_reason=None,
                ),
            )

    predictor._sdk = SDK()  # type: ignore[assignment]

    def begin() -> bool:
        return predictor.begin_execution(
            execution_id="same-execution",
            tool_call_id="same-call",
            command="printf ok",
            container_id="a" * 64,
            gateway_id="gateway",
            runtime_id="runtime",
        )

    with concurrent.futures.ThreadPoolExecutor(max_workers=16) as executor:
        assert all(executor.map(lambda _index: begin(), range(64)))
    assert starts == 1


def test_concurrent_predictions_share_one_causal_kb_transaction(monkeypatch) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
    )
    original_lattice = predictor._lattice_predictions_for_clauses
    original_clause = predictor.kb.predict_command_latency_bucket_from_clauses
    first_lattice_done = threading.Event()
    second_clause_done = threading.Event()

    def interleaved_lattice(*args, **kwargs):
        result = original_lattice(*args, **kwargs)
        if threading.current_thread().name == "first-prediction":
            first_lattice_done.set()
            # Before the fix, the second request could advance the clause KB
            # while the first request was between independently locked KBs.
            second_clause_done.wait(0.2)
        return result

    def observed_clause(*args, **kwargs):
        result = original_clause(*args, **kwargs)
        if threading.current_thread().name == "second-prediction":
            second_clause_done.set()
        return result

    predictor._lattice_predictions_for_clauses = interleaved_lattice
    predictor.kb.predict_command_latency_bucket_from_clauses = observed_clause
    monkeypatch.setattr(
        tool_resource_predictor.time,
        "time",
        lambda: (
            1_000.0
            if threading.current_thread().name == "first-prediction"
            else 1_001.0
        ),
    )
    results: dict[str, ToolPrediction] = {}

    def predict_first() -> None:
        results["first"] = predictor.predict(
            _tool_request("event-first", "call-first", "python first.py")
        )

    def predict_second() -> None:
        results["second"] = predictor.predict(
            _tool_request("event-second", "call-second", "python second.py")
        )

    first = threading.Thread(target=predict_first, name="first-prediction")
    second = threading.Thread(target=predict_second, name="second-prediction")
    first.start()
    assert first_lattice_done.wait(2.0)
    second.start()
    first.join(2.0)
    second.join(2.0)

    assert not first.is_alive()
    assert not second.is_alive()
    assert results["first"].tool_resource["unavailable_reason"] == (
        "no_clause_latency_evidence"
    )
    assert results["second"].tool_resource["unavailable_reason"] == (
        "no_clause_latency_evidence"
    )


def test_sanitized_execution_ids_cannot_collide_artifact_paths(tmp_path: Path) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
        artifact_dir=tmp_path / "tool-resource",
    )
    fake_sdk = _FakeToolResourceSDK()
    predictor._sdk = fake_sdk  # type: ignore[assignment]

    for execution_id in ("exec/a", "exec_a"):
        assert predictor.begin_execution(
            execution_id=execution_id,
            tool_call_id=execution_id,
            command="printf ok",
            container_id="a" * 64,
        )

    paths = {context.artifact_path.name for context in fake_sdk.contexts}
    assert len(paths) == 2


def test_predictor_does_not_report_fail_isolated_collector_as_started(
    tmp_path: Path,
) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1",
        artifact_dir=tmp_path / "tool-resource",
    )

    class UnavailableSDK:
        def start_command(self, context, tool_call_id: str, command: str):
            return SimpleNamespace(
                tool_call_id=tool_call_id,
                _observer=SimpleNamespace(
                    telemetry_available=False,
                    unavailable_reason="collector attach failed: permission denied",
                ),
            )

    predictor._sdk = UnavailableSDK()  # type: ignore[assignment]

    assert not predictor.begin_execution(
        execution_id="exec-1",
        tool_call_id="call-1",
        command="echo hi",
        container_id="a" * 64,
    )
    summary = predictor._telemetry_by_execution_id["exec-1"]
    assert summary.started is True
    assert summary.status == "unavailable"
    assert summary.unavailable_reason == "collector attach failed: permission denied"


def test_openclaw_trace_v6_loads_as_tool_resource_observations(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace)

    loaded = load_openclaw_trace_observations(trace, repo="repo-1")

    assert loaded.tool_spans_seen == 1
    assert loaded.observations == ()
    assert len(loaded.completed_calls) == 1
    completed = loaded.completed_calls[0]
    assert completed.repo == "repo-1"
    assert completed.tool_name == "exec"
    assert completed.command == "python -m pytest tests -q"
    assert completed.ts_end - completed.ts_start == pytest.approx(1.2)
    assert completed.memory_total_peak_bytes is None


def test_openclaw_trace_span_repo_overrides_batch_fallback(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace)
    records = [
        json.loads(line)
        for line in trace.read_text(encoding="utf-8").splitlines()
    ]
    for record in records:
        if record.get("kind") == "tool":
            record["repo"] = "owner/project"
    trace.write_text(
        "\n".join(json.dumps(record) for record in records) + "\n",
        encoding="utf-8",
    )

    loaded = load_openclaw_trace_observations(
        trace,
        repo="swe-rebench-batch",
    )
    assert len(loaded.completed_calls) == 1
    assert loaded.completed_calls[0].repo == "owner/project"

    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="swe-rebench-batch",
    )
    owner_request = _tool_request(
        "evt-owner",
        "call-owner",
        "python -m pytest tests -q",
    ).model_copy(update={"repo": "owner/project"})
    batch_request = _tool_request(
        "evt-batch",
        "call-batch",
        "python -m pytest tests -q",
    ).model_copy(update={"repo": "swe-rebench-batch"})

    owner = predictor.predict(owner_request)
    batch = predictor.predict(batch_request)

    assert owner.tool_resource["continuous_predictions"]["latency_ms"][
        "scope"
    ] == "repo"
    assert batch.tool_resource["continuous_predictions"]["latency_ms"][
        "scope"
    ] is None


def test_openclaw_trace_rejects_mismatched_span_repos(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace)
    records = [
        json.loads(line)
        for line in trace.read_text(encoding="utf-8").splitlines()
    ]
    for record in records:
        if record.get("record_type") == "span_start":
            record["repo"] = "owner/project-a"
        elif record.get("record_type") == "span_end":
            record["repo"] = "owner/project-b"
    trace.write_text(
        "\n".join(json.dumps(record) for record in records) + "\n",
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match=r"tool span 'call-1' repo mismatch"):
        load_openclaw_trace_observations(trace, repo="swe-rebench-batch")

    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="swe-rebench-batch",
    )
    assert predictor.report.openclaw_traces_accepted == 0
    assert predictor.report.continuous_observations_loaded == 0
    assert any("repo mismatch" in rejection for rejection in predictor.report.rejections)


@pytest.mark.parametrize(
    "attribution_source",
    ["shared-sandbox-container", "shared-runtime-process"],
)
def test_openclaw_trace_shared_scope_keeps_only_runtime_latency(
    tmp_path: Path,
    attribution_source: str,
) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(
        trace,
        memory_rss_bytes_before=50 * 1024 * 1024,
        attribution_source=attribution_source,
    )

    loaded = load_openclaw_trace_observations(trace, repo="repo-1")

    assert len(loaded.completed_calls) == 1
    completed = loaded.completed_calls[0]
    assert completed.cpu_peak_cores is None
    assert completed.cpu_peak_cores_eligible is False
    assert completed.memory_total_peak_bytes is None
    assert completed.memory_eligible is False

    records = [
        json.loads(line)
        for line in trace.read_text(encoding="utf-8").splitlines()
    ]
    start = next(row for row in records if row["record_type"] == "span_start")
    end = next(row for row in records if row["record_type"] == "span_end")
    clause = tool_resource_predictor._observation_from_tool_span(
        start,
        end,
        repo="repo-1",
    )
    assert clause is not None
    assert clause.latency_ms == pytest.approx(1200.0)
    assert clause.cpu_peak_cores is None
    assert clause.sampled_peak_rss_mb is None
    assert clause.cpu_ns_cumulative is None

    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    prediction = predictor.predict(
        _tool_request("evt-next", "call-next", "python -m pytest tests -q"),
    )
    continuous = prediction.tool_resource["continuous_predictions"]
    assert continuous["latency_ms"]["conditional_p90"] == pytest.approx(1200.0)
    assert continuous["cpu_peak_cores"]["conditional_p90"] is None
    assert continuous["memory_total_peak_bytes"]["conditional_p90"] is None


def test_tool_resource_predictor_predicts_from_openclaw_trace(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace)
    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    request = ToolBeforeRequest(
        schema_version="clawtune.v1",
        event_id="evt-1",
        occurred_at="2026-07-24T17:29:44Z",
        plugin_version="0.1.0",
        run_id="run-2",
        session_id="session-1",
        session_key=None,
        agent_id="main",
        tool_call_id="call-2",
        tool_name="exec",
        tool_kind="shell",
        tool_input_kind="json",
        derived_paths=[],
        params_digest="sha256:" + "a" * 64,
        param_features=ParamFeatures(
            serialized_size_bytes=10,
            string_length=10,
            list_item_count=0,
            path_count=0,
            has_command_like_field=True,
        ),
        raw_params={"command": "python -m pytest tests -q"},
    )

    result = predictor.predict(request)

    assert result.resource_class == "latency_medium"
    assert result.duration_p50_ms == 1200
    assert result.duration_p90_ms == 1200
    assert result.confidence is None
    continuous = result.tool_resource["continuous_predictions"]
    assert result.tool_resource["kv_ttl_cost"]["reference_runtime_s"] == pytest.approx(1.2)
    without_continuous = result.tool_resource | {"continuous_predictions": {}, "kv_ttl_cost": None}
    resources = without_continuous.pop("lattice_resource_predictions")
    assert resources
    assert all(item["p50"] is None for clause in resources for item in clause["predictions"])
    assert without_continuous == {
        "repo": "repo-1",
        "command": "python -m pytest tests -q",
        "parse_failed": False,
        "clause_bins": ["python"],
        "clause_predictions": [
            {
                "clause_index": 0,
                "bin": "python",
                "argv": ["python", "-m", "pytest", "tests", "-q"],
                "prediction": None,
                "unavailable_reason": "no_clause_latency_evidence",
            }
        ],
        "prediction": None,
        "unavailable_reason": "no_clause_latency_evidence",
        "continuous_predictions": {},
        "lattice_time_predictions": _unavailable_lattice_time_predictions(
            [("python", ["python", "-m", "pytest", "tests", "-q"])]
        ),
        "kv_ttl_cost": None,
        "prediction_algorithms": _prediction_algorithms(),
    }
    assert continuous["latency_ms"]["conditional_p90"] == pytest.approx(1200.0)
    assert continuous["latency_ms"]["scope"] == "repo"
    assert continuous["latency_ms"]["key_kind"] == "exact_command"
    assert continuous["cpu_peak_cores"]["conditional_p90"] is None
    assert continuous["cpu_peak_cores"]["scope"] is None
    assert continuous["cpu_peak_cores"]["key_kind"] is None
    assert continuous["memory_total_peak_bytes"] == {
        "target": "memory_total_peak_bytes",
        "conditional_p90": None,
        "scope": None,
        "key_kind": None,
        "evidence_count": 0,
        "fallback_path": [],
        "note": "no continuous evidence for target",
    }


class _FakeNumaSampler:
    """Duck-typed stand-in for NumaCpuUsageSampler used in predictor tests."""

    def sample(self) -> dict[str, object]:
        return {
            "available": True,
            "sampled": True,
            "node_count": 2,
            "window_s": 1.0,
            "user_hz": 100,
            "nodes": [
                {
                    "node": 0,
                    "cpulist": "0-1",
                    "online_cpus": 2,
                    "cpu_utilization_pct": 50.0,
                    "busy_cores": 1.0,
                },
                {
                    "node": 1,
                    "cpulist": "2-3",
                    "online_cpus": 2,
                    "cpu_utilization_pct": 0.0,
                    "busy_cores": 0.0,
                },
            ],
        }


def test_predict_includes_numa_usage_when_sampler_configured(tmp_path: Path) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        numa_usage_sampler=_FakeNumaSampler(),  # type: ignore[arg-type]
    )

    result = predictor.predict(
        _tool_request("evt-1", "call-1", "python -m pytest tests -q")
    )

    assert result.tool_resource is not None
    assert result.tool_resource["numa_usage"]["available"] is True
    assert result.tool_resource["numa_usage"]["sampled"] is True
    assert result.tool_resource["numa_usage"]["node_count"] == 2
    assert result.tool_resource["numa_usage"]["nodes"][0]["node"] == 0
    assert result.tool_resource["numa_usage"]["nodes"][0][
        "cpu_utilization_pct"
    ] == 50.0
    assert result.tool_resource["numa_usage"]["nodes"][0]["busy_cores"] == 1.0
    assert len(result.tool_resource["numa_usage"]["nodes"]) == 2


def test_predict_omits_numa_usage_without_sampler(tmp_path: Path) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    result = predictor.predict(
        _tool_request("evt-1", "call-1", "python -m pytest tests -q")
    )

    assert result.tool_resource is not None
    assert "numa_usage" not in result.tool_resource


def test_ebpf_clause_identity_matches_online_prediction(tmp_path: Path, monkeypatch) -> None:
    def parse_command(command: str) -> dict:
        if command == "python -m pytest tests -q":
            return {
                "clauses": [{"bin": "python", "argv": ["python", "-m", "pytest", "tests", "-q"]}],
                "parse_failed": False,
            }
        return {
            "clauses": [{"bin": "git", "argv": ["git", "status"]}],
            "parse_failed": False,
        }

    monkeypatch.setattr(tool_resource_predictor, "parse_command_clauses", parse_command)
    ebpf = tmp_path / "ebpf.json"
    ebpf.write_text(
        json.dumps(
            {
                "version": 2,
                "mode": "clause",
                "replay_execution": "completed",
                "cleanup": "ok",
                "status_model": "call_granular_v1",
                "telemetry_quality": "ok",
                "collection_validity": "valid",
                "formal_completeness": "complete",
                "integrity": {"status": "ok"},
                "provenance": {"repo": "repo-1"},
                "calls": [
                    {
                        "eligible_for_kb": True,
                        "clauses": [
                            {
                                "availability": {"latency": "ok"},
                                "bin": "python",
                                "argv": ["python", "-m", "pytest", "tests", "-q"],
                                "latency_ms": 1200,
                                "ts_start": 1.0,
                                "ts_end": 2.2,
                            }
                        ],
                    },
                    {
                        "eligible_for_kb": True,
                        "clauses": [
                            {
                                "availability": {"latency": "ok"},
                                "bin": "git",
                                "argv": ["git", "status"],
                                "latency_ms": 50,
                                "ts_start": 3.0,
                                "ts_end": 3.05,
                            }
                        ],
                    },
                ],
            }
        ),
        encoding="utf-8",
    )
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(ebpf,),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    result = predictor.predict(_tool_request("evt-1", "call-1", "python -m pytest tests -q"))

    assert predictor.report.observations_loaded == 2
    assert result.resource_class == "unknown"
    assert result.duration_p50_ms is None  # ToolKB has no whole-tool history.
    assert result.call_prediction == result.tool
    assert result.tool.targets["duration_ms"].status == "unavailable"
    assert result.trie.targets["duration_ms"].p50 == 1200
    assert result.lattice.targets["duration_ms"].p50 == 1200
    assert result.confidence is None  # bucket mass is not calibrated confidence
    assert result.tool_resource is not None
    assert result.tool_resource["prediction"]["scope"] == "repo"
    assert result.tool_resource["prediction"]["key_kind"] == "exact_clause"
    assert result.tool_resource["prediction"]["evidence_count"] == 1
    assert result.tool_resource["clause_predictions"] == [
        {
            "clause_index": 0,
            "bin": "python",
            "argv": ["python", "-m", "pytest", "tests", "-q"],
            "prediction": result.tool_resource["prediction"],
            "unavailable_reason": None,
        }
    ]
    lattice = result.tool_resource["lattice_time_predictions"]
    assert predictor.report.lattice_observations_loaded == 2
    assert predictor.report.lattice_kb_available is True
    assert len(lattice) == 1
    assert lattice[0]["clause_index"] == 0
    assert [item["algorithm"] for item in lattice[0]["predictions"]] == [
        "shrinkage",
        "loso",
        "max_cardinality",
    ]
    assert [item["prediction_ms"] for item in lattice[0]["predictions"]] == pytest.approx(
        [1200.0, 1200.0, 1200.0]
    )
    assert result.tool_resource["continuous_predictions"]["cpu_peak_cores"][
        "conditional_p90"
    ] is None

    predictor.continuous_kb.observe_completed_call(
        CompletedCall(
            repo="repo-1",
            tool_name="exec",
            command="python -m pytest tests -q",
            ts_start=4.0,
            ts_end=4.9,
            cpu_peak_cores=None,
            cpu_peak_cores_eligible=False,
            memory_total_peak_bytes=None,
            memory_eligible=False,
        )
    )
    continuous_result = predictor.predict(
        _tool_request("evt-2", "call-2", "python -m pytest tests -q")
    )

    assert continuous_result.duration_p50_ms == 900
    assert continuous_result.duration_p90_ms == 900
    assert continuous_result.confidence is None
    assert continuous_result.tool_resource["prediction"] is not None


def test_openclaw_trace_history_populates_repo_argv_prefix(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace, command="python -m pytest tests -q")
    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    result = predictor.predict(_tool_request("evt-prefix", "call-prefix", "python -m pytest integration -q"))

    assert result.resource_class == "latency_medium"
    assert result.tool_resource["prediction"] is None
    latency = result.tool_resource["continuous_predictions"]["latency_ms"]
    assert latency["scope"] == "repo"
    assert latency["key_kind"] == "command_prefix_depth_3"
    assert latency["fallback_path"] == [
        "repo:exact_command",
        "repo:command_prefix_depth_4",
        "repo:command_prefix_depth_3",
    ]


def test_openclaw_trace_cold_start_persists_runtime_kb(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    artifact_dir = tmp_path / "tool-resource"
    _write_trace(trace, command="python -m pytest tests -q")

    ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(trace,),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )

    assert not (artifact_dir / "clause-resource-kb.json").is_file()
    assert (artifact_dir / "runtime-tool-resource-kb.json").is_file()

    reloaded = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )
    result = reloaded.predict(_tool_request("evt-prefix", "call-prefix", "python -m pytest integration -q"))

    assert result.resource_class == "latency_medium"
    assert result.tool_resource["prediction"] is None
    assert result.tool_resource["continuous_predictions"]["latency_ms"]["key_kind"] == "command_prefix_depth_3"


def test_restarting_with_the_same_trace_does_not_duplicate_runtime_history(tmp_path):
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace, command="python job.py")
    for _ in range(3):
        predictor = ToolResourcePredictor.from_traces(
            openclaw_trace_paths=(trace,), ebpf_trace_paths=(),
            buckets=LatencyBuckets((100, 500, 2000)), repo="repo-1",
            artifact_dir=tmp_path / "kb",
        )
        samples = predictor.continuous_kb.predict_load_samples(
            ToolCallQuery("repo-1", "exec", "python job.py", 2_000_000_000)
        )
        assert len(samples["duration_ms"]["values"]) == 1
        predictor.close()


def test_shipped_toolkb_starts_without_fabricated_whole_call_predictions(
    tmp_path: Path,
) -> None:
    artifact_dir = tmp_path / "tool-resource"
    artifact_dir.mkdir()
    source = (
        Path(__file__).resolve().parents[3]
        / "seeds"
        / "bootstrap-v1"
        / "runtime-tool-resource-kb.json"
    )
    shutil.copyfile(source, artifact_dir / "runtime-tool-resource-kb.json")
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0, 10_000.0)),
        repo="12rambau/sepal_ui",
        artifact_dir=artifact_dir,
    )

    result = predictor.predict(_tool_request("evt-public-runtime", "call-public-runtime", "git status"))

    # Clause seed data must not be fabricated into whole-call labels.
    continuous = result.tool_resource["continuous_predictions"]
    latency = continuous["latency_ms"]
    assert latency["scope"] is None
    assert latency["evidence_count"] == 0
    assert latency["conditional_p90"] is None
    cpu = continuous["cpu_peak_cores"]
    assert cpu["scope"] is None
    assert cpu["evidence_count"] == 0
    assert cpu["conditional_p90"] is None


def test_shared_snapshots_reuse_same_repo_evidence_but_isolate_other_repos() -> None:
    snapshot_dir = (
        Path(__file__).resolve().parents[3] / "seeds" / "bootstrap-v1"
    )
    runtime = RuntimeToolResourceKB.from_json_obj(
        json.loads(
            (snapshot_dir / "runtime-tool-resource-kb.json").read_text(
                encoding="utf-8"
            )
        )
    )
    runtime_base_ts = (runtime._last_query_ts or 0.0) + 1.0
    runtime.observe_completed_call(
        CompletedCall(
            repo="12rambau/sepal_ui",
            tool_name="exec",
            command="git status",
            ts_start=runtime_base_ts,
            ts_end=runtime_base_ts + 0.2,
            cpu_peak_cores=0.25,
            cpu_peak_cores_eligible=True,
            sampled_peak_rss_bytes=32 * 1024**2,
            sampled_peak_rss_eligible=True,
            memory_total_peak_bytes=64 * 1024**2,
            memory_extra_peak_bytes=24 * 1024**2, memory_baseline_bytes=40 * 1024**2,
            memory_environment_id="test", memory_measurement="cgroup_v2_environment_union_v1",
            memory_eligible=True, cpu_peak_window_ms=500,
        )
    )
    same_repo = runtime.query(
        ToolCallQuery(
            repo="12rambau/sepal_ui",
            tool_name="exec",
            command="git status",
            ts_start=runtime_base_ts + 2.0,
        )
    )
    restored_runtime = RuntimeToolResourceKB.from_json_obj(runtime.to_json_obj())
    other_repo = restored_runtime.query(
        ToolCallQuery(
            repo="other/project",
            tool_name="exec",
            command="git status",
            ts_start=runtime_base_ts + 3.0,
        )
    )

    assert same_repo["latency_ms"].scope == "repo"
    assert same_repo["latency_ms"].conditional_p90 == pytest.approx(200.0)
    assert same_repo["memory_total_peak_bytes"].conditional_p90 == pytest.approx(64 * 1024**2)
    # New repo history must not leak to another repo; ToolKB has no initial priors.
    assert other_repo["latency_ms"].scope is None
    assert other_repo["latency_ms"].conditional_p90 is None
    assert other_repo["memory_total_peak_bytes"].scope is None
    assert other_repo["memory_total_peak_bytes"].conditional_p90 is None

    clause = ClauseResourceKB.from_json_obj(
        json.loads(
            (snapshot_dir / "clause-resource-kb.json").read_text(
                encoding="utf-8"
            )
        )
    )
    clause_base_ts = (clause._last_query_ts or 0.0) + 1.0
    clause.observe_completed_clause(
        ClauseObservation(
            repo="12rambau/sepal_ui",
            bin="git",
            argv=("git", "status"),
            ts_start=clause_base_ts,
            ts_end=clause_base_ts + 0.2,
            latency_ms=200.0,
        )
    )
    buckets = LatencyBuckets((100.0, 500.0, 2_000.0, 10_000.0))
    same_clause = clause.predict_command_latency_bucket(
        "12rambau/sepal_ui", "git status", clause_base_ts + 2.0, buckets
    )
    restored_clause = ClauseResourceKB.from_json_obj(clause.to_json_obj())
    other_clause = restored_clause.predict_command_latency_bucket(
        "other/project", "git status", clause_base_ts + 3.0, buckets
    )

    assert same_clause.prediction is not None
    assert same_clause.prediction.scope == "repo"
    # A replayed seed retains repo history; it does not manufacture a public prior.
    assert other_clause.prediction is None


def test_public_clause_snapshot_produces_public_global_single_clause_bucket(
    tmp_path: Path,
) -> None:
    artifact_dir = tmp_path / "tool-resource"
    artifact_dir.mkdir()
    public = ClauseResourceKB.fit_public([ClauseObservation(
        repo="", bin="python", argv=("python", "-V"),
        ts_start=0., ts_end=.1, latency_ms=100.,
    )])
    (artifact_dir / "clause-resource-kb.json").write_text(
        json.dumps(public.to_json_obj()), encoding="utf-8",
    )
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0, 10_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )

    result = predictor.predict(_tool_request("evt-public", "call-public", "python -V"))

    prediction = result.tool_resource["prediction"]
    assert predictor.report.kb_available is True
    assert prediction is not None
    assert 0 <= prediction["bucket_id"] < 5
    assert prediction["scope"] == "public"
    assert prediction["key_kind"] in {"bin", "global"}
    assert prediction["evidence_count"] > 0
    assert result.tool_resource["clause_predictions"] == [
        {
            "clause_index": 0,
            "bin": "python",
            "argv": ["python", "-V"],
            "prediction": prediction,
            "unavailable_reason": None,
        }
    ]


def test_public_clause_snapshot_predicts_exec_clause_in_real_compound_command(
    tmp_path: Path,
) -> None:
    artifact_dir = tmp_path / "tool-resource"
    artifact_dir.mkdir()
    public = ClauseResourceKB.fit_public([ClauseObservation(
        repo="", bin="python", argv=("python", "-V"),
        ts_start=0., ts_end=.1, latency_ms=100.,
    )])
    (artifact_dir / "clause-resource-kb.json").write_text(
        json.dumps(public.to_json_obj()), encoding="utf-8",
    )
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0, 10_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )

    result = predictor.predict(
        _tool_request(
            "evt-compound-public",
            "call-compound-public",
            "cd /workspace && python3 -m pytest tests -q",
        )
    )

    tool_resource = result.tool_resource
    assert tool_resource["clause_bins"] == ["python3"]
    assert tool_resource["prediction"] is not None
    assert tool_resource["unavailable_reason"] is None
    assert tool_resource.get("composed", False) is False
    assert len(tool_resource["clause_predictions"]) == 1
    clause = tool_resource["clause_predictions"][0]
    assert clause["clause_index"] == 0
    assert clause["bin"] == "python3"
    assert clause["prediction"]["scope"] == "public"
    assert clause["prediction"]["key_kind"] in {"bin", "global"}
    assert clause["prediction"]["evidence_count"] > 0
    assert clause["unavailable_reason"] is None


def test_ebpf_loader_uses_native_sdk_artifact_validation(tmp_path: Path) -> None:
    ebpf = tmp_path / "invalid-ebpf.json"
    ebpf.write_text(
        json.dumps(
            {
                "version": 2,
                "mode": "clause",
                "provenance": {"repo": "repo-1"},
                "calls": [
                    {
                        "eligible_for_kb": True,
                        "clauses": [
                            {
                                "bin": "python",
                                "argv": ["python", "-m", "pytest"],
                                "latency_ms": 1200,
                            }
                        ],
                    }
                ],
            }
        ),
        encoding="utf-8",
    )

    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(ebpf,),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    assert predictor.report.ebpf_traces_loaded == 0
    assert predictor.report.observations_loaded == 0
    assert predictor.report.kb_available is False
    assert predictor.report.rejections


def test_tool_resource_predictor_exposes_native_unavailable_reason(
    tmp_path: Path,
    monkeypatch,
) -> None:
    def parse_command(_command: str) -> dict:
        return {
            "clauses": [
                {"bin": "python", "argv": ["python", "-m", "pytest"]},
                {"bin": "git", "argv": ["git", "status"]},
            ],
            "parse_failed": False,
        }

    monkeypatch.setattr(tool_resource_predictor, "parse_command_clauses", parse_command)
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace, command="python -m pytest")
    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    result = predictor.predict(_tool_request("evt-1", "call-1", "python -m pytest && git status"))

    assert result.resource_class == "latency_medium"
    continuous = result.tool_resource["continuous_predictions"]
    assert result.tool_resource["kv_ttl_cost"]["reference_runtime_s"] == pytest.approx(1.2)
    without_continuous = result.tool_resource | {"continuous_predictions": {}, "kv_ttl_cost": None}
    resources = without_continuous.pop("lattice_resource_predictions")
    assert resources
    assert all(item["p50"] is None for clause in resources for item in clause["predictions"])
    assert without_continuous == {
        "repo": "repo-1",
        "command": "python -m pytest && git status",
        "parse_failed": False,
        "clause_bins": ["python", "git"],
        "clause_predictions": [
            {
                "clause_index": 0,
                "bin": "python",
                "argv": ["python", "-m", "pytest"],
                "prediction": None,
                "unavailable_reason": "no_clause_latency_evidence",
            },
            {
                "clause_index": 1,
                "bin": "git",
                "argv": ["git", "status"],
                "prediction": None,
                "unavailable_reason": "no_clause_latency_evidence",
            },
        ],
        "prediction": None,
        "unavailable_reason": "compound_clause_evidence_incomplete",
        "continuous_predictions": {},
        "lattice_time_predictions": _unavailable_lattice_time_predictions(
            [
                ("python", ["python", "-m", "pytest"]),
                ("git", ["git", "status"]),
            ]
        ),
        "kv_ttl_cost": None,
        "prediction_algorithms": _prediction_algorithms(),
    }
    assert continuous["latency_ms"]["conditional_p90"] == pytest.approx(1200.0)
    assert continuous["latency_ms"]["key_kind"] == "command_prefix_depth_3"
    assert continuous["cpu_peak_cores"]["conditional_p90"] is None
    assert continuous["cpu_peak_cores"]["key_kind"] is None
    assert continuous["memory_total_peak_bytes"]["note"] == "no continuous evidence for target"


def test_compound_prediction_requires_evidence_for_every_effective_clause() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    clauses = (
        {"bin": "python", "argv": ("python", "-m", "pytest")},
        {"bin": "apt-get", "argv": ("apt-get", "update")},
    )
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="python",
            argv=("python", "-m", "pytest"),
            ts_start=1.0,
            ts_end=1.08,
            latency_ms=80.0,
        )
    )

    incomplete = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        clauses,
        2.0,
        buckets,
        command="python -m pytest && apt-get update",
    )

    assert incomplete.prediction is None
    assert incomplete.unavailable_reason == "compound_clause_evidence_incomplete"
    assert incomplete.clause_bins == ("python", "apt-get")
    assert [item.clause_index for item in incomplete.clause_predictions] == [0, 1]
    assert incomplete.clause_predictions[0].prediction is not None
    assert incomplete.clause_predictions[0].unavailable_reason is None
    assert incomplete.clause_predictions[1].prediction is None
    assert (
        incomplete.clause_predictions[1].unavailable_reason
        == "no_clause_latency_evidence"
    )

    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="apt-get",
            argv=("apt-get", "update"),
            ts_start=2.1,
            ts_end=3.0,
            latency_ms=900.0,
        )
    )
    complete = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        clauses,
        4.0,
        buckets,
        command="python -m pytest && apt-get update",
    )

    assert complete.prediction is not None
    assert complete.composed is True
    assert complete.unavailable_reason is None
    assert complete.prediction.scope == "composed"
    assert complete.prediction.bucket_id == 2
    assert complete.composed_total_ms == pytest.approx(980.0)
    assert all(item.prediction is not None for item in complete.clause_predictions)
    assert all(item.unavailable_reason is None for item in complete.clause_predictions)
    assert [unit["kind"] for unit in complete.composition] == ["single", "single"]


def test_compound_prediction_ignores_noexec_builtins_but_preserves_raw_bins() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="python",
            argv=("python", "-m", "pytest"),
            ts_start=1.0,
            ts_end=1.2,
            latency_ms=200.0,
        )
    )

    compound = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        (
            {"bin": "cd", "argv": ("cd", "/workspace")},
            {"bin": "python", "argv": ("python", "-m", "pytest")},
        ),
        2.0,
        buckets,
        command="cd /workspace && python -m pytest",
    )

    assert compound.clause_bins == ("cd", "python")
    assert compound.prediction is not None
    assert compound.composed is True
    assert compound.unavailable_reason is None
    assert compound.composed_total_ms == pytest.approx(200.0)
    assert len(compound.clause_predictions) == 1
    assert compound.clause_predictions[0].clause_index == 1
    assert compound.clause_predictions[0].bin == "python"
    assert compound.clause_predictions[0].prediction is not None

    builtin_only = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        ({"bin": "cd", "argv": ("cd", "/workspace")},),
        3.0,
        buckets,
        command="cd /workspace",
    )

    assert builtin_only.clause_bins == ("cd",)
    assert builtin_only.clause_predictions == ()
    assert builtin_only.prediction is None
    assert builtin_only.unavailable_reason == "no_executable_clauses"

    builtin_compound = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        (
            {"bin": "cd", "argv": ("cd", "/workspace")},
            {"bin": "export", "argv": ("export", "MODE=test")},
        ),
        4.0,
        buckets,
        command="cd /workspace && export MODE=test",
    )

    assert builtin_compound.clause_bins == ("cd", "export")
    assert builtin_compound.clause_predictions == ()
    assert builtin_compound.prediction is None
    assert builtin_compound.unavailable_reason == "no_executable_clauses"

    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="echo",
            argv=("/bin/echo", "hello"),
            ts_start=4.1,
            ts_end=4.2,
            latency_ms=100.0,
        )
    )
    explicit_builtin_path = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        ({"bin": "echo", "argv": ("/bin/echo", "hello")},),
        5.0,
        buckets,
        command="/bin/echo hello",
    )

    assert len(explicit_builtin_path.clause_predictions) == 1
    assert explicit_builtin_path.clause_predictions[0].prediction is not None
    assert explicit_builtin_path.unavailable_reason is None


def test_compound_composition_sums_serial_units() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="python",
            argv=("python", "-V"),
            ts_start=1.0,
            ts_end=1.05,
            latency_ms=50.0,
        )
    )
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="git",
            argv=("git", "status"),
            ts_start=1.1,
            ts_end=1.3,
            latency_ms=200.0,
        )
    )

    result = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        (
            {"bin": "python", "argv": ("python", "-V")},
            {"bin": "git", "argv": ("git", "status")},
        ),
        2.0,
        buckets,
        command="python -V && git status",
    )

    assert result.composed is True
    assert result.unavailable_reason is None
    assert result.composed_total_ms == pytest.approx(250.0)
    assert result.prediction is not None
    assert result.prediction.scope == "composed"
    assert [unit["kind"] for unit in result.composition] == ["single", "single"]
    assert [unit["time_ms"] for unit in result.composition] == pytest.approx(
        [50.0, 200.0]
    )


def test_compound_composition_uses_pipeline_max() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="grep",
            argv=("grep", "pat"),
            ts_start=1.0,
            ts_end=1.4,
            latency_ms=400.0,
        )
    )
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="python",
            argv=("python", "-c", "1"),
            ts_start=1.0,
            ts_end=1.15,
            latency_ms=150.0,
        )
    )

    result = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        (
            {
                "bin": "grep",
                "argv": ("grep", "pat"),
                "in_pipe": True,
                "pipeline_position": 0,
            },
            {
                "bin": "python",
                "argv": ("python", "-c", "1"),
                "in_pipe": True,
                "pipeline_position": 1,
            },
        ),
        2.0,
        buckets,
        command="grep pat | python -c 1",
    )

    assert result.composed is True
    assert result.composed_total_ms == pytest.approx(400.0)
    assert result.composition[0]["kind"] == "pipeline"
    assert result.composition[0]["bins"] == ["grep", "python"]
    assert result.composition[0]["dropped_viewer_bins"] == []


def test_compound_composition_drops_trailing_pipe_viewer() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="ls",
            argv=("ls", "-la"),
            ts_start=1.0,
            ts_end=1.05,
            latency_ms=50.0,
        )
    )
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="head",
            argv=("head", "-20"),
            ts_start=1.0,
            ts_end=1.3,
            latency_ms=300.0,
        )
    )

    result = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        (
            {
                "bin": "ls",
                "argv": ("ls", "-la"),
                "in_pipe": True,
                "pipeline_position": 0,
            },
            {
                "bin": "head",
                "argv": ("head", "-20"),
                "in_pipe": True,
                "pipeline_position": 1,
            },
        ),
        2.0,
        buckets,
        command="ls -la | head -20",
    )

    assert result.composed is True
    # head runs concurrently with ls and its wall clock tracks the producer,
    # so it is dropped from composition and adds no independent time.
    assert result.composed_total_ms == pytest.approx(50.0)
    assert result.prediction is not None
    assert result.prediction.bucket_id == 0
    unit = result.composition[0]
    assert unit["kind"] == "pipeline"
    assert unit["bins"] == ["ls"]
    assert unit["dropped_viewer_bins"] == ["head"]
    # The dependent consumer is excluded from prediction as well as composition.
    assert [item.bin for item in result.clause_predictions] == ["ls"]
    assert all(item.prediction is not None for item in result.clause_predictions)


def test_compound_composition_keeps_pipeline_lead_viewer() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="head",
            argv=("head", "-5"),
            ts_start=1.0,
            ts_end=1.3,
            latency_ms=300.0,
        )
    )
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="wc",
            argv=("wc", "-l"),
            ts_start=1.0,
            ts_end=1.1,
            latency_ms=100.0,
        )
    )

    result = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        (
            {
                "bin": "head",
                "argv": ("head", "-5"),
                "in_pipe": True,
                "pipeline_position": 0,
            },
            {
                "bin": "wc",
                "argv": ("wc", "-l"),
                "in_pipe": True,
                "pipeline_position": 1,
            },
        ),
        2.0,
        buckets,
        command="head -5 file | wc -l",
    )

    assert result.composed is True
    # A viewer leading the pipeline (position 0) does real work and is kept;
    # only the trailing consumer wc is dropped.
    assert result.composed_total_ms == pytest.approx(300.0)
    unit = result.composition[0]
    assert unit["bins"] == ["head"]
    assert unit["dropped_viewer_bins"] == ["wc"]


def test_standalone_viewer_clause_is_not_composed() -> None:
    kb = ClauseResourceKB()
    buckets = LatencyBuckets((100.0, 500.0))
    kb.observe_completed_clause(
        ClauseObservation(
            repo="repo-1",
            bin="cat",
            argv=("cat", "file"),
            ts_start=1.0,
            ts_end=1.2,
            latency_ms=200.0,
        )
    )

    result = kb.predict_command_latency_bucket_from_clauses(
        "repo-1",
        ({"bin": "cat", "argv": ("cat", "file")},),
        2.0,
        buckets,
        command="cat file",
    )

    assert result.composed is False
    assert result.prediction is not None
    assert result.prediction.scope != "composed"
    assert result.composed_total_ms is None


@pytest.mark.parametrize("tool_name", ["read", "edit"])
def test_commandless_repo_tool_name_learning_is_causal_and_survives_snapshot(
    tool_name: str,
) -> None:
    kb = RuntimeToolResourceKB()
    kb.observe_completed_call(
        CompletedCall(
            repo="repo-1",
            tool_name=tool_name,
            command=None,
            ts_start=1.0,
            ts_end=1.2,
            cpu_peak_cores=0.25,
            cpu_peak_cores_eligible=True,
            sampled_peak_rss_bytes=32 * 1024**2,
            sampled_peak_rss_eligible=True,
            memory_total_peak_bytes=64 * 1024**2,
            memory_extra_peak_bytes=24 * 1024**2, memory_baseline_bytes=40 * 1024**2,
            memory_environment_id="test", memory_measurement="cgroup_v2_environment_union_v1",
            memory_eligible=True, cpu_peak_window_ms=500,
        )
    )

    second_call = kb.query(
        ToolCallQuery(
            repo="repo-1",
            tool_name=tool_name,
            command=None,
            ts_start=2.0,
        )
    )

    assert second_call["latency_ms"].conditional_p90 == pytest.approx(200.0)
    assert second_call["cpu_peak_cores"].conditional_p90 == pytest.approx(0.25)
    assert second_call["memory_total_peak_bytes"].conditional_p90 == pytest.approx(64 * 1024**2)
    for prediction in second_call.values():
        assert prediction.scope == "repo"
        assert prediction.key_kind == "tool_name"
        assert prediction.evidence_count == 1
        assert prediction.fallback_path == ("repo:tool_name",)

    kb.observe_completed_call(
        CompletedCall(
            repo="repo-1",
            tool_name=tool_name,
            command=None,
            ts_start=2.1,
            ts_end=2.5,
            cpu_peak_cores=0.5,
            cpu_peak_cores_eligible=True,
            sampled_peak_rss_bytes=40 * 1024**2,
            sampled_peak_rss_eligible=True,
            memory_total_peak_bytes=80 * 1024**2,
            memory_extra_peak_bytes=30 * 1024**2, memory_baseline_bytes=50 * 1024**2,
            memory_environment_id="test", memory_measurement="cgroup_v2_environment_union_v1",
            memory_eligible=True, cpu_peak_window_ms=500,
        )
    )
    restored = RuntimeToolResourceKB.from_json_obj(kb.to_json_obj())

    third_call = restored.query(
        ToolCallQuery(
            repo="repo-1",
            tool_name=tool_name,
            command=None,
            ts_start=3.0,
        )
    )

    assert third_call["latency_ms"].conditional_p90 == pytest.approx(400.0)
    assert third_call["cpu_peak_cores"].conditional_p90 == pytest.approx(0.5)
    assert third_call["memory_total_peak_bytes"].conditional_p90 == pytest.approx(80 * 1024**2)
    assert all(prediction.evidence_count == 2 for prediction in third_call.values())


def test_tool_resource_predictor_learns_from_completion_without_cold_start() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    request = _tool_request("evt-1", "call-1", "python -m pytest tests -q")
    predictor.record_tool_started(request)

    added = predictor.observe_completion(
        ToolCompletedEvent(
            schema_version="clawtune.v1",
            event_id="evt-1",
            occurred_at="2026-07-24T17:29:45Z",
            plugin_version="0.1.0",
            run_id="run-1",
            session_id="session-1",
            session_key=None,
            agent_id="main",
            tool_call_id="call-1",
            decision_id=None,
            lease_id=None,
            execution_id=None,
            tool_name="exec",
            duration_ms=1200,
            succeeded=True,
            error_type=None,
            error_digest=None,
            result_size_bytes=None,
            raw_result=None,
            raw_event=None,
            resource_scope=None,
        ),
        _runtime_sample("evt-1", "call-1"),
    )
    result = predictor.predict(_tool_request("evt-2", "call-2", "python -m pytest tests -q"))

    assert added == 1
    assert result.resource_class == "latency_medium"
    assert result.duration_p50_ms == 1200
    assert result.duration_p90_ms == 1200
    assert result.tool_resource["prediction"] is None
    assert result.tool_resource["unavailable_reason"] == "no_clause_latency_evidence"
    assert result.tool_resource["continuous_predictions"]["cpu_peak_cores"][
        "conditional_p90"
    ] is None
    assert result.tool_resource["continuous_predictions"]["memory_total_peak_bytes"][
        "note"
    ] == "no continuous evidence for target"


@pytest.mark.parametrize("error_type,censored", [(None, False), ("ValueError", False), ("TimeoutError", True), ("CancelledError", True)])
def test_completion_retains_outcome_and_masks_truncated_labels(error_type, censored):
    event = _tool_completion("evt-end", "call-1").model_copy(update={"succeeded": error_type is None, "error_type": error_type})
    call = tool_resource_predictor.completed_call_from_completion(event, _runtime_sample("evt-start", "call-1"), repo="repo")
    assert call is not None and call.censored is censored
    assert call.outcome == ("ok" if error_type is None else "error")
    kb = RuntimeToolResourceKB()
    kb.observe_completed_call(call)
    evidence = kb.predict_load_samples(ToolCallQuery("repo", event.tool_name, None, call.ts_end + 1))
    assert bool(evidence) is not censored
    if not censored:
        assert evidence["cpu_time_seconds"]["values"] == (1.0,)
        assert evidence["cpu_avg_cores"]["values"][0] == pytest.approx(1.0 / 1.2)
        assert "cpu_peak_cores" not in evidence


def test_completion_correlation_isolated_by_runtime_owner() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    first = _tool_request("evt-start-a", "shared-call", "python task_a.py").model_copy(
        update={"gateway_id": "gateway-a", "runtime_id": "runtime-a"}
    )
    second = _tool_request("evt-start-b", "shared-call", "python task_b.py").model_copy(
        update={"gateway_id": "gateway-b", "runtime_id": "runtime-b"}
    )
    predictor.record_tool_started(first)
    predictor.record_tool_started(second)

    # Omitting the optional agent identity forces the legacy-compatible lookup
    # while the supplied runtime owner still makes the match unambiguous.
    completion = _tool_completion("evt-end-b", "shared-call").model_copy(
        update={
            "gateway_id": "gateway-b",
            "runtime_id": "runtime-b",
            "agent_id": None,
        }
    )
    assert predictor.observe_completion(
        completion,
        _runtime_sample("evt-end-b", "shared-call"),
    ) == 1

    remaining = list(predictor._starts.values())
    assert remaining == [first]


def test_legacy_completion_does_not_guess_between_ambiguous_runtime_owners() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    predictor.record_tool_started(
        _tool_request("evt-start-a", "shared-call", "python task_a.py").model_copy(
            update={"gateway_id": "gateway-a", "runtime_id": "runtime-a"}
        )
    )
    predictor.record_tool_started(
        _tool_request("evt-start-b", "shared-call", "python task_b.py").model_copy(
            update={"gateway_id": "gateway-b", "runtime_id": "runtime-b"}
        )
    )

    completion = _tool_completion("evt-end-legacy", "shared-call").model_copy(
        update={"agent_id": None}
    )
    assert predictor.observe_completion(
        completion,
        _runtime_sample("evt-end-legacy", "shared-call"),
    ) == 1

    # A legacy peer without gateway/runtime identity is compatible with both
    # starts, so neither owner is consumed or misattributed.
    assert len(predictor._starts) == 2


@pytest.mark.parametrize(
    "attribution_source",
    ["shared-sandbox-container", "shared-runtime-process"],
)
def test_live_shared_scope_keeps_only_runtime_latency(
    attribution_source: str,
) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    scope = ResourceScope(
        kind="cgroup-v2",
        cgroup_path="/sys/fs/cgroup/shared-sandbox",
        source="openclaw-sandbox",
        attribution_source=attribution_source,
    )
    request = _tool_request(
        "evt-shared",
        "call-shared",
        "python -m pytest tests -q",
    ).model_copy(update={"resource_scope": scope})
    completion = ToolCompletedEvent(
        schema_version="clawtune.v1",
        event_id="evt-shared",
        occurred_at="2026-07-24T17:29:45Z",
        plugin_version="0.1.0",
        run_id="run-1",
        session_id="session-1",
        session_key=None,
        agent_id="main",
        tool_call_id="call-shared",
        decision_id=None,
        lease_id=None,
        execution_id=None,
        tool_name="exec",
        duration_ms=1200,
        succeeded=True,
        error_type=None,
        error_digest=None,
        result_size_bytes=None,
        raw_result=None,
        raw_event=None,
        resource_scope=scope,
    )
    sample = _runtime_sample("evt-shared", "call-shared")

    completed = tool_resource_predictor.completed_call_from_completion(
        completion,
        sample,
        repo="repo-1",
        start=request,
    )
    assert completed is not None
    assert completed.cpu_peak_cores is None
    assert completed.cpu_peak_cores_eligible is False
    assert completed.memory_total_peak_bytes is None
    assert completed.memory_eligible is False

    clause = tool_resource_predictor.observation_from_completion(
        completion,
        sample,
        repo="repo-1",
        start=request,
    )
    assert clause is not None
    assert clause.latency_ms == pytest.approx(1200.0)
    assert clause.cpu_peak_cores is None
    assert clause.sampled_peak_rss_mb is None
    assert clause.cpu_ns_cumulative is None

    predictor.record_tool_started(request)
    assert predictor.observe_completion(completion, sample) == 1
    prediction = predictor.predict(
        _tool_request(
            "evt-shared-next",
            "call-shared-next",
            "python -m pytest tests -q",
        ),
    )
    continuous = prediction.tool_resource["continuous_predictions"]
    assert continuous["latency_ms"]["conditional_p90"] == pytest.approx(1200.0)
    assert continuous["cpu_peak_cores"]["conditional_p90"] is None
    assert continuous["memory_total_peak_bytes"]["conditional_p90"] is None


def test_tool_resource_predictor_explains_unknown_without_cold_start() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    result = predictor.predict(_tool_request("evt-1", "call-1", "python -m pytest tests -q"))

    assert result.resource_class == "unknown"
    assert result.tool_resource["repo"] == "repo-1"
    assert result.tool_resource["command"] == "python -m pytest tests -q"
    assert result.tool_resource["clause_bins"] == ["python"]
    assert result.tool_resource["prediction"] is None
    assert result.tool_resource["unavailable_reason"] == "no_clause_latency_evidence"
    continuous = result.tool_resource["continuous_predictions"]
    assert continuous["latency_ms"]["note"] == "no continuous evidence for target"
    assert continuous["cpu_peak_cores"]["note"] == "no continuous evidence for target"
    assert continuous["memory_total_peak_bytes"]["note"] == "no continuous evidence for target"
    assert [item["name"] for item in result.tool_resource["prediction_algorithms"]["enabled"]] == [
        "clause_latency_bucket",
        "lattice_shrinkage",
        "lattice_loso",
        "lattice_max_cardinality",
        "runtime_tool_resource_conditional_p90",
    ]


def test_lattice_time_predictions_are_limited_to_ebpf_exec_clauses() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    predictor.lattice_kb.merge_historical(
        [
            ClauseObservation(
                repo="repo-1",
                bin="python",
                argv=("python", "task.py"),
                ts_start=1.0,
                ts_end=2.0,
                latency_ms=250.0,
            )
        ]
    )
    request = _tool_request("evt-read", "call-read", "ignored").model_copy(
        update={
            "tool_name": "read",
            "tool_kind": "file",
            "raw_params": {"path": "/workspace/task.py"},
        }
    )

    result = predictor.predict(request)

    assert result.tool_resource["lattice_time_predictions"] == []
    assert result.tool_resource["lattice_resource_predictions"] == []


def test_resource_lattice_predictions_reach_before_call_payload_and_fail_independently(monkeypatch) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(), ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)), repo="repo-1",
    )
    predictor.lattice_kb.merge_historical([ClauseObservation(
        repo="repo-1", bin="python", argv=("python", "task.py"),
        ts_start=1, ts_end=2, latency_ms=1000,
        cpu_ns_cumulative=2_000_000_000, memory_total_peak_bytes=128 * 1024**2,
        memory_extra_peak_bytes=128 * 1024**2, memory_baseline_bytes=0,
        memory_environment_id="test", memory_measurement="cgroup_v2_environment_union_v1", memory_eligible=True,
        cpu_peak_cores=3,
    )])
    request = _tool_request("resource-event", "resource-call", "python task.py")
    result = predictor.predict(request)
    output = result.tool_resource["lattice_resource_predictions"][0]
    by_target = {row["target"]: row for row in output["predictions"] if row["algorithm"] == "shrinkage"}
    assert by_target["cpu_time_seconds"]["p50"] == 2
    assert by_target["cpu_avg_cores"]["p50"] == 2
    assert by_target["memory_total_peak_bytes"]["p90"] == 128 * 1024**2
    assert all(row["prediction_ms"] == 1000 for row in result.tool_resource["lattice_time_predictions"][0]["predictions"])
    def fail(*args, **kwargs):
        raise ValueError("resource-only failure")
    monkeypatch.setattr(predictor.lattice_kb, "predict_resource_clauses", fail)
    result = predictor.predict(request)
    assert result.tool_resource["lattice_time_predictions"][0]["predictions"][0]["prediction_ms"] == 1000
    assert result.tool_resource["lattice_resource_predictions"][0]["predictions"][0]["unavailable_reason"] == "lattice_resource_error:ValueError"


def test_online_prediction_returns_quality_gated_pmu_history() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(), ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)), repo="repo-1",
    )
    now = time.time()
    predictor.continuous_kb.observe_completed_call(CompletedCall(
        "repo-1", "exec", "python task.py", now - 2, now - 1,
        pmu_ipc=1.25, pmu_llc_mpki=2.5,
        pmu_llc_miss_rate=.125, pmu_eligible=True,
    ))

    result = predictor.predict(_tool_request("pmu-event", "pmu-call", "python task.py"))

    assert result.pmu_prediction is not None
    assert result.pmu_prediction.targets["ipc"].p50 == 1.25
    assert result.pmu_prediction.targets["llc_mpki"].p90 == 2.5
    assert result.pmu_prediction.targets["llc_miss_rate"].p50 == .125


@pytest.mark.parametrize("frozen", [False, True])
def test_finish_execution_counts_only_accepted_clauses(tmp_path, monkeypatch, frozen):
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(), ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    if frozen:
        predictor = ToolResourcePredictor(
            kb=predictor.kb, buckets=predictor.buckets, report=predictor.report,
            repo="repo-1", frozen=True,
        )
    observations = tuple(
        ClauseObservation(
            repo="repo-1", bin=bin_, argv=argv, ts_start=1.0, ts_end=2.0,
            latency_ms=1000.0, in_pipe=True, pipeline_position=position,
        )
        for position, bin_, argv in (
            (0, "cat", ("cat", "file")),
            (1, "head", ("head", "-n", "1")),
        )
    )
    predictor._runs_by_execution_id["exec-pipe"] = SimpleNamespace(
        tool_call_id="call-pipe",
        _observer=SimpleNamespace(context=SimpleNamespace(
            artifact_path=tmp_path / "pipe.json",
        )),
    )
    monkeypatch.setattr(predictor._sdk, "finish_command", lambda *args, **kwargs: SimpleNamespace(
        kb_observations=observations, kb_observations_added=2,
        kb_update_error=None, call_telemetry={}, telemetry_artifact=None,
    ))
    summary = predictor.finish_execution(execution_id="exec-pipe", exit_code=0, signal=None)
    predictor.flush_kb_updates(timeout_seconds=2.0)
    expected = 0 if frozen else 1
    assert summary.kb_observations_added == expected
    assert summary.kb_update_error is None
    assert len(predictor.kb._pending) == expected
    assert len(predictor.lattice_kb._pending) == expected
    assert predictor._clause_kb_version == expected


def test_finish_execution_feeds_and_persists_the_shared_lattice_kb(
    tmp_path: Path,
    monkeypatch,
) -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=tmp_path,
    )
    now = time.time()
    observation = ClauseObservation(
        repo="repo-1",
        bin="python",
        argv=("python", "task.py"),
        ts_start=now - 2.0,
        ts_end=now - 1.0,
        latency_ms=250.0,
    )
    run = SimpleNamespace(
        tool_call_id="call-online",
        _observer=SimpleNamespace(
            context=SimpleNamespace(artifact_path=tmp_path / "call-online.json")
        ),
    )
    predictor._runs_by_execution_id["exec-online"] = run
    prepare_threads: list[str] = []
    original_prepare = type(predictor.lattice_kb).prepare

    def track_prepare(self) -> None:
        prepare_threads.append(threading.current_thread().name)
        original_prepare(self)

    monkeypatch.setattr(type(predictor.lattice_kb), "prepare", track_prepare)
    monkeypatch.setattr(
        predictor._sdk,
        "finish_command",
        lambda *_args, **_kwargs: SimpleNamespace(
            kb_observations=(observation,),
            kb_observations_added=1,
            kb_update_error=None,
            call_telemetry={},
            telemetry_artifact=None,
        ),
    )

    summary = predictor.finish_execution(
        execution_id="exec-online",
        exit_code=0,
        signal=None,
        succeeded=True,
    )
    predictor.flush_kb_updates(timeout_seconds=2.0)

    assert summary.kb_update_error is None
    assert prepare_threads == ["clawtune-kb-writer"]
    snapshot = json.loads(
        (tmp_path / "clause-lattice-time-kb.json").read_text(encoding="utf-8")
    )
    assert len(snapshot["pending"]) == 1
    monkeypatch.setattr(
        "tool_time.lattice_kb._build_node_state",
        lambda _observations: pytest.fail("prediction rebuilt the prepared lattice"),
    )

    prediction = predictor.predict(_tool_request("evt-online", "call-next", "python task.py"))
    outcomes = prediction.tool_resource["lattice_time_predictions"][0]["predictions"]
    assert [item["prediction_ms"] for item in outcomes] == pytest.approx(
        [250.0, 250.0, 250.0]
    )


def test_tool_resource_predictor_explains_empty_continuous_memory_with_anchor() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )

    result = predictor.predict(
        _tool_request("evt-1", "call-1", "python -m pytest tests -q"),
    )

    memory = result.tool_resource["continuous_predictions"]["memory_total_peak_bytes"]
    assert memory["conditional_p90"] is None
    assert memory["note"] == "no continuous evidence for target"


def test_exec_prediction_uses_fallback_parser_when_mvdan_fails(
    tmp_path: Path,
    monkeypatch,
) -> None:
    command = "python -m pytest tests -q"
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace, command=command)
    predictor = ToolResourcePredictor.from_openclaw_traces(
        [trace],
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0, 10_000.0)),
        repo="repo-1",
    )

    def fail_parse(_command: str) -> dict:
        raise RuntimeError("mvdan unavailable")

    monkeypatch.setattr(tool_resource_predictor, "parse_command_clauses", fail_parse)
    monkeypatch.setattr(tool_resource_runtime_kb, "parse_command_clauses", fail_parse)

    result = predictor.predict(_tool_request("evt-1", "call-1", command))

    assert result.resource_class == "latency_medium"
    assert result.tool_resource["unavailable_reason"] == "no_clause_latency_evidence"
    assert result.tool_resource["prediction"] is None
    assert result.tool_resource["continuous_predictions"]["latency_ms"]["scope"] == "repo"
    assert result.tool_resource["continuous_predictions"]["latency_ms"]["key_kind"] == "exact_command"


def test_tool_resource_predictor_persists_clause_kb_prefixes(tmp_path: Path) -> None:
    artifact_dir = tmp_path / "tool-resource"
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )
    request = _tool_request("evt-1", "call-1", "python -m pytest tests -q")
    predictor.record_tool_started(request)

    assert predictor.observe_completion(
        ToolCompletedEvent(
            schema_version="clawtune.v1",
            event_id="evt-1",
            occurred_at="2026-07-24T17:29:45Z",
            plugin_version="0.1.0",
            run_id="run-1",
            session_id="session-1",
            session_key=None,
            agent_id="main",
            tool_call_id="call-1",
            decision_id=None,
            lease_id=None,
            execution_id=None,
            tool_name="exec",
            duration_ms=1200,
            succeeded=True,
            error_type=None,
            error_digest=None,
            result_size_bytes=None,
            raw_result=None,
            raw_event=None,
            resource_scope=None,
        ),
        _runtime_sample("evt-1", "call-1"),
    ) == 1
    predictor.flush_kb_updates(timeout_seconds=2.0)
    assert not (artifact_dir / "clause-resource-kb.json").is_file()
    assert (artifact_dir / "runtime-tool-resource-kb.json").is_file()

    reloaded = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )
    result = reloaded.predict(_tool_request("evt-2", "call-2", "python -m pytest integration -q"))

    assert result.resource_class == "latency_medium"
    assert result.tool_resource["prediction"] is None
    assert result.tool_resource["unavailable_reason"] == "no_clause_latency_evidence"
    assert result.tool_resource["continuous_predictions"]["latency_ms"]["key_kind"] == "command_prefix_depth_3"


@pytest.mark.parametrize("workers", [2, 8])
@pytest.mark.parametrize("fail_once", [False, True])
def test_tool_resource_predictor_concurrent_completions_persist_without_lost_update(
    tmp_path: Path,
    monkeypatch,
    workers,
    fail_once,
) -> None:
    artifact_dir = tmp_path / "tool-resource"
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )
    predictor._kb_writes = tool_resource_predictor._KnowledgeBaseWriteCoordinator(
        predictor._flush_kb_batch,
        batch_window_s=0.2,
    )
    writes: list[tuple[Path, str]] = []
    original_write = tool_resource_predictor._write_json_atomic

    def track_write(path: Path, obj) -> None:
        writes.append((path, threading.current_thread().name))
        if fail_once and path.name == "runtime-tool-resource-kb.json" and sum(p == path for p, _ in writes) == 1:
            raise OSError("injected transient snapshot write failure")
        original_write(path, obj)

    monkeypatch.setattr(tool_resource_predictor, "_write_json_atomic", track_write)
    for index in range(workers):
        predictor.record_tool_started(_tool_request(f"evt-{index}", f"call-{index}", f"python task_{index}.py"))
    overlap = threading.Barrier(workers)

    def complete(event_id: str, tool_call_id: str) -> int:
        overlap.wait(timeout=5)
        return predictor.observe_completion(
            ToolCompletedEvent(
                schema_version="clawtune.v1",
                event_id=event_id,
                occurred_at="2026-07-24T17:29:45Z",
                plugin_version="0.1.0",
                run_id="run-1",
                session_id="session-1",
                session_key=None,
                agent_id="main",
                tool_call_id=tool_call_id,
                decision_id=None,
                lease_id=None,
                execution_id=None,
                tool_name="exec",
                duration_ms=1200,
                succeeded=True,
                error_type=None,
                error_digest=None,
                result_size_bytes=None,
                raw_result=None,
                raw_event=None,
                resource_scope=None,
            ),
            _runtime_sample(event_id, tool_call_id),
        )

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        results = list(
            executor.map(
                lambda args: complete(*args),
                [(f"evt-{i}", f"call-{i}") for i in range(workers)],
            )
        )

    assert results == [1] * workers
    try:
        predictor.flush_kb_updates(timeout_seconds=5.0)
    except tool_resource_predictor.KnowledgeBaseFlushError:
        assert fail_once
        predictor.flush_kb_updates(timeout_seconds=5.0)
    runtime_writes = [
        (path, thread_name)
        for path, thread_name in writes
        if path.name == "runtime-tool-resource-kb.json"
    ]
    assert runtime_writes
    assert all(name == "clawtune-kb-writer" for _, name in runtime_writes)
    if fail_once:
        assert len(runtime_writes) >= 2
    reloaded = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
        artifact_dir=artifact_dir,
    )
    assert reloaded.continuous_kb.to_json_obj() == predictor.continuous_kb.to_json_obj()
    for index in range(workers):
        prediction = reloaded.predict(_tool_request(f"next-{index}", f"next-{index}", f"python task_{index}.py"))
        assert prediction.tool_resource["continuous_predictions"]["latency_ms"]["conditional_p90"] == pytest.approx(1200.0)


def test_tool_resource_predictor_does_not_relabel_rss_using_ambient_anchor() -> None:
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets((100.0, 500.0, 2_000.0)),
        repo="repo-1",
    )
    request = _tool_request("evt-1", "call-1", "python -m pytest tests -q")
    predictor.record_tool_started(request)
    assert predictor.observe_completion(
        ToolCompletedEvent(
            schema_version="clawtune.v1",
            event_id="evt-1",
            occurred_at="2026-07-24T17:29:45Z",
            plugin_version="0.1.0",
            run_id="run-1",
            session_id="session-1",
            session_key=None,
            agent_id="main",
            tool_call_id="call-1",
            decision_id=None,
            lease_id=None,
            execution_id=None,
            tool_name="exec",
            duration_ms=1200,
            succeeded=True,
            error_type=None,
            error_digest=None,
            result_size_bytes=None,
            raw_result=None,
            raw_event=None,
            resource_scope=None,
        ),
        _runtime_sample("evt-1", "call-1"),
    ) == 1

    result = predictor.predict(
        _tool_request("evt-2", "call-2", "python -m pytest tests -q"),
    )

    memory = result.tool_resource["continuous_predictions"]["memory_total_peak_bytes"]
    assert memory["conditional_p90"] is None
    assert memory["scope"] is None
    assert memory["key_kind"] is None
    assert memory["note"] == "no continuous evidence for target"


def test_sidecar_uses_tool_resource_predictor_when_configured(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace)
    state = build_state(
        SidecarConfig(
            tool_resource_trace_paths=(trace,),
            tool_resource_latency_buckets_ms=(100.0, 500.0, 2_000.0),
            tool_resource_artifact_dir=tmp_path / "tool-resource",
        )
    )
    client = TestClient(create_app(state))

    response = client.post(
        "/v1/decisions/tool",
        json={
            "schema_version": "clawtune.v1",
            "event_id": "evt-1",
            "occurred_at": "2026-07-24T17:29:44Z",
            "plugin_version": "0.1.0",
            "run_id": "run-2",
            "session_id": "session-1",
            "session_key": None,
            "agent_id": "main",
            "tool_call_id": "call-2",
            "tool_name": "exec",
            "tool_kind": "shell",
            "tool_input_kind": "json",
            "operation_hint": None,
            "derived_paths": [],
            "params_digest": "sha256:" + "a" * 64,
            "param_features": {
                "serialized_size_bytes": 10,
                "string_length": 10,
                "list_item_count": 0,
                "path_count": 0,
                "has_command_like_field": True,
            },
            "raw_params": {"command": "python -m pytest tests -q"},
            "resource_scope": None,
        },
    )

    assert response.status_code == 200
    schema = json.loads(
        (
            Path(__file__).resolve().parents[3]
            / "contracts"
            / "tool-decision.schema.json"
        ).read_text(encoding="utf-8")
    )
    schemas = [json.loads(p.read_text(encoding="utf-8")) for p in
               (Path(__file__).resolve().parents[3] / "contracts").glob("*.schema.json")]
    registry = Registry().with_resources((s["$id"], Resource.from_contents(s)) for s in schemas)
    Draft202012Validator(schema, registry=registry).validate(response.json())
    assert response.json()["prediction"]["resource_class"] == "latency_medium"
    pmu = response.json()["prediction"]["pmu_prediction"]
    assert set(pmu["targets"]) == {"cycles", "instructions", "llc_read_accesses", "llc_read_misses", "ipc", "llc_mpki", "llc_miss_rate", "llc_read_accesses_per_cpu_second", "llc_read_misses_per_cpu_second"}
    assert all(value["status"] == "unavailable" for value in pmu["targets"].values())


@pytest.mark.parametrize("quality,points,overlap", [("ok", 2, True), ("partial", 2, True), ("ok", 1, True), ("ok", 2, False)])
def test_resource_label_quality_online_offline_parity(quality, points, overlap):
    from dataclasses import replace
    sample = replace(_runtime_sample("evt", "call"), sampling_quality=quality,
        sampling_point_count=points, monitor_start_wall_s=1000.0 if overlap else 1002.0,
        monitor_end_wall_s=1001.2 if overlap else 1003.0)
    event = _tool_completion("evt", "call")
    online = tool_resource_predictor.completed_call_from_completion(event, sample, repo="repo")
    end = {"name": "exec", "status": {"code": "ok"}, "duration_ns": "1200000000",
        "wall_time_ns": "1001200000000",
           "execution": {"execution_id": "call", "tool_resource": {"call_telemetry": {
               "eligible_for_kb": True, "clauses": [{"ts_start": .1, "ts_end": .9}]}}},
           "resources": {"sampling_quality": quality,
        "sampling_point_count": points, "coverage_ratio": 1.0 if overlap else 0.0,
        "monitor_start_wall_time_ns": str(int(sample.monitor_start_wall_s * 1e9)),
        "monitor_end_wall_time_ns": str(int(sample.monitor_end_wall_s * 1e9)),
        "cpu_time_s": 1.0, "rss_peak_bytes": 104857600, "memory_rss_bytes_before": 10}}
    offline = tool_resource_predictor._completed_call_from_tool_span(None, end, repo="repo")
    usable = quality == "ok" and points >= 2 and overlap
    assert online.cpu_time_eligible is usable
    assert offline.cpu_time_eligible is usable
    assert online.memory_eligible is False  # RSS alone is not an environment measurement
    assert offline.memory_eligible is False
    assert online.ts_end - online.ts_start == pytest.approx(1.2)
    assert offline.ts_end - offline.ts_start == pytest.approx(1.2)
    assert tool_resource_predictor.observation_from_completion(event, sample, repo="repo").cpu_ns_cumulative == (1000000000 if usable else None)
    assert tool_resource_predictor._observation_from_tool_span(None, end, repo="repo").cpu_ns_cumulative == (1000000000 if usable else None)


def test_execution_window_uses_retained_duration_without_changing_tool_elapsed():
    from clawtune_sidecar.monitoring.ebpf_tool import execution_observation
    from clawtune_sidecar.monitoring.tool_runtime import apply_resource_observation
    from tool_resource.runtime_kb import _target_values
    observation = execution_observation({"telemetry_quality": "ok", "clauses": [{
        "t_exec_ns": 100_000_000, "t_end_ns": 900_000_000,
        "availability": {"cpu_time": "ok", "memory": "ok"},
        "cpu_time_seconds": .6, "peak_memory_mb": 10,
    }]}, started_ns=0, ended_ns=1_200_000_000, clock="linux_monotonic")
    sample = apply_resource_observation(_runtime_sample("evt", "call"), observation)
    online = tool_resource_predictor.completed_call_from_completion(
        _tool_completion("evt", "call"), sample, repo="repo",
        workload_duration_seconds=.8,
    )
    end = {"name": "exec", "status": {"code": "ok"}, "duration_ns": "1200000000",
           "wall_time_ns": "1001200000000",
           "execution": {"execution_id": "call", "tool_resource": {"call_telemetry": {
               "eligible_for_kb": True, "clauses": [{"ts_start": .1, "ts_end": .9}]}}},
           "resources": {
               "resource_observation": observation, "cpu_time_s": sample.cpu_time_delta_s}}
    offline = tool_resource_predictor._completed_call_from_tool_span(None, end, repo="repo")
    assert not observation["window"]["complete"]
    online_targets = _target_values(online)
    offline_targets = _target_values(offline)
    assert online_targets["cpu_time_seconds"] == offline_targets["cpu_time_seconds"] == .6
    assert online_targets["cpu_avg_cores"] == pytest.approx(.75)
    assert offline_targets["cpu_avg_cores"] == pytest.approx(.75)
    assert online_targets["workload_latency_ms"] == pytest.approx(800)
    assert offline_targets["workload_latency_ms"] == pytest.approx(800)
    assert online_targets["sampled_peak_rss_bytes"] == offline_targets["sampled_peak_rss_bytes"] == 10_000_000
    assert online_targets["latency_ms"] == offline_targets["latency_ms"] == pytest.approx(1200)
    assert sample.cpu_utilization_avg_cores == pytest.approx(.5)


def test_compact_call_telemetry_retains_aligned_call_resource():
    call_resource = {
        "peak_cpu_cores": 0.75,
        "sampled_peak_rss_mb": 32.0,
        "availability": {"cpu": "ok", "memory": "ok"},
    }
    compact = tool_resource_predictor._compact_call_telemetry(
        {
            "tool_call_id": "call",
            "command": "left | right",
            "telemetry_quality": "ok",
            "eligible_for_kb": True,
            "call_resource": call_resource,
            "clauses": [],
        }
    )

    assert compact["call_resource"] == call_resource


def test_trace_does_not_export_out_of_window_snapshots_as_tool_usage(tmp_path):
    from dataclasses import replace
    from clawtune_sidecar.trace import AgentTestBenchTraceWriter
    sample = replace(_runtime_sample("evt", "call"), sampling_quality="partial",
        sampling_point_count=1, monitor_duration_ms=0,
        monitor_start_wall_s=1002.0, monitor_end_wall_s=1002.0)
    event = _tool_completion("evt", "call").model_copy(update={
        "resource_scope": ResourceScope(pid=123, source="docker-exec", attribution_source="docker-exec-pid")})
    writer = AgentTestBenchTraceWriter(tmp_path)
    try:
        writer.record_tool(event, sample)
        assert writer.flush()
        rows = [json.loads(line) for p in tmp_path.glob("*.jsonl") for line in p.read_text().splitlines()]
        end = next(r for r in rows if r.get("record_type") == "span_end")
        assert end["resources"]["coverage_reason"] == "monitor_window_no_overlap"
        for name in ["cpu_time_s", "rss_peak_bytes", "disk_read_bytes_delta", "net_rx_bytes_delta", "cpu_utilization_avg_cores"]:
            assert end["resources"][name] is None
        assert end["duration_ns"] == "1200000000"
    finally:
        writer.close()


def test_sidecar_does_not_invent_environment_memory_from_rss(tmp_path: Path) -> None:
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace, memory_rss_bytes_before=0)
    state = build_state(
        SidecarConfig(
            tool_resource_trace_paths=(trace,),
            tool_resource_latency_buckets_ms=(100.0, 500.0, 2_000.0),
            tool_resource_artifact_dir=tmp_path / "tool-resource",
        )
    )
    client = TestClient(create_app(state))

    response = client.post(
        "/v1/decisions/tool",
        json={
            "schema_version": "clawtune.v1",
            "event_id": "evt-1",
            "occurred_at": "2026-07-24T17:29:44Z",
            "plugin_version": "0.1.0",
            "run_id": "run-2",
            "session_id": "session-1",
            "session_key": None,
            "agent_id": "main",
            "tool_call_id": "call-2",
            "tool_name": "exec",
            "tool_kind": "shell",
            "tool_input_kind": "json",
            "operation_hint": None,
            "derived_paths": [],
            "params_digest": "sha256:" + "a" * 64,
            "param_features": {
                "serialized_size_bytes": 10,
                "string_length": 10,
                "list_item_count": 0,
                "path_count": 0,
                "has_command_like_field": True,
            },
            "raw_params": {"command": "python -m pytest tests -q"},
            "resource_scope": None,
        },
    )

    assert response.status_code == 200
    memory = response.json()["prediction"]["tool_resource"]["continuous_predictions"][
        "memory_total_peak_bytes"
    ]
    assert memory["conditional_p90"] is None
    assert memory["scope"] is None
    assert memory["key_kind"] is None
    assert memory["note"] == "no continuous evidence for target"


def test_trace_writes_tool_prediction_payload(tmp_path: Path) -> None:
    source_trace = tmp_path / "source-trace.jsonl"
    trace_dir = tmp_path / "written-traces"
    _write_trace(source_trace)
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            tool_resource_trace_paths=(source_trace,),
            tool_resource_latency_buckets_ms=(100.0, 500.0, 2_000.0),
        )
    )
    client = TestClient(create_app(state))
    request = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-before",
        "occurred_at": "2026-07-24T17:29:44Z",
        "plugin_version": "0.1.0",
        "run_id": "run-trace-prediction",
        "session_id": "session-trace-prediction",
        "session_key": None,
        "agent_id": "main",
        "tool_call_id": "call-prediction",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 10,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": {"command": "python -m pytest tests -q"},
        "resource_scope": None,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    assert decision["prediction"]["resource_class"] == "latency_medium"

    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-after",
        "occurred_at": "2026-07-24T17:29:45Z",
        "plugin_version": "0.1.0",
        "run_id": "run-trace-prediction",
        "session_id": "session-trace-prediction",
        "session_key": None,
        "agent_id": "main",
        "tool_call_id": "call-prediction",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "exec",
        "duration_ms": 1200,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": None,
        "raw_result": None,
        "resource_scope": None,
    }
    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    records = [
        json.loads(line)
        for path in trace_dir.glob("*.jsonl")
        for line in path.read_text(encoding="utf-8").splitlines()
    ]
    tool_start = next(
        record
        for record in records
        if record.get("record_type") == "span_start" and record.get("kind") == "tool"
    )
    assert tool_start["prediction"] == decision["prediction"]
    assert tool_start["prediction"]["duration_p50_ms"] == 1200
    assert tool_start["prediction"]["duration_p90_ms"] == 1200
    assert set(tool_start["prediction"]["pmu_prediction"]["targets"]) == {
        "cycles", "instructions", "llc_read_accesses", "llc_read_misses", "ipc", "llc_mpki", "llc_miss_rate",
        "llc_read_accesses_per_cpu_second", "llc_read_misses_per_cpu_second",
    }
    assert tool_start["prediction"]["tool_resource"]["prediction"] is None
    assert (
        tool_start["prediction"]["tool_resource"]["continuous_predictions"]["latency_ms"]["key_kind"]
        == "exact_command"
    )
    algorithms = tool_start["prediction"]["tool_resource"]["prediction_algorithms"]
    assert [item["name"] for item in algorithms["enabled"]] == [
        "clause_latency_bucket",
        "lattice_shrinkage",
        "lattice_loso",
        "lattice_max_cardinality",
        "runtime_tool_resource_conditional_p90",
    ]
    assert algorithms["excluded"] == [
        {
            "name": "quantile_mlp",
            "source": "tool_resource.mlp",
            "reason": "not enabled by the sidecar; this integration uses non-MLP empirical predictors only",
        }
    ]


def _tool_request(event_id: str, tool_call_id: str, command: str) -> ToolBeforeRequest:
    return ToolBeforeRequest(
        schema_version="clawtune.v1",
        event_id=event_id,
        occurred_at="2026-07-24T17:29:44Z",
        plugin_version="0.1.0",
        run_id="run-1",
        session_id="session-1",
        session_key=None,
        agent_id="main",
        tool_call_id=tool_call_id,
        tool_name="exec",
        tool_kind="shell",
        tool_input_kind="json",
        derived_paths=[],
        params_digest="sha256:" + "a" * 64,
        param_features=ParamFeatures(
            serialized_size_bytes=10,
            string_length=10,
            list_item_count=0,
            path_count=0,
            has_command_like_field=True,
        ),
        raw_params={"command": command},
    )


def _tool_completion(event_id: str, tool_call_id: str) -> ToolCompletedEvent:
    return ToolCompletedEvent(
        schema_version="clawtune.v1",
        event_id=event_id,
        occurred_at="2026-07-24T17:29:45Z",
        plugin_version="0.1.0",
        run_id="run-1",
        session_id="session-1",
        session_key=None,
        agent_id="main",
        tool_call_id=tool_call_id,
        decision_id=None,
        lease_id=None,
        execution_id=None,
        tool_name="exec",
        duration_ms=1200,
        succeeded=True,
        error_type=None,
        error_digest=None,
        result_size_bytes=None,
        raw_result=None,
        raw_event=None,
        resource_scope=None,
    )


def _runtime_sample(event_id: str, tool_call_id: str) -> ToolRuntimeSample:
    return ToolRuntimeSample(
        event_id=event_id,
        tool_call_id=tool_call_id,
        tool_name="exec",
        operation="pytest",
        started_at=1_000.0,
        ended_at=1_001.2,
        duration_ms=1200,
        monitor_duration_ms=1200,
        monitor_start_wall_s=1_000.0,
        monitor_end_wall_s=1_001.2,
        monitor_start_monotonic_s=10.0,
        monitor_end_monotonic_s=11.2,
        cpu_time_delta_s=1.0,
        rss_bytes_before=10,
        rss_bytes_after=20,
        read_bytes_delta=0,
        write_bytes_delta=0,
        net_rx_bytes_delta=0,
        net_tx_bytes_delta=0,
        ctx_switches_delta=0,
        rss_bytes_peak=104857600,
        cpu_utilization_avg_cores=0.8,
        cpu_utilization_avg_pct=80.0,
        disk_read_bytes_per_s=0.0,
        disk_write_bytes_per_s=0.0,
        net_rx_bytes_per_s=0.0,
        net_tx_bytes_per_s=0.0,
        sampling_interval_ms=50,
        sampling_point_count=2,
        sampling_quality="ok",
        resource_timeline=[],
        resource_timeline_truncated=False,
        resource_class="unknown",
        target_pid=123,
        process_count_before=1,
        process_count_after=1,
        attribution_status="pid",
        monitor_source="pid",
    )


def _prediction_algorithms() -> dict:
    return {
        "enabled": [
            {
                "name": "clause_latency_bucket",
                "family": "empirical_bucket",
                "source": "ClauseResourceKB",
                "targets": ["latency_ms"],
                "outputs": [
                    "bucket_id",
                    "probability_by_bucket",
                    "duration_p50_ms",
                    "duration_p90_ms",
                    "resource_class",
                ],
            },
            {
                "name": "lattice_shrinkage",
                "family": "context_lattice",
                "source": "LatticeTimeKB",
                "targets": ["latency_ms", "cpu_time_seconds", "cpu_avg_cores", "cpu_peak_cores", "sampled_peak_rss_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["clause_point_prediction_ms", "resource_p50", "resource_p90"],
            },
            {
                "name": "lattice_loso",
                "family": "context_lattice",
                "source": "LatticeTimeKB",
                "targets": ["latency_ms", "cpu_time_seconds", "cpu_avg_cores", "cpu_peak_cores", "sampled_peak_rss_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["clause_point_prediction_ms", "resource_p50", "resource_p90"],
            },
            {
                "name": "lattice_max_cardinality",
                "family": "context_lattice",
                "source": "LatticeTimeKB",
                "targets": ["latency_ms", "cpu_time_seconds", "cpu_avg_cores", "cpu_peak_cores", "sampled_peak_rss_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["clause_point_prediction_ms", "resource_p50", "resource_p90"],
            },
            {
                "name": "runtime_tool_resource_conditional_p90",
                "family": "empirical_ecdf",
                "source": "RuntimeToolResourceKB",
                "targets": ["latency_ms", "cpu_peak_cores", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["conditional_p90"],
            },
        ],
        "excluded": [
            {
                "name": "quantile_mlp",
                "source": "tool_resource.mlp",
                "reason": "not enabled by the sidecar; this integration uses non-MLP empirical predictors only",
            }
        ],
    }


def _unavailable_lattice_time_predictions(
    clauses: list[tuple[str, list[str]]],
) -> list[dict]:
    return [
        {
            "clause_index": clause_index,
            "bin": bin_,
            "argv": argv,
            "predictions": [
                {
                    "algorithm": algorithm,
                    "prediction_ms": None,
                    "selected_features": [],
                    "evidence_count": 0,
                    "selected_risk": None,
                    "exact_match": None,
                    "fallback": None,
                    "unavailable_reason": "no_lattice_time_evidence",
                }
                for algorithm in ("shrinkage", "loso", "max_cardinality")
            ],
        }
        for clause_index, (bin_, argv) in enumerate(clauses)
    ]


# ---------------------------------------------------------------------------
# KV-TTL cost proxy integration tests
# ---------------------------------------------------------------------------


def _bucket_prediction(
    bucket_id: int = 1,
    *,
    probability_by_bucket: tuple[float, ...] = (0.1, 0.8, 0.05, 0.05),
) -> ClauseLatencyBucketPrediction:
    return ClauseLatencyBucketPrediction(
        bucket_id=bucket_id,
        probability_by_bucket=probability_by_bucket,
        scope="exact_clause",
        key_kind="exact_clause",
        evidence_count=10,
        fallback_path=(),
    )


def _edge_predictor(
    edges_ms: tuple[float, ...] = (100.0, 500.0, 2_000.0),
    **kwargs,
) -> ToolResourcePredictor:
    return ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(),
        ebpf_trace_paths=(),
        buckets=LatencyBuckets(edges_ms),
        repo="test-repo",
        **kwargs,
    )


def test_kv_ttl_cost_payload_with_derived_ttl() -> None:
    predictor = _edge_predictor()
    bp = _bucket_prediction(bucket_id=1)
    cost = predictor._kv_ttl_cost_payload(bp, reference_runtime_s=0.3)

    assert cost is not None
    # Derived TTL: buckets_s = [0.1, 0.5, 2.0] → ttl[1] = 0.5
    assert cost["buckets_s"] == [0.1, 0.5, 2.0]
    assert cost["ttl_by_bucket_s"] == [0.1, 0.5, 2.0, 0.0]
    assert cost["initial_bucket_index"] == 1
    assert cost["ttl_s"] == 0.5
    assert cost["kv_eviction_time_s"] == 2.0
    assert cost["reference_runtime_s"] == 0.3
    # 0.3 < dynamic eviction D = 2.0s → no miss, retention = min(0.3, 2.0) = 0.3
    assert cost["kv_retention_time_s"] == 0.3
    assert cost["kv_cache_miss"] is False
    assert cost["num_bucket_jumps"] == 0
    assert cost["proxy_cost_s"] is None
    assert cost["miss_penalty_s"] is None


def test_kv_ttl_cost_payload_with_miss_penalty() -> None:
    predictor = _edge_predictor(miss_penalty_s=2.0)
    bp = _bucket_prediction(bucket_id=0)
    # reference_runtime 0.6s < dynamic eviction D = 2.0s → no miss,
    # retention = min(0.6, 2.0) = 0.6
    cost = predictor._kv_ttl_cost_payload(bp, reference_runtime_s=0.6)

    assert cost is not None
    assert cost["ttl_s"] == 0.1
    assert cost["kv_eviction_time_s"] == 2.0
    assert cost["kv_retention_time_s"] == 0.6
    assert cost["kv_cache_miss"] is False
    assert cost["proxy_cost_s"] == 0.6
    assert cost["miss_penalty_s"] == 2.0


def test_kv_ttl_cost_payload_jumps_multiple_buckets() -> None:
    predictor = _edge_predictor()
    bp = _bucket_prediction(bucket_id=0)
    # p90 = 3.0s → advances through buckets 0..3 into the open tail (3 jumps)
    cost = predictor._kv_ttl_cost_payload(bp, reference_runtime_s=3.0)

    assert cost is not None
    assert cost["initial_bucket_index"] == 0
    assert cost["final_bucket_index"] == 3
    assert cost["num_bucket_jumps"] == 3
    assert cost["bucket_exhausted"] is True
    # TTL from initial bucket 0 = 0.1s, actual 3.0s → miss
    assert cost["kv_cache_miss"] is True
    assert cost["kv_eviction_time_s"] == 2.0
    assert cost["kv_retention_time_s"] == 2.0


def test_kv_ttl_cost_payload_supports_open_ended_last_bucket() -> None:
    predictor = _edge_predictor(edges_ms=(100.0, 500.0))
    bp = _bucket_prediction(bucket_id=2)
    cost = predictor._kv_ttl_cost_payload(bp, reference_runtime_s=5.0)

    assert cost is not None
    assert cost["initial_bucket_index"] == 2
    assert cost["ttl_s"] == 0.0
    assert cost["kv_eviction_time_s"] == 0.0
    assert cost["kv_cache_miss"] is True


def test_kv_ttl_cost_payload_with_custom_ttl_by_bucket() -> None:
    predictor = _edge_predictor(
        edges_ms=(100.0, 500.0, 2_000.0),
        ttl_by_bucket_s=(2.0, 1.0, 0.0, 0.0),
    )
    bp = _bucket_prediction(bucket_id=2)
    cost = predictor._kv_ttl_cost_payload(bp, reference_runtime_s=0.5)

    assert cost is not None
    assert cost["ttl_by_bucket_s"] == [2.0, 1.0, 0.0, 0.0]
    # Initial bucket 2 → TTL = 0.0 (immediate evict)
    assert cost["ttl_s"] == 0.0
    assert cost["kv_cache_miss"] is True
    assert cost["kv_retention_time_s"] == 0.0


def test_sidecar_response_includes_kv_ttl_cost_key(tmp_path: Path) -> None:
    """Prediction payload always carries the ``kv_ttl_cost`` key, even when
    None (no eBPF data available for a bucket prediction)."""
    trace = tmp_path / "trace.jsonl"
    _write_trace(trace)
    state = build_state(
        SidecarConfig(
            tool_resource_trace_paths=(trace,),
            tool_resource_latency_buckets_ms=(100.0, 500.0, 2_000.0),
            tool_resource_artifact_dir=tmp_path / "tool-resource",
        )
    )
    client = TestClient(create_app(state))

    response = client.post(
        "/v1/decisions/tool",
        json={
            "schema_version": "clawtune.v1",
            "event_id": "evt-1",
            "occurred_at": "2026-07-24T17:29:44Z",
            "plugin_version": "0.1.0",
            "run_id": "run-2",
            "session_id": "session-1",
            "session_key": None,
            "agent_id": "main",
            "tool_call_id": "call-2",
            "tool_name": "exec",
            "tool_kind": "shell",
            "tool_input_kind": "json",
            "operation_hint": None,
            "derived_paths": [],
            "params_digest": "sha256:" + "a" * 64,
            "param_features": {
                "serialized_size_bytes": 10,
                "string_length": 10,
                "list_item_count": 0,
                "path_count": 0,
                "has_command_like_field": True,
            },
            "raw_params": {"command": "python -m pytest tests -q"},
            "resource_scope": None,
        },
    )

    assert response.status_code == 200
    tr = response.json()["prediction"]["tool_resource"]
    assert "kv_ttl_cost" in tr
    # Compatible runtime evidence now also supplies duration buckets for TTL.
    assert tr["kv_ttl_cost"]["reference_runtime_s"] == pytest.approx(1.2)


@pytest.mark.parametrize("cleanup,error_kind", [("ok", "incomplete"), ("failed", "incomplete"), ("ok", "invalid"), ("failed", "invalid"), ("ok", "io")])
def test_incomplete_finalization_distinguishes_expected_withholding_from_failure(tmp_path, monkeypatch, cleanup, error_kind):
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(), ebpf_trace_paths=(), buckets=LatencyBuckets((100.0, 500.0)),
        repo="repo-1", artifact_dir=tmp_path,
    )
    artifact_path = tmp_path / "interrupted.json"
    run = SimpleNamespace(tool_call_id="call", _observer=SimpleNamespace(
        context=SimpleNamespace(artifact_path=artifact_path)))
    predictor._runs_by_execution_id["interrupted"] = run
    error = f"ValueError: {artifact_path}: replay execution is incomplete" if error_kind == "incomplete" else "OSError: write failed"
    if error_kind == "invalid":
        error = f"ValueError: {artifact_path}: artifact telemetry quality is 'invalid'; not eligible for KB"
    monkeypatch.setattr(predictor._sdk, "finish_command", lambda *a, **k: SimpleNamespace(
        kb_observations=(), kb_observations_added=0, kb_update_error=error,
        call_telemetry={}, telemetry_artifact={"replay_execution": "incomplete", "cleanup": cleanup, "telemetry_quality": "invalid"},
    ))
    try:
        summary = predictor.finish_execution(execution_id="interrupted", exit_code=None,
                                             signal=None, incomplete_reason="task_timeout")
        assert summary.kb_observations_added == 0
        assert summary.unavailable_reason == "task_timeout"
        assert (summary.kb_update_error is None) == (cleanup == "ok" and error_kind in {"incomplete", "invalid"})
        assert not predictor.execution_active("interrupted")
    finally:
        predictor.close()


def test_edge_kappa_node_limit_does_not_drop_tool_kb_completion(tmp_path, monkeypatch, caplog):
    from edge_kappa_kb import EdgeKappaKB
    from clawtune_sidecar.predictors.edge_kappa import EdgeKappaRuntime
    from tool_time.edge_kappa_adapter import shell_query

    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=(), ebpf_trace_paths=(), artifact_dir=tmp_path,
        buckets=LatencyBuckets((100, 500, 2000, 10000)))
    kb = EdgeKappaKB(max_graph_nodes=1)
    kb.begin(shell_query("python a.py", repo="openclaw"), "old", 1,
             task_id="old", call_id="old", clause_id="0")
    predictor.edge_kappa = EdgeKappaRuntime(kb)
    predictor._telemetry_by_execution_id["execution"] = SimpleNamespace(artifact_path="unused.json")
    monkeypatch.setattr(tool_resource_predictor, "_read_ebpf_artifact", lambda _: {"calls": []})
    monkeypatch.setattr(tool_resource_predictor, "_ebpf_observations", lambda *args, **kwargs: [
        ClauseObservation(repo="openclaw", bin="python", argv=("python", "b.py"),
                          ts_start=1000, ts_end=1001, latency_ms=1000)])
    observed = []
    original_observe = predictor.continuous_kb.observe_completed_call

    def observe(call):
        observed.append(call)
        return original_observe(call)

    monkeypatch.setattr(predictor.continuous_kb, "observe_completed_call", observe)
    try:
        event = _tool_completion("after", "call").model_copy(update={"execution_id": "execution"})
        assert predictor.observe_completion(event, _runtime_sample("after", "call")) == 1
        assert len(observed) == 1
        assert "graph node limit exceeded" in caplog.text
        predictor.flush_kb_updates()
        assert predictor._runtime_kb_persisted_version == predictor._runtime_kb_version == 1
        saved = json.loads((tmp_path / "runtime-tool-resource-kb.json").read_text())
        assert saved == predictor.continuous_kb.to_json_obj()
    finally:
        predictor.close()


def test_edge_kappa_real_predict_completion_and_reload(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from clawtune_sidecar.predictors import call_load
    from clawtune_sidecar.predictors import tool_resource as module
    from tool_resource.runtime_kb import ClauseObservation
    monkeypatch.setattr(call_load, "plain_execution", lambda _: ((dict(
        bin="python", argv=["python", "job.py"], clause_index=0,
        in_pipe=False, pipeline_position=-1),), None))
    clock = [999.0]
    monkeypatch.setattr(module.time, "time", lambda: clock[0])
    predictor = ToolResourcePredictor.from_traces(openclaw_trace_paths=(), ebpf_trace_paths=(),
        buckets=LatencyBuckets((100, 500, 2000, 10000)), artifact_dir=tmp_path)
    request = _tool_request("before-edge", "edge-call", "python job.py")
    predictor.record_tool_started(request)
    first = predictor.predict(request)
    assert first.edge_kappa.targets["duration_ms"].status == "unavailable"
    assert first.tool == first.call_prediction
    predictor._telemetry_by_execution_id["edge-execution"] = SimpleNamespace(artifact_path="unused.json")
    monkeypatch.setattr(module, "_read_ebpf_artifact", lambda _: {"calls": []})
    observation = ClauseObservation(repo="openclaw", bin="python", argv=("python", "job.py"),
        ts_start=1000., ts_end=1001., latency_ms=1000.)
    monkeypatch.setattr(module, "_ebpf_observations", lambda *args, **kwargs: [observation])
    event = _tool_completion("after-edge", "edge-call").model_copy(update={"execution_id": "edge-execution"})
    clock[0] = 1002.
    predictor.observe_completion(event, _runtime_sample("after-edge", "edge-call"))
    second = predictor.predict(_tool_request("before-next", "edge-next", "python job.py"))
    assert second.edge_kappa.targets["duration_ms"].avg == 1000
    assert second.edge_kappa.targets["duration_ms"].buckets.probabilities == [0, 0, 1, 0, 0]
    assert second.edge_kappa.targets["cpu_avg_cores"].status == "unavailable"
    predictor.flush_kb_updates()
    saved = json.loads((tmp_path / "edge-kappa-kb.json").read_text())
    assert saved["generation"] == 1
    predictor.close()
    restored = ToolResourcePredictor.from_traces(openclaw_trace_paths=(), ebpf_trace_paths=(),
        buckets=LatencyBuckets((100, 500, 2000, 10000)), artifact_dir=tmp_path)
    assert not restored.report.rejections
    assert restored.predict(_tool_request("again", "another", "python job.py")).edge_kappa.targets["duration_ms"].avg == 1000
    restored.close()
