from __future__ import annotations

import json
import os
import time
from threading import Event
from types import SimpleNamespace
from datetime import datetime, timezone
from pathlib import Path

import httpx
import pytest
from fastapi.testclient import TestClient

import clawtune_sidecar.api.app as app_module
from clawtune_sidecar.api.app import create_app
from clawtune_sidecar.api.dependencies import build_state
from clawtune_sidecar.config import SidecarConfig
from clawtune_sidecar.contracts.models import ParamFeatures, ResourceScope, ToolBeforeRequest
from clawtune_sidecar.llm_proxy import (
    _forward_headers,
    _parse_sse_buffer,
    _upstream_url,
)
from clawtune_sidecar.monitoring.docker_exec import DockerExecObserver, _docker_events_command
from clawtune_sidecar.monitoring.tool_runtime import _relative_timeline
from clawtune_sidecar.trace import _coverage, _tool_timestamps


def test_tool_action_window_uses_reported_duration_not_monitor_window() -> None:
    sample = SimpleNamespace(started_at=100.0, ended_at=101.0)

    assert _tool_timestamps(sample, 100) == (100.9, 101.0)


def test_coverage_ratio_is_defensively_bounded() -> None:
    duration_ns, ratio, reason = _coverage(
        action_start_wall_ns=1_000,
        action_end_wall_ns=2_000,
        action_duration_ns=100,
        monitor_start_wall_ns=900,
        monitor_end_wall_ns=2_100,
        has_pid=True,
    )

    assert duration_ns == 100
    assert ratio == 1.0
    assert reason == "full_window"


def test_runtime_drain_can_defer_global_kb_flush(monkeypatch, tmp_path) -> None:
    state = build_state(SidecarConfig(trace_dir=tmp_path / "traces"))
    flushes: list[float | None] = []
    monkeypatch.setattr(
        state.predictor,
        "flush_kb_updates",
        lambda timeout_seconds=None: flushes.append(timeout_seconds),
    )

    with TestClient(create_app(state)) as client:
        deferred = client.post(
            "/v1/runtime/task-runtime/drain?flush_kb=false"
        )
        assert deferred.status_code == 200
        assert deferred.json()["drained"] is True
        assert deferred.json()["kb_flushed"] is False
        assert flushes == []

        durable = client.post(
            "/v1/runtime/final-barrier/drain?flush_kb=true"
        )
        assert durable.status_code == 200
        assert durable.json()["kb_flushed"] is True
        assert len(flushes) == 1


def test_runtime_drain_keeps_claimed_execution_out_of_kb_barrier(monkeypatch, tmp_path) -> None:
    state = build_state(SidecarConfig(trace_dir=tmp_path / "traces"))
    flushes: list[bool] = []
    monkeypatch.setattr(state.predictor, "flush_kb_updates", lambda *_args, **_kwargs: flushes.append(True))
    with TestClient(create_app(state)) as client:
        registration = client.post(
            "/v2/executions",
            json={
                "execution_id": "exec-a",
                "tool_call_id": "call-a",
                "run_id": "run-a",
                "session_key_hash": None,
                "runtime_id": "task-a",
                "gateway_id": "swe-rebench",
                "command_digest": "sha256:" + "a" * 64,
                "command": "true",
                "backend": "managed-wrapper",
            },
        )
        assert registration.status_code == 200
        claim = client.post(
            "/v2/executions/claim",
            json={
                "execution_id": "exec-a",
                "token": registration.json()["one_time_token"],
                "launcher_pid": 1234,
            },
        )
        assert claim.status_code == 200
        path = "/v1/gateways/swe-rebench/runtimes/task-a/drain?timeout_seconds=0"
        waiting = client.post(path)
        assert waiting.status_code == 200
        assert waiting.json()["drained"] is False
        assert waiting.json()["claimed_unexited_ids"] == ["exec-a"]
        assert flushes == []
        exited = client.post(
            "/v2/executions/exec-a/exited",
            json={"update_token": claim.json()["update_token"], "exit_code": 125, "signal": None},
        )
        assert exited.status_code == 200
        assert client.post(path).json()["drained"] is True
        assert flushes == [True]


def test_benchmark_final_barrier_waits_for_real_runtime(monkeypatch, tmp_path):
    import io
    import urllib.parse
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[3]))
    from benchmarks.runtime import flush_all_kb_updates
    from swe_rebench import host_openclaw as host

    state = build_state(SidecarConfig(trace_dir=tmp_path / "traces"))
    flushes = []
    monkeypatch.setattr(state.predictor, "flush_kb_updates", lambda *a, **k: flushes.append(True))
    state._runtime_activity[("swe-rebench", "task-b")] = 1
    with TestClient(create_app(state)) as client:
        def urlopen(request, **kwargs):
            url = urllib.parse.urlsplit(request.full_url)
            response = client.post(url.path + "?" + url.query)
            response.raise_for_status()
            return io.BytesIO(response.content)
        monkeypatch.setattr(host.urllib.request, "urlopen", urlopen)
        with pytest.raises(RuntimeError, match="task-b did not drain"):
            flush_all_kb_updates(8765, ["task-a", "task-b"], timeout_seconds=0)
        assert flushes == []
        state._runtime_activity.clear()
        flush_all_kb_updates(8765, ["task-a", "task-b"])
        assert flushes == [True]


def test_v6_quality_is_honest_about_partial_sampling() -> None:
    from clawtune_sidecar.trace import _v6_quality

    # Full window coverage with healthy sampling is the only "complete".
    assert _v6_quality("ok", "full_window") == "complete"
    # Partial/low sampling must never be labelled complete even under full
    # coverage (e.g. a rebased/mixed baseline that only sampled a late window).
    assert _v6_quality("partial", "full_window") == "partial"
    assert _v6_quality("low", "full_window") == "partial"
    assert _v6_quality("partial", "pid_registered_late") == "partial"
    assert _v6_quality("ok", "pid_registered_late") == "partial"
    assert _v6_quality("unattributed", "full_window") == "unknown"
    assert _v6_quality("unavailable", "full_window") == "unknown"


def test_host_execution_cgroup_roots_are_permission_aware(monkeypatch) -> None:
    from clawtune_sidecar.api import app as app_module

    fallback = ResourceScope(
        kind="cgroup-v2",
        pid=1,
        root_pid=1,
        cgroup_path="/sys/fs/cgroup/system.slice/docker-x.scope",
        source="openclaw-sandbox",
        attribution_source="shared-sandbox-container",
    )
    # Non-root (no geteuid on this platform -> euid -1): only the fallback
    # container subtree candidate is emitted.
    roots = app_module._host_execution_cgroup_roots(fallback, None)
    assert "/sys/fs/cgroup/system.slice/docker-x.scope/clawtune-executions" in roots

    # A configured root short-circuits the search entirely.
    assert app_module._host_execution_cgroup_roots(fallback, "/cfg/clawtune") == [
        "/cfg/clawtune"
    ]

    # Root (euid 0): try the sandbox container subtree first when it was
    # already delegated, then the root-managed clawtune cgroup. Provisioning
    # now verifies delegation and skips the first candidate when Docker's
    # populated scope cannot enable domain controllers for children.
    import types

    monkeypatch.setattr(
        app_module, "os", types.SimpleNamespace(geteuid=lambda: 0)
    )
    roots_root = app_module._host_execution_cgroup_roots(fallback, None)
    assert roots_root[0].replace("\\", "/") == (
        "/sys/fs/cgroup/system.slice/docker-x.scope/clawtune-executions"
    )
    assert any(
        root.replace("\\", "/") == "/sys/fs/cgroup/clawtune"
        for root in roots_root
    )


def test_docker_exec_observer_cgroup_diff_fallback_captures_pid(tmp_path: Path) -> None:
    from clawtune_sidecar.contracts.models import ToolCompletedEvent

    cgroup = tmp_path / "sandbox-cgroup"
    cgroup.mkdir()
    (cgroup / "cgroup.procs").write_text("100\n", encoding="utf-8")
    request = ToolBeforeRequest(
        schema_version="clawtune.v1",
        event_id="evt-read-start",
        occurred_at="2026-07-16T03:23:00Z",
        plugin_version="0.1.0",
        run_id="run-diff",
        session_id="session-diff",
        session_key=None,
        agent_id=None,
        tool_call_id="call-read",
        tool_name="read",
        tool_kind="file",
        tool_input_kind="json",
        operation_hint=None,
        derived_paths=[],
        params_digest="sha256:" + "a" * 64,
        param_features=ParamFeatures(
            serialized_size_bytes=10,
            string_length=5,
            list_item_count=0,
            path_count=1,
            has_command_like_field=False,
        ),
        raw_params={"path": "README.md"},
        resource_scope=ResourceScope(
            kind="cgroup-v2",
            cgroup_path=str(cgroup),
            container_id="sandbox-1",
            include_children=True,
            source="openclaw-sandbox",
            attribution_source="shared-sandbox-container",
        ),
    )
    observer = DockerExecObserver(
        enabled=True, cgroup_path=str(cgroup), autostart=False
    )
    observer.begin_tool(request)
    # A new pid (the read docker exec) appears in the container cgroup during
    # the tool window; the docker-events path finds nothing.
    (cgroup / "cgroup.procs").write_text("100\n12345\n", encoding="utf-8")
    observer._poll_cgroup_once()
    event = ToolCompletedEvent(
        schema_version="clawtune.v1",
        event_id="evt-read-end",
        occurred_at="2026-07-16T03:23:01Z",
        plugin_version="0.1.0",
        run_id="run-diff",
        session_id="session-diff",
        session_key=None,
        agent_id=None,
        tool_call_id="call-read",
        decision_id="decision-1",
        lease_id="lease-1",
        execution_id=None,
        tool_name="read",
        duration_ms=100,
        succeeded=True,
        error_type=None,
        error_digest=None,
        result_size_bytes=4,
        raw_result="data",
        resource_scope=None,
    )
    scope = observer.infer_scope(event)
    assert scope is not None
    assert scope.kind == "pid"
    assert scope.root_pid == 12345
    assert scope.attribution_source == "docker-exec-pid"
    assert scope.source == "docker-cgroup-diff"
    diag = observer.diagnostics()
    assert diag["cgroup_diff_captures"] == 1


def test_prepare_host_execution_cgroup_moves_pid_tree_and_records_diagnostics(
    tmp_path: Path,
    monkeypatch,
) -> None:
    cgroup_root = tmp_path / "cgroup"
    cgroup_root.mkdir()
    (cgroup_root / "cgroup.controllers").write_text(
        "cpu memory\n", encoding="utf-8"
    )
    monkeypatch.setattr(app_module, "_CGROUP_V2_ROOT", cgroup_root)
    monkeypatch.setattr(app_module, "_PROC_ROOT", tmp_path / "proc")
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(app_module, "_cgroup_accounting_usable", lambda _path: True)
    monkeypatch.setattr(
        app_module,
        "_execution_cgroup_accounting_usable",
        lambda _path: True,
    )
    # The payload has already forked a child; both must be moved into the
    # per-execution cgroup so the cgroup captures the whole tool's CPU.
    monkeypatch.setattr(
        app_module, "_process_tree_pids", lambda _pid: [4242, 9999]
    )
    execution_cgroup = cgroup_root / "clawtune" / "exec-1"
    written_pids: list[int] = []
    original_write_text = Path.write_text

    def capture_cgroup_write(path: Path, data: str, *args, **kwargs) -> int:
        # Other tests may still have asynchronous cgroup cleanup work running.
        # Observe only the execution cgroup created by this test so unrelated
        # background writes cannot make this assertion timing-dependent.
        if path == execution_cgroup / "cgroup.procs":
            written_pids.append(int(data.strip()))
        return original_write_text(path, data, *args, **kwargs)

    monkeypatch.setattr(Path, "write_text", capture_cgroup_write)
    request = SimpleNamespace(
        child_pid=7,
        pid_namespace_inode=123,
        process_starttime_ticks=456,
        container_id=None,
    )
    diagnostics: list[str] = []

    scope = app_module._prepare_host_execution_cgroup(
        "exec-1",
        request,
        None,
        None,
        diagnostics=diagnostics,
    )

    assert scope is not None
    assert scope.kind == "cgroup-v2"
    assert scope.cgroup_path == str(execution_cgroup)
    assert scope.attribution_source == "exclusive-execution-cgroup"
    procs = (execution_cgroup / "cgroup.procs").read_text(encoding="utf-8").split()
    assert written_pids == [9999, 4242]
    assert "4242" in procs
    joined = "\n".join(diagnostics)
    assert "resolved launcher host pid 4242" in joined
    assert "owns launcher pid tree" in joined


def test_prepare_host_execution_cgroup_uses_stable_environment_parent(
    tmp_path: Path,
    monkeypatch,
) -> None:
    root = tmp_path / "delegated"
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(app_module, "_host_execution_cgroup_roots", lambda *_args: [str(root)])
    monkeypatch.setattr(app_module, "_enable_cgroup_controllers", lambda _path: frozenset({"cpu", "memory"}))
    monkeypatch.setattr(app_module, "_cgroup_accounting_usable", lambda _path: True)
    monkeypatch.setattr(app_module, "_execution_cgroup_accounting_usable", lambda _path: True)
    moved_to: list[Path] = []
    monkeypatch.setattr(
        app_module,
        "_move_pid_tree_into_cgroup",
        lambda _pid, path, **_kwargs: moved_to.append(path) or True,
    )
    request = SimpleNamespace(
        child_pid=7,
        pid_namespace_inode=123,
        process_starttime_ticks=456,
        container_id="container-a",
    )
    first = app_module._prepare_host_execution_cgroup(
        "exec-1", request, None, None, environment_identity="gateway|runtime|container-a"
    )
    second = app_module._prepare_host_execution_cgroup(
        "exec-2", request, None, None, environment_identity="gateway|runtime|container-a"
    )
    assert first is not None and second is not None
    assert Path(first.cgroup_path).parent == Path(second.cgroup_path).parent
    assert Path(first.cgroup_path).parent.name.startswith("env-")
    assert moved_to == [Path(first.cgroup_path), Path(second.cgroup_path)]


def test_prepare_host_execution_cgroup_skips_undelegated_candidate(
    tmp_path: Path,
    monkeypatch,
) -> None:
    docker_root = tmp_path / "docker.scope" / "clawtune-executions"
    delegated_root = tmp_path / "delegated"
    moved_to: list[Path] = []
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(
        app_module,
        "_host_execution_cgroup_roots",
        lambda *_args: [str(docker_root), str(delegated_root)],
    )
    monkeypatch.setattr(
        app_module,
        "_enable_cgroup_controllers",
        lambda _path: frozenset(),
    )
    monkeypatch.setattr(
        app_module,
        "_cgroup_accounting_usable",
        lambda path: path == delegated_root,
    )
    monkeypatch.setattr(
        app_module,
        "_execution_cgroup_accounting_usable",
        lambda _path: True,
    )

    def move(_pid, path, **_kwargs):
        moved_to.append(path)
        return True

    monkeypatch.setattr(app_module, "_move_pid_tree_into_cgroup", move)
    request = SimpleNamespace(
        child_pid=7,
        pid_namespace_inode=123,
        process_starttime_ticks=456,
        container_id=None,
    )
    diagnostics: list[str] = []

    scope = app_module._prepare_host_execution_cgroup(
        "exec-1",
        request,
        None,
        None,
        diagnostics=diagnostics,
    )

    expected = delegated_root / "exec-1"
    assert scope is not None
    assert scope.cgroup_path == str(expected)
    assert moved_to == [expected]
    assert any(
        "cpu and memory controllers not delegated" in item
        and str(docker_root) in item
        for item in diagnostics
    )


def test_move_pid_tree_retries_when_live_child_membership_is_missing(
    tmp_path: Path,
    monkeypatch,
) -> None:
    cgroup = tmp_path / "execution-cgroup"
    cgroup.mkdir()
    (cgroup / "cgroup.procs").write_text("", encoding="utf-8")
    proc_root = tmp_path / "proc"
    (proc_root / "9999").mkdir(parents=True)
    monkeypatch.setattr(app_module, "_PROC_ROOT", proc_root)
    monkeypatch.setattr(
        app_module,
        "_process_tree_pids",
        lambda _root_pid: [4242, 9999],
    )
    sleeps: list[float] = []
    monkeypatch.setattr(app_module.time, "sleep", sleeps.append)

    moved = app_module._move_pid_tree_into_cgroup(4242, cgroup)

    assert moved is False
    assert sleeps == [0.02, 0.02]
    assert (cgroup / "cgroup.procs").read_text(encoding="utf-8").strip() == "4242"


def test_enable_cgroup_controllers_separates_required_from_optional(
    tmp_path: Path,
    monkeypatch,
) -> None:
    root = tmp_path / "cgroup"
    enabled: set[str] = set()
    writes: list[str] = []

    def fake_read(path: Path, **_kwargs) -> str:
        if path.name == "cgroup.controllers":
            # cpuset is intentionally unavailable and must not poison the
            # required cpu+memory operation.
            return "cpu memory io"
        if path.name == "cgroup.subtree_control":
            return " ".join(sorted(enabled))
        raise OSError(path)

    def fake_write(path: Path, value: str, **_kwargs) -> int:
        assert path.name == "cgroup.subtree_control"
        writes.append(value)
        for token in value.split():
            if token.startswith("+"):
                enabled.add(token[1:])
        return len(value)

    monkeypatch.setattr(Path, "read_text", fake_read)
    monkeypatch.setattr(Path, "write_text", fake_write)

    result = app_module._enable_cgroup_controllers(root)

    assert writes == ["+cpu +memory", "+io"]
    assert result == frozenset({"cpu", "memory", "io"})


@pytest.mark.parametrize(
    ("subtree_control", "expected"),
    [
        ("cpu memory", True),
        ("memory cpu io", True),
        ("cpu", False),
        ("memory", False),
        ("pids", False),
        ("", False),
    ],
)
def test_cgroup_accounting_usable_requires_cpu_and_memory(
    tmp_path: Path,
    subtree_control: str,
    expected: bool,
) -> None:
    from clawtune_sidecar.api import app as app_module

    parent = tmp_path / "parent"
    root = parent / "execution-root"
    root.mkdir(parents=True)
    # A rich parent availability list must not mask a missing delegation on
    # the root that will own the per-execution children.
    (parent / "cgroup.controllers").write_text(
        "cpu memory io cpuset\n",
        encoding="utf-8",
    )
    (root / "cgroup.subtree_control").write_text(
        subtree_control,
        encoding="utf-8",
    )

    assert app_module._cgroup_accounting_usable(root) is expected


def test_cgroup_accounting_usable_fails_closed_when_readback_missing(
    tmp_path: Path,
) -> None:
    parent = tmp_path / "parent"
    root = parent / "execution-root"
    root.mkdir(parents=True)
    (parent / "cgroup.controllers").write_text(
        "cpu memory io cpuset\n",
        encoding="utf-8",
    )

    assert app_module._cgroup_accounting_usable(root) is False


@pytest.mark.parametrize(
    ("cpu_stat", "memory_current", "expected"),
    [
        ("usage_usec 0\n", "0\n", True),
        ("usage_usec 123\n", "4096\n", True),
        ("user_usec 1\n", "4096\n", False),
        ("usage_usec nope\n", "4096\n", False),
        ("usage_usec 1\n", "nope\n", False),
    ],
)
def test_execution_cgroup_requires_parsable_cpu_and_memory_interfaces(
    tmp_path: Path,
    cpu_stat: str,
    memory_current: str,
    expected: bool,
) -> None:
    leaf = tmp_path / "execution"
    leaf.mkdir()
    (leaf / "cpu.stat").write_text(cpu_stat, encoding="utf-8")
    (leaf / "memory.current").write_text(memory_current, encoding="utf-8")

    assert app_module._execution_cgroup_accounting_usable(leaf) is expected


def test_execution_cgroup_accounting_fails_when_interface_is_missing(
    tmp_path: Path,
) -> None:
    leaf = tmp_path / "execution"
    leaf.mkdir()
    (leaf / "cpu.stat").write_text("usage_usec 1\n", encoding="utf-8")

    assert app_module._execution_cgroup_accounting_usable(leaf) is False


def _read_trace_records(trace_dir: Path) -> list[dict]:
    """Find the first JSONL file in trace_dir and return parsed records."""
    files = list(trace_dir.glob("*.jsonl"))
    if not files:
        return []
    return [json.loads(line) for line in files[0].read_text(encoding="utf-8").splitlines()]


def _client(tmp_path: Path) -> TestClient:
    state = build_state(SidecarConfig(trace_dir=tmp_path / "traces"))
    return TestClient(create_app(state))


def _trace_client(tmp_path: Path) -> tuple[TestClient, Path]:
    trace_dir = tmp_path / "traces"
    state = build_state(SidecarConfig(trace_dir=trace_dir))
    return TestClient(create_app(state)), trace_dir


def _trace_proxy_client(tmp_path: Path) -> tuple[TestClient, Path]:
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            llm_proxy_upstream_base_url="https://upstream.example/v1",
        )
    )
    return TestClient(create_app(state)), trace_dir


def _trace_client_with_sandbox_cgroup(tmp_path: Path, cgroup_path: Path) -> tuple[TestClient, Path]:
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            sandbox_cgroup_path=str(cgroup_path),
            sandbox_container_id="sandbox-1",
            tool_resource_ebpf_required=False,
        )
    )
    return TestClient(create_app(state)), trace_dir


def test_health_endpoints_publish_stable_clawtune_identity(tmp_path: Path) -> None:
    client = _client(tmp_path)

    live = client.get("/health/live")
    ready = client.get("/health/ready")

    assert live.status_code == 200
    live_payload = live.json()
    assert live_payload["schema_version"] == "clawtune.health.v1"
    assert live_payload["service"] == "clawtune-sidecar"
    assert live_payload["live"] is True
    # Version-negotiation fields are part of the initial 0.1.0 protocol.
    assert isinstance(live_payload.get("sidecar_version"), str)
    assert isinstance(live_payload.get("protocol_versions"), list)

    assert ready.status_code == 200
    ready_payload = ready.json()
    assert ready_payload["schema_version"] == "clawtune.health.v1"
    assert ready_payload["service"] == "clawtune-sidecar"
    assert ready_payload["ready"] is True
    assert isinstance(ready_payload.get("sidecar_version"), str)
    assert isinstance(ready_payload.get("protocol_versions"), list)


def _write_cgroup_fixture(path: Path, usage_usec: int = 100_000) -> None:
    path.mkdir()
    (path / "cpu.stat").write_text(f"usage_usec {usage_usec}\n", encoding="utf-8")
    (path / "memory.current").write_text("4096\n", encoding="utf-8")
    (path / "io.stat").write_text("8:0 rbytes=10 wbytes=20\n", encoding="utf-8")
    (path / "cgroup.procs").write_text("", encoding="utf-8")


def _register_claimed_execution(
    client: TestClient,
    *,
    execution_id: str = "call-exec",
    runtime_id: str = "runtime-1",
    gateway_id: str = "gateway-1",
) -> dict[str, object]:
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": execution_id,
            "tool_call_id": "call-exec",
            "run_id": "run-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"enable_cgroup": True},
            "backend": "managed-wrapper",
            "runtime_id": runtime_id,
            "gateway_id": gateway_id,
        },
    ).json()
    claimed = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": execution_id,
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    )
    assert claimed.status_code == 200
    return claimed.json()


def test_host_cgroup_path_is_derived_from_verified_pid_membership(
    tmp_path: Path,
) -> None:
    proc_root = tmp_path / "proc"
    cgroup_root = tmp_path / "cgroup"
    target = cgroup_root / "user.slice" / "tool.scope"
    (proc_root / "4242").mkdir(parents=True)
    target.mkdir(parents=True)
    (cgroup_root / "cgroup.controllers").write_text("cpu memory\n", encoding="utf-8")
    (proc_root / "4242" / "cgroup").write_text(
        "0::/user.slice/tool.scope\n",
        encoding="utf-8",
    )
    (target / "cgroup.procs").write_text("4242\n", encoding="utf-8")

    assert app_module._host_cgroup_path_for_pid(
        4242,
        proc_root=proc_root,
        cgroup_root=cgroup_root,
    ) == str(target.resolve())


@pytest.mark.parametrize(
    ("relative", "members"),
    [
        ("/", "4242\n"),
        ("/user.slice/tool.scope", "9999\n"),
        ("/../outside", "4242\n"),
    ],
)
def test_host_cgroup_path_rejects_root_nonmember_and_escape(
    tmp_path: Path,
    relative: str,
    members: str,
) -> None:
    proc_root = tmp_path / "proc"
    cgroup_root = tmp_path / "cgroup"
    target = cgroup_root / "user.slice" / "tool.scope"
    (proc_root / "4242").mkdir(parents=True)
    target.mkdir(parents=True)
    (cgroup_root / "cgroup.controllers").write_text("cpu\n", encoding="utf-8")
    (proc_root / "4242" / "cgroup").write_text(
        f"0::{relative}\n",
        encoding="utf-8",
    )
    (target / "cgroup.procs").write_text(members, encoding="utf-8")

    assert app_module._host_cgroup_path_for_pid(
        4242,
        proc_root=proc_root,
        cgroup_root=cgroup_root,
    ) is None


def test_host_cgroup_gate_uses_standard_v2_root_when_unconfigured(
    tmp_path: Path,
    monkeypatch,
) -> None:
    cgroup_root = tmp_path / "cgroup"
    cgroup_root.mkdir()
    (cgroup_root / "cgroup.controllers").write_text("cpu memory\n", encoding="utf-8")
    monkeypatch.setattr(app_module, "_CGROUP_V2_ROOT", cgroup_root)
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(app_module, "_cgroup_accounting_usable", lambda _path: True)
    monkeypatch.setattr(
        app_module,
        "_execution_cgroup_accounting_usable",
        lambda _path: True,
    )
    request = SimpleNamespace(
        child_pid=7,
        pid_namespace_inode=123,
        process_starttime_ticks=456,
        container_id=None,
    )

    scope = app_module._prepare_host_execution_cgroup(
        "exec-1",
        request,
        None,
        None,
    )

    assert scope is not None
    assert scope.cgroup_path == str(cgroup_root / "clawtune" / "exec-1")
    assert (
        cgroup_root / "clawtune" / "exec-1" / "cgroup.procs"
    ).read_text(encoding="utf-8").strip() == "4242"


def test_verified_host_scope_falls_back_to_authenticated_pid_lineage(
    tmp_path: Path,
    monkeypatch,
) -> None:
    shared = tmp_path / "session.scope"
    shared.mkdir()
    monkeypatch.setattr(
        app_module,
        "_host_cgroup_path_for_pid",
        lambda _pid: str(shared),
    )
    monkeypatch.setattr(app_module, "_pid_starttime_ticks", lambda _pid: 99)
    monkeypatch.setattr(app_module, "_pid_namespace_inode", lambda _pid: 123)

    scope = app_module._verified_host_execution_scope(
        "exec-1",
        SimpleNamespace(cgroup_path=None),
        4242,
    )

    assert scope is not None
    assert scope.root_pid == 4242
    assert scope.cgroup_path == str(shared)
    assert scope.attribution_source == "trusted-execution-root-pid"


def _trace_proxy_client_with_debug(tmp_path: Path) -> tuple[TestClient, Path]:
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            llm_proxy_upstream_base_url="https://upstream.example/v1",
            llm_proxy_debug_dump=True,
        )
    )
    return TestClient(create_app(state)), trace_dir


def test_llm_proxy_upstream_url_preserves_v1_when_base_omits_it() -> None:
    assert (
        _upstream_url(
            SidecarConfig(llm_proxy_upstream_base_url="https://api.deepseek.com"),
            "/v1/chat/completions",
        )
        == "https://api.deepseek.com/v1/chat/completions"
    )
    assert (
        _upstream_url(
            SidecarConfig(llm_proxy_upstream_base_url="https://api.deepseek.com/v1"),
            "/v1/chat/completions",
        )
        == "https://api.deepseek.com/v1/chat/completions"
    )


def test_llm_proxy_forwards_openclaw_authorization_header_by_default() -> None:
    class Request:
        headers = {
            "authorization": "Bearer sk-openclaw",
            "content-type": "application/json",
        }

    headers_without_upstream_key = _forward_headers(Request(), SidecarConfig())
    assert headers_without_upstream_key["authorization"] == "Bearer sk-openclaw"
    assert headers_without_upstream_key["content-type"] == "application/json"


def test_llm_proxy_upstream_key_overrides_openclaw_authorization_header() -> None:
    class Request:
        headers = {
            "authorization": "Bearer sk-openclaw",
            "content-type": "application/json",
        }

    headers = _forward_headers(
        Request(),
        SidecarConfig(llm_proxy_upstream_api_key="real-key"),
    )

    assert headers["authorization"] == "Bearer real-key"
    assert headers["content-type"] == "application/json"


def test_decision_and_completion_round_trip(tmp_path: Path) -> None:
    client = _client(tmp_path)
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-1",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": None,
        "session_id": None,
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-1",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": "pytest",
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": None,
        "resource_scope": None,
    }
    decision_response = client.post("/v1/decisions/tool", json=request)
    assert decision_response.status_code == 200
    decision = decision_response.json()
    assert decision["action"] == "allow"

    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-2",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": None,
        "session_id": None,
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-1",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "exec",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": None,
    }
    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}
    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": False}
    recent = client.get("/v1/tools/recent").json()
    assert len(recent["samples"]) == 1
    sample = recent["samples"][0]
    assert sample["tool_call_id"] == "call-1"
    assert sample["tool_name"] == "exec"
    assert sample["duration_ms"] == 100
    assert sample["resource_class"] == "unknown"
    assert sample["attribution_status"] == "unattributed"

    request_without_tool_call_id = request | {
        "event_id": "evt-3",
        "tool_call_id": None,
        "params_digest": "sha256:" + "b" * 64,
        "resource_scope": {
            "pid": os.getpid(),
            "process_start_time": None,
            "container_id": None,
            "include_children": True,
            "source": "test",
        },
    }
    second_decision = client.post("/v1/decisions/tool", json=request_without_tool_call_id).json()
    completion_without_tool_call_id = completion | {
        "event_id": "evt-4",
        "tool_call_id": None,
        "decision_id": second_decision["decision_id"],
        "lease_id": second_decision["lease_id"],
    }
    assert client.post("/v1/events/tool-completed", json=completion_without_tool_call_id).json() == {
        "stored": True
    }
    recent = client.get("/v1/tools/recent").json()
    assert len(recent["samples"]) == 2
    assert recent["samples"][0]["target_pid"] == os.getpid()


def test_metrics_endpoint(tmp_path: Path) -> None:
    client = _client(tmp_path)
    response = client.get("/metrics")
    assert response.status_code == 200
    assert "scheduler_tool_requests_total" in response.text
    assert "scheduler_tool_runtime_samples_total" in response.text
    assert "scheduler_tool_runtime_unattributed_samples_total" in response.text
    assert "scheduler_tool_cpu_seconds_total" in response.text
    assert "scheduler_tool_memory_rss_bytes" in response.text
    assert "scheduler_tool_memory_rss_peak_bytes" in response.text
    assert "scheduler_tool_process_count" in response.text
    assert "scheduler_tool_cpu_utilization_avg_cores" in response.text
    assert "scheduler_tool_net_rx_bytes_total" in response.text
    assert "scheduler_tool_net_tx_bytes_total" in response.text
    assert "scheduler_tool_io_write_bytes_per_second" in response.text
    assert "scheduler_tool_net_tx_bytes_per_second" in response.text


@pytest.mark.parametrize("tool_name", ["read", "web_search", "web_fetch"])
def test_internal_tool_prefers_shared_sandbox_over_shared_runtime_scope(
    tmp_path: Path, tool_name: str,
) -> None:
    cgroup = tmp_path / "cgroup"
    runtime_cgroup = tmp_path / "runtime-cgroup"
    cgroup.mkdir()
    runtime_cgroup.mkdir()
    (cgroup / "cpu.stat").write_text("usage_usec 100000\n", encoding="utf-8")
    (cgroup / "memory.current").write_text("4096\n", encoding="utf-8")
    (cgroup / "io.stat").write_text("8:0 rbytes=10 wbytes=20\n", encoding="utf-8")
    (cgroup / "cgroup.procs").write_text("", encoding="utf-8")
    (runtime_cgroup / "cpu.stat").write_text("usage_usec 900000\n", encoding="utf-8")
    (runtime_cgroup / "memory.current").write_text("8192\n", encoding="utf-8")
    (runtime_cgroup / "io.stat").write_text(
        "8:0 rbytes=100 wbytes=200\n", encoding="utf-8"
    )
    (runtime_cgroup / "cgroup.procs").write_text("", encoding="utf-8")
    client, trace_dir = _trace_client_with_sandbox_cgroup(tmp_path, cgroup)
    shared_runtime_scope = {
        "kind": "cgroup-v2",
        "execution_id": None,
        "pid": os.getpid(),
        "root_pid": os.getpid(),
        "process_start_time": None,
        "root_starttime_ticks": None,
        "cgroup_path": str(runtime_cgroup),
        "pid_namespace_inode": None,
        "container_id": None,
        "include_children": True,
        "source": "openclaw-runtime",
        "attribution_source": "shared-runtime-process",
    }
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-sandbox",
        "session_id": "session-sandbox",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read",
        "tool_name": "read",
        "tool_kind": "file",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 1,
            "has_command_like_field": False,
        },
        "raw_params": {"path": "README.md"},
        "resource_scope": shared_runtime_scope,
    }
    request["tool_name"] = tool_name
    decision = client.post("/v1/decisions/tool", json=request).json()
    time.sleep(0.03)  # Allow the background sampler to establish its initial sample.
    update = cgroup / "cpu.stat.next"
    update.write_text("usage_usec 200000\n", encoding="utf-8")
    update.replace(cgroup / "cpu.stat")
    time.sleep(0.03)
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-end",
        "occurred_at": datetime.now(timezone.utc).isoformat(),
        "plugin_version": "0.1.0",
        "run_id": "run-sandbox",
        "session_id": "session-sandbox",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "read",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 4,
        "raw_result": "data",
        "resource_scope": shared_runtime_scope,
    }

    completion["tool_name"] = tool_name
    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    trace_records = _read_trace_records(trace_dir)
    tool_start = [
        record
        for record in trace_records
        if record.get("record_type") == "span_start" and record.get("kind") == "tool"
    ][0]
    tool_end = [
        record
        for record in trace_records
        if record.get("record_type") == "span_end" and record.get("kind") == "tool"
    ][0]
    expected_cgroup = runtime_cgroup if tool_name in {"web_search", "web_fetch"} else cgroup
    assert tool_end["execution"]["cgroup_path"] == str(expected_cgroup)
    assert tool_end["resources"]["attribution_status"] == "partially_attributed"
    assert tool_end["resources"]["scope"] == "none"
    assert tool_end["resources"]["coverage_reason"] == ("shared_runtime_process" if tool_name in {"web_search", "web_fetch"} else "shared_sandbox_container")
    assert tool_end["resources"]["monitor_duration_ns"] is not None
    assert tool_end["resources"]["cgroup_cpu_time_s"] is None
    assert tool_end["resources"]["resource_observation"]["fallback_used"] is False
    assert (
        int(tool_end["monotonic_time_ns"]) - int(tool_start["monotonic_time_ns"])
        == int(tool_end["duration_ns"])
    )


def test_internal_tool_uses_docker_exec_inferred_scope_before_fallback(tmp_path: Path) -> None:
    fallback_cgroup = tmp_path / "fallback-cgroup"
    inferred_cgroup = tmp_path / "inferred-cgroup"
    _write_cgroup_fixture(fallback_cgroup, usage_usec=100_000)
    _write_cgroup_fixture(inferred_cgroup, usage_usec=500_000)
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            sandbox_cgroup_path=str(fallback_cgroup),
            sandbox_container_id="sandbox-1",
        )
    )
    state.docker_exec_observer = DockerExecObserver(
        enabled=True,
        container_id="sandbox-1",
        autostart=False,
    )
    client = TestClient(create_app(state))
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-docker-exec",
        "session_id": "session-docker-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read",
        "tool_name": "read",
        "tool_kind": "file",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 1,
            "has_command_like_field": False,
        },
        "raw_params": {"path": "README.md"},
        "resource_scope": None,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    state.docker_exec_observer.record_exec_start(
        exec_id="exec-read-1",
        container_id="sandbox-1",
        pid=os.getpid(),
        cgroup_path=str(inferred_cgroup),
        command="sh -c openclaw-sandbox-fs read README.md",
    )
    (inferred_cgroup / "cpu.stat").write_text("usage_usec 700000\n", encoding="utf-8")
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-end",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-docker-exec",
        "session_id": "session-docker-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "read",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 4,
        "raw_result": "data",
        "resource_scope": None,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    tool_end = [
        record
        for record in _read_trace_records(trace_dir)
        if record.get("record_type") == "span_end" and record.get("kind") == "tool"
    ][0]
    assert tool_end["execution"]["cgroup_path"] is None
    assert tool_end["execution"]["payload_pid"] == os.getpid()
    assert tool_end["execution"]["source"] == "docker-events"
    assert tool_end["resources"]["scope"] == "none"
    assert tool_end["resources"]["attribution_source"] == "docker-exec-pid"
    assert tool_end["resources"]["attribution_status"] == "unattributed"
    assert tool_end["resources"]["coverage_reason"] != "shared_sandbox_container"


def test_internal_tool_overrides_shared_runtime_scope_with_docker_exec(tmp_path: Path) -> None:
    runtime_cgroup = tmp_path / "runtime-cgroup"
    inferred_cgroup = tmp_path / "inferred-cgroup"
    _write_cgroup_fixture(runtime_cgroup, usage_usec=100_000)
    _write_cgroup_fixture(inferred_cgroup, usage_usec=500_000)
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            sandbox_cgroup_path=str(runtime_cgroup),
            sandbox_container_id="sandbox-1",
        )
    )
    state.docker_exec_observer = DockerExecObserver(
        enabled=True,
        container_id="sandbox-1",
        autostart=False,
    )
    client = TestClient(create_app(state))
    shared_runtime_scope = {
        "kind": "cgroup-v2",
        "execution_id": None,
        "pid": os.getpid(),
        "root_pid": os.getpid(),
        "process_start_time": None,
        "root_starttime_ticks": None,
        "cgroup_path": str(runtime_cgroup),
        "pid_namespace_inode": None,
        "container_id": None,
        "include_children": True,
        "source": "openclaw-runtime",
        "attribution_source": "shared-runtime-process",
    }
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-docker-exec",
        "session_id": "session-docker-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read",
        "tool_name": "read",
        "tool_kind": "file",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 1,
            "has_command_like_field": False,
        },
        "raw_params": {"path": "README.md"},
        "resource_scope": shared_runtime_scope,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    state.docker_exec_observer.record_exec_start(
        exec_id="exec-read-1",
        container_id="sandbox-1",
        pid=os.getpid(),
        cgroup_path=str(inferred_cgroup),
        command="sh -c openclaw-sandbox-fs read README.md",
    )
    (inferred_cgroup / "cpu.stat").write_text("usage_usec 700000\n", encoding="utf-8")
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-end",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-docker-exec",
        "session_id": "session-docker-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "read",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 4,
        "raw_result": "data",
        "resource_scope": shared_runtime_scope,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    tool_end = [
        record
        for record in _read_trace_records(trace_dir)
        if record.get("record_type") == "span_end" and record.get("kind") == "tool"
    ][0]
    assert tool_end["execution"]["cgroup_path"] is None
    assert tool_end["execution"]["payload_pid"] == os.getpid()
    assert tool_end["execution"]["source"] == "docker-events"
    assert tool_end["resources"]["scope"] == "none"
    assert tool_end["resources"]["attribution_source"] == "docker-exec-pid"
    assert tool_end["resources"]["coverage_reason"] != "shared_runtime_process"


def test_host_openclaw_scoped_read_gets_docker_exec_pid(tmp_path: Path) -> None:
    """host-openclaw-sandbox: read/edit run as docker execs with a per-tool PID.

    ``with_sandbox_fallback`` gives the before-request an openclaw-sandbox
    (shared-sandbox-container) scope, but the Docker observer must still
    register the tool and override that whole-container scope with the
    per-tool docker-exec PID captured from the sandbox's ``docker exec``.
    """
    sandbox_cgroup = tmp_path / "sandbox-cgroup"
    _write_cgroup_fixture(sandbox_cgroup, usage_usec=100_000)
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            sandbox_cgroup_path=str(sandbox_cgroup),
            sandbox_container_id="sandbox-1",
        )
    )
    state.docker_exec_observer = DockerExecObserver(
        enabled=True,
        container_id="sandbox-1",
        autostart=False,
    )
    client = TestClient(create_app(state))
    sandbox_scope: dict[str, object] = {
        "kind": "cgroup-v2",
        "execution_id": None,
        "pid": os.getpid(),
        "root_pid": os.getpid(),
        "process_start_time": None,
        "root_starttime_ticks": None,
        "cgroup_path": str(sandbox_cgroup),
        "pid_namespace_inode": None,
        "container_id": "sandbox-1",
        "include_children": True,
        "source": "openclaw-sandbox",
        "attribution_source": "shared-sandbox-container",
    }
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-sandbox-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-docker-exec",
        "session_id": "session-docker-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read-sandbox",
        "tool_name": "read",
        "tool_kind": "file",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 1,
            "has_command_like_field": False,
        },
        "raw_params": {"path": "README.md"},
        "resource_scope": sandbox_scope,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    state.docker_exec_observer.record_exec_start(
        exec_id="exec-read-sandbox-1",
        container_id="sandbox-1",
        pid=os.getpid(),
        command="openclaw-sandbox-fs read README.md",
    )
    completion: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-read-sandbox-end",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-docker-exec",
        "session_id": "session-docker-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-read-sandbox",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "read",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 4,
        "raw_result": "data",
        "resource_scope": sandbox_scope,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {
        "stored": True
    }

    tool_end = [
        record
        for record in _read_trace_records(trace_dir)
        if record.get("record_type") == "span_end" and record.get("kind") == "tool"
    ][0]
    assert tool_end["execution"]["source"] == "docker-events"
    assert tool_end["execution"]["payload_pid"] == os.getpid()
    assert tool_end["resources"]["scope"] == "none"
    assert tool_end["resources"]["attribution_source"] == "docker-exec-pid"
    assert tool_end["resources"]["attribution_status"] == "unattributed"
    assert tool_end["resources"]["coverage_reason"] != "shared_sandbox_container"


def test_docker_exec_event_uses_exec_id_attribute_not_container_id() -> None:
    observer = DockerExecObserver(
        enabled=True,
        container_id="sandbox-1",
        autostart=False,
    )
    inspected: list[str] = []

    def inspect_exec(exec_id: str) -> dict[str, object]:
        inspected.append(exec_id)
        return {
            "Pid": os.getpid(),
            "ContainerID": "sandbox-1",
            "ProcessConfig": {
                "entrypoint": "sh",
                "arguments": ["-c", "openclaw-sandbox-fs read README.md"],
            },
        }

    observer._inspect_exec = inspect_exec  # type: ignore[method-assign]
    observer._handle_event_line(
        json.dumps(
            {
                "id": "sandbox-1",
                "Actor": {
                    "ID": "sandbox-1",
                    "Attributes": {
                        "execID": "exec-real-id",
                        "container": "sandbox-1",
                        "name": "clawtune-srb-test-1",
                    },
                },
            }
        )
    )

    assert inspected == ["exec-real-id"]
    assert observer._records[0].exec_id == "exec-real-id"


def test_docker_exec_observer_binds_live_pid_before_completion() -> None:
    bound = []
    observer = DockerExecObserver(
        enabled=True,
        container_id="sandbox-1",
        autostart=False,
        on_scope=lambda tool_call_id, scope: (
            bound.append((tool_call_id, scope)) or True
        ),
    )
    observer.begin_tool(
        ToolBeforeRequest(
            schema_version="clawtune.v1",
            event_id="evt-read",
            occurred_at="2026-07-16T03:23:00Z",
            plugin_version="0.1.0",
            run_id="run-1",
            session_id="session-1",
            session_key=None,
            agent_id=None,
            tool_call_id="call-read",
            tool_name="read",
            tool_kind="file",
            tool_input_kind="json",
            derived_paths=[],
            params_digest="sha256:" + "a" * 64,
            param_features=ParamFeatures(
                serialized_size_bytes=1,
                string_length=1,
                list_item_count=0,
                path_count=1,
                has_command_like_field=False,
            ),
        )
    )

    observer.record_exec_start(
        exec_id="exec-read",
        container_id="sandbox-1",
        pid=os.getpid(),
        command="openclaw-sandbox-fs read README.md",
    )

    assert bound[0][0] == "call-read"
    assert bound[0][1].kind == "pid"
    assert bound[0][1].pid == os.getpid()
    assert bound[0][1].attribution_source == "docker-exec-pid"


def test_docker_exec_observer_subscribes_before_container_exec_start() -> None:
    command = _docker_events_command("docker")

    assert command == [
        "docker",
        "events",
        "--format",
        "{{json .}}",
        "--filter",
        "type=container",
        "--filter",
        "event=exec_create",
        "--filter",
        "event=exec_start",
    ]
    assert "type=exec" not in command


def test_exec_tool_can_use_shared_sandbox_cgroup_fallback(tmp_path: Path) -> None:
    cgroup = tmp_path / "cgroup"
    cgroup.mkdir()
    (cgroup / "cpu.stat").write_text("usage_usec 100000\n", encoding="utf-8")
    (cgroup / "memory.current").write_text("4096\n", encoding="utf-8")
    (cgroup / "io.stat").write_text("8:0 rbytes=10 wbytes=20\n", encoding="utf-8")
    (cgroup / "cgroup.procs").write_text("", encoding="utf-8")
    client, trace_dir = _trace_client_with_sandbox_cgroup(tmp_path, cgroup)
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-sandbox-exec",
        "session_id": "session-sandbox-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-exec",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": "ls",
        "derived_paths": [],
        "params_digest": "sha256:" + "b" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": {"command": "ls"},
        "resource_scope": None,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    (cgroup / "cpu.stat").write_text("usage_usec 200000\n", encoding="utf-8")
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-end",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-sandbox-exec",
        "session_id": "session-sandbox-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-exec",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": "call-exec",
        "tool_name": "exec",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": None,
        "raw_result": {"details": {"exitCode": 0}},
        "resource_scope": None,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    tool_end = next(
        r
        for r in _read_trace_records(trace_dir)
        if r.get("record_type") == "span_end" and r.get("kind") == "tool"
    )
    assert tool_end["execution"]["mode"] == "launcher"
    assert tool_end["resources"]["attribution_status"] == "partially_attributed"
    assert tool_end["resources"]["scope"] == "none"
    assert tool_end["resources"]["coverage_reason"] == "shared_sandbox_container"


@pytest.mark.parametrize("launcher_cgroup_path", ["/sys/fs/cgroup", None])
def test_exec_unusable_launcher_scope_falls_back_to_shared_sandbox(
    tmp_path: Path,
    launcher_cgroup_path: str | None,
) -> None:
    cgroup = tmp_path / "cgroup"
    cgroup.mkdir()
    (cgroup / "cpu.stat").write_text("usage_usec 100000\n", encoding="utf-8")
    (cgroup / "memory.current").write_text("4096\n", encoding="utf-8")
    (cgroup / "io.stat").write_text("8:0 rbytes=10 wbytes=20\n", encoding="utf-8")
    (cgroup / "cgroup.procs").write_text("", encoding="utf-8")
    client, trace_dir = _trace_client_with_sandbox_cgroup(tmp_path, cgroup)
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-sandbox-root-exec",
        "session_id": "session-sandbox-root-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-exec",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": "ls",
        "derived_paths": [],
        "params_digest": "sha256:" + "b" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": {"command": "ls"},
        "resource_scope": None,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-sandbox-root-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "ls",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    ).json()
    client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": os.getpid(),
            # A container PID can collide with a real host PID.  It must not
            # replace the host-side sandbox cgroup sampler merely because the
            # numeric PID happens to be readable on the sidecar host.
            "child_pid": os.getpid(),
            "process_starttime_ticks": 123,
            "cgroup_path": launcher_cgroup_path,
            "pid_namespace_inode": 456,
            "container_id": "sandbox-1",
        },
    )
    (cgroup / "cpu.stat").write_text("usage_usec 200000\n", encoding="utf-8")
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-end",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-sandbox-root-exec",
        "session_id": "session-sandbox-root-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-exec",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": "call-exec",
        "tool_name": "exec",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": None,
        "raw_result": {"details": {"exitCode": 0}},
        "resource_scope": None,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    tool_end = next(
        r
        for r in _read_trace_records(trace_dir)
        if r.get("record_type") == "span_end" and r.get("kind") == "tool"
    )
    assert tool_end["execution"]["cgroup_path"] == str(cgroup)
    assert tool_end["resources"]["attribution_source"] == "shared-sandbox-container"
    assert tool_end["resources"]["attribution_status"] == "partially_attributed"
    assert tool_end["resources"]["coverage_reason"] == "shared_sandbox_container"


def test_ebpf_execution_waits_for_sandbox_container_scope(tmp_path: Path) -> None:
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    begin_calls: list[dict[str, object]] = []
    started_execution_ids: set[str] = set()

    def begin_execution(**kwargs):
        if kwargs["execution_id"] in started_execution_ids:
            return False
        started_execution_ids.add(kwargs["execution_id"])
        begin_calls.append(kwargs)
        return True

    state.predictor.begin_execution = begin_execution  # type: ignore[method-assign]

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi && true",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    ).json()
    assert begin_calls == []

    client.post(
        "/v1/runtime/sandbox-scope",
        json={
            "kind": "cgroup-v2",
            "execution_id": None,
            "pid": os.getpid(),
            "root_pid": os.getpid(),
            "process_start_time": None,
            "root_starttime_ticks": None,
            "cgroup_path": str(tmp_path / "sandbox-cgroup"),
            "pid_namespace_inode": None,
            "container_id": "b" * 64,
            "include_children": True,
            "source": "openclaw-sandbox",
            "attribution_source": "shared-sandbox-container",
        },
    )
    client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": os.getpid(),
            "child_pid": os.getpid(),
            "process_starttime_ticks": 123,
            "cgroup_path": str(tmp_path / "call-cgroup"),
            "pid_namespace_inode": 456,
            "container_id": None,
        },
    )

    assert begin_calls == [
        {
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "command": "echo hi && true",
            "container_id": "b" * 64,
            "repo": "openclaw",
        }
    ]


def test_ebpf_execution_starts_on_claim_when_sandbox_scope_is_known(tmp_path: Path) -> None:
    sandbox_cgroup = tmp_path / "sandbox-cgroup"
    _write_cgroup_fixture(sandbox_cgroup)
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            sandbox_cgroup_path=str(sandbox_cgroup),
            sandbox_container_id="b" * 64,
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    begin_calls: list[dict[str, object]] = []

    def begin_execution(**kwargs):
        begin_calls.append(kwargs)
        return True

    state.predictor.begin_execution = begin_execution  # type: ignore[method-assign]

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi && true",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"enable_cgroup": True},
            "backend": "managed-wrapper",
        },
    ).json()
    client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    )

    assert begin_calls == [
        {
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "command": "echo hi && true",
            "container_id": "b" * 64,
            "repo": "openclaw",
        }
    ]


def test_execution_exit_waits_for_completion_result_before_ebpf_finish(
    tmp_path: Path,
) -> None:
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    finish_calls: list[dict[str, object]] = []

    def finish_execution(**kwargs):
        finish_calls.append(kwargs)
        return {
            "execution_id": kwargs["execution_id"],
            "tool_call_id": "call-result",
            "artifact_path": None,
            "started": True,
            "status": "ok",
            "unavailable_reason": None,
        }

    state.predictor.finish_execution = finish_execution  # type: ignore[method-assign]
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "exec-result",
            "tool_call_id": "call-result",
            "run_id": "run-result",
            "session_key_hash": None,
            "command_digest": "sha256:" + "d" * 64,
            "command": "pip install -e . 2>&1 | tail -10",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "exec-result",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    ).json()

    assert client.post(
        "/v2/executions/exec-result/exited",
        json={
            "update_token": claim["update_token"],
            "exit_code": 0,
            "signal": None,
        },
    ).json() == {"stored": True}
    assert finish_calls == []
    # Telemetry reads must never acquire/finalize the active eBPF run.
    client.get("/v2/executions/exec-result/telemetry")
    assert finish_calls == []

    original_scope = state.executions.scope

    def scope_after_ebpf_finish(execution_id: str):
        # Completion finalization must happen before the route's async scope
        # lookup, otherwise an 800 ms plugin timeout can race a raw-less GET.
        assert finish_calls
        return original_scope(execution_id)

    state.executions.scope = scope_after_ebpf_finish  # type: ignore[method-assign]

    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-result",
        "occurred_at": "2026-07-29T00:00:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-result",
        "session_id": "session-result",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-result",
        "decision_id": None,
        "lease_id": None,
        "execution_id": "exec-result",
        "tool_name": "exec",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": None,
        "raw_result": {
            "details": {
                "exitCode": 0,
                "aggregated": "/bin/sh: 1: pip: not found",
            }
        },
        "resource_scope": None,
    }
    assert client.post("/v1/events/tool-completed", json=completion).json() == {
        "stored": True
    }
    assert finish_calls == [
        {
            "execution_id": "exec-result",
            "exit_code": 0,
            "signal": None,
            "raw_result": completion["raw_result"],
            "succeeded": True,
        }
    ]


def test_running_exec_completion_waits_for_real_exit_fallback(
    tmp_path: Path,
    monkeypatch,
) -> None:
    sandbox_cgroup = tmp_path / "sandbox-cgroup"
    _write_cgroup_fixture(sandbox_cgroup)
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            sandbox_cgroup_path=str(sandbox_cgroup),
            sandbox_container_id="b" * 64,
            tool_resource_ebpf_required=False,
        )
    )
    monkeypatch.setattr(app_module, "_EBPF_COMPLETION_GRACE_SECONDS", 0.01)
    finish_calls: list[dict[str, object]] = []
    finalized = Event()

    def finish_execution(**kwargs):
        finish_calls.append(kwargs)
        finalized.set()
        return {
            "execution_id": kwargs["execution_id"],
            "tool_call_id": kwargs["execution_id"],
            "artifact_path": None,
            "started": True,
            "status": "ok",
            "unavailable_reason": None,
        }

    state.predictor.begin_execution = lambda **_kwargs: True  # type: ignore[method-assign]
    state.predictor.execution_active = lambda _execution_id: True  # type: ignore[method-assign]
    state.predictor.finish_execution = finish_execution  # type: ignore[method-assign]
    with TestClient(create_app(state)) as client:
        registration = client.post(
            "/v2/executions",
            json={
                "execution_id": "call-exec",
                "tool_call_id": "call-exec",
                "run_id": "run-launcher-exec",
                "session_key_hash": None,
                "command_digest": "sha256:" + "d" * 64,
                "command": "pip install flask falcon starlette | tail",
                "workdir": "/workspace",
                "host": "gateway",
                "placement": None,
                "profiling": {"mode": "off"},
                "backend": "managed-wrapper",
            },
        ).json()
        claim = client.post(
            "/v2/executions/claim",
            json={
                "execution_id": "call-exec",
                "token": registration["one_time_token"],
                "launcher_pid": 100,
            },
        ).json()
        completion = {
            "schema_version": "clawtune.v1",
            "event_id": "evt-exec-yielded",
            "occurred_at": "2026-07-16T03:23:01Z",
            "plugin_version": "0.1.0",
            "run_id": "run-launcher-exec",
            "session_id": "session-launcher-exec",
            "session_key": None,
            "agent_id": None,
            "tool_call_id": "call-exec",
            "decision_id": None,
            "lease_id": None,
            "execution_id": "call-exec",
            "tool_name": "exec",
            "duration_ms": 100,
            "succeeded": True,
            "error_type": None,
            "error_digest": None,
            "result_size_bytes": None,
            "raw_result": {"details": {"status": "running"}},
            "resource_scope": {
                "kind": "cgroup-v2",
                "execution_id": "call-exec",
                "cgroup_path": str(sandbox_cgroup),
            },
        }

        assert client.post("/v1/events/tool-completed", json=completion).json() == {
            "stored": True
        }
        assert finish_calls == []

        assert client.post(
            "/v2/executions/call-exec/exited",
            json={
                "update_token": claim["update_token"],
                "exit_code": 0,
                "signal": None,
            },
        ).json() == {"stored": True}
        assert finalized.wait(timeout=1.0)

    assert finish_calls == [
        {
            "execution_id": "call-exec",
            "exit_code": 0,
            "signal": None,
        }
    ]


@pytest.mark.parametrize(
    "authoritative_attribution",
    ["exclusive-execution-cgroup", "trusted-execution-root-pid"],
)
@pytest.mark.parametrize(
    ("shared_source", "shared_attribution"),
    [
        ("openclaw-sandbox", "shared-sandbox-container"),
        ("openclaw-runtime", "shared-runtime-process"),
        ("clawtune-launch", "clawtune-launch"),
    ],
)
def test_completion_prefers_authoritative_execution_scope_over_supplied_scope(
    tmp_path: Path,
    monkeypatch,
    authoritative_attribution: str,
    shared_source: str,
    shared_attribution: str,
) -> None:
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    claim = _register_claimed_execution(client)
    historical_cgroup = tmp_path / "removed-after-exit" / "call-exec"
    historical_cgroup.mkdir(parents=True)
    state.executions.update_scope(
        "call-exec",
        ResourceScope(
            kind="cgroup-v2",
            execution_id="call-exec",
            pid=4242,
            root_pid=4242,
            cgroup_path=str(historical_cgroup),
            include_children=True,
            source="clawtune-sidecar-host-cgroup",
            attribution_source=authoritative_attribution,
        ),
        owned_cgroup_path=str(historical_cgroup),
    )
    state.predictor.begin_execution = (  # type: ignore[method-assign]
        lambda **_kwargs: True
    )
    shared_cgroup = tmp_path / "sandbox-cgroup"
    sandbox_response = client.post(
        "/v1/gateways/gateway-1/runtimes/runtime-1/sandbox-scope",
        json={
            "kind": "cgroup-v2",
            "execution_id": None,
            "pid": 200,
            "root_pid": 200,
            "cgroup_path": str(shared_cgroup),
            "container_id": "b" * 64,
            "include_children": True,
            "source": "openclaw-sandbox",
            "attribution_source": "shared-sandbox-container",
        },
    )
    assert sandbox_response.status_code == 200
    monkeypatch.setattr(
        app_module,
        "_cleanup_owned_cgroup",
        lambda path: Path(path).rmdir() if path is not None else None,
    )
    exited = client.post(
        "/v2/executions/call-exec/exited",
        json={
            "update_token": claim["update_token"],
            "exit_code": 0,
            "signal": None,
        },
    )
    assert exited.status_code == 200
    assert historical_cgroup.exists()
    completed_scopes: list[ResourceScope | None] = []
    memory_windows: list[tuple[float, float] | None] = []
    monkeypatch.setattr(
        state.predictor,
        "execution_telemetry",
        lambda _execution_id: SimpleNamespace(call_telemetry={
            "telemetry_quality": "ok",
            "clauses": [{
                "t_exec_ns": 10_020_000_000,
                "t_end_ns": 10_080_000_000,
                "ts_start": 1_000.02,
                "ts_end": 1_000.08,
                "availability": {},
            }],
        }),
    )

    def capture_completion(event, *, environment_memory_window=None):
        completed_scopes.append(event.resource_scope)
        memory_windows.append(environment_memory_window)
        return None

    state.tool_monitor.complete = capture_completion  # type: ignore[method-assign]
    response = client.post(
        "/v1/events/tool-completed",
        json={
            "schema_version": "clawtune.v1",
            "event_id": "evt-exec-end",
            "occurred_at": "2026-07-16T03:23:01Z",
            "plugin_version": "0.1.0",
            "run_id": "run-exec",
            "session_id": "session-exec",
            "session_key": None,
            "agent_id": None,
            "tool_call_id": "call-exec",
            "decision_id": None,
            "lease_id": None,
            "execution_id": "call-exec",
            "tool_name": "exec",
            "duration_ms": 100,
            "action_start_monotonic_ns": "10000000000",
            "action_end_monotonic_ns": "10100000000",
            "monotonic_clock_domain": "linux_monotonic",
            "succeeded": True,
            "error_type": None,
            "error_digest": None,
            "result_size_bytes": None,
            "raw_result": {"details": {"exitCode": 0}},
            "runtime_id": "runtime-1",
            "gateway_id": "gateway-1",
            "resource_scope": {
                "kind": "cgroup-v2",
                "execution_id": None,
                "pid": 200,
                "root_pid": 200,
                "cgroup_path": str(shared_cgroup),
                "container_id": "b" * 64,
                "include_children": True,
                "source": shared_source,
                "attribution_source": shared_attribution,
            },
        },
    )

    assert response.status_code == 200
    assert len(completed_scopes) == 1
    completed_scope = completed_scopes[0]
    assert completed_scope is not None
    assert completed_scope.cgroup_path == str(historical_cgroup)
    assert completed_scope.attribution_source == authoritative_attribution
    assert memory_windows[0] is not None
    assert memory_windows[0][1] - memory_windows[0][0] == pytest.approx(.06)
    assert not historical_cgroup.exists()


@pytest.mark.parametrize(
    ("record_attribution", "expected_rebinds"),
    [
        ("exclusive-execution-cgroup", 0),
        ("trusted-execution-root-pid", 0),
        ("clawtune-launch", 1),
    ],
)
def test_late_sandbox_scope_does_not_downgrade_authoritative_monitor_scope(
    tmp_path: Path,
    record_attribution: str,
    expected_rebinds: int,
) -> None:
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    _register_claimed_execution(client)
    execution_cgroup = tmp_path / "execution-cgroup"
    state.executions.update_scope(
        "call-exec",
        ResourceScope(
            kind="cgroup-v2",
            execution_id="call-exec",
            pid=4242,
            root_pid=4242,
            cgroup_path=str(execution_cgroup),
            include_children=True,
            source="clawtune-sidecar-host-cgroup",
            attribution_source=record_attribution,
        ),
    )
    state.predictor.begin_execution = (  # type: ignore[method-assign]
        lambda **_kwargs: True
    )
    rebound_scopes: list[ResourceScope] = []

    def capture_rebind(_tool_call_id, scope, **_kwargs):
        rebound_scopes.append(scope)
        return True

    state.tool_monitor.bind_scope = capture_rebind  # type: ignore[method-assign]
    sandbox_cgroup = tmp_path / "sandbox-cgroup"
    response = client.post(
        "/v1/gateways/gateway-1/runtimes/runtime-1/sandbox-scope",
        json={
            "kind": "cgroup-v2",
            "execution_id": None,
            "pid": 200,
            "root_pid": 200,
            "cgroup_path": str(sandbox_cgroup),
            "container_id": "b" * 64,
            "include_children": True,
            "source": "openclaw-sandbox",
            "attribution_source": "shared-sandbox-container",
        },
    )

    assert response.status_code == 200
    assert len(rebound_scopes) == expected_rebinds
    if rebound_scopes:
        assert rebound_scopes[0].attribution_source == "shared-sandbox-container"


def test_owned_cgroup_survives_exited_until_completion_final_snapshot(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(app_module, "_OWNED_CGROUP_CLEANUP_GRACE_SECONDS", 0.01)
    monkeypatch.setattr(app_module, "_OWNED_CGROUP_CLEANUP_RETRY_SECONDS", 1.0)
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            tool_resource_ebpf_required=False,
        )
    )
    cleanup_observations: list[tuple[int, bool]] = []
    cleanup_started = Event()

    def remove_fixture(path: str | None) -> bool:
        assert path is not None
        target = Path(path)
        usage = int(
            (target / "cpu.stat").read_text(encoding="utf-8").split()[1]
        )
        trace_flushed = any(
            record.get("record_type") == "span_end"
            for record in _read_trace_records(trace_dir)
        )
        cleanup_observations.append((usage, trace_flushed))
        if not trace_flushed:
            cleanup_started.set()
            return False
        for child in target.iterdir():
            child.unlink()
        target.rmdir()
        return True

    monkeypatch.setattr(app_module, "_cleanup_owned_cgroup", remove_fixture)
    with TestClient(create_app(state)) as client:
        before = {
            "schema_version": "clawtune.v1",
            "event_id": "evt-owned-start",
            "occurred_at": "2026-07-16T03:23:00Z",
            "plugin_version": "0.1.0",
            "run_id": "run-exec",
            "session_id": "session-exec",
            "session_key": None,
            "agent_id": None,
            "tool_call_id": "call-exec",
            "tool_name": "exec",
            "tool_kind": "shell",
            "tool_input_kind": "json",
            "operation_hint": "echo",
            "derived_paths": [],
            "params_digest": "sha256:" + "b" * 64,
            "param_features": {
                "serialized_size_bytes": 10,
                "string_length": 7,
                "list_item_count": 0,
                "path_count": 0,
                "has_command_like_field": True,
            },
            "raw_params": {"command": "echo hi"},
            "runtime_id": "runtime-1",
            "gateway_id": "gateway-1",
            "resource_scope": None,
        }
        decision = client.post("/v1/decisions/tool", json=before).json()
        claim = _register_claimed_execution(client)
        exact = tmp_path / "exact-execution-cgroup"
        _write_cgroup_fixture(exact, usage_usec=100_000)
        scope = ResourceScope(
            kind="cgroup-v2",
            execution_id="call-exec",
            pid=4242,
            root_pid=4242,
            cgroup_path=str(exact),
            include_children=True,
            source="clawtune-sidecar-host-cgroup",
            attribution_source="exclusive-execution-cgroup",
        )
        state.executions.update_scope(
            "call-exec",
            scope,
            owned_cgroup_path=str(exact),
        )
        record = state.executions.get("call-exec")
        assert record is not None
        assert state.tool_monitor.bind_scope(
            "call-exec",
            scope,
            runtime_id="runtime-1",
            owner=record.request,
        )
        exited = client.post(
            "/v2/executions/call-exec/exited",
            json={
                "update_token": claim["update_token"],
                "exit_code": 0,
                "signal": None,
            },
        )
        assert exited.status_code == 200
        assert exact.is_dir()
        assert cleanup_started.wait(timeout=2.0)
        assert cleanup_observations == [(100_000, False)]
        # Simulate counters advancing after delayed GC has started but while
        # its cooperative retry is cancellable by the completion hook.
        (exact / "cpu.stat").write_text(
            "usage_usec 300000\n",
            encoding="utf-8",
        )

        completed = client.post(
            "/v1/events/tool-completed",
            json={
                "schema_version": "clawtune.v1",
                "event_id": "evt-owned-end",
                "occurred_at": datetime.now(timezone.utc).isoformat(),
                "plugin_version": "0.1.0",
                "run_id": "run-exec",
                "session_id": "session-exec",
                "session_key": None,
                "agent_id": None,
                "tool_call_id": "call-exec",
                "decision_id": decision["decision_id"],
                "lease_id": decision["lease_id"],
                "execution_id": "call-exec",
                "tool_name": "exec",
                "duration_ms": 100,
                "succeeded": True,
                "error_type": None,
                "error_digest": None,
                "result_size_bytes": None,
                "raw_result": {"details": {"exitCode": 0}},
                "runtime_id": "runtime-1",
                "gateway_id": "gateway-1",
                "resource_scope": None,
            },
        )
        assert completed.status_code == 200
        assert completed.json() == {"stored": True}
        assert cleanup_observations == [(100_000, False), (300_000, True)]
        assert not exact.exists()

    tool_end = next(
        record
        for record in _read_trace_records(trace_dir)
        if record.get("record_type") == "span_end"
        and record.get("kind") == "tool"
    )
    assert tool_end["execution"]["cgroup_path"] == str(exact)
    assert tool_end["resources"]["attribution_source"] == (
        "exclusive-execution-cgroup"
    )
    assert tool_end["resources"]["cpu_time_s"] == pytest.approx(0.2)
    assert tool_end["resources"]["resource_observation"]["fallback_used"] is True


def test_owned_cgroup_delayed_gc_when_completion_is_lost(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(app_module, "_OWNED_CGROUP_CLEANUP_GRACE_SECONDS", 0.02)
    cleaned = Event()

    def remove_fixture(path: str | None) -> bool:
        assert path is not None
        target = Path(path)
        for child in target.iterdir():
            child.unlink()
        target.rmdir()
        cleaned.set()
        return True

    monkeypatch.setattr(app_module, "_cleanup_owned_cgroup", remove_fixture)
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            tool_resource_ebpf_required=False,
        )
    )
    with TestClient(create_app(state)) as client:
        claim = _register_claimed_execution(client)
        exact = tmp_path / "lost-completion-cgroup"
        _write_cgroup_fixture(exact)
        state.executions.update_scope(
            "call-exec",
            ResourceScope(
                kind="cgroup-v2",
                execution_id="call-exec",
                cgroup_path=str(exact),
                source="clawtune-sidecar-host-cgroup",
                attribution_source="exclusive-execution-cgroup",
            ),
            owned_cgroup_path=str(exact),
        )

        exited = client.post(
            "/v2/executions/call-exec/exited",
            json={
                "update_token": claim["update_token"],
                "exit_code": 0,
                "signal": None,
            },
        )
        assert exited.status_code == 200
        assert cleaned.wait(timeout=2.0)
        assert not exact.exists()
        deadline = time.monotonic() + 2.0
        while (
            "call-exec" in state._owned_cgroup_paths
            and time.monotonic() < deadline
        ):
            time.sleep(0.01)
        assert "call-exec" not in state._owned_cgroup_paths


def test_execution_started_host_cgroup_gate_creates_exact_scope(
    tmp_path: Path,
    monkeypatch,
) -> None:
    sandbox_cgroup = tmp_path / "sandbox-cgroup"
    _write_cgroup_fixture(sandbox_cgroup)
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            sandbox_cgroup_path=str(sandbox_cgroup),
            sandbox_container_id="b" * 64,
            execution_cgroup_root=str(tmp_path / "exact-root"),
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    begin_calls: list[dict[str, object]] = []

    def begin_execution(**kwargs):
        begin_calls.append(kwargs)
        return True

    state.predictor.begin_execution = begin_execution  # type: ignore[method-assign]
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(app_module, "_pid_starttime_ticks", lambda _pid: 99)
    monkeypatch.setattr(app_module, "_pid_namespace_inode", lambda _pid: 123)
    monkeypatch.setattr(app_module, "_cgroup_accounting_usable", lambda _path: True)
    monkeypatch.setattr(
        app_module,
        "_execution_cgroup_accounting_usable",
        lambda _path: True,
    )

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-host-gate",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"enable_cgroup": True},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    ).json()
    assert begin_calls == []
    started = client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": 100,
            "child_pid": 7,
            "process_starttime_ticks": 99,
            "cgroup_path": None,
            "pid_namespace_inode": 123,
            "container_id": None,
            "host_cgroup_gate": True,
        },
    )

    assert started.status_code == 200
    exact = Path(started.json()["cgroup_path"])
    assert exact.name == "call-exec"
    assert exact.parent.name.startswith("env-")
    assert exact.parent.parent == tmp_path / "exact-root"
    assert started.json() == {"stored": True, "cgroup_path": str(exact)}
    assert (exact / "cgroup.procs").read_text(encoding="utf-8").strip() == "4242"
    scope = client.get("/v2/executions/call-exec/scope").json()["execution_scope"]
    assert scope["cgroup_path"] == str(exact)
    assert scope["pid"] == 4242
    assert scope["attribution_source"] == "exclusive-execution-cgroup"
    assert begin_calls[-1]["cgroup_path"] == str(exact)


def test_execution_started_required_host_gate_fails_without_exclusive_cgroup(
    tmp_path: Path,
    monkeypatch,
) -> None:
    available_only_root = tmp_path / "available-only-root"
    available_only_root.mkdir()
    (available_only_root / "cgroup.controllers").write_text(
        "cpu memory io\n",
        encoding="utf-8",
    )
    (available_only_root / "cgroup.subtree_control").write_text(
        "",
        encoding="utf-8",
    )
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            sandbox_container_id="b" * 64,
            execution_cgroup_root=str(available_only_root),
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    monkeypatch.setattr(
        app_module,
        "_resolve_host_pid",
        lambda *_args, **_kwargs: 4242,
    )
    # Model a populated/non-delegated parent: controllers are advertised as
    # available, but the kernel refuses to enable them for children.
    monkeypatch.setattr(
        app_module,
        "_enable_cgroup_controllers",
        lambda _root: frozenset(),
    )

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-required-host-gate",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"enable_cgroup": True},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    ).json()

    started = client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": 100,
            "child_pid": 7,
            "process_starttime_ticks": 99,
            "cgroup_path": None,
            "pid_namespace_inode": 123,
            "container_id": None,
            "host_cgroup_gate": True,
            "cgroup_required": True,
        },
    )

    assert started.status_code == 503
    assert started.json() == {
        "detail": "exclusive_execution_cgroup_unavailable"
    }
    assert state.executions.get("call-exec").scope is None


def test_execution_started_derives_host_cgroup_when_launcher_gate_off(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """host_cgroup_gate=False (the launcher created its own cgroup in the
    container) must still derive the launcher's ACTUAL host cgroup from
    /proc/<host_pid>/cgroup instead of jumping straight to per-PID psutil.
    The launcher-supplied container-namespace path is not host-valid and must
    not block the host derivation."""
    host_cgroup = tmp_path / "host-cgroup"
    _write_cgroup_fixture(host_cgroup)
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            sandbox_cgroup_path=str(host_cgroup),
            sandbox_container_id="b" * 64,
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(
        app_module,
        "_host_cgroup_path_for_pid",
        lambda _pid: str(host_cgroup.resolve()),
    )
    monkeypatch.setattr(app_module, "_pid_starttime_ticks", lambda _pid: 99)
    monkeypatch.setattr(app_module, "_pid_namespace_inode", lambda _pid: 123)

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-host-cgroup-derive",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"enable_cgroup": True},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    ).json()
    started = client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": 100,
            "child_pid": 7,
            "process_starttime_ticks": 99,
            "cgroup_path": "/clawtune-executions/call-exec",
            "pid_namespace_inode": 123,
            "container_id": "b" * 64,
            "host_cgroup_gate": False,
        },
    )

    assert started.status_code == 200
    scope = client.get("/v2/executions/call-exec/scope").json()["execution_scope"]
    assert scope["kind"] == "cgroup-v2"
    assert scope["cgroup_path"] == str(host_cgroup.resolve())
    assert scope["attribution_source"] == "trusted-execution-root-pid"
    assert scope["root_pid"] == 4242


def test_execution_started_falls_back_to_per_pid_when_host_cgroup_unresolvable(
    tmp_path: Path,
    monkeypatch,
) -> None:
    """When /proc cannot yield a host cgroup for the launcher pid, the scope
    degrades to per-PID process-tree attribution (still attributed, not lost)."""
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            sandbox_container_id="b" * 64,
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    monkeypatch.setattr(app_module, "_host_cgroup_path_for_pid", lambda _pid: None)
    monkeypatch.setattr(app_module, "_pid_starttime_ticks", lambda _pid: 99)
    monkeypatch.setattr(app_module, "_pid_namespace_inode", lambda _pid: 123)

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-host-cgroup-fallback",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"enable_cgroup": True},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    ).json()
    started = client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": 100,
            "child_pid": 7,
            "process_starttime_ticks": 99,
            "cgroup_path": "/clawtune-executions/call-exec",
            "pid_namespace_inode": 123,
            "container_id": "b" * 64,
            "host_cgroup_gate": False,
        },
    )

    assert started.status_code == 200
    scope = client.get("/v2/executions/call-exec/scope").json()["execution_scope"]
    assert scope["kind"] == "pid"
    assert scope["cgroup_path"] is None
    assert scope["attribution_source"] == "trusted-execution-root-pid"
    assert scope["root_pid"] == 4242


def test_ebpf_execution_starts_when_sandbox_scope_arrives_after_started(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr(app_module, "_resolve_host_pid", lambda *_args, **_kwargs: 4242)
    call_cgroup = tmp_path / "call-cgroup"
    call_cgroup.mkdir()
    monkeypatch.setattr(
        app_module,
        "_host_cgroup_path_for_pid",
        lambda _pid: str(call_cgroup.resolve()),
    )
    monkeypatch.setattr(
        app_module,
        "_canonical_cgroup_path",
        lambda path, **_kwargs: Path(path).resolve(),
    )
    state = build_state(
        SidecarConfig(
            trace_dir=tmp_path / "traces",
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    begin_calls: list[dict[str, object]] = []

    def begin_execution(**kwargs):
        begin_calls.append(kwargs)
        return True

    state.predictor.begin_execution = begin_execution  # type: ignore[method-assign]

    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi && true",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    ).json()
    client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": os.getpid(),
            "child_pid": os.getpid(),
            "process_starttime_ticks": 123,
            "cgroup_path": str(call_cgroup),
            "pid_namespace_inode": 456,
            "container_id": None,
        },
    )
    assert begin_calls == [
        {
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "command": "echo hi && true",
            "container_id": None,
            "repo": "openclaw",
            "cgroup_path": str(call_cgroup),
            "trusted_root_pid": 4242,
        }
    ]
    begin_calls.clear()

    client.post(
        "/v1/runtime/sandbox-scope",
        json={
            "kind": "cgroup-v2",
            "execution_id": None,
            "pid": os.getpid(),
            "root_pid": os.getpid(),
            "process_start_time": None,
            "root_starttime_ticks": None,
            "cgroup_path": str(tmp_path / "sandbox-cgroup"),
            "pid_namespace_inode": None,
            "container_id": "b" * 64,
            "include_children": True,
            "source": "openclaw-sandbox",
            "attribution_source": "shared-sandbox-container",
        },
    )

    assert begin_calls == [
        {
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "command": "echo hi && true",
            "container_id": "b" * 64,
            "repo": "openclaw",
            "trusted_root_pid": 4242,
        }
    ]


def test_required_ebpf_defers_claim_without_container_id(tmp_path: Path) -> None:
    state = build_state(SidecarConfig(tool_resource_ebpf_required=True, trace_dir=tmp_path / "traces"))
    client = TestClient(create_app(state))
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi && true",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()

    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    )

    assert claim.status_code == 200


def test_required_ebpf_rejects_unavailable_collector_during_started(
    tmp_path: Path,
    monkeypatch,
) -> None:
    monkeypatch.setattr("clawtune_sidecar.api.app._resolve_host_pid", lambda *a, **kw: os.getpid())
    state = build_state(SidecarConfig(tool_resource_ebpf_required=True, trace_dir=tmp_path / "traces"))
    client = TestClient(create_app(state))
    state.predictor.begin_execution = lambda **kwargs: False  # type: ignore[method-assign]
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    ).json()

    started = client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": os.getpid(),
            "child_pid": os.getpid(),
            "process_starttime_ticks": 123,
            "cgroup_path": str(tmp_path / "call-cgroup"),
            "pid_namespace_inode": 456,
            "container_id": "b" * 64,
        },
    )

    assert started.status_code == 503
    detail = started.json()["detail"]
    assert detail["code"] == "tool_resource_ebpf_start_failed"
    assert detail["reason"]


def test_required_ebpf_starts_during_claim_with_sandbox_container_id(tmp_path: Path) -> None:
    state = build_state(
        SidecarConfig(tool_resource_ebpf_required=True,
            trace_dir=tmp_path / "traces",
            sandbox_container_id="b" * 64,
        )
    )
    client = TestClient(create_app(state))
    begin_calls: list[dict[str, object]] = []

    def begin_execution(**kwargs):
        begin_calls.append(kwargs)
        return True

    state.predictor.begin_execution = begin_execution  # type: ignore[method-assign]
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "echo hi && true",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()

    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    )

    assert claim.status_code == 200
    assert begin_calls == [
        {
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "command": "echo hi && true",
            "container_id": "b" * 64,
            "repo": "openclaw",
        }
    ]


def test_exec_completion_uses_registered_launcher_scope(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.setattr("clawtune_sidecar.api.app._resolve_host_pid", lambda *a, **kw: os.getpid())
    cgroup = tmp_path / "launcher-cgroup"
    cgroup.mkdir()
    (cgroup / "cpu.stat").write_text("usage_usec 100000\n", encoding="utf-8")
    (cgroup / "memory.current").write_text("4096\n", encoding="utf-8")
    (cgroup / "io.stat").write_text("8:0 rbytes=10 wbytes=20\n", encoding="utf-8")
    (cgroup / "cgroup.procs").write_text("", encoding="utf-8")
    trace_dir = tmp_path / "traces"
    state = build_state(
        SidecarConfig(
            trace_dir=trace_dir,
            tool_resource_ebpf_required=False,
        )
    )
    client = TestClient(create_app(state))
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-start",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-launcher-exec",
        "session_id": "session-launcher-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-exec",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": "ls",
        "derived_paths": [],
        "params_digest": "sha256:" + "b" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": {"command": "ls"},
        "resource_scope": None,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    registration = client.post(
        "/v2/executions",
        json={
            "execution_id": "call-exec",
            "tool_call_id": "call-exec",
            "run_id": "run-launcher-exec",
            "session_key_hash": None,
            "command_digest": "sha256:" + "c" * 64,
            "command": "ls",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": None,
            "profiling": {"mode": "off"},
            "backend": "managed-wrapper",
        },
    ).json()
    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "call-exec",
            "token": registration["one_time_token"],
            "launcher_pid": os.getpid(),
        },
    ).json()
    client.post(
        "/v2/executions/call-exec/started",
        json={
            "update_token": claim["update_token"],
            "launcher_pid": os.getpid(),
            "child_pid": os.getpid(),
            "process_starttime_ticks": 123,
            "cgroup_path": str(cgroup),
            "pid_namespace_inode": 456,
            "container_id": "sandbox-1",
        },
    )
    (cgroup / "cpu.stat").write_text("usage_usec 200000\n", encoding="utf-8")
    assert client.post(
        "/v2/executions/call-exec/exited",
        json={
            "update_token": claim["update_token"],
            "exit_code": 0,
            "signal": None,
        },
    ).json() == {"stored": True}
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-end",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-launcher-exec",
        "session_id": "session-launcher-exec",
        "session_key": None,
        "agent_id": None,
        "tool_call_id": "call-exec",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": "call-exec",
        "tool_name": "exec",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": None,
        "raw_result": {"details": {"exitCode": 0}},
        "resource_scope": None,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    tool_end = next(
        r
        for r in _read_trace_records(trace_dir)
        if r.get("record_type") == "span_end" and r.get("kind") == "tool"
    )
    assert tool_end["execution"]["source"] == "clawtune-launch"
    assert tool_end["execution"]["cgroup_path"] == str(cgroup)
    assert tool_end["resources"]["attribution_source"] == "clawtune-launch"
    assert tool_end["resources"]["attribution_status"] == "unattributed"
    assert tool_end["resources"]["scope"] == "none"
    assert tool_end["execution"]["tool_resource"]["execution_id"] == "call-exec"
    assert tool_end["execution"]["tool_resource"]["status"] in {
        "ok",
        "invalid",
        "unavailable",
        "collected_not_eligible",
    }


def test_resource_timeline_uses_interval_rates() -> None:
    timeline = _relative_timeline(
        [
            {
                "ts": 10.0,
                "cpu_time_s": 1.0,
                "rss_bytes": 100,
                "read_bytes": 0,
                "write_bytes": 0,
                "net_rx_bytes": 1_000_000,
                "net_tx_bytes": 2_000_000,
                "ctx_switches": 5,
                "process_count": 1,
                "available": True,
                "source": "psutil-process-tree",
            },
            {
                "ts": 10.5,
                "cpu_time_s": 1.2,
                "rss_bytes": 200,
                "read_bytes": 128,
                "write_bytes": 512,
                "net_rx_bytes": 1_001_000,
                "net_tx_bytes": 2_002_000,
                "ctx_switches": 8,
                "process_count": 1,
                "available": True,
                "source": "psutil-process-tree",
            },
        ]
    )

    assert timeline[0]["net_rx_bytes_delta"] == 0
    assert timeline[0]["net_rx_bytes_per_s"] is None
    assert timeline[1]["elapsed_ms"] == 500
    assert abs(timeline[1]["cpu_time_delta_s"] - 0.2) < 0.001
    assert timeline[1]["net_rx_bytes_delta"] == 1_000
    assert timeline[1]["net_tx_bytes_delta"] == 2_000
    assert timeline[1]["net_rx_bytes_per_s"] == 2_000
    assert timeline[1]["net_tx_bytes_per_s"] == 4_000


def test_agent_test_bench_trace_jsonl_records_tool_and_model_events(tmp_path: Path) -> None:
    client, trace_dir = _trace_client(tmp_path)
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-trace-before",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-trace",
        "session_id": "session-trace",
        "session_key": None,
        "agent_id": "agent-trace",
        "tool_call_id": "call-trace",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": "pytest",
        "derived_paths": [],
        "params_digest": "sha256:" + "c" * 64,
        "param_features": {
            "serialized_size_bytes": 24,
            "string_length": 20,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": {"command": "pytest tests/test_trace.py"},
        "raw_event": {"params": {"command": "pytest tests/test_trace.py"}},
        # Provide the current process PID so the resource sampler can capture
        # real cpu_time / rss data (needed by assertions below).  Without a
        # PID the sampler returns an empty snapshot and cpu_time_s stays None.
        "resource_scope": {"pid": os.getpid()},
    }
    decision = client.post("/v1/decisions/tool", json=request).json()

    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-trace-after",
        "occurred_at": datetime.now(timezone.utc).isoformat(),
        "plugin_version": "0.1.0",
        "run_id": "run-trace",
        "session_id": "session-trace",
        "session_key": None,
        "agent_id": "agent-trace",
        "tool_call_id": "call-trace",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "exec",
        "duration_ms": 2000,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 128,
        "raw_result": "2 passed",
        "raw_event": {"result": "2 passed"},
    }
    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    model_started = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-model-start",
        "occurred_at": "2026-07-16T03:23:03Z",
        "plugin_version": "0.1.0",
        "run_id": "run-trace",
        "session_id": "session-trace",
        "session_key": None,
        "agent_id": "agent-trace",
        "event_type": "model_call_started",
        "call_id": "llm-trace",
        "provider": "test-provider",
        "model": "test-model",
        "duration_ms": None,
        "outcome": None,
        "context_token_budget": 8192,
        "raw_input": [{"role": "user", "content": "run tests"}],
        "raw_output": None,
        "raw_event": {"messages": [{"role": "user", "content": "run tests"}]},
    }
    model_ended = model_started | {
        "event_id": "evt-model-end",
        "occurred_at": "2026-07-16T03:23:05Z",
        "event_type": "model_call_ended",
        "duration_ms": 2000,
        "outcome": "success",
        "raw_input": None,
        "raw_output": "done",
        "raw_event": {"content": "done"},
    }
    assert client.post("/v1/events/model", json=model_started).json() == {"stored": True}
    assert client.post("/v1/events/model", json=model_ended).json() == {"stored": True}

    # Find the per-run trace file
    records = _read_trace_records(trace_dir)
    assert len(records) >= 1
    assert records[0]["record_type"] == "trace_metadata"
    assert records[0]["schema_version"] == 6

    tool_starts = [r for r in records if r.get("record_type") == "span_start" and r.get("kind") == "tool"]
    assert len(tool_starts) == 1
    tool_start = tool_starts[0]
    assert tool_start["trace_id"] == "run-trace"
    assert tool_start["agent_id"] == "agent-trace"
    assert tool_start["name"] == "exec"
    assert tool_start["input"]["requested_args"] == {"command": "pytest tests/test_trace.py"}

    tool_ends = [r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "tool"]
    assert len(tool_ends) == 1
    tool_end = tool_ends[0]
    assert tool_end["status"]["code"] == "ok"
    assert tool_end["output"]["result"] == "2 passed"
    assert tool_end["output"]["exit_code"] == 0
    assert tool_end["resources"]["cpu_time_s"] is None
    assert tool_end["resources"]["rss_peak_bytes"] is None
    assert tool_end["resources"]["resource_observation"]["fallback_used"] is False
    assert "sampling_interval_ms" in tool_end["resources"]
    assert tool_end["resources"]["sampling_point_count"] is None
    assert isinstance(tool_end["resources"]["resource_timeline"], list)
    assert tool_end["resources"]["resource_timeline_truncated"] is False

    model_starts = [r for r in records if r.get("record_type") == "span_start" and r.get("kind") == "llm"]
    assert len(model_starts) == 1
    assert model_starts[0]["name"] == "test-model"
    assert model_starts[0]["input"]["messages"] == [{"role": "user", "content": "run tests"}]

    model_ends = [r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "llm"]
    assert len(model_ends) == 1
    assert model_ends[0]["output"]["content"] == "done"
    # LLM spans must satisfy the same monotonic invariant as tool spans
    # (mono_end - mono_start == duration_ns). Regression for the collapsed
    # monotonic-stamp bug in _record_model_v6.
    assert model_ends[0]["duration_ns"] == str(2000 * 1_000_000)
    assert (
        int(model_ends[0]["monotonic_time_ns"]) - int(model_starts[0]["monotonic_time_ns"])
        == int(model_ends[0]["duration_ns"])
    )


def test_llm_span_monotonic_invariant_holds_when_duration_absent(tmp_path: Path) -> None:
    client, trace_dir = _trace_client(tmp_path)
    started = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-model-zero-start",
        "occurred_at": "2026-07-16T03:23:03Z",
        "plugin_version": "0.1.0",
        "run_id": "run-zero",
        "session_id": "session-zero",
        "session_key": None,
        "agent_id": "agent-zero",
        "event_type": "model_call_started",
        "call_id": "llm-zero",
        "provider": "test-provider",
        "model": "test-model",
        "duration_ms": None,
        "outcome": None,
        "context_token_budget": 8192,
        "raw_input": [{"role": "user", "content": "hi"}],
        "raw_output": None,
        "raw_event": {"messages": [{"role": "user", "content": "hi"}]},
    }
    ended = started | {
        "event_id": "evt-model-zero-end",
        "occurred_at": "2026-07-16T03:23:04Z",
        "event_type": "model_call_ended",
        "duration_ms": None,  # no reported duration
        "outcome": "success",
        "raw_input": None,
        "raw_output": "ok",
        "raw_event": {"content": "ok"},
    }
    assert client.post("/v1/events/model", json=started).json() == {"stored": True}
    assert client.post("/v1/events/model", json=ended).json() == {"stored": True}

    records = _read_trace_records(trace_dir)
    llm_starts = [r for r in records if r.get("record_type") == "span_start" and r.get("kind") == "llm"]
    llm_ends = [r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "llm"]
    assert len(llm_starts) == 1
    assert len(llm_ends) == 1
    # No reported duration -> duration_ns is 0 and the monotonic span is
    # zero-width; the invariant mono_end - mono_start == duration_ns holds.
    assert llm_ends[0]["duration_ns"] == "0"
    assert (
        int(llm_ends[0]["monotonic_time_ns"]) - int(llm_starts[0]["monotonic_time_ns"])
        == int(llm_ends[0]["duration_ns"])
    )
    assert llm_ends[0]["resources"]["action_duration_ns"] == "0"


def test_trace_marks_raw_exec_exit_code_failure(tmp_path: Path) -> None:
    client, trace_dir = _trace_client(tmp_path)
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-before",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-exec-fail",
        "session_id": "session-exec-fail",
        "session_key": None,
        "agent_id": "agent-exec-fail",
        "tool_call_id": "call-exec-fail",
        "tool_name": "exec",
        "tool_kind": "shell",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "a" * 64,
        "param_features": {
            "serialized_size_bytes": 10,
            "string_length": 5,
            "list_item_count": 0,
            "path_count": 0,
            "has_command_like_field": True,
        },
        "raw_params": {"command": "ls"},
        "raw_event": None,
        "resource_scope": None,
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-exec-after",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-exec-fail",
        "session_id": "session-exec-fail",
        "session_key": None,
        "agent_id": "agent-exec-fail",
        "tool_call_id": "call-exec-fail",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": "call-exec-fail",
        "tool_name": "exec",
        "duration_ms": 100,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 10,
        "raw_result": {
            "details": {
                "status": "completed",
                "exitCode": 125,
                "aggregated": "Command could not be started by the execution environment.",
            }
        },
        "resource_scope": None,
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    records = _read_trace_records(trace_dir)
    tool_end = next(r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "tool")
    assert tool_end["status"]["code"] == "error"
    assert tool_end["status"]["message"] == "exit_code_125"
    assert tool_end["output"]["exit_code"] == 125


def test_trace_marks_shared_runtime_process_scope(tmp_path: Path) -> None:
    client, trace_dir = _trace_client(tmp_path)
    request: dict[str, object] = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-runtime-before",
        "occurred_at": "2026-07-16T03:23:00Z",
        "plugin_version": "0.1.0",
        "run_id": "run-runtime",
        "session_id": "session-runtime",
        "session_key": None,
        "agent_id": "agent-runtime",
        "tool_call_id": "call-runtime",
        "tool_name": "write",
        "tool_kind": "internal",
        "tool_input_kind": "json",
        "operation_hint": None,
        "derived_paths": [],
        "params_digest": "sha256:" + "d" * 64,
        "param_features": {
            "serialized_size_bytes": 24,
            "string_length": 20,
            "list_item_count": 0,
            "path_count": 1,
            "has_command_like_field": False,
        },
        "raw_params": {"path": "x.txt"},
        "resource_scope": {
            "kind": "pid",
            "pid": os.getpid(),
            "root_pid": os.getpid(),
            "process_start_time": None,
            "root_starttime_ticks": None,
            "cgroup_path": None,
            "pid_namespace_inode": None,
            "container_id": None,
            "include_children": True,
            "source": "openclaw-runtime",
            "attribution_source": "shared-runtime-process",
        },
    }
    decision = client.post("/v1/decisions/tool", json=request).json()
    completion = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-runtime-after",
        "occurred_at": "2026-07-16T03:23:01Z",
        "plugin_version": "0.1.0",
        "run_id": "run-runtime",
        "session_id": "session-runtime",
        "session_key": None,
        "agent_id": "agent-runtime",
        "tool_call_id": "call-runtime",
        "decision_id": decision["decision_id"],
        "lease_id": decision["lease_id"],
        "execution_id": None,
        "tool_name": "write",
        "duration_ms": 1000,
        "succeeded": True,
        "error_type": None,
        "error_digest": None,
        "result_size_bytes": 2,
        "raw_result": "ok",
    }

    assert client.post("/v1/events/tool-completed", json=completion).json() == {"stored": True}

    records = _read_trace_records(trace_dir)
    tool_end = next(r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "tool")
    assert tool_end["execution"]["payload_pid"] == os.getpid()
    assert tool_end["resources"]["attribution_status"] == "partially_attributed"
    assert tool_end["resources"]["coverage_reason"] in {
        "shared_runtime_process",
        "monitor_window_no_overlap",
    }


def test_proxy_capture_without_model_hook_does_not_write_standalone_trace(tmp_path: Path, monkeypatch) -> None:
    client, trace_dir = _trace_proxy_client(tmp_path)
    # Remove any existing trace files
    for f in trace_dir.glob("*.jsonl"):
        f.unlink()

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def post(self, url, headers=None, content=None):
            return httpx.Response(
                200,
                json={
                    "id": "chatcmpl-test",
                    "object": "chat.completion",
                    "model": "test-model",
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": "world"},
                            "finish_reason": "stop",
                        }
                    ],
                },
            )

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)
    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "messages": [{"role": "user", "content": "hello"}],
        },
    )

    assert response.status_code == 200
    assert _read_trace_records(trace_dir) == []


def test_llm_proxy_records_full_request_and_response(tmp_path: Path, monkeypatch) -> None:
    client, trace_dir = _trace_proxy_client(tmp_path)

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def post(self, url, headers=None, content=None):
            assert url == "https://upstream.example/v1/chat/completions"
            request_payload = json.loads(content.decode("utf-8"))
            assert request_payload["messages"][0]["content"] == "hello"
            return httpx.Response(
                200,
                json={
                    "id": "chatcmpl-test",
                    "object": "chat.completion",
                    "model": request_payload["model"],
                    "choices": [
                        {
                            "index": 0,
                            "message": {"role": "assistant", "content": "world"},
                            "finish_reason": "stop",
                        }
                    ],
                },
            )

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "messages": [{"role": "user", "content": "hello"}],
        },
    )

    assert response.status_code == 200
    assert response.json()["choices"][0]["message"]["content"] == "world"
    # Proxy-only calls should not write trace without model hook
    assert _read_trace_records(trace_dir) == []


def test_model_hook_record_is_enriched_from_proxy_capture(tmp_path: Path, monkeypatch) -> None:
    client, trace_dir = _trace_proxy_client(tmp_path)

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def post(self, url, headers=None, content=None):
            return httpx.Response(
                200,
                json={
                    "id": "chatcmpl-test",
                    "object": "chat.completion",
                    "model": "test-model",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "world",
                                "tool_calls": [
                                    {
                                        "id": "call-proxy-tool",
                                        "type": "function",
                                        "function": {"name": "exec", "arguments": '{"command":"pwd"}'},
                                    }
                                ],
                            },
                            "finish_reason": "tool_calls",
                        }
                    ],
                },
            )

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    assert client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "messages": [{"role": "user", "content": "hello"}],
        },
    ).status_code == 200

    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    started = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-model-start-proxy",
        "occurred_at": now,
        "plugin_version": "0.1.0",
        "run_id": "run-proxy",
        "session_id": "session-proxy",
        "session_key": "agent:main:main",
        "agent_id": None,
        "event_type": "model_call_started",
        "call_id": "run-proxy:model:1",
        "provider": "vllm",
        "model": "test-model",
        "duration_ms": None,
        "outcome": None,
        "context_token_budget": 8192,
        "raw_input": None,
        "raw_output": None,
        "raw_event": {"runId": "run-proxy", "sessionId": "session-proxy"},
    }
    ended = started | {
        "event_id": "evt-model-end-proxy",
        "occurred_at": now,
        "event_type": "model_call_ended",
        "duration_ms": 2000,
        "outcome": "completed",
        "raw_event": {"runId": "run-proxy", "sessionId": "session-proxy"},
    }
    assert client.post("/v1/events/model", json=started).json() == {"stored": True}
    assert client.post("/v1/events/model", json=ended).json() == {"stored": True}

    records = _read_trace_records(trace_dir)
    llm_starts = [r for r in records if r.get("record_type") == "span_start" and r.get("kind") == "llm"]
    assert len(llm_starts) == 1
    assert llm_starts[0]["run_id"] == "run-proxy"
    assert llm_starts[0]["session_id"] == "session-proxy"
    assert llm_starts[0]["agent_id"] == "main"
    assert llm_starts[0]["input"]["messages"] == [{"role": "user", "content": "hello"}]
    llm_ends = [r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "llm"]
    assert llm_ends[0]["output"]["content"]["content"] == "world"
    assert llm_ends[0]["output"]["content"]["tool_calls"][0]["id"] == "call-proxy-tool"


def _drive_proxy_and_model_events(
    client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
    *,
    gateway_id: str | None,
    runtime_id: str | None,
) -> None:
    """Send a proxied chat completion plus model start/end events.

    Mirrors a live agent turn: OpenClaw POSTs to the sidecar LLM proxy (which
    records ``messages_in``/``content`` keyed by the runtime credential) and the
    plugin separately reports ``model_call_started`` / ``model_call_ended``.
    The sidecar must correlate the proxy capture with the model span.
    """

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def post(self, url, headers=None, content=None):
            return httpx.Response(
                200,
                json={
                    "id": "chatcmpl-test",
                    "object": "chat.completion",
                    "model": "test-model",
                    "choices": [
                        {
                            "index": 0,
                            "message": {
                                "role": "assistant",
                                "content": "world",
                                "tool_calls": [
                                    {
                                        "id": "call-proxy-tool",
                                        "type": "function",
                                        "function": {"name": "exec", "arguments": '{"command":"pwd"}'},
                                    }
                                ],
                            },
                            "finish_reason": "tool_calls",
                        }
                    ],
                },
            )

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    headers = {}
    if runtime_id is not None:
        headers["x-clawtune-runtime-id"] = runtime_id
    assert client.post(
        "/v1/chat/completions",
        json={"model": "test-model", "messages": [{"role": "user", "content": "hello"}]},
        headers=headers,
    ).status_code == 200

    now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    started = {
        "schema_version": "clawtune.v1",
        "event_id": "evt-model-start-proxy",
        "occurred_at": now,
        "plugin_version": "0.1.0",
        "run_id": "run-proxy",
        "session_id": "session-proxy",
        "session_key": "agent:main:main",
        "agent_id": None,
        "gateway_id": gateway_id,
        "runtime_id": runtime_id,
        "event_type": "model_call_started",
        "call_id": "run-proxy:model:1",
        "provider": "vllm",
        "model": "test-model",
        "duration_ms": None,
        "outcome": None,
        "context_token_budget": 8192,
        "raw_input": None,
        "raw_output": None,
        "raw_event": {"runId": "run-proxy", "sessionId": "session-proxy"},
    }
    ended = started | {
        "event_id": "evt-model-end-proxy",
        "occurred_at": now,
        "event_type": "model_call_ended",
        "duration_ms": 2000,
        "outcome": "completed",
        "raw_event": {"runId": "run-proxy", "sessionId": "session-proxy"},
    }
    assert client.post("/v1/events/model", json=started).json() == {"stored": True}
    assert client.post("/v1/events/model", json=ended).json() == {"stored": True}


def test_model_proxy_capture_correlates_when_events_carry_gateway_id(
    tmp_path: Path, monkeypatch
) -> None:
    """swe-rebench scenario: model events carry gateway_id="swe-rebench" and a
    runtime id, while proxy captures only carry the runtime credential. The
    proxy messages must still be attached to the LLM span."""
    client, trace_dir = _trace_proxy_client(tmp_path)
    _drive_proxy_and_model_events(
        client,
        monkeypatch,
        gateway_id="swe-rebench",
        runtime_id="clawtune-srb-996de1b4ee38",
    )

    records = _read_trace_records(trace_dir)
    llm_starts = [
        r for r in records if r.get("record_type") == "span_start" and r.get("kind") == "llm"
    ]
    assert len(llm_starts) == 1
    assert llm_starts[0]["gateway_id"] == "swe-rebench"
    assert llm_starts[0]["runtime_id"] == "clawtune-srb-996de1b4ee38"
    assert llm_starts[0]["input"]["messages"] == [{"role": "user", "content": "hello"}]
    llm_ends = [
        r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "llm"
    ]
    assert llm_ends[0]["output"]["content"]["content"] == "world"
    assert llm_ends[0]["output"]["content"]["tool_calls"][0]["id"] == "call-proxy-tool"


def test_model_proxy_capture_correlates_without_gateway_id(tmp_path: Path, monkeypatch) -> None:
    """Plain OpenClaw / legacy scenario: no gateway_id anywhere. Correlation
    still works on runtime_id + model + time alone."""
    client, trace_dir = _trace_proxy_client(tmp_path)
    _drive_proxy_and_model_events(client, monkeypatch, gateway_id=None, runtime_id=None)

    records = _read_trace_records(trace_dir)
    llm_starts = [
        r for r in records if r.get("record_type") == "span_start" and r.get("kind") == "llm"
    ]
    assert len(llm_starts) == 1
    assert llm_starts[0]["gateway_id"] is None
    assert llm_starts[0]["input"]["messages"] == [{"role": "user", "content": "hello"}]
    llm_ends = [
        r for r in records if r.get("record_type") == "span_end" and r.get("kind") == "llm"
    ]
    assert llm_ends[0]["output"]["content"]["content"] == "world"


def test_proxy_capture_rejected_when_explicit_gateway_differs(tmp_path: Path) -> None:
    """Isolation intent is preserved: when a proxy capture DOES carry an explicit
    gateway_id, a model event from a different gateway must not consume it."""
    from clawtune_sidecar.contracts.models import ModelEvent
    from clawtune_sidecar.trace import AgentTestBenchTraceWriter

    writer = AgentTestBenchTraceWriter(tmp_path / "traces")
    ts = time.time()
    event_kwargs = dict(
        schema_version="clawtune.v1",
        event_id="evt-1",
        occurred_at=time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime(ts)),
        plugin_version="0.1.0",
        run_id="run-1",
        session_id="session-1",
        session_key="agent:main:main",
        agent_id=None,
        event_type="model_call_ended",
        call_id="c1",
        provider="vllm",
        model="test-model",
        duration_ms=1000,
        outcome="completed",
        context_token_budget=8192,
        raw_input=None,
        raw_output=None,
        raw_event=None,
        runtime_id="runtime-a",
        repo="owner/repo",
    )

    def _record_with_gateway(gateway_id: str) -> None:
        writer.record_llm_proxy_call(
            runtime_id="runtime-a",
            action_id=f"llm-proxy-{gateway_id}",
            provider="llm-proxy",
            model="test-model",
            messages_in=[{"role": "user", "content": "hello"}],
            content="world",
            raw_request=None,
            raw_response=None,
            ts_start=ts - 1.0,
            ts_end=ts,
            status_code=200,
            stream=False,
            error=None,
        )
        # The proxy does not emit a gateway_id today, but if a future capture
        # does, the strict isolation rule must still reject foreign gateways.
        writer._recent_proxy_calls[-1]["gateway_id"] = gateway_id

    _record_with_gateway("gateway-a")
    different = ModelEvent(**{**event_kwargs, "gateway_id": "gateway-b"})
    assert writer._pop_recent_proxy_call(different) is None
    # The rejected capture was not consumed; drop it so the next scenario starts
    # with a single unambiguous candidate.
    writer._recent_proxy_calls.clear()

    _record_with_gateway("gateway-a")
    same = ModelEvent(**{**event_kwargs, "gateway_id": "gateway-a"})
    matched = writer._pop_recent_proxy_call(same)
    assert matched is not None
    assert matched["data"]["messages_in"] == [{"role": "user", "content": "hello"}]


def test_llm_proxy_reconstructs_streaming_tool_calls(tmp_path: Path, monkeypatch) -> None:
    client, trace_dir = _trace_proxy_client(tmp_path)

    class FakeStream:
        status_code = 200

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def aiter_bytes(self):
            chunks = [
                {
                    "choices": [
                        {
                            "index": 0,
                            "delta": {
                                "tool_calls": [
                                    {
                                        "index": 0,
                                        "id": "call-1",
                                        "type": "function",
                                        "function": {"name": "exec", "arguments": '{"command":"py'},
                                    }
                                ]
                            },
                            "finish_reason": None,
                        }
                    ]
                },
                {
                    "choices": [
                        {
                            "index": 0,
                            "delta": {
                                "tool_calls": [
                                    {"index": 0, "function": {"arguments": 'thon --version"}'}}
                                ]
                            },
                            "finish_reason": "tool_calls",
                        }
                    ]
                },
            ]
            for chunk in chunks:
                yield f"data: {json.dumps(chunk)}\n\n".encode("utf-8")
            yield b"data: [DONE]\n\n"

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        def stream(self, method, url, headers=None, content=None):
            return FakeStream()

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "stream": True,
            "messages": [{"role": "user", "content": "run python"}],
        },
    )

    assert response.status_code == 200
    # Proxy-only streaming should not write trace without model hook
    assert _read_trace_records(trace_dir) == []
    assert list(trace_dir.glob("llm_proxy_debug_*.json")) == []


def test_llm_proxy_buffers_fragmented_sse_events(tmp_path: Path, monkeypatch) -> None:
    client, _trace_dir = _trace_proxy_client(tmp_path)
    event = {
        "choices": [
            {
                "index": 0,
                "delta": {"content": "hello"},
                "finish_reason": None,
            }
        ]
    }
    wire = f"data: {json.dumps(event)}\n\n".encode("utf-8")

    class FakeStream:
        status_code = 200

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def aiter_bytes(self):
            yield wire[:25]
            yield wire[25:]
            yield b"data: [DONE]\n\n"

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        def stream(self, method, url, headers=None, content=None):
            return FakeStream()

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "stream": True,
            "messages": [{"role": "user", "content": "hello"}],
        },
    )

    assert response.status_code == 200
    assert response.text.count("data: ") == 2
    assert '"content": "hello"' in response.text
    assert "[DONE]" in response.text


def test_llm_proxy_parses_crlf_sse_before_end_of_stream() -> None:
    first = b'data: {"choices":[{"delta":{"content":"hello"}}]}\r\n\r\n'
    second = b"data: [DONE]\r\n\r\n"

    events, remainder = _parse_sse_buffer(first + second[:8])

    assert len(events) == 1
    assert events[0]["choices"][0]["delta"]["content"] == "hello"
    assert remainder == second[:8]


def test_llm_proxy_surfaces_empty_stream_and_writes_safe_diagnostic(
    tmp_path: Path,
    monkeypatch,
) -> None:
    client, trace_dir = _trace_proxy_client(tmp_path)

    class FakeStream:
        status_code = 200

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def aiter_bytes(self):
            yield b'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\n\n'
            yield b"data: [DONE]\n\n"

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        def stream(self, method, url, headers=None, content=None):
            return FakeStream()

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "stream": True,
            "messages": [{"role": "user", "content": "hello"}],
        },
    )

    assert response.status_code == 200
    assert "upstream_empty_response" in response.text
    assert response.text.rstrip().endswith("data: [DONE]")
    debug_files = list(trace_dir.glob("llm_proxy_debug_*.json"))
    assert len(debug_files) == 1
    diagnostic = json.loads(debug_files[0].read_text(encoding="utf-8"))
    assert diagnostic["automatic_empty_diagnostic"] is True
    assert diagnostic["raw_preview_bytes"] > 0
    assert "raw_preview_sha256" in diagnostic
    assert "raw_preview" not in diagnostic


def test_llm_proxy_writes_debug_dump_only_when_enabled(tmp_path: Path, monkeypatch) -> None:
    client, trace_dir = _trace_proxy_client_with_debug(tmp_path)
    event = {
        "choices": [
            {
                "index": 0,
                "delta": {"content": "hello"},
                "finish_reason": "stop",
            }
        ]
    }

    class FakeStream:
        status_code = 200

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        async def aiter_bytes(self):
            yield f"data: {json.dumps(event)}\n\n".encode("utf-8")
            yield b"data: [DONE]\n\n"

    class FakeAsyncClient:
        def __init__(self, *args, **kwargs) -> None:
            pass

        async def __aenter__(self):
            return self

        async def __aexit__(self, exc_type, exc, tb) -> None:
            return None

        def stream(self, method, url, headers=None, content=None):
            return FakeStream()

    monkeypatch.setattr("clawtune_sidecar.llm_proxy.httpx.AsyncClient", FakeAsyncClient)

    response = client.post(
        "/v1/chat/completions",
        json={
            "model": "test-model",
            "stream": True,
            "messages": [{"role": "user", "content": "hello"}],
        },
    )

    assert response.status_code == 200
    debug_files = list(trace_dir.glob("llm_proxy_debug_*.json"))
    assert len(debug_files) == 1


def test_execution_registration_round_trip(tmp_path: Path) -> None:
    client = _client(tmp_path)
    response = client.post(
        "/v2/executions",
        json={
            "execution_id": "exec-1",
            "tool_call_id": "call-1",
            "run_id": "run-1",
            "session_key_hash": "sha256:" + "a" * 64,
            "command_digest": "sha256:" + "b" * 64,
            "command": "pytest tests -q",
            "workdir": "/workspace",
            "host": "gateway",
            "placement": {"cpu_set": None, "numa_node": None, "llc_cluster": None, "advisory": True},
            "profiling": {"mode": "off"},
            "backend": "marker",
        },
    )
    assert response.status_code == 200
    registration = response.json()
    assert registration["execution_id"] == "exec-1"
    assert registration["one_time_token"]
    assert registration["expires_at"].endswith("Z")

    claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "exec-1",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    )
    assert claim.status_code == 200
    spec = claim.json()
    assert spec["execution_id"] == "exec-1"
    assert spec["command"] == "pytest tests -q"
    assert spec["workdir"] == "/workspace"
    assert spec["update_token"]

    duplicate_claim = client.post(
        "/v2/executions/claim",
        json={
            "execution_id": "exec-1",
            "token": registration["one_time_token"],
            "launcher_pid": 100,
        },
    )
    assert duplicate_claim.status_code == 409

    started = client.post(
        "/v2/executions/exec-1/started",
        json={
            "update_token": spec["update_token"],
            "launcher_pid": 100,
            "child_pid": 101,
            "process_starttime_ticks": 12345,
            "cgroup_path": None,
            "pid_namespace_inode": 4026531836,
            "container_id": None,
        },
    )
    assert started.status_code == 200
    assert started.json() == {"stored": True}

    scope = client.get("/v2/executions/exec-1/scope")
    assert scope.status_code == 200
    assert scope.json()["execution_scope"] == {
        "kind": "pid",
        "execution_id": "exec-1",
        "pid": 101,
        "root_pid": 101,
        "process_start_time": None,
        "root_starttime_ticks": 12345.0,
        "cgroup_path": None,
        "pid_namespace_inode": 4026531836,
        "container_id": None,
        "include_children": True,
        "source": "clawtune-launch",
        "attribution_source": "clawtune-launch",
    }

    exited = client.post(
        "/v2/executions/exec-1/exited",
        json={"update_token": spec["update_token"], "exit_code": 0, "signal": None},
    )
    assert exited.status_code == 200
    assert exited.json() == {"stored": True}


@pytest.mark.parametrize("parallelism", [1, 4])
def test_slow_completion_keeps_event_loop_responsive(tmp_path, parallelism):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event, Lock
    state = build_state(SidecarConfig(trace_dir=tmp_path / "traces", tool_resource_ebpf_required=False))
    entered, release, lock = Event(), Event(), Lock()
    calls = []
    def finish(**kwargs):
        with lock:
            calls.append(kwargs["execution_id"])
            if len(calls) == parallelism:
                entered.set()
        assert release.wait(5)
        return {"execution_id": kwargs["execution_id"], "started": True, "status": "ok"}
    state.predictor.finish_execution = finish
    with TestClient(create_app(state)) as client, ThreadPoolExecutor(max_workers=parallelism + 1) as pool:
        completions = []
        for i in range(parallelism):
            eid = f"slow-{i}"
            registration = client.post("/v2/executions", json={
                "execution_id": eid, "tool_call_id": eid, "run_id": "run-slow",
                "session_key_hash": None, "command_digest": "sha256:" + "d" * 64,
                "command": "echo hi", "workdir": "/workspace", "host": "gateway",
                "placement": None, "profiling": {"mode": "off"}, "backend": "managed-wrapper",
            }).json()
            claim = client.post("/v2/executions/claim", json={"execution_id": eid,
                "token": registration["one_time_token"], "launcher_pid": 100}).json()
            client.post(f"/v2/executions/{eid}/exited", json={
                "update_token": claim["update_token"], "exit_code": 0, "signal": None})
            completions.append({
                "schema_version": "clawtune.v1", "event_id": "evt-" + eid,
                "occurred_at": "2026-07-29T00:00:00Z", "plugin_version": "0.1.0",
                "run_id": "run-slow", "session_id": "session-slow", "session_key": None,
                "agent_id": None, "tool_call_id": eid, "decision_id": None, "lease_id": None,
                "execution_id": eid, "tool_name": "exec", "duration_ms": 100,
                "succeeded": True, "error_type": None, "error_digest": None,
                "result_size_bytes": None, "resource_scope": None,
            })
        futures = [pool.submit(client.post, "/v1/events/tool-completed", json=c) for c in completions]
        try:
            assert entered.wait(2), "finalization serialized the event loop"
            health = pool.submit(client.get, "/health/live")
            assert health.result(timeout=1).status_code == 200
            assert not any(f.done() for f in futures)
            duplicate = pool.submit(client.post, "/v1/events/tool-completed", json={
                **completions[0], "event_id": "evt-duplicate-completion",
            })
            with pytest.raises(TimeoutError):
                duplicate.result(timeout=0.1)
        finally:
            release.set()
        assert all(f.result(timeout=3).status_code == 200 for f in futures)
        assert duplicate.result(timeout=3).status_code == 200
        assert len(calls) == parallelism


@pytest.mark.parametrize("parallelism", [1, 4])
def test_slow_start_keeps_event_loop_responsive(tmp_path, parallelism):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event, Lock
    scope = tmp_path / "cgroup"
    _write_cgroup_fixture(scope)
    state = build_state(SidecarConfig(trace_dir=tmp_path / "traces", tool_resource_ebpf_required=False,
        sandbox_cgroup_path=str(scope), sandbox_container_id="b" * 64))
    entered, release, lock = Event(), Event(), Lock()
    calls = []
    def begin(**kwargs):
        with lock:
            calls.append(kwargs['execution_id'])
            if len(calls) == parallelism:
                entered.set()
        assert release.wait(5)
        return True
    state.predictor.begin_execution = begin
    with TestClient(create_app(state)) as client, ThreadPoolExecutor(parallelism + 1) as pool:
        claims=[]
        for i in range(parallelism):
            eid=f'slow-start-{i}'
            r=client.post('/v2/executions',json={'execution_id':eid,'tool_call_id':eid,'run_id':'run-start',
                'session_key_hash':None,'command_digest':'sha256:'+'d'*64,'command':'echo hi',
                'workdir':'/workspace','host':'gateway','placement':None,'profiling':{'mode':'off'},'backend':'managed-wrapper'}).json()
            claims.append({'execution_id':eid,'token':r['one_time_token'],'launcher_pid':100})
        futures=[pool.submit(client.post,'/v2/executions/claim',json=c) for c in claims]
        try:
            assert entered.wait(2)
            assert pool.submit(client.get,'/health/live').result(timeout=1).status_code==200
        finally:
            release.set()
        assert all(f.result(timeout=3).status_code==200 for f in futures)
