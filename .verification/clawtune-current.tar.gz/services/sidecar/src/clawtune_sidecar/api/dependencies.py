from __future__ import annotations

import asyncio
import math
from dataclasses import dataclass, field

from clawtune_sidecar.admission.leases import LeaseManager
from clawtune_sidecar.config import SidecarConfig
from clawtune_sidecar.contracts.models import ResourceScope, ToolDecision
from clawtune_sidecar.executions import ExecutionRegistry
from clawtune_sidecar.monitoring.docker_exec import DockerExecObserver
from clawtune_sidecar.monitoring.pmu import PmuCollector, auto_fd_budget
from clawtune_sidecar.monitoring.tool_runtime import RealtimeToolMonitor
from clawtune_sidecar.policies.base import SchedulingPolicy
from clawtune_sidecar.policies.concurrency import ConcurrencyPolicy
from clawtune_sidecar.policies.observe import ObserveOnlyPolicy
from clawtune_sidecar.predictors.tool_resource import ToolResourcePredictor
from clawtune_sidecar.telemetry.metrics import Metrics
from clawtune_sidecar.topology.linux import NumaCpuUsageSampler, read_topology
from clawtune_sidecar.trace import AgentTestBenchTraceWriter
from tool_resource.runtime_kb import LatencyBuckets


@dataclass
class AppState:
    config: SidecarConfig
    predictor: ToolResourcePredictor
    leases: LeaseManager
    policy: SchedulingPolicy
    tool_monitor: RealtimeToolMonitor
    pmu_collector: PmuCollector
    docker_exec_observer: DockerExecObserver | None
    executions: ExecutionRegistry
    metrics: Metrics
    topology: dict
    trace_writer: AgentTestBenchTraceWriter
    _sandbox_scope_override: ResourceScope | None
    _completed_tool_event_ids: set[tuple[str | None, ...]]
    _model_event_ids: set[tuple[str | None, ...]]
    _tool_decisions_by_event_id: dict[
        tuple[str | None, ...],
        tuple[str, str, ToolDecision],
    ]
    _decision_tasks: dict[
        tuple[str | None, ...],
        asyncio.Task[ToolDecision],
    ]
    _runtime_activity: dict[tuple[str | None, str | None], int]
    _ebpf_finalize_tasks: dict[str, asyncio.Task[None]]
    _owned_cgroup_cleanup_tasks: dict[str, asyncio.Task[None]]
    _owned_cgroup_paths: dict[str, str]
    _owned_environment_cgroup_paths: set[str]
    _recent_samples: list[dict[str, object]]  # recent tool runtime samples for /v1/tools/recent
    _sandbox_scopes_by_owner: dict[tuple[str | None, str], ResourceScope] = field(
        default_factory=dict
    )
    _native_runtime_scopes: dict[tuple[str, str], ResourceScope] = field(default_factory=dict)
    _max_recent_samples: int = 200  # max samples to keep in memory


def build_state(config: SidecarConfig | None = None) -> AppState:
    cfg = config or SidecarConfig.from_env()
    topology = read_topology(
        reserve_ratio=cfg.cpu_reserve_ratio,
        reserve_cores=cfg.cpu_reserve_cores,
        cpu_budget_cores=cfg.cpu_budget_cores,
    )
    detected_tool_budget = topology.get("tool_cpu_budget_cores")
    auto_active_tools = max(
        1,
        math.floor(
            float(detected_tool_budget)
            if isinstance(detected_tool_budget, (int, float))
            else 1.0
        ),
    )
    max_active_tools = cfg.max_global_concurrency or auto_active_tools
    topology["max_active_tools"] = max_active_tools
    topology["max_active_tools_source"] = (
        "configured" if cfg.max_global_concurrency else "effective_cpu_budget"
    )
    cpu_budget_mcpu = (
        max(1, round(float(detected_tool_budget) * 1_000))
        if topology.get("available") is True
        and isinstance(detected_tool_budget, (int, float))
        and float(detected_tool_budget) > 0.0
        else None
    )
    topology["tool_cpu_budget_mcpu"] = cpu_budget_mcpu
    leases = LeaseManager(
        max_active_tools,
        cfg.lease_ttl_ms,
        cpu_budget_mcpu=cpu_budget_mcpu,
    )
    if (cfg.tool_resource_artifact_dir is not None and not cfg.tool_resource_frozen
            and not cfg.tool_resource_trace_paths and not cfg.tool_resource_ebpf_trace_paths):
        from clawtune_kb import initialize_state
        from clawtune_kb.contracts import data_root
        from pathlib import Path
        import os
        kb_dir = cfg.tool_resource_artifact_dir
        seed = Path(os.environ.get("CLAWTUNE_KB_SEED", str(data_root() / "seeds/bootstrap-v1")))
        if not kb_dir.exists():
            initialize_state(kb_dir, seed, owner=os.environ.get("CLAWTUNE_KB_OWNER", "daily"))
    predictor = ToolResourcePredictor.from_traces(
        openclaw_trace_paths=cfg.tool_resource_trace_paths,
        ebpf_trace_paths=cfg.tool_resource_ebpf_trace_paths,
        buckets=LatencyBuckets(cfg.tool_resource_latency_buckets_ms),
        load_buckets=cfg.tool_resource_load_buckets,
        frozen=cfg.tool_resource_frozen,
        repo=cfg.tool_resource_repo,
        artifact_dir=(
            cfg.tool_resource_artifact_dir
            if cfg.tool_resource_artifact_dir is not None
            else cfg.trace_dir / "tool-resource"
        ),
        container_executable=cfg.tool_resource_container_executable,
        ttl_by_bucket_s=cfg.tool_resource_ttl_by_bucket_s,
        miss_penalty_s=cfg.tool_resource_miss_penalty_s,
        numa_usage_sampler=NumaCpuUsageSampler(),
    )
    if predictor.artifact_dir is not None:
        predictor.artifact_dir.mkdir(parents=True, exist_ok=True)
    policy: SchedulingPolicy
    if cfg.policy == "concurrency":
        policy = ConcurrencyPolicy(leases, cfg.admission_wait_ms)
    else:
        policy = ObserveOnlyPolicy()
    tool_monitor = RealtimeToolMonitor(
        poll_interval_s=max(0.01, cfg.resource_poll_interval_ms / 1000),
        max_timeline_points=max(1, cfg.resource_timeline_max_points),
    )
    pmu_max_active = cfg.pmu_max_active or max_active_tools
    pmu_max_fds = (
        cfg.pmu_max_fds
        if cfg.pmu_max_fds is not None
        else auto_fd_budget(pmu_max_active)
    )
    pmu_collector = PmuCollector(
        enabled=cfg.pmu_enabled,
        max_active=pmu_max_active,
        max_fds=pmu_max_fds,
        reliable_ratio=cfg.pmu_reliable_running_ratio,
    )
    topology["pmu"] = pmu_collector.diagnostics()
    docker_exec_observer = (
        DockerExecObserver(
            enabled=cfg.docker_exec_observer_enabled,
            docker_socket=cfg.docker_socket,
            container_id=cfg.sandbox_container_id,
            container_prefix=cfg.docker_exec_container_prefix,
            cgroup_path=cfg.sandbox_cgroup_path,
            on_scope=tool_monitor.bind_scope,
        )
        if cfg.docker_exec_observer_enabled
        else None
    )
    return AppState(
        config=cfg,
        predictor=predictor,
        leases=leases,
        policy=policy,
        tool_monitor=tool_monitor,
        pmu_collector=pmu_collector,
        docker_exec_observer=docker_exec_observer,
        executions=ExecutionRegistry(),
        metrics=Metrics(),
        topology=topology,
        trace_writer=AgentTestBenchTraceWriter(
            cfg.trace_dir,
            runtime_paths=cfg.trace_runtime_paths,
            max_messages_bytes=cfg.trace_max_messages_bytes,
            default_repo=cfg.tool_resource_repo,
        ),
        _sandbox_scope_override=None,
        _completed_tool_event_ids=set(),
        _model_event_ids=set(),
        _tool_decisions_by_event_id={},
        _decision_tasks={},
        _runtime_activity={},
        _ebpf_finalize_tasks={},
        _owned_cgroup_cleanup_tasks={},
        _owned_cgroup_paths={},
        _owned_environment_cgroup_paths=set(),
        _recent_samples=[],
        _sandbox_scopes_by_owner={},
    )
