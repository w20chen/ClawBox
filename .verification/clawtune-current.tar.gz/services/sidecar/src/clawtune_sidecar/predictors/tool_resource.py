from __future__ import annotations

import hashlib
import json
import math
import os
import queue
import shlex
import threading
import time
from collections.abc import Iterable, Mapping, Sequence
from concurrent.futures import Future, TimeoutError as FutureTimeoutError
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Callable

from clawtune_sidecar.contracts.models import (
    ToolBeforeRequest,
    ToolCompletedEvent,
    ToolPrediction,
)
from clawtune_sidecar.identity import (
    CorrelationKey,
    correlation_key,
    owners_compatible,
)
from clawtune_sidecar.monitoring.tool_runtime import ToolRuntimeSample
from clawtune_sidecar.prediction_config import load_bucket_edges
from clawtune_sidecar.predictors.call_load import predict_call_load
from clawtune_sidecar.predictors.edge_kappa import EdgeKappaRuntime, call_key
from clawtune_sidecar.topology.linux import NumaCpuUsageSampler
from clawtune_sidecar.tool_resource_commands import extract_command
from tool_resource.features import (
    parse_command_clauses,
    shell_bin_requires_exec_evidence,
)
from tool_resource.kv_ttl import evaluate_bucket_ttl
from tool_resource.metrics import ecdf_quantile
from tool_resource.runtime_kb import (
    ClauseLatencyBucketOutcome,
    ClauseLatencyBucketPrediction,
    ClauseObservation,
    ClauseResourceKB,
    CommandLatencyBucketPrediction,
    CompletedCall,
    LatencyBuckets,
    RuntimeToolResourceKB,
    TargetPrediction,
    ToolCallQuery,
    is_pipeline_dependent_consumer,
)
from tool_resource.sdk import (
    CommandRun,
    DockerExecutionContext,
    ToolResourceSDK,
    _load_valid_artifact,
    _observations_from_call,
)
from tool_time.lattice_kb import (
    LATTICE_TIME_ALGORITHMS,
    ClauseLatticeTimePredictions,
    LatticeTimeKB,
    LatticeTimePrediction,
)


_SHARED_RESOURCE_ATTRIBUTION_SOURCES = frozenset(
    {"shared-runtime-process", "shared-sandbox-container"}
)
_SHARED_RESOURCE_SCOPE_SOURCES = frozenset(
    {"openclaw-runtime", "openclaw-sandbox"}
)


@dataclass(frozen=True)
class ToolResourceLoadReport:
    ebpf_traces_seen: int
    ebpf_traces_loaded: int
    openclaw_traces_seen: int
    openclaw_traces_accepted: int
    openclaw_tool_spans_seen: int
    observations_loaded: int
    continuous_observations_loaded: int
    kb_available: bool
    continuous_kb_available: bool
    lattice_observations_loaded: int
    lattice_kb_available: bool
    rejections: tuple[str, ...]


@dataclass(frozen=True)
class OpenClawTraceLoadReport:
    traces_seen: int
    traces_accepted: int
    tool_spans_seen: int
    observations_loaded: int
    rejections: tuple[str, ...]


@dataclass(frozen=True)
class ExecutionTelemetrySummary:
    execution_id: str
    tool_call_id: str | None
    artifact_path: str | None
    started: bool
    status: str
    unavailable_reason: str | None = None
    kb_observations_added: int = 0
    kb_update_error: str | None = None
    call_telemetry: dict[str, Any] | None = None
    artifact_summary: dict[str, Any] | None = None


class KnowledgeBaseFlushError(RuntimeError):
    """Raised when queued shared-KB state cannot be made durable."""


@dataclass(frozen=True)
class _KnowledgeBaseUpdate:
    lattice_observations: tuple[ClauseObservation, ...] = ()


@dataclass(frozen=True)
class _KnowledgeBaseBarrier:
    future: Future[None]


class _KnowledgeBaseWriteCoordinator:
    """Single-writer, batched persistence coordinator for one shared KB.

    Caller threads update the cheap in-memory runtime/clause indexes under the
    predictor lock, then enqueue a durability notification.  The worker owns
    lattice preparation and all snapshot writes, coalescing bursts from many
    sessions into one generation.  A barrier always retries dirty snapshots
    before it resolves, so a sidecar drain can make all preceding observations
    durable without racing another completion writer.
    """

    def __init__(
        self,
        apply_batch: Callable[[tuple[ClauseObservation, ...]], None],
        *,
        batch_window_s: float = 0.01,
        max_batch_size: int = 512,
        idle_timeout_s: float = 0.25,
    ) -> None:
        self._apply_batch = apply_batch
        self._batch_window_s = batch_window_s
        self._max_batch_size = max_batch_size
        self._idle_timeout_s = idle_timeout_s
        self._queue: queue.Queue[_KnowledgeBaseUpdate | _KnowledgeBaseBarrier] = (
            queue.Queue()
        )
        self._state_lock = threading.Lock()
        self._worker: threading.Thread | None = None
        self._inflight = False

    def enqueue(
        self,
        lattice_observations: Sequence[ClauseObservation] = (),
    ) -> None:
        self._queue.put(
            _KnowledgeBaseUpdate(tuple(lattice_observations))
        )
        self._ensure_worker()

    def flush(self, timeout_seconds: float | None = None) -> None:
        barrier: Future[None] = Future()
        self._queue.put(_KnowledgeBaseBarrier(barrier))
        self._ensure_worker()
        try:
            barrier.result(timeout=timeout_seconds)
        except FutureTimeoutError as exc:
            raise TimeoutError(
                "timed out waiting for shared tool-resource KB flush"
            ) from exc

    def pending(self) -> bool:
        with self._state_lock:
            return self._inflight or not self._queue.empty()

    def _ensure_worker(self) -> None:
        with self._state_lock:
            if self._worker is not None and self._worker.is_alive():
                return
            self._worker = threading.Thread(
                target=self._run,
                name="clawtune-kb-writer",
                daemon=True,
            )
            self._worker.start()

    def _run(self) -> None:
        while True:
            try:
                first = self._queue.get(timeout=self._idle_timeout_s)
            except queue.Empty:
                with self._state_lock:
                    if self._queue.empty():
                        self._worker = None
                        return
                continue

            with self._state_lock:
                self._inflight = True
            items: list[_KnowledgeBaseUpdate | _KnowledgeBaseBarrier] = [first]
            if not isinstance(first, _KnowledgeBaseBarrier):
                deadline = time.monotonic() + self._batch_window_s
                while len(items) < self._max_batch_size:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    try:
                        item = self._queue.get(timeout=remaining)
                    except queue.Empty:
                        break
                    items.append(item)
                    if isinstance(item, _KnowledgeBaseBarrier):
                        break

            try:
                self._process(items)
            finally:
                with self._state_lock:
                    self._inflight = False

    def _process(
        self,
        items: Sequence[_KnowledgeBaseUpdate | _KnowledgeBaseBarrier],
    ) -> None:
        observations: list[ClauseObservation] = []
        barriers: list[Future[None]] = []
        for item in items:
            if isinstance(item, _KnowledgeBaseBarrier):
                barriers.append(item.future)
            else:
                observations.extend(item.lattice_observations)

        try:
            # Even an empty barrier batch retries snapshots left dirty by a
            # prior transient persistence error.
            self._apply_batch(tuple(observations))
        except BaseException as exc:
            for barrier in barriers:
                if not barrier.done():
                    barrier.set_exception(exc)
            return
        for barrier in barriers:
            if not barrier.done():
                barrier.set_result(None)


class _DeferredSdkClauseKb:
    """SDK view that predicts from the live KB but defers all mutations."""

    def __init__(self, predictor: "ToolResourcePredictor") -> None:
        self._predictor = predictor

    def predict_command_latency_bucket(self, *args: Any, **kwargs: Any) -> Any:
        with self._predictor._kb_lock:
            return self._predictor.kb.predict_command_latency_bucket(
                *args,
                **kwargs,
            )

    def observe_completed_clause(self, _observation: ClauseObservation) -> bool:
        # ToolResourceSDK returns the validated observations to the adapter.
        # The predictor applies them once under its shared-KB lock.
        return True


class ToolResourcePredictor:
    """OpenClaw adapter for the vendored tool_resource SDK and KB."""

    def __init__(
        self,
        *,
        kb: ClauseResourceKB,
        buckets: LatencyBuckets,
        report: ToolResourceLoadReport,
        repo: str,
        artifact_dir: Path | None = None,
        container_executable: str = "docker",
        clause_kb_snapshot_path: Path | None = None,
        runtime_kb_snapshot_path: Path | None = None,
        lattice_kb: LatticeTimeKB | None = None,
        edge_kappa: EdgeKappaRuntime | None = None,
        lattice_kb_snapshot_path: Path | None = None,
        ttl_by_bucket_s: tuple[float, ...] | None = None,
        miss_penalty_s: float | None = None,
        numa_usage_sampler: NumaCpuUsageSampler | None = None,
        load_buckets: Mapping[str, Sequence[float]] | None = None,
        frozen: bool = False,
    ) -> None:
        self.frozen = frozen
        # Historical attributes: kb is TrieKB; continuous_kb is ToolKB.
        self.kb = kb
        self.continuous_kb = RuntimeToolResourceKB()
        self.buckets = buckets
        self.load_buckets = load_bucket_edges(buckets.edges_ms, load_buckets)
        self.report = report
        self.repo = repo
        self.memory_measurement = os.getenv(
            "CLAWTUNE_TOOL_RESOURCE_MEMORY_MEASUREMENT", "cgroup_v2_environment_union_v1",
        )
        if self.memory_measurement not in {
            "cgroup_v2_memory_current", "cgroup_v2_environment_union_v1",
            "guest_memtotal_minus_memavailable",
        }:
            raise ValueError("unsupported CLAWTUNE_TOOL_RESOURCE_MEMORY_MEASUREMENT")
        self.artifact_dir = artifact_dir
        self.container_executable = container_executable
        self.clause_kb_snapshot_path = clause_kb_snapshot_path
        self.runtime_kb_snapshot_path = runtime_kb_snapshot_path
        self.lattice_kb = lattice_kb or LatticeTimeKB()
        self.edge_kappa = edge_kappa or EdgeKappaRuntime.fit((), self.load_buckets["duration_ms"], frozen=frozen)
        self.edge_kappa_snapshot_path = artifact_dir / "edge-kappa-kb.json" if artifact_dir else None
        self._edge_kappa_version = 0
        self._edge_kappa_persisted_version = 0
        if frozen:
            self.kb.freeze()
            self.continuous_kb.freeze()
            self.lattice_kb.freeze()
        self.lattice_kb_snapshot_path = lattice_kb_snapshot_path
        self.numa_usage_sampler = numa_usage_sampler
        # KV-TTL policy.  Finite bucket boundaries are derived from the
        # configured latency edges.  There is one TTL per resulting bucket,
        # including the open-ended tail bucket.  Legacy configurations with
        # one value per edge remain valid and imply immediate tail eviction.
        self.buckets_s = tuple(edge / 1000.0 for edge in buckets.edges_ms)
        configured_ttls = (
            ttl_by_bucket_s
            if ttl_by_bucket_s is not None
            else (*self.buckets_s, 0.0)
        )
        self.ttl_by_bucket_s = (
            (*configured_ttls, 0.0)
            if len(configured_ttls) == len(self.buckets_s)
            else configured_ttls
        )
        self.miss_penalty_s = miss_penalty_s
        if self.miss_penalty_s is not None and (
            not math.isfinite(self.miss_penalty_s) or self.miss_penalty_s < 0.0
        ):
            raise ValueError(
                "tool_resource_miss_penalty_s must be finite and non-negative"
            )
        expected_ttl_count = len(self.buckets_s) + 1
        if len(self.ttl_by_bucket_s) != expected_ttl_count:
            raise ValueError(
                "tool_resource_ttl_by_bucket_s must have one entry per latency "
                f"bucket (got {len(self.ttl_by_bucket_s)} entries for "
                f"{expected_ttl_count} buckets)"
            )
        self._kb_lock = threading.RLock()
        self._execution_lock = threading.RLock()
        self._execution_start_lock = threading.Lock()
        self._starts_lock = threading.RLock()
        self._runtime_kb_version = 0
        self._runtime_kb_persisted_version = 0
        self._clause_kb_version = 0
        self._clause_kb_persisted_version = 0
        self._lattice_kb_version = 0
        self._lattice_kb_persisted_version = 0
        self._lattice_needs_prepare = False
        self._lattice_staged: LatticeTimeKB | None = None
        self._sdk = ToolResourceSDK(  # type: ignore[arg-type]
            _DeferredSdkClauseKb(self),
            buckets,
        )
        self._runs_by_execution_id: dict[str, CommandRun] = {}
        self._execution_owners: dict[str, tuple[str | None, str | None]] = {}
        self._telemetry_by_execution_id: dict[str, ExecutionTelemetrySummary] = {}
        self._starts: dict[CorrelationKey, ToolBeforeRequest] = {}
        self._kb_writes = _KnowledgeBaseWriteCoordinator(
            self._flush_kb_batch,
        )

    @classmethod
    def from_traces(cls, **kwargs) -> "ToolResourcePredictor":
        from clawtune_kb import StateStore
        artifact_dir = kwargs.get("artifact_dir")
        if artifact_dir is not None and (artifact_dir / "manifest.json").is_file():
            from clawtune_kb import validate_seed
            validate_seed(artifact_dir)
            if not kwargs.get("frozen", False):
                raise ValueError("immutable seed cannot be opened for online learning; initialize a working KB")
        store = None
        if artifact_dir is not None and (artifact_dir / "state.json").is_file() and not kwargs.get("frozen", False):
            store = StateStore(artifact_dir)
            store.__enter__()
            # Managed states never discover historical files at startup.
            kwargs["openclaw_trace_paths"] = ()
            kwargs["ebpf_trace_paths"] = ()
        try:
            result = cls._from_traces(**kwargs)
            result._state_store = store
            return result
        except BaseException:
            if store is not None:
                store.__exit__(None, None, None)
            raise

    @classmethod
    def _from_traces(
        cls,
        *,
        openclaw_trace_paths: Iterable[Path],
        ebpf_trace_paths: Iterable[Path],
        buckets: LatencyBuckets,
        repo: str = "openclaw",
        artifact_dir: Path | None = None,
        container_executable: str = "docker",
        ttl_by_bucket_s: tuple[float, ...] | None = None,
        miss_penalty_s: float | None = None,
        numa_usage_sampler: NumaCpuUsageSampler | None = None,
        load_buckets: Mapping[str, Sequence[float]] | None = None,
        frozen: bool = False,
    ) -> "ToolResourcePredictor":
        if frozen:
            if artifact_dir is None:
                raise ValueError("frozen evaluation requires an explicit cold-start directory")
            paths = [_clause_kb_snapshot_path(artifact_dir), _runtime_kb_snapshot_path(artifact_dir),
                     _lattice_kb_snapshot_path(artifact_dir)]
            # No trace scanning, artifact auto-discovery, training merge, or
            # snapshot rewriting is legal when evaluating a frozen seed.
            seed_manifest_path = artifact_dir / "seed-manifest.json"
            expected = (json.loads(seed_manifest_path.read_text(encoding="utf-8"))["snapshots"]
                        if seed_manifest_path.is_file() else None)
            payloads = []
            for path in paths:
                data = path.read_bytes()
                if expected is not None and hashlib.sha256(data).hexdigest() != expected.get(path.name):
                    raise ValueError(f"frozen cold-start snapshot hash mismatch: {path.name}")
                payloads.append(json.loads(data))
            clause = ClauseResourceKB.from_json_obj(payloads[0])
            runtime = RuntimeToolResourceKB.from_json_obj(payloads[1])
            lattice = LatticeTimeKB.from_json_obj(payloads[2])
            runtime.freeze()
            result = cls(kb=clause, lattice_kb=lattice, buckets=buckets, repo=repo,
                artifact_dir=artifact_dir, container_executable=container_executable,
                load_buckets=load_buckets, ttl_by_bucket_s=ttl_by_bucket_s, miss_penalty_s=miss_penalty_s,
                numa_usage_sampler=numa_usage_sampler, frozen=True,
                report=ToolResourceLoadReport(ebpf_traces_seen=0, ebpf_traces_loaded=0,
                    openclaw_traces_seen=0, openclaw_traces_accepted=0, openclaw_tool_spans_seen=0,
                    observations_loaded=0, continuous_observations_loaded=0,
                    kb_available=True, continuous_kb_available=True,
                    lattice_observations_loaded=lattice.observation_count, lattice_kb_available=bool(lattice.observation_count),
                    rejections=()))
            result.continuous_kb = runtime
            edge_path = artifact_dir / "edge-kappa-kb.json"
            if expected is not None and edge_path.name in expected and not edge_path.is_file():
                raise ValueError("frozen edge kappa snapshot missing from declared seed")
            if edge_path.is_file():
                manifest_path = artifact_dir / "manifest.json"
                edge_hashes = (json.loads(manifest_path.read_text(encoding="utf-8"))["snapshots"]
                               if manifest_path.is_file() else expected)
                data = edge_path.read_bytes()
                if edge_hashes is not None and hashlib.sha256(data).hexdigest() != edge_hashes.get(edge_path.name):
                    raise ValueError("frozen edge kappa snapshot hash mismatch")
                result.edge_kappa = EdgeKappaRuntime.from_snapshot(json.loads(data), frozen=True)
                if result.edge_kappa.kb.bucket_edges_ms != tuple(result.load_buckets["duration_ms"]):
                    raise ValueError("edge kappa bucket edges mismatch")
            return result
        openclaw_paths = list(_expand_trace_paths(openclaw_trace_paths))
        ebpf_paths = list(_expand_trace_paths(ebpf_trace_paths))
        # When no explicit eBPF paths are configured, auto-discover
        # individual call artifacts that have accumulated in the artifact
        # directory across prior ``openclaw agent --local`` invocations.
        if not ebpf_paths and artifact_dir is not None and not (artifact_dir / "state.json").exists():
            ebpf_paths = _discover_artifact_call_files(artifact_dir)
        observations: list[ClauseObservation] = []
        continuous_observations: list[CompletedCall] = []
        rejections: list[str] = []
        ebpf_loaded = 0

        for path in ebpf_paths:
            try:
                artifact = _read_ebpf_artifact(path)
                observations.extend(_ebpf_observations(artifact, fallback_repo=repo))
                ebpf_loaded += 1
            except ValueError as exc:
                rejections.append(f"{path}: {exc}")

        openclaw_accepted = 0
        openclaw_spans_seen = 0
        for path in openclaw_paths:
            try:
                loaded = load_openclaw_trace_observations(path, repo=repo)
            except ValueError as exc:
                rejections.append(f"{path}: {exc}")
                continue
            openclaw_accepted += 1
            openclaw_spans_seen += loaded.tool_spans_seen
            continuous_observations.extend(loaded.completed_calls)
            observations.extend(loaded.observations)

        snapshot_path = _clause_kb_snapshot_path(artifact_dir)
        runtime_snapshot_path = _runtime_kb_snapshot_path(artifact_dir)
        lattice_snapshot_path = _lattice_kb_snapshot_path(artifact_dir)
        kb: ClauseResourceKB
        kb_has_public_evidence = False
        loaded_snapshot = _load_clause_kb_snapshot(snapshot_path, rejections)
        if loaded_snapshot is not None:
            kb = loaded_snapshot
            if observations and not _has_public_clause_latency(kb):
                try:
                    kb._public = ClauseResourceKB.fit_public(observations)._public  # type: ignore[attr-defined]
                except ValueError as exc:
                    rejections.append(f"fit_public: {exc}")
            kb.merge_historical(observations)
            kb_has_public_evidence = _has_public_clause_latency(kb)
        elif observations:
            try:
                kb = ClauseResourceKB.fit_public(observations)
                kb_has_public_evidence = True
            except ValueError as exc:
                rejections.append(f"fit_public: {exc}")
                kb = ClauseResourceKB()
            kb.merge_historical(observations)
        else:
            kb = ClauseResourceKB()

        loaded_lattice_snapshot = _load_lattice_kb_snapshot(
            lattice_snapshot_path,
            rejections,
        )
        if loaded_lattice_snapshot is None:
            lattice_kb = LatticeTimeKB.fit(observations)
        else:
            lattice_kb = loaded_lattice_snapshot
            lattice_kb.merge_historical(observations)
        lattice_kb_available = lattice_kb.observation_count > 0
        try:
            lattice_kb.prepare()
        except Exception as exc:
            lattice_kb_available = False
            rejections.append(f"prepare lattice KB: {type(exc).__name__}: {exc}")

        edge_path = artifact_dir / "edge-kappa-kb.json" if artifact_dir else None
        if edge_path is not None and edge_path.is_file():
            edge_kappa = EdgeKappaRuntime.from_snapshot(json.loads(edge_path.read_text(encoding="utf-8")))
            if edge_kappa.kb.bucket_edges_ms != tuple(buckets.edges_ms):
                raise ValueError("edge kappa bucket edges mismatch")
            edge_kappa.merge_historical(observations)
        else:
            # Upgrade a writable three-KB state from its committed raw training
            # observations, never from another backend's predictions.
            edge_training = [ClauseObservation(**dict(row, argv=tuple(row["argv"])))
                             for row in lattice_kb.to_json_obj()["observations"]]
            edge_kappa = EdgeKappaRuntime.fit(edge_training, buckets.edges_ms)
        predictor = cls(
            kb=kb,
            edge_kappa=edge_kappa,
            buckets=buckets,
            report=ToolResourceLoadReport(
                ebpf_traces_seen=len(ebpf_paths),
                ebpf_traces_loaded=ebpf_loaded,
                openclaw_traces_seen=len(openclaw_paths),
                openclaw_traces_accepted=openclaw_accepted,
                openclaw_tool_spans_seen=openclaw_spans_seen,
                observations_loaded=len(observations),
                continuous_observations_loaded=len(continuous_observations),
                kb_available=kb_has_public_evidence,
                continuous_kb_available=bool(continuous_observations),
                lattice_observations_loaded=lattice_kb.observation_count,
                lattice_kb_available=lattice_kb_available,
                rejections=tuple(rejections),
            ),
            repo=repo,
            artifact_dir=artifact_dir,
            container_executable=container_executable,
            clause_kb_snapshot_path=snapshot_path,
            runtime_kb_snapshot_path=runtime_snapshot_path,
            lattice_kb=lattice_kb,
            lattice_kb_snapshot_path=lattice_snapshot_path,
            ttl_by_bucket_s=ttl_by_bucket_s,
            miss_penalty_s=miss_penalty_s,
            numa_usage_sampler=numa_usage_sampler,
            load_buckets=load_buckets,
        )
        loaded_runtime_snapshot = _load_runtime_kb_snapshot(
            runtime_snapshot_path,
            rejections,
        )
        if loaded_runtime_snapshot is not None:
            predictor.continuous_kb = loaded_runtime_snapshot
        predictor.continuous_kb.merge_historical(continuous_observations)
        if observations or loaded_snapshot is not None:
            predictor._persist_clause_kb()
        if continuous_observations or loaded_runtime_snapshot is not None:
            predictor._persist_runtime_kb()
        if observations or loaded_lattice_snapshot is not None:
            predictor._persist_lattice_kb()
        if predictor.edge_kappa_snapshot_path is not None:
            _write_json_atomic(predictor.edge_kappa_snapshot_path, predictor.edge_kappa.to_snapshot())
        return predictor

    @classmethod
    def from_openclaw_traces(
        cls,
        trace_paths: Iterable[Path],
        *,
        buckets: LatencyBuckets,
        repo: str = "openclaw",
        ttl_by_bucket_s: tuple[float, ...] | None = None,
        miss_penalty_s: float | None = None,
        numa_usage_sampler: NumaCpuUsageSampler | None = None,
    ) -> "ToolResourcePredictor":
        return cls.from_traces(
            openclaw_trace_paths=trace_paths,
            ebpf_trace_paths=(),
            buckets=buckets,
            repo=repo,
            ttl_by_bucket_s=ttl_by_bucket_s,
            miss_penalty_s=miss_penalty_s,
            numa_usage_sampler=numa_usage_sampler,
        )

    def predict(
        self, request: ToolBeforeRequest,
    ) -> ToolPrediction:
        # All backends and diagnostics see one serialized causal transaction.
        # Legacy payload is migration-only; no policy consumes its clause data.
        with self._kb_lock:
            legacy = self._predict_legacy(request, )
            query = ToolCallQuery(repo=request.repo or self.repo, tool_name=request.tool_name,
                                  command=_command_for_request(request), ts_start=time.time(),
                                  memory_measurement=self.memory_measurement,
                                  )
            call, diagnostics = predict_call_load(runtime=self.continuous_kb, trie=self.kb,
                                                  lattice=self.lattice_kb, query=query, edges=self.load_buckets,
                                                  edge_kappa=self.edge_kappa, edge_call_id=call_key(request))
            if not self.frozen:
                self._edge_kappa_version += 1
                self._kb_writes.enqueue()
            from clawtune_sidecar.contracts.load_prediction import summarize_pmu_evidence
            try:
                pmu = summarize_pmu_evidence(self.continuous_kb.predict_pmu_samples(query))
            except Exception:
                pmu = summarize_pmu_evidence({})
            duration = call.targets["duration_ms"]
            p50 = None if duration.p50 is None else int(round(duration.p50))
            p90 = None if duration.p90 is None else int(round(duration.p90))
            payload = legacy.tool_resource
            if isinstance(payload, dict):
                # TTL must use the same authoritative duration distribution.
                payload["kv_ttl_cost"] = None
                if duration.buckets.probabilities is not None and duration.p90 is not None:
                    probabilities = duration.buckets.probabilities
                    bucket = max(range(len(probabilities)), key=probabilities.__getitem__)
                    derived = ClauseLatencyBucketPrediction(
                        bucket_id=bucket, probability_by_bucket=tuple(probabilities), scope="composed",
                        key_kind="compound_composed", evidence_count=min(duration.evidence_counts),
                        fallback_path=("call_load.v2",))
                    payload["kv_ttl_cost"] = self._kv_ttl_cost_payload(derived, reference_runtime_s=duration.p90 / 1000)
            return ToolPrediction(duration_p50_ms=p50, duration_p90_ms=p90,
                                  resource_class=_resource_class_for_duration_ms(p90), confidence=None,
                                  tool=call, trie=diagnostics.backends["trie"],
                                  lattice=diagnostics.backends["lattice"],
                                  edge_kappa=diagnostics.backends["edge_kappa"],
                                  call_prediction=call, pmu_prediction=pmu,
                                  diagnostics=diagnostics, tool_resource=payload)

    def _predict_legacy(
        self,
        request: ToolBeforeRequest,
    ) -> ToolPrediction:
        command = _command_for_request(request)
        repo = request.repo or self.repo
        # Host NUMA busyness is captured once per prediction, before any KB
        # work, so every output path reports the same snapshot.
        numa_usage = self._numa_usage_snapshot()
        try:
            clauses, parse_failed = clauses_from_tool_request(
                request.tool_name,
                request.raw_params,
            )
        except Exception as exc:
            # Timestamp acquisition and every KB read form one transaction.
            # Taking the timestamp only after the lock prevents an older
            # request from resuming behind a newer request and tripping the
            # monotonic causal guards.
            with self._kb_lock:
                query_ts = time.time()
                continuous_predictions = self._continuous_predictions_for_request(
                    request,
                    command,
                    query_ts,
                            )
                runtime_p50_ms, runtime_p90_ms = self._continuous_latency_topline_ms(
                    request,
                    command,
                    query_ts,
                )
                return ToolPrediction(
                    duration_p50_ms=runtime_p50_ms,
                    duration_p90_ms=runtime_p90_ms,
                    resource_class=_resource_class_for_duration_ms(runtime_p90_ms),
                    tool_resource=_tool_resource_prediction_payload(
                        _unavailable_prediction_for_request(
                            request,
                            repo=repo,
                            command=command,
                            reason=_prediction_error_reason(exc),
                        ),
                        continuous_predictions=continuous_predictions,
                        lattice_time_predictions=(),
                        kv_ttl_cost=None,
                        numa_usage=numa_usage,
                    ),
                )

        # The three causal KBs share one wall-clock ordering contract.  Keep
        # the full prediction transaction under the same re-entrant lock so
        # their monotonic watermarks cannot be interleaved by another request.
        with self._kb_lock:
            query_ts = time.time()
            lattice_time_predictions: tuple[ClauseLatticeTimePredictions, ...] = ()
            lattice_resource_predictions: tuple[dict[str, Any], ...] = ()
            try:
                if request.tool_name == "exec":
                    lattice_time_predictions = self._lattice_predictions_for_clauses(
                        clauses,
                        query_ts,
                        repo=repo,
                        parse_failed=parse_failed,
                        shell_command=True,
                    )
                if request.tool_name == "exec":
                    lattice_resource_predictions = self._lattice_resource_predictions_for_clauses(
                        repo, clauses, query_ts, parse_failed=parse_failed,
                    )
                prediction = self.kb.predict_command_latency_bucket_from_clauses(
                    repo,
                    clauses,
                    query_ts,
                    self.buckets,
                    command=command or request.tool_name,
                    parse_failed=parse_failed,
                    shell_command=request.tool_name == "exec",
                )
            except Exception as exc:
                continuous_predictions = self._continuous_predictions_for_request(
                    request,
                    command,
                    query_ts,
                            )
                runtime_p50_ms, runtime_p90_ms = self._continuous_latency_topline_ms(
                    request,
                    command,
                    query_ts,
                )
                return ToolPrediction(
                    duration_p50_ms=runtime_p50_ms,
                    duration_p90_ms=runtime_p90_ms,
                    resource_class=_resource_class_for_duration_ms(runtime_p90_ms),
                    tool_resource=_tool_resource_prediction_payload(
                        _unavailable_prediction_for_request(
                            request,
                            repo=repo,
                            command=command,
                            reason=_prediction_error_reason(exc),
                        ),
                        continuous_predictions=continuous_predictions,
                        lattice_time_predictions=lattice_time_predictions,
                        lattice_resource_predictions=lattice_resource_predictions,
                        kv_ttl_cost=None,
                        numa_usage=numa_usage,
                    ),
                )
            continuous_predictions = self._continuous_predictions_for_request(
                request,
                command,
                query_ts,
                    )
            if prediction.prediction is None:
                runtime_p50_ms, runtime_p90_ms = self._continuous_latency_topline_ms(
                    request,
                    command,
                    query_ts,
                )
                return ToolPrediction(
                    duration_p50_ms=runtime_p50_ms,
                    duration_p90_ms=runtime_p90_ms,
                    resource_class=_resource_class_for_duration_ms(runtime_p90_ms),
                    tool_resource=_tool_resource_prediction_payload(
                        prediction,
                        continuous_predictions=continuous_predictions,
                        lattice_time_predictions=lattice_time_predictions,
                        lattice_resource_predictions=lattice_resource_predictions,
                        kv_ttl_cost=None,
                        numa_usage=numa_usage,
                    ),
                )

            bucket_prediction = prediction.prediction
            runtime_p50_ms, runtime_p90_ms = self._continuous_latency_topline_ms(
                request,
                command,
                query_ts,
            )
            duration_p50_ms = _bucket_percentile_ms(
                bucket_prediction.probability_by_bucket,
                self.buckets,
                0.5,
            )
            duration_p90_ms = _bucket_percentile_ms(
                bucket_prediction.probability_by_bucket,
                self.buckets,
                0.9,
            )
            uses_continuous_duration = (
                runtime_p50_ms is not None or runtime_p90_ms is not None
            )
            return ToolPrediction(
                duration_p50_ms=(
                    runtime_p50_ms
                    if runtime_p50_ms is not None
                    else duration_p50_ms
                ),
                duration_p90_ms=(
                    runtime_p90_ms
                    if runtime_p90_ms is not None
                    else duration_p90_ms
                ),
                resource_class=(
                    _resource_class_for_duration_ms(runtime_p90_ms)
                    if runtime_p90_ms is not None
                    else _resource_class_for_bucket(bucket_prediction.bucket_id)
                ),
                confidence=(
                    None
                    if uses_continuous_duration or prediction.composed
                    else max(
                        bucket_prediction.probability_by_bucket,
                        default=0.0,
                    )
                ),
                tool_resource=_tool_resource_prediction_payload(
                    prediction,
                    continuous_predictions=continuous_predictions,
                    lattice_time_predictions=lattice_time_predictions,
                    lattice_resource_predictions=lattice_resource_predictions,
                    kv_ttl_cost=self._kv_ttl_cost_payload(
                        bucket_prediction,
                        reference_runtime_s=duration_p90_ms / 1000.0,
                    ),
                    numa_usage=numa_usage,
                ),
            )

    def _kv_ttl_cost_payload(
        self,
        bucket_prediction: ClauseLatencyBucketPrediction,
        *,
        reference_runtime_s: float,
    ) -> dict[str, Any] | None:
        """Prediction-time KV-TTL cost estimate against the predicted runtime.

        The reference runtime is the prediction's p90 duration, so this is a
        planning estimate.  The pure evaluator advances through right-open
        runtime buckets and applies each new bucket's absolute TTL.  The final
        open-ended bucket has its own policy entry.
        """

        if bucket_prediction.bucket_id >= len(self.ttl_by_bucket_s):
            return {
                "unavailable_reason": "initial_bucket_out_of_range",
                "initial_bucket_index": bucket_prediction.bucket_id,
            }
        try:
            evaluation = evaluate_bucket_ttl(
                actual_time_s=reference_runtime_s,
                initial_bucket_index=bucket_prediction.bucket_id,
                buckets=list(self.buckets_s),
                ttl_by_bucket=list(self.ttl_by_bucket_s),
            )
        except ValueError as exc:
            return {"unavailable_reason": f"evaluation_error:{type(exc).__name__}"}
        return {
            "reference_runtime_s": evaluation.actual_time_s,
            "initial_bucket_index": evaluation.initial_bucket_index,
            "final_bucket_index": evaluation.final_bucket_index,
            "num_bucket_jumps": evaluation.num_bucket_jumps,
            "bucket_exhausted": evaluation.bucket_exhausted,
            "ttl_s": evaluation.ttl_s,
            "kv_eviction_time_s": evaluation.kv_eviction_time_s,
            "kv_retention_time_s": evaluation.kv_retention_time_s,
            "kv_cache_miss": evaluation.kv_cache_miss,
            # Compatibility-only aggregate kept outside the reusable TTL
            # evaluator. Offline evaluation should report C_R and C_M directly.
            "proxy_cost_s": (
                None
                if self.miss_penalty_s is None
                else evaluation.kv_retention_time_s
                + self.miss_penalty_s * float(evaluation.kv_cache_miss)
            ),
            "buckets_s": list(self.buckets_s),
            "ttl_by_bucket_s": list(self.ttl_by_bucket_s),
            "miss_penalty_s": self.miss_penalty_s,
        }

    def record_tool_started(self, request: ToolBeforeRequest) -> None:
        with self._starts_lock:
            self._starts[correlation_key(request)] = request

    def observe_completion(
        self,
        event: ToolCompletedEvent,
        sample: ToolRuntimeSample,
    ) -> int:
        with self._starts_lock:
            start = self._starts.pop(correlation_key(event), None)
            if start is None and event.tool_call_id is not None:
                start = self._pop_start_by_tool_call_id(
                    event.tool_call_id,
                    event,
                )
        if self.frozen:
            return 0
        artifact: dict[str, Any] | None = None
        if event.execution_id:
            summary = self._telemetry_by_execution_id.get(event.execution_id)
            if summary is not None and summary.artifact_path:
                try:
                    artifact = _read_ebpf_artifact(Path(summary.artifact_path))
                except Exception:
                    artifact = None
        completed_call = completed_call_from_completion(
            event,
            sample,
            repo=event.repo or (start.repo if start is not None else None) or self.repo,
            start=start,
            workload_duration_seconds=_retained_workload_duration_seconds(artifact),
        )
        # Add only newly measured environment labels. Existing clause CPU/time
        # observations were already ingested at eBPF finish and are not repeated.
        if sample.environment_memory and event.execution_id and completed_call and not completed_call.censored:
            if artifact is not None:
                try:
                    from clawtune_sidecar.monitoring.environment_memory import clause_memory_labels
                    repo = event.repo or (start.repo if start else None) or self.repo
                    for call in artifact.get("calls", []):
                        if call.get("eligible_for_kb") is not True:
                            continue
                        clauses = call.get("clauses", [])
                        from tool_resource.features import enrich_input_sources
                        clauses = enrich_input_sources(call.get("command"), clauses)
                        labels = clause_memory_labels(sample.environment_memory, clauses)
                        for row, labels_for_clause in zip(clauses, labels):
                            if not labels_for_clause:
                                continue
                            observation = ClauseObservation(repo=repo, bin=row["bin"], argv=tuple(row["argv"]),
                                ts_start=row["ts_start"], ts_end=row["ts_end"],
                                in_pipe=row.get("in_pipe", False), pipeline_position=row.get("pipeline_position", -1),
                                in_loop=row.get("in_loop", False), in_subst=row.get("in_subst", False),
                                stdin_from_pipe=row.get("stdin_from_pipe"),
                                **labels_for_clause)
                            with self._kb_lock:
                                self.kb.observe_completed_clause(observation)
                                self._clause_kb_version += 1
                            sample.environment_memory.setdefault("memory_clause_observations", []).append(asdict(observation))
                            self._kb_writes.enqueue((observation,))
                except Exception:
                    # Auxiliary learning cannot change the tool outcome.
                    import logging
                    logging.getLogger(__name__).exception("environment memory clause update failed")
        try:
            try:
                edge_observations = _ebpf_observations(artifact, fallback_repo=self.repo) if artifact is not None else []
            except ValueError:
                # Memory-only/invalid clause rows are not trusted duration labels.
                edge_observations = []
            with self._kb_lock:
                try:
                    self.edge_kappa.complete_call(call_key(start or event), edge_observations, commit_time=time.time())
                finally:
                    # A failed batch may still have accepted earlier clauses.
                    self._edge_kappa_version += 1
        except Exception:
            import logging
            logging.getLogger(__name__).exception("edge kappa clause update failed")
        self._kb_writes.enqueue()
        if completed_call is not None:
            with self._kb_lock:
                self.continuous_kb.observe_completed_call(completed_call)
                self._runtime_kb_version += 1
            if self.runtime_kb_snapshot_path is not None:
                self._kb_writes.enqueue()
        return 1 if completed_call is not None else 0

    def begin_execution(
        self,
        *,
        execution_id: str,
        tool_call_id: str | None,
        command: str,
        container_id: str | None,
        repo: str | None = None,
        gateway_id: str | None = None,
        runtime_id: str | None = None,
        cgroup_path: str | None = None,
        trusted_root_pid: int | None = None,
    ) -> bool:
        reused = self._reuse_active_execution(
            execution_id,
            gateway_id=gateway_id,
            runtime_id=runtime_id,
            trusted_root_pid=trusted_root_pid,
        )
        if reused is not None:
            return reused
        previous = self._telemetry_by_execution_id.get(execution_id)
        if previous is not None and previous.started:
            return previous.status != "unavailable"
        host_scope_available = bool(cgroup_path and trusted_root_pid is not None)
        if self.artifact_dir is None or (not container_id and not host_scope_available):
            reason = (
                "artifact_dir_unconfigured"
                if self.artifact_dir is None
                else "execution_scope_unavailable"
            )
            self._telemetry_by_execution_id[execution_id] = ExecutionTelemetrySummary(
                execution_id=execution_id,
                tool_call_id=tool_call_id,
                artifact_path=None,
                started=False,
                status="unavailable",
                unavailable_reason=reason,
            )
            self._trim_execution_telemetry()
            return False
        artifact_path = self.artifact_dir / f"{_safe_artifact_name(execution_id)}.json"
        context = DockerExecutionContext(
            container_id=container_id,
            container_executable=self.container_executable,
            repo=repo or self.repo,
            artifact_path=artifact_path,
            cgroup_path=cgroup_path,
            trusted_root_pid=trusted_root_pid,
        )
        with self._execution_start_lock:
            reused = self._reuse_active_execution(
                execution_id,
                gateway_id=gateway_id,
                runtime_id=runtime_id,
                trusted_root_pid=trusted_root_pid,
            )
            if reused is not None:
                return reused
            try:
                run = self._sdk.start_command(
                    context,
                    tool_call_id or execution_id,
                    command,
                )
            except Exception as exc:
                self._telemetry_by_execution_id[
                    execution_id
                ] = ExecutionTelemetrySummary(
                    execution_id=execution_id,
                    tool_call_id=tool_call_id,
                    artifact_path=str(artifact_path),
                    started=False,
                    status="unavailable",
                    unavailable_reason=f"start_failed:{type(exc).__name__}: {exc}",
                )
                self._trim_execution_telemetry()
                return False
            observer = getattr(run, "_observer", None)
            telemetry_available = bool(
                getattr(observer, "telemetry_available", True)
            )
            unavailable_reason = (
                getattr(observer, "unavailable_reason", None)
                if not telemetry_available
                else None
            )
            with self._execution_lock:
                self._runs_by_execution_id[execution_id] = run
                self._execution_owners[execution_id] = (gateway_id, runtime_id)
        self._telemetry_by_execution_id[execution_id] = ExecutionTelemetrySummary(
            execution_id=execution_id,
            tool_call_id=tool_call_id,
            artifact_path=str(artifact_path),
            started=True,
            status="started" if telemetry_available else "unavailable",
            unavailable_reason=unavailable_reason,
        )
        self._trim_execution_telemetry()
        return telemetry_available

    def _reuse_active_execution(
        self,
        execution_id: str,
        *,
        gateway_id: str | None,
        runtime_id: str | None,
        trusted_root_pid: int | None,
    ) -> bool | None:
        with self._execution_lock:
            existing = self._runs_by_execution_id.get(execution_id)
            existing_owner = self._execution_owners.get(execution_id)
            if existing is None:
                return None
            if existing_owner is not None and not _execution_owners_compatible(
                existing_owner,
                (gateway_id, runtime_id),
            ):
                raise ValueError("active execution owner changed")
            observer = getattr(existing, "_observer", None)
            if trusted_root_pid is not None:
                bind_root = getattr(observer, "bind_trusted_root", None)
                if callable(bind_root):
                    bind_root(trusted_root_pid)
            if existing_owner is not None:
                self._execution_owners[execution_id] = (
                    existing_owner[0] or gateway_id,
                    existing_owner[1] or runtime_id,
                )
            return bool(getattr(observer, "telemetry_available", True))

    def finish_execution(
        self,
        *,
        execution_id: str,
        exit_code: int | None,
        signal: int | None,
        raw_result: Any | None = None,
        succeeded: bool | None = None,
        incomplete_reason: str | None = None,
    ) -> ExecutionTelemetrySummary:
        if incomplete_reason is not None and (
            exit_code is not None or signal is not None
        ):
            raise ValueError(
                "incomplete eBPF finalization cannot carry launcher exit status"
            )
        with self._execution_lock:
            run = self._runs_by_execution_id.pop(execution_id, None)
            self._execution_owners.pop(execution_id, None)
        if run is None:
            return self._telemetry_by_execution_id.get(
                execution_id,
                ExecutionTelemetrySummary(
                    execution_id=execution_id,
                    tool_call_id=None,
                    artifact_path=None,
                    started=False,
                    status="unavailable",
                    unavailable_reason="no_active_ebpf_run",
                ),
            )
        replay_execution = (
            "incomplete"
            if incomplete_reason is not None
            else ("completed" if exit_code == 0 and signal is None else "failed")
        )
        workload_result = _ebpf_workload_result(
            raw_result,
            exit_code=exit_code,
            signal=signal,
            # A terminal OpenClaw hook is not an authoritative process exit.
            # Do not copy its optimistic success bit into an orphaned run.
            succeeded=None if incomplete_reason is not None else succeeded,
        )
        try:
            result = self._sdk.finish_command(
                run,
                workload_result,
                replay_execution=replay_execution,
            )
        except Exception as exc:
            finish_error = f"finish_failed:{type(exc).__name__}: {exc}"
            summary = ExecutionTelemetrySummary(
                execution_id=execution_id,
                tool_call_id=run.tool_call_id,
                artifact_path=str(run._observer.context.artifact_path),
                started=True,
                status="unavailable",
                unavailable_reason=incomplete_reason or finish_error,
                kb_update_error=(
                    finish_error if incomplete_reason is not None else None
                ),
            )
            self._telemetry_by_execution_id[execution_id] = summary
            self._trim_execution_telemetry()
            return summary
        # The SDK deliberately withholds incomplete executions from learning.
        # Its validation rejection is expected here, provided collector cleanup
        # succeeded; genuine finalization/persistence errors must remain visible.
        expected_incomplete_rejection = (
            incomplete_reason is not None
            and result.kb_update_error == (
                f"ValueError: {run._observer.context.artifact_path}: replay execution is incomplete"
            )
            and isinstance(result.telemetry_artifact, dict)
            and result.telemetry_artifact.get("replay_execution") == "incomplete"
            and result.telemetry_artifact.get("cleanup") == "ok"
        )
        kb_update_errors = (
            [result.kb_update_error]
            if result.kb_update_error is not None and not expected_incomplete_rejection
            and not (
                isinstance(result.telemetry_artifact, dict)
                and result.telemetry_artifact.get("cleanup") == "ok"
                and result.kb_update_error == (
                    f"ValueError: {run._observer.context.artifact_path}: artifact telemetry quality is "
                    f"{result.telemetry_artifact.get('telemetry_quality')!r}; not eligible for KB"
                )
            ) else []
        )
        accepted_observations: list[ClauseObservation] = []
        if result.kb_observations_added and not self.frozen:
            with self._kb_lock:
                for observation in result.kb_observations:
                    try:
                        accepted = self.kb.observe_completed_clause(observation)
                    except Exception as exc:
                        kb_update_errors.append(
                            "clause_kb_update_failed:"
                            f"{type(exc).__name__}: {exc}"
                        )
                        continue
                    if not accepted:
                        continue
                    accepted_observations.append(observation)
                    self._clause_kb_version += 1
            if accepted_observations:
                self._kb_writes.enqueue(accepted_observations)
        kb_update_error = "; ".join(kb_update_errors) or None
        call_telemetry = (
            dict(result.call_telemetry)
            if isinstance(result.call_telemetry, dict)
            else None
        )
        summary = ExecutionTelemetrySummary(
            execution_id=execution_id,
            tool_call_id=run.tool_call_id,
            artifact_path=str(run._observer.context.artifact_path),
            started=True,
            status=(
                "unavailable"
                if incomplete_reason is not None
                else _ebpf_status(
                    result.telemetry_artifact,
                    call_telemetry,
                    kb_update_error,
                )
            ),
            unavailable_reason=(
                incomplete_reason
                if incomplete_reason is not None
                else _ebpf_unavailable_reason(
                    result.telemetry_artifact,
                    call_telemetry,
                    kb_update_error,
                )
            ),
            kb_observations_added=len(accepted_observations),
            kb_update_error=kb_update_error,
            call_telemetry=_compact_call_telemetry(call_telemetry),
            artifact_summary=_compact_artifact_summary(result.telemetry_artifact),
        )
        self._telemetry_by_execution_id[execution_id] = summary
        self._trim_execution_telemetry()
        return summary

    def execution_telemetry(self, execution_id: str) -> ExecutionTelemetrySummary | None:
        return self._telemetry_by_execution_id.get(execution_id)

    def execution_active(self, execution_id: str) -> bool:
        """Return whether this execution still owns an unfinished SDK run."""

        with self._execution_lock:
            return execution_id in self._runs_by_execution_id

    def active_execution_ids(
        self,
        runtime_id: str,
        gateway_id: str | None = None,
    ) -> tuple[str, ...]:
        """Return active collectors owned by one runtime, including orphans."""

        with self._execution_lock:
            return tuple(
                sorted(
                    execution_id
                    for execution_id in self._runs_by_execution_id
                    if _execution_owner_matches_runtime(
                        self._execution_owners.get(execution_id),
                        runtime_id=runtime_id,
                        gateway_id=gateway_id,
                    )
                )
            )

    def _trim_execution_telemetry(self) -> None:
        while len(self._telemetry_by_execution_id) > 10_000:
            oldest = next(iter(self._telemetry_by_execution_id))
            self._telemetry_by_execution_id.pop(oldest, None)

    def flush_kb_updates(self, timeout_seconds: float | None = None) -> None:
        """Wait until every previously queued shared-KB update is durable.

        The sidecar drain endpoint should run this blocking barrier in a worker
        thread.  A raised error means at least one in-memory generation is
        still newer than its snapshot and the runtime must not be declared
        drained yet.
        """

        self._kb_writes.flush(timeout_seconds)

    def close(self) -> None:
        """Make queued KB generations durable before sidecar shutdown."""

        try:
            self.flush_kb_updates(timeout_seconds=30.0)
        finally:
            store = getattr(self, "_state_store", None)
            if store is not None:
                store.__exit__(None, None, None)
                self._state_store = None

    def kb_updates_pending(self) -> bool:
        """Return whether the single writer has queued or in-flight work."""

        return self._kb_writes.pending()

    def _flush_kb_batch(
        self,
        lattice_observations: tuple[ClauseObservation, ...],
    ) -> None:
        if self.frozen:
            return
        errors: list[str] = []
        snapshots: list[tuple[str, Path, dict[str, Any], int]] = []

        with self._kb_lock:
            candidate = self._lattice_staged
            if candidate is None and lattice_observations:
                candidate = self.lattice_kb.fork_for_update()
        if candidate is not None:
            for observation in lattice_observations:
                try:
                    accepted = candidate.observe_completed_clause(observation)
                except Exception as exc:
                    errors.append(
                        "lattice_kb_update_failed:"
                        f"{type(exc).__name__}: {exc}"
                    )
                    continue
                if accepted:
                    self._lattice_kb_version += 1
            # The coordinator is a single writer. Readers continue to use the
            # previous prepared generation while this potentially slow build runs.
            self._lattice_staged = candidate
            self._lattice_needs_prepare = True
            try:
                candidate.prepare()
            except Exception as exc:
                errors.append(f"lattice_prepare_failed:{type(exc).__name__}: {exc}")
            else:
                with self._kb_lock:
                    self.lattice_kb = candidate
                    self._lattice_staged = None
                    self._lattice_needs_prepare = False

        with self._kb_lock:
            self._capture_kb_snapshot_locked(
                snapshots, errors, name="edge_kappa", path=self.edge_kappa_snapshot_path,
                version=self._edge_kappa_version, persisted_version=self._edge_kappa_persisted_version,
                serializer=self.edge_kappa.to_snapshot,
            )
            self._capture_kb_snapshot_locked(
                snapshots,
                errors,
                name="runtime",
                path=self.runtime_kb_snapshot_path,
                version=self._runtime_kb_version,
                persisted_version=self._runtime_kb_persisted_version,
                serializer=self.continuous_kb.to_json_obj,
            )
            self._capture_kb_snapshot_locked(
                snapshots,
                errors,
                name="clause",
                path=self.clause_kb_snapshot_path,
                version=self._clause_kb_version,
                persisted_version=self._clause_kb_persisted_version,
                serializer=self.kb.to_json_obj,
            )
            if not self._lattice_needs_prepare:
                self._capture_kb_snapshot_locked(
                    snapshots,
                    errors,
                    name="lattice",
                    path=self.lattice_kb_snapshot_path,
                    version=self._lattice_kb_version,
                    persisted_version=self._lattice_kb_persisted_version,
                    serializer=self.lattice_kb.to_json_obj,
                )

        for name, path, payload, version in snapshots:
            try:
                _write_json_atomic(path, payload)
            except Exception as exc:
                errors.append(
                    f"{name}_kb_persist_failed:{type(exc).__name__}: {exc}"
                )
                continue
            with self._kb_lock:
                if name == "edge_kappa":
                    self._edge_kappa_persisted_version = max(self._edge_kappa_persisted_version, version)
                elif name == "runtime":
                    self._runtime_kb_persisted_version = max(
                        self._runtime_kb_persisted_version,
                        version,
                    )
                elif name == "clause":
                    self._clause_kb_persisted_version = max(
                        self._clause_kb_persisted_version,
                        version,
                    )
                else:
                    self._lattice_kb_persisted_version = max(
                        self._lattice_kb_persisted_version,
                        version,
                    )

        if errors:
            raise KnowledgeBaseFlushError("; ".join(errors))

        store = getattr(self, "_state_store", None)
        if store is not None:
            store.checkpoint()

    def _capture_kb_snapshot_locked(
        self,
        snapshots: list[tuple[str, Path, dict[str, Any], int]],
        errors: list[str],
        *,
        name: str,
        path: Path | None,
        version: int,
        persisted_version: int,
        serializer: Callable[[], dict[str, Any]],
    ) -> None:
        if path is None or version <= persisted_version:
            return
        try:
            payload = serializer()
        except Exception as exc:
            errors.append(
                f"{name}_kb_snapshot_failed:{type(exc).__name__}: {exc}"
            )
            return
        snapshots.append((name, path, payload, version))

    def _persist_clause_kb(self) -> bool:
        if self.clause_kb_snapshot_path is None:
            return False
        try:
            _write_json_atomic(self.clause_kb_snapshot_path, self.kb.to_json_obj())
            return True
        except Exception:
            return False

    def _persist_runtime_kb(self) -> bool:
        if self.runtime_kb_snapshot_path is None:
            return False
        try:
            _write_json_atomic(self.runtime_kb_snapshot_path, self.continuous_kb.to_json_obj())
            return True
        except Exception:
            return False

    def _persist_lattice_kb(self) -> bool:
        if self.lattice_kb_snapshot_path is None:
            return False
        try:
            _write_json_atomic(
                self.lattice_kb_snapshot_path,
                self.lattice_kb.to_json_obj(),
            )
            return True
        except Exception:
            return False

    def _lattice_resource_predictions_for_clauses(
        self, repo: str, clauses: Sequence[Mapping[str, Any]], query_ts: float,
        *, parse_failed: bool,
    ) -> tuple[dict[str, Any], ...]:
        try:
            return self.lattice_kb.predict_resource_clauses(
                repo, clauses, query_ts, parse_failed=parse_failed,
            )
        except Exception as exc:
            outcomes = LatticeTimeKB().predict_resource_clauses(
                repo, clauses, query_ts, parse_failed=True,
            )
            for clause in outcomes:
                for prediction in clause["predictions"]:
                    prediction["unavailable_reason"] = f"lattice_resource_error:{type(exc).__name__}"
            return outcomes

    def _lattice_predictions_for_clauses(
        self,
        clauses: Sequence[Mapping[str, Any]],
        query_ts: float,
        *,
        repo: str,
        parse_failed: bool,
        shell_command: bool,
    ) -> tuple[ClauseLatticeTimePredictions, ...]:
        try:
            with self._kb_lock:
                return self.lattice_kb.predict_clauses(
                    repo,
                    clauses,
                    query_ts,
                    parse_failed=parse_failed,
                    shell_command=shell_command,
                )
        except Exception as exc:
            return _unavailable_lattice_time_predictions(
                clauses,
                reason=f"lattice_prediction_error:{type(exc).__name__}",
                shell_command=shell_command,
            )

    def _continuous_predictions_for_request(
        self,
        request: ToolBeforeRequest,
        command: str | None,
        ts_start: float,
    ) -> dict[str, Any]:
        repo = request.repo or self.repo
        query = ToolCallQuery(
            repo=repo,
            tool_name=request.tool_name,
            command=command,
            ts_start=ts_start,
            memory_measurement=self.memory_measurement,
        )
        with self._kb_lock:
            return self._continuous_predictions_for_query(query)

    def _continuous_predictions_for_query(
        self,
        query: ToolCallQuery,
    ) -> dict[str, Any]:
        predictions: dict[str, Any] = {}
        try:
            self.continuous_kb._advance(query.ts_start)  # type: ignore[attr-defined]
        except AttributeError:
            # Historical RuntimeToolResourceKB exposes absorption through query().
            try:
                self.continuous_kb.query(query)
            except Exception:
                pass
        except Exception:
            pass
        for target in ("latency_ms", "cpu_peak_cores", "memory_total_peak_bytes", "memory_extra_peak_bytes"):
            try:
                prediction = self.continuous_kb._predict_target(query, target)  # type: ignore[attr-defined]
            except Exception as exc:
                predictions[target] = {
                    "target": target,
                    "conditional_p90": None,
                    "scope": None,
                    "key_kind": None,
                    "evidence_count": 0,
                    "fallback_path": [],
                    "note": _continuous_unavailable_note(target, exc),
                }
                continue
            predictions[target] = _target_prediction_payload(prediction)
        return predictions

    def _continuous_latency_topline_ms(
        self,
        request: ToolBeforeRequest,
        command: str | None,
        ts_start: float,
    ) -> tuple[int | None, int | None]:
        repo = request.repo or self.repo
        query = ToolCallQuery(
            repo=repo,
            tool_name=request.tool_name,
            command=command,
            ts_start=ts_start,
        )
        with self._kb_lock:
            return self._continuous_latency_for_query(query)

    def _continuous_latency_for_query(
        self,
        query: ToolCallQuery,
    ) -> tuple[int | None, int | None]:
        try:
            self.continuous_kb._advance(query.ts_start)  # type: ignore[attr-defined]
        except AttributeError:
            try:
                self.continuous_kb.query(query)
            except Exception:
                pass
        except Exception:
            pass
        try:
            values, _scope, _kind, _path = self.continuous_kb._select(  # type: ignore[attr-defined]
                query.repo,
                "latency_ms",
                query.tool_name,
                query.command,
            )
        except Exception:
            return None, None
        if not values:
            return None, None
        return (
            max(0, int(round(ecdf_quantile(values, 0.5)))),
            max(0, int(round(ecdf_quantile(values, 0.9)))),
        )

    def _numa_usage_snapshot(self) -> dict[str, Any] | None:
        """Best-effort per-NUMA-node CPU usage snapshot for this prediction.

        Returns ``None`` when no sampler is configured so existing deployments
        and tests see no new payload key.  A sampler failure degrades to
        ``None`` rather than failing the prediction.
        """
        if self.numa_usage_sampler is None:
            return None
        try:
            return self.numa_usage_sampler.sample()
        except Exception:
            return None

    def _pop_start_by_tool_call_id(
        self,
        tool_call_id: str,
        completion: ToolCompletedEvent,
    ) -> ToolBeforeRequest | None:
        matches = [
            (key, request)
            for key, request in self._starts.items()
            if request.tool_call_id == tool_call_id
            and owners_compatible(request, completion)
        ]
        if len(matches) != 1:
            return None
        key, request = matches[0]
        self._starts.pop(key, None)
        return request


@dataclass(frozen=True)
class _LoadedTrace:
    tool_spans_seen: int
    observations: tuple[ClauseObservation, ...]
    completed_calls: tuple[CompletedCall, ...]


def load_openclaw_trace_observations(path: Path, *, repo: str) -> _LoadedTrace:
    if not path.is_file():
        raise ValueError("trace path is not a file")
    starts: dict[str, dict[str, Any]] = {}
    observations: list[ClauseObservation] = []
    completed_calls: list[CompletedCall] = []
    tool_spans_seen = 0
    with path.open(encoding="utf-8-sig") as fh:
        for line_no, line in enumerate(fh, start=1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"line {line_no}: invalid JSON: {exc}") from exc
            if not isinstance(record, dict) or record.get("kind") != "tool":
                continue
            span_id = record.get("span_id")
            if not isinstance(span_id, str) or not span_id:
                continue
            if record.get("record_type") == "span_start":
                starts[span_id] = record
                continue
            if record.get("record_type") != "span_end":
                continue
            tool_spans_seen += 1
            start = starts.get(span_id)
            span_repo = _repo_from_tool_span(
                start,
                record,
                fallback_repo=repo,
                span_id=span_id,
                line_no=line_no,
            )
            completed_call = _completed_call_from_tool_span(
                start,
                record,
                repo=span_repo,
            )
            if completed_call is not None:
                completed_calls.append(completed_call)
                if not completed_call.censored:
                    resources = record.get("resources") or {}
                    from clawtune_sidecar.monitoring.environment_memory import memory_labels
                    for row in resources.get("memory_clause_observations", []):
                        if not isinstance(row, dict) or row.get("repo") != span_repo or not memory_labels(row):
                            continue
                        values = dict(row)
                        values["argv"] = tuple(values["argv"])
                        observations.append(ClauseObservation(**values))
    return _LoadedTrace(tool_spans_seen, tuple(observations), tuple(completed_calls))


def _repo_from_tool_span(
    start: dict[str, Any] | None,
    end: dict[str, Any],
    *,
    fallback_repo: str,
    span_id: str,
    line_no: int,
) -> str:
    """Resolve one span's repo without silently merging tenant histories."""

    explicit: list[tuple[str, str]] = []
    for record_type, record in (("span_start", start), ("span_end", end)):
        if record is None or "repo" not in record or record["repo"] is None:
            continue
        value = record["repo"]
        if not isinstance(value, str) or not value:
            raise ValueError(
                f"line {line_no}: tool span {span_id!r} has invalid "
                f"{record_type} repo"
            )
        explicit.append((record_type, value))

    if len(explicit) == 2 and explicit[0][1] != explicit[1][1]:
        raise ValueError(
            f"line {line_no}: tool span {span_id!r} repo mismatch: "
            f"span_start={explicit[0][1]!r}, span_end={explicit[1][1]!r}"
        )
    return explicit[0][1] if explicit else fallback_repo


def observation_from_completion(
    event: ToolCompletedEvent,
    sample: ToolRuntimeSample,
    *,
    repo: str,
    start: ToolBeforeRequest | None = None,
) -> ClauseObservation | None:
    if not event.succeeded:
        return None
    raw_params = start.raw_params if start is not None else _raw_params_from_result(event.raw_event, event.raw_result)
    clauses, parse_failed = clauses_from_tool_request(event.tool_name, raw_params)
    if parse_failed or len(clauses) != 1:
        return None
    clause = clauses[0]
    ts_start = sample.started_at
    ts_end = sample.ended_at
    if ts_end < ts_start:
        ts_end = ts_start
    exclude_resource_labels = _sample_attribution_ineligible(sample, event, start)
    cpu_time_eligible = _sample_metric_eligible(sample, "cpu_time")
    cpu_peak_eligible = _sample_metric_eligible(sample, "cpu_peak")
    memory_peak_eligible = _sample_metric_eligible(sample, "memory_peak")
    return ClauseObservation(
        repo=repo,
        bin=str(clause["bin"]),
        argv=tuple(str(item) for item in clause["argv"]),
        ts_start=ts_start,
        ts_end=ts_end,
        latency_ms=max(0.0, float(event.duration_ms)),
        cpu_peak_cores=(sample.cpu_peak_cores if cpu_peak_eligible and not exclude_resource_labels else None),
        sampled_peak_rss_mb=(
            sample.rss_bytes_peak / 1_000_000.0
            if memory_peak_eligible and not exclude_resource_labels and sample.rss_bytes_peak is not None
            else None
        ),
        cpu_ns_cumulative=(
            None if exclude_resource_labels or not cpu_time_eligible else _cpu_ns(sample.cpu_time_delta_s)
        ),
        in_loop=False,
        in_pipe=False,
        in_subst=False,
        pipeline_position=-1,
    )


def _retained_workload_duration_seconds(
    artifact: Mapping[str, Any] | None,
) -> float | None:
    """Return the interval union for clauses retained by the prediction model."""
    if not artifact:
        return None
    intervals: list[tuple[float, float]] = []
    for call in artifact.get("calls", []):
        if not isinstance(call, Mapping) or call.get("eligible_for_kb") is not True:
            continue
        clauses = call.get("clauses")
        if not isinstance(clauses, list):
            continue
        # Consumer admission uses recorded pipe position, not inferred stdin.
        # Keep this shared label path independent of shell parser availability.
        for clause in clauses:
            if not isinstance(clause, Mapping) or is_pipeline_dependent_consumer(clause):
                continue
            start, end = clause.get("ts_start"), clause.get("ts_end")
            if (
                isinstance(start, (int, float))
                and not isinstance(start, bool)
                and isinstance(end, (int, float))
                and not isinstance(end, bool)
                and math.isfinite(float(start))
                and math.isfinite(float(end))
                and end > start
            ):
                intervals.append((float(start), float(end)))
    if not intervals:
        return None
    intervals.sort()
    total = 0.0
    current_start, current_end = intervals[0]
    for start, end in intervals[1:]:
        if start <= current_end:
            current_end = max(current_end, end)
        else:
            total += current_end - current_start
            current_start, current_end = start, end
    return total + current_end - current_start


def completed_call_from_completion(
    event: ToolCompletedEvent,
    sample: ToolRuntimeSample,
    *,
    repo: str,
    start: ToolBeforeRequest | None = None,
    workload_duration_seconds: float | None = None,
) -> CompletedCall | None:
    raw_params = start.raw_params if start is not None else _raw_params_from_result(event.raw_event, event.raw_result)
    command = extract_command(raw_params)
    ts_start = sample.started_at
    ts_end = sample.ended_at
    if ts_end < ts_start:
        ts_end = ts_start
    if workload_duration_seconds is None and event.execution_id is None:
        workload_duration_seconds = _observation_window_seconds(sample.resource_observation)
    exclude_resource_labels = _sample_attribution_ineligible(sample, event, start)
    cpu_time_eligible = _sample_metric_eligible(sample, "cpu_time")
    cpu_peak_eligible = _sample_metric_eligible(sample, "cpu_peak")
    memory_peak_eligible = _sample_metric_eligible(sample, "memory_peak")
    pmu = _quality_gated_pmu_metrics(sample.pmu_profile if event.execution_id else None,
                                   execution_id=event.execution_id)
    return CompletedCall(
        repo=repo,
        tool_name=event.tool_name,
        command=command,
        ts_start=ts_start,
        ts_end=ts_end,
        workload_duration_seconds=workload_duration_seconds,
        workload_duration_required=event.execution_id is not None,
        censored=_truncated_outcome(event.error_type),
        outcome="ok" if event.succeeded else "error",
        # A monitor average is not a fixed-window peak. Only explicitly measured
        # peak labels may populate either peak target.
        cpu_peak_cores=sample.cpu_peak_cores,
        cpu_peak_cores_eligible=(not exclude_resource_labels and cpu_peak_eligible
                                 and sample.cpu_peak_cores is not None),
        cpu_peak_window_ms=500,
        sampled_peak_rss_bytes=sample.rss_bytes_peak,
        sampled_peak_rss_eligible=(not exclude_resource_labels and memory_peak_eligible
                                   and sample.rss_bytes_peak is not None),
        **{k: v for k, v in (sample.environment_memory or {}).items()
           if k in {"memory_baseline_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes",
                    "memory_measurement", "memory_environment_id", "memory_eligible"}},
        cpu_time_seconds=sample.cpu_time_delta_s,
        cpu_time_eligible=(not exclude_resource_labels and cpu_time_eligible
                           and sample.cpu_time_delta_s is not None),
        pmu_cycles=pmu.get("cycles"),
        pmu_instructions=pmu.get("instructions"),
        pmu_llc_read_accesses=pmu.get("llc_read_accesses"),
        pmu_llc_read_misses=pmu.get("llc_read_misses"),
        pmu_llc_read_accesses_per_cpu_second=pmu.get("llc_read_accesses_per_cpu_second"),
        pmu_llc_read_misses_per_cpu_second=pmu.get("llc_read_misses_per_cpu_second"),
        pmu_ipc=pmu["ipc"],
        pmu_llc_mpki=pmu["llc_mpki"],
        pmu_llc_miss_rate=pmu["llc_miss_rate"],
        pmu_eligible=pmu["eligible"],
    )


def clauses_from_tool_request(tool_name: str, raw_params: Any) -> tuple[tuple[dict[str, Any], ...], bool]:
    command = extract_command(raw_params)
    if tool_name in {"exec", "terminal_exec"} and command:
        return _clauses_from_command(command)
    if not tool_name:
        return (), False
    argv = [tool_name]
    if isinstance(raw_params, dict):
        hint = raw_params.get("path") or raw_params.get("operation") or raw_params.get("cmd")
        if isinstance(hint, str) and hint:
            argv.append(Path(hint).name if "/" in hint or "\\" in hint else hint)
    return ({"bin": tool_name, "argv": argv},), False


def _observation_from_tool_span(
    start: dict[str, Any] | None,
    end: dict[str, Any],
    *,
    repo: str,
) -> ClauseObservation | None:
    status = end.get("status") if isinstance(end.get("status"), dict) else {}
    if status.get("code") not in {"ok", "unknown"}:
        return None
    tool_name = end.get("name")
    if not isinstance(tool_name, str) or not tool_name:
        return None
    raw_params = _raw_params_from_start(start)
    clauses, parse_failed = clauses_from_tool_request(tool_name, raw_params)
    if parse_failed or len(clauses) != 1:
        return None
    clause = clauses[0]
    duration_ms = _duration_ms(end)
    if duration_ms is None or duration_ms <= 0:
        return None
    ts_start, ts_end = _span_times(end, duration_ms)
    resources = end.get("resources") if isinstance(end.get("resources"), dict) else {}
    execution = end.get("execution") if isinstance(end.get("execution"), dict) else {}
    observation = resources.get("resource_observation")
    observation = observation if isinstance(observation, Mapping) else None
    exclude_resource_labels = _trace_attribution_ineligible(resources, execution, observation)
    observed_memory = _resource_metric(observation, "memory_peak")
    return ClauseObservation(
        repo=repo,
        bin=str(clause["bin"]),
        argv=tuple(str(item) for item in clause["argv"]),
        ts_start=ts_start,
        ts_end=ts_end,
        latency_ms=duration_ms,
        cpu_peak_cores=(
            _optional_float(resources.get("cpu_peak_cores"))
            if _trace_metric_eligible(resources, "cpu_peak") and not exclude_resource_labels
            else None
        ),
        sampled_peak_rss_mb=(
            float(observed_memory["value_bytes"]) / 1_000_000.0
            if observed_memory.get("eligible") is True
            and not exclude_resource_labels
            and isinstance(observed_memory.get("value_bytes"), (int, float))
            else None
        ),
        cpu_ns_cumulative=(
            None
            if exclude_resource_labels or not (
                _trace_metric_eligible(resources, "cpu_time")
                if observation is not None
                else _trace_cpu_window_aligned(resources, ts_start, ts_end)
            )
            else _cpu_ns(resources.get("cpu_time_s"))
        ),
        in_loop=False,
        in_pipe=False,
        in_subst=False,
        pipeline_position=-1,
    )


def _truncated_outcome(value: Any) -> bool:
    text = str(value or "").lower()
    return any(marker in text for marker in ("timeout", "timed out", "cancel", "abort", "interrupt", "killed"))


def _observation_window_seconds(observation: Mapping[str, Any] | None) -> float | None:
    window = observation.get("window") if isinstance(observation, Mapping) else None
    if not isinstance(window, Mapping) or window.get("action_clock_unusable") is True:
        return None
    try:
        start, end = int(window["requested_start_ns"]), int(window["requested_end_ns"])
    except (KeyError, TypeError, ValueError, OverflowError):
        return None
    return (end - start) / 1e9 if end > start else None


def _completed_call_from_tool_span(
    start: dict[str, Any] | None,
    end: dict[str, Any],
    *,
    repo: str,
) -> CompletedCall | None:
    status = end.get("status") if isinstance(end.get("status"), dict) else {}
    if status.get("code") not in {"ok", "unknown", "error"}:
        return None
    tool_name = end.get("name")
    if not isinstance(tool_name, str) or not tool_name:
        return None
    duration_ms = _duration_ms(end)
    if duration_ms is None or duration_ms < 0:
        return None
    ts_start, ts_end = _span_times(end, duration_ms)
    raw_params = _raw_params_from_start(start)
    command = extract_command(raw_params)
    resources = end.get("resources") if isinstance(end.get("resources"), dict) else {}
    peak_cpu_cores = _optional_float(resources.get("cpu_peak_cores"))
    execution = end.get("execution") if isinstance(end.get("execution"), dict) else {}
    observation = resources.get("resource_observation")
    observation = observation if isinstance(observation, Mapping) else None
    exclude_resource_labels = _trace_attribution_ineligible(resources, execution, observation)
    observed_memory = _resource_metric(observation, "memory_peak")
    pmu = _quality_gated_pmu_metrics(resources.get("pmu") if execution.get("execution_id") else None,
                                   execution_id=execution.get("execution_id"))
    workload_required = execution.get("execution_id") is not None
    telemetry = execution.get("tool_resource") or {}
    call_telemetry = telemetry.get("call_telemetry") if isinstance(telemetry, Mapping) else None
    workload_duration = (
        _retained_workload_duration_seconds({"calls": [call_telemetry]})
        if workload_required else _observation_window_seconds(observation)
    )
    return CompletedCall(
        repo=repo,
        tool_name=tool_name,
        command=command,
        ts_start=ts_start,
        ts_end=ts_end,
        workload_duration_seconds=workload_duration,
        workload_duration_required=workload_required,
        censored=_truncated_outcome(status.get("message")) or resources.get("censored") is True,
        outcome=str(status.get("code", "unknown")),
        cpu_peak_cores=peak_cpu_cores,
        cpu_peak_cores_eligible=(not exclude_resource_labels and peak_cpu_cores is not None
                                 and resources.get("cpu_peak_window_ms") == 500
                                 and (_trace_metric_eligible(resources, "cpu_peak")
                                      if observation is not None else True)),
        cpu_peak_window_ms=resources.get("cpu_peak_window_ms"),
        sampled_peak_rss_bytes=(
            int(observed_memory["value_bytes"])
            if observed_memory.get("available") is True
            and isinstance(observed_memory.get("value_bytes"), (int, float))
            else None
        ),
        sampled_peak_rss_eligible=(
            not exclude_resource_labels
            and observed_memory.get("eligible") is True
        ),
        cpu_time_seconds=_optional_float(resources.get("cpu_time_s", resources.get("cpu_time_delta_s"))),
        cpu_time_eligible=(not exclude_resource_labels
            and (_trace_metric_eligible(resources, "cpu_time")
                 if observation is not None
                 else _trace_cpu_window_aligned(resources, ts_start, ts_end))),
        memory_baseline_bytes=resources.get("memory_baseline_bytes"),
        memory_total_peak_bytes=resources.get("memory_total_peak_bytes"),
        memory_extra_peak_bytes=resources.get("memory_extra_peak_bytes"),
        memory_measurement=resources.get("memory_measurement"),
        memory_environment_id=resources.get("memory_environment_id"),
        memory_eligible=resources.get("memory_eligible") is True,
        pmu_cycles=pmu.get("cycles"),
        pmu_instructions=pmu.get("instructions"),
        pmu_llc_read_accesses=pmu.get("llc_read_accesses"),
        pmu_llc_read_misses=pmu.get("llc_read_misses"),
        pmu_llc_read_accesses_per_cpu_second=pmu.get("llc_read_accesses_per_cpu_second"),
        pmu_llc_read_misses_per_cpu_second=pmu.get("llc_read_misses_per_cpu_second"),
        pmu_ipc=pmu["ipc"],
        pmu_llc_mpki=pmu["llc_mpki"],
        pmu_llc_miss_rate=pmu["llc_miss_rate"],
        pmu_eligible=pmu["eligible"],
    )


def _trace_cpu_window_aligned(resources: dict[str, Any], start: float, end: float) -> bool:
    # Re-check the window on replay, including traces written by older collectors.
    first = _ns_to_s(resources.get("monitor_start_wall_time_ns"))
    last = _ns_to_s(resources.get("monitor_end_wall_time_ns"))
    return (end > start and first is not None and last is not None
            and abs(first - start) <= .001
            and abs(last - end) <= .001)


def _sample_resources_usable(sample: ToolRuntimeSample) -> bool:
    # A numeric zero from one late snapshot is not a measured tool CPU label.
    if isinstance(sample.resource_observation, Mapping):
        return any(
            _sample_metric_eligible(sample, name)
            for name in ("cpu_time", "cpu_peak", "memory_peak", "disk_io")
        )
    return (
        sample.sampling_quality == "ok"
        and sample.sampling_point_count >= 2
        and sample.monitor_duration_ms > 0
        and min(sample.ended_at, sample.monitor_end_wall_s)
        > max(sample.started_at, sample.monitor_start_wall_s)
    )


def _resource_metric(observation: Mapping[str, Any] | None, name: str) -> Mapping[str, Any]:
    metrics = observation.get("metrics") if isinstance(observation, Mapping) else None
    value = metrics.get(name) if isinstance(metrics, Mapping) else None
    return value if isinstance(value, Mapping) else {}


def _sample_metric_eligible(sample: ToolRuntimeSample, name: str) -> bool:
    if isinstance(sample.resource_observation, Mapping):
        return _resource_metric(sample.resource_observation, name).get("eligible") is True
    if name == "cpu_time":
        return sample.cpu_utilization_avg_cores is not None
    if name == "cpu_peak":
        return sample.cpu_peak_cores is not None
    if name == "memory_peak":
        return False
    return _sample_resources_usable(sample)


def _trace_metric_eligible(resources: Mapping[str, Any], name: str) -> bool:
    observation = resources.get("resource_observation")
    return _resource_metric(observation if isinstance(observation, Mapping) else None, name).get("eligible") is True


def _trace_resources_usable(resources: dict[str, Any]) -> bool:
    # Fail closed for legacy records without quality evidence. Keep latency
    # and independently validated PMU even when resource labels are rejected.
    observation = resources.get("resource_observation")
    if isinstance(observation, Mapping):
        return any(
            _resource_metric(observation, name).get("eligible") is True
            for name in ("cpu_time", "cpu_peak", "memory_peak", "disk_io")
        )
    ratio = _optional_float(resources.get("coverage_ratio"))
    return (
        resources.get("sampling_quality") == "ok"
        and isinstance(resources.get("sampling_point_count"), int)
        and resources["sampling_point_count"] >= 2
        and ratio is not None and ratio > 0
        and resources.get("coverage_reason") != "monitor_window_no_overlap"
    )


def _sample_attribution_ineligible(
    sample: ToolRuntimeSample,
    event: ToolCompletedEvent,
    start: ToolBeforeRequest | None,
) -> bool:
    observation = sample.resource_observation
    if isinstance(observation, Mapping):
        # The eBPF observation describes the actual measurement scope. It is
        # authoritative when finalized execution telemetry replaces an early
        # shared runtime scope carried by the hook event.
        return observation.get("attribution") != "exclusive_process_tree"
    return _completion_uses_shared_resources(event, start) or not _sample_resources_usable(sample)


def _trace_attribution_ineligible(
    resources: dict[str, Any],
    execution: dict[str, Any],
    observation: Mapping[str, Any] | None,
) -> bool:
    if observation is not None:
        return observation.get("attribution") != "exclusive_process_tree"
    return (
        not _trace_resources_usable(resources)
        or _uses_shared_resources(resources)
        or _uses_shared_resources(execution)
    )


def _quality_gated_pmu_metrics(profile: Any, *, execution_id: str | None = None) -> dict[str, Any]:
    from clawtune_sidecar.monitoring.pmu import quality_gated_pmu_metrics
    if execution_id is not None and (not isinstance(profile, dict) or profile.get("execution_id") != execution_id):
        profile = None
    return quality_gated_pmu_metrics(profile)


def _completion_uses_shared_resources(
    event: ToolCompletedEvent,
    start: ToolBeforeRequest | None,
) -> bool:
    # The completion scope is the final, server-resolved attribution scope.
    # Fall back to the request only when completion did not resolve one.
    scope = event.resource_scope
    if scope is None and start is not None:
        scope = start.resource_scope
    return _uses_shared_resources(scope)


def _uses_shared_resources(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, Mapping):
        attribution_source = value.get("attribution_source")
        source = value.get("source")
    else:
        attribution_source = getattr(value, "attribution_source", None)
        source = getattr(value, "source", None)
    return (
        attribution_source in _SHARED_RESOURCE_ATTRIBUTION_SOURCES
        or source in _SHARED_RESOURCE_SCOPE_SOURCES
    )


def _read_ebpf_artifact(path: Path) -> dict[str, Any]:
    return _load_valid_artifact(path)


def _ebpf_observations(
    artifact: dict[str, Any],
    *,
    fallback_repo: str,
) -> list[ClauseObservation]:
    provenance = artifact.get("provenance")
    repo = (
        provenance.get("repo")
        if isinstance(provenance, dict) and isinstance(provenance.get("repo"), str)
        else fallback_repo
    )
    observations: list[ClauseObservation] = []
    for call in artifact.get("calls", []):
        if not isinstance(call, dict) or call.get("eligible_for_kb") is not True:
            continue
        observations.extend(
            _observations_from_call(
                repo,
                call,
                require_timestamps=False,
            )
        )
    return observations


def _ebpf_completed_calls(
    artifact: dict[str, Any],
    *,
    fallback_repo: str,
) -> list[CompletedCall]:
    provenance = artifact.get("provenance")
    repo = (
        provenance.get("repo")
        if isinstance(provenance, dict) and isinstance(provenance.get("repo"), str)
        else fallback_repo
    )
    calls: list[CompletedCall] = []
    for call in artifact.get("calls", []):
        if not isinstance(call, dict) or call.get("eligible_for_kb") is not True:
            continue
        clauses = call.get("clauses")
        if not isinstance(clauses, list):
            continue
        for clause in clauses:
            completed = _ebpf_completed_call(repo, clause)
            if completed is not None:
                calls.append(completed)
    return calls


def _ebpf_completed_call(repo: str, row: Any) -> CompletedCall | None:
    if not isinstance(row, dict):
        return None
    availability = row.get("availability")
    if not isinstance(availability, dict) or availability.get("latency") != "ok":
        return None
    latency_ms = _optional_float(row.get("latency_ms"))
    if latency_ms is None:
        return None
    ts_start = _optional_float(row.get("ts_start"))
    ts_end = _optional_float(row.get("ts_end"))
    if ts_start is None or ts_end is None or ts_end < ts_start:
        ts_start = 0.0
        ts_end = latency_ms / 1000
    argv = row.get("argv")
    command = shlex.join(argv) if isinstance(argv, list) and all(isinstance(item, str) for item in argv) else None
    peak_cpu_cores = _optional_float(row.get("peak_cpu_cores"))
    return CompletedCall(
        repo=repo,
        tool_name="exec",
        command=command,
        ts_start=ts_start,
        ts_end=ts_end,
        censored=False,
        cpu_peak_cores=peak_cpu_cores,
        cpu_peak_cores_eligible=peak_cpu_cores is not None,
    )


def _ebpf_workload_result(
    raw_result: Any,
    *,
    exit_code: int | None,
    signal: int | None,
    succeeded: bool | None,
) -> dict[str, Any]:
    """Build the bounded live-result envelope consumed by eBPF.

    The launcher supplies the authoritative exit status, while OpenClaw's
    completion hook supplies stdout/stderr.  Keeping both lets the clause
    bridge prove command-lookup failures even when a pipeline's final command
    masks an earlier exit 127.
    """

    result = _ebpf_result_text(raw_result)
    stderr = _ebpf_named_text(raw_result, "stderr")
    return {
        "exit_code": exit_code,
        "signal": signal,
        "ok": (
            succeeded
            if succeeded is not None
            else exit_code == 0 and signal is None
        ),
        "result": _bounded_ebpf_text(result),
        "stderr": _bounded_ebpf_text(stderr),
    }


def _ebpf_result_text(value: Any) -> str:
    if isinstance(value, str):
        return value
    if not isinstance(value, Mapping):
        return ""
    details = value.get("details")
    for container in (details, value):
        if not isinstance(container, Mapping):
            continue
        for key in ("aggregated", "stdout", "text"):
            text = container.get(key)
            if isinstance(text, str) and text:
                return text
    content = value.get("content")
    if isinstance(content, Sequence) and not isinstance(content, (str, bytes)):
        parts = [
            item.get("text")
            for item in content
            if isinstance(item, Mapping) and isinstance(item.get("text"), str)
        ]
        if parts:
            return "\n".join(parts)
    nested = value.get("result")
    return _ebpf_result_text(nested) if nested is not value else ""


def _ebpf_named_text(value: Any, key: str) -> str:
    if not isinstance(value, Mapping):
        return ""
    details = value.get("details")
    for container in (details, value):
        if isinstance(container, Mapping):
            text = container.get(key)
            if isinstance(text, str) and text:
                return text
    return ""


def _bounded_ebpf_text(value: str, limit: int = 65_536) -> str:
    encoded = value.encode("utf-8", errors="replace")
    if len(encoded) <= limit:
        return value
    return encoded[:limit].decode("utf-8", errors="ignore")


def _ebpf_status(
    artifact: Any,
    call_telemetry: Mapping[str, Any] | None,
    kb_update_error: str | None,
) -> str:
    if call_telemetry is not None:
        quality = call_telemetry.get("telemetry_quality")
        if quality == "ok":
            return "ok" if kb_update_error is None else "collected_not_eligible"
        if quality in {"invalid", "unavailable"}:
            return str(quality)
    if isinstance(artifact, Mapping):
        calls = artifact.get("calls")
        if isinstance(calls, list) and any(
            isinstance(call, Mapping) and call.get("telemetry_quality") == "invalid"
            for call in calls
        ):
            return "invalid"
        quality = artifact.get("telemetry_quality")
        if quality == "ok":
            return "ok" if kb_update_error is None else "collected_not_eligible"
        if quality in {"invalid", "unavailable"}:
            return str(quality)
    return "unavailable" if kb_update_error else "unknown"


def _ebpf_unavailable_reason(
    artifact: Any,
    call_telemetry: Mapping[str, Any] | None,
    kb_update_error: str | None,
) -> str | None:
    if call_telemetry is not None:
        reason = call_telemetry.get("unavailable_reason") or call_telemetry.get("reason")
        if isinstance(reason, str) and reason:
            return reason
        quality = call_telemetry.get("telemetry_quality")
        if quality == "invalid":
            return "call_telemetry_invalid"
        if quality == "unavailable":
            return "call_telemetry_unavailable"
    if isinstance(artifact, Mapping):
        calls = artifact.get("calls")
        if isinstance(calls, list):
            invalid = [
                call
                for call in calls
                if isinstance(call, Mapping) and call.get("telemetry_quality") == "invalid"
            ]
            if invalid:
                return "artifact_contains_invalid_call_telemetry"
        reason = artifact.get("unavailable_reason") or artifact.get("reason")
        if isinstance(reason, str) and reason:
            return reason
    return kb_update_error


def _compact_call_telemetry(call: Mapping[str, Any] | None) -> dict[str, Any] | None:
    if call is None:
        return None
    clauses = call.get("clauses")
    return {
        "tool_call_id": call.get("tool_call_id"),
        "command": call.get("command"),
        "telemetry_quality": call.get("telemetry_quality"),
        "formal_completeness": call.get("formal_completeness"),
        "eligible_for_kb": call.get("eligible_for_kb"),
        "clause_count": len(clauses) if isinstance(clauses, list) else 0,
        "call_resource": call.get("call_resource"),
        "clauses": _compact_clauses(clauses),
    }


def _compact_artifact_summary(artifact: Any) -> dict[str, Any] | None:
    if not isinstance(artifact, Mapping):
        return None
    calls = artifact.get("calls")
    return {
        "schema": artifact.get("schema"),
        "schema_version": artifact.get("version"),
        "mode": artifact.get("mode"),
        "replay_execution": artifact.get("replay_execution"),
        "collector": artifact.get("collector"),
        "container_id": artifact.get("container_id"),
        "telemetry_quality": artifact.get("telemetry_quality"),
        "formal_completeness": artifact.get("formal_completeness"),
        "telemetry_loss_total": artifact.get("telemetry_loss_total"),
        "call_count": len(calls) if isinstance(calls, list) else 0,
    }


def _first_value(*values: Any) -> Any:
    for value in values:
        if value is not None:
            return value
    return None


def _cpu_ns_to_s(value: Any) -> float | None:
    if value is None:
        return None
    try:
        return float(value) / 1e9
    except (TypeError, ValueError):
        return None


def _cpu_ns_from_row(row: Mapping[str, Any]) -> int | None:
    """Normalize the clause CPU accumulator to ns.

    Prefers the collector's raw ns key (``cpu_ns_cumulative``) and falls back
    to the seconds-form key (``cumulative_cpu_s``) by scaling back to ns, so
    both emitted CPU fields always agree: ``cumulative_cpu_s`` is just the
    human-readable seconds form of ``cpu_ns_cumulative``.
    """
    raw_ns = row.get("cpu_ns_cumulative")
    if raw_ns is not None:
        try:
            return int(raw_ns)
        except (TypeError, ValueError):
            return None
    seconds = row.get("cumulative_cpu_s")
    if seconds is not None:
        try:
            return int(float(seconds) * 1e9)
        except (TypeError, ValueError):
            return None
    return None


def _nested(row: Mapping[str, Any], path: tuple[str, ...]) -> Any:
    cur: Any = row
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur


def _compact_clauses(clauses: Any) -> list[dict[str, Any]]:
    if not isinstance(clauses, list):
        return []
    compact: list[dict[str, Any]] = []
    for row in clauses:
        if not isinstance(row, Mapping):
            continue
        cpu_ns = _cpu_ns_from_row(row)
        compact.append(
            {
                "bin": row.get("bin"),
                "argv": row.get("argv"),
                # Preserve recorded shell structure for parser-free offline replay.
                # Missing fields remain missing: do not invent standalone semantics.
                **{field: row[field] for field in
                   ("in_loop", "in_pipe", "in_subst", "pipeline_position", "stdin_from_pipe") if field in row},
                "status": row.get("status"),
                "availability": row.get("availability"),
                "ts_start": row.get("ts_start"),
                "ts_end": row.get("ts_end"),
                "latency_ms": row.get("latency_ms"),
                # Map from the eBPF artifact's actual keys: the clause row
                # carries cpu_ns_cumulative, sampled_peak_rss_mb and a nested
                # disk_io object (the eBPF collector does not monitor network).
                # Both CPU fields come from one normalized ns value so they
                # always agree; cumulative_cpu_s is the human-readable form.
                "cpu_ns_cumulative": cpu_ns,
                "cumulative_cpu_s": _cpu_ns_to_s(cpu_ns),
                "cpu_time_seconds": _cpu_ns_to_s(_nested(row, ("provenance", "cpu_time_ns"))),
                "t_exec_ns": _nested(row, ("provenance", "t_exec_ns")),
                "t_end_ns": _nested(row, ("provenance", "t_end_ns")),
                "peak_cpu_cores": row.get("peak_cpu_cores"),
                "peak_memory_mb": _first_value(
                    row.get("peak_memory_mb"), row.get("sampled_peak_rss_mb")
                ),
                "disk_read_bytes": _first_value(
                    row.get("disk_read_bytes"),
                    _nested(row, ("disk_io", "read_bytes_total")),
                ),
                "disk_write_bytes": _first_value(
                    row.get("disk_write_bytes"),
                    _nested(row, ("disk_io", "write_bytes_total")),
                ),
                # The eBPF eBPF collector does not monitor network today;
                # these stay null so consumers can distinguish "unavailable"
                # from a real measurement.
                "network_rx_bytes": row.get("network_rx_bytes"),
                "network_tx_bytes": row.get("network_tx_bytes"),
            }
        )
    return compact


def _clauses_from_command(command: str) -> tuple[tuple[dict[str, Any], ...], bool]:
    from tool_resource.commands import parse_execution
    try:
        clauses, reason = parse_execution(command, parser=parse_command_clauses)
    except Exception:
        clauses, reason = parse_execution(command, parser=_fallback_parse_command_clauses)
    return clauses, reason == "parse_failed"


def _fallback_parse_command_clauses(command: str) -> dict[str, Any]:
    import shlex

    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=";&|()<>")
        lexer.whitespace_split = True
        argv = list(lexer)
        if any(token and all(c in ";&|()<>" for c in token) for token in argv):
            return {"clauses": [], "parse_failed": True}
    except ValueError:
        return {"clauses": [], "parse_failed": True}
    if not argv:
        return {"clauses": [], "parse_failed": True}
    return {
        "clauses": [{"bin": argv[0].rsplit("/", 1)[-1], "argv": argv, "span": (0, len(command))}],
        "parse_failed": False,
    }


def _normalize_clause(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    bin_ = value.get("bin")
    argv = value.get("argv")
    if not isinstance(bin_, str) or not bin_:
        return None
    if not isinstance(argv, list) or not all(isinstance(item, str) for item in argv):
        return None
    if not argv:
        return None
    position = value.get("pipeline_position", -1)
    if isinstance(position, bool) or not isinstance(position, int):
        position = -1
    return {
        "bin": bin_,
        "argv": argv,
        "in_loop": bool(value.get("in_loop", False)),
        "in_pipe": bool(value.get("in_pipe", False)),
        "in_subst": bool(value.get("in_subst", False)),
        "pipeline_position": position,
        "stdin_from_pipe": value.get("stdin_from_pipe"),
    }


def _raw_params_from_start(start: dict[str, Any] | None) -> Any:
    if not isinstance(start, dict):
        return None
    input_value = start.get("input")
    if not isinstance(input_value, dict):
        return None
    return input_value.get("requested_args")


def _raw_params_from_result(raw_event: Any, raw_result: Any) -> Any:
    for candidate in (raw_event, raw_result):
        if not isinstance(candidate, dict):
            continue
        for key in ("params", "arguments", "input", "requested_args"):
            value = candidate.get(key)
            if value is not None:
                return value
    return None


def _command_for_request(request: ToolBeforeRequest) -> str | None:
    command = extract_command(request.raw_params)
    return command if command else None


def _duration_ms(record: dict[str, Any]) -> float | None:
    raw = record.get("duration_ns")
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return None
    if value < 0:
        return None
    return value / 1_000_000


def _span_times(record: dict[str, Any], duration_ms: float) -> tuple[float, float]:
    end = _ns_to_s(record.get("wall_time_ns"))
    if end is None:
        end = 0.0
    start = max(0.0, end - duration_ms / 1000)
    return start, end


def _ns_to_s(value: Any) -> float | None:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed / 1_000_000_000


def _optional_float(value: Any) -> float | None:
    if value is None:
        return None
    if not isinstance(value, int | float) or isinstance(value, bool):
        return None
    parsed = float(value)
    return parsed if math.isfinite(parsed) else None


def _rss_mb(value: Any) -> float | None:
    parsed = _optional_float(value)
    return None if parsed is None else parsed / (1024 * 1024)


def _cpu_ns(value: Any) -> int | None:
    parsed = _optional_float(value)
    if parsed is None or parsed < 0:
        return None
    return int(parsed * 1_000_000_000)


def _bucket_percentile_ms(
    probability_by_bucket: Sequence[float],
    buckets: LatencyBuckets,
    percentile: float,
) -> int:
    cumulative = 0.0
    for index, probability in enumerate(probability_by_bucket):
        cumulative += probability
        if cumulative >= percentile:
            return int(round(_bucket_representative_ms(index, buckets)))
    return int(round(_bucket_representative_ms(len(probability_by_bucket) - 1, buckets)))


def _bucket_representative_ms(bucket_id: int, buckets: LatencyBuckets) -> float:
    edges = buckets.edges_ms
    if bucket_id <= 0:
        return edges[0] / 2
    if bucket_id >= len(edges):
        return edges[-1] * 2
    return (edges[bucket_id - 1] + edges[bucket_id]) / 2


def _resource_class_for_bucket(bucket_id: int) -> str:
    if bucket_id <= 1:
        return "latency_short"
    if bucket_id <= 3:
        return "latency_medium"
    return "latency_long"


def _resource_class_for_duration_ms(duration_ms: int | None) -> str:
    if duration_ms is None:
        return "unknown"
    if duration_ms <= 500:
        return "latency_short"
    if duration_ms <= 2_000:
        return "latency_medium"
    return "latency_long"


def _tool_resource_prediction_payload(
    prediction: CommandLatencyBucketPrediction,
    *,
    continuous_predictions: dict[str, Any] | None = None,
    lattice_time_predictions: Sequence[ClauseLatticeTimePredictions] = (),
    lattice_resource_predictions: Sequence[dict[str, Any]] = (),
    kv_ttl_cost: dict[str, Any] | None = None,
    numa_usage: dict[str, Any] | None = None,
) -> dict[str, Any]:
    clause_prediction = prediction.prediction
    payload = {
        "repo": prediction.repo,
        "command": prediction.command,
        "parse_failed": prediction.parse_failed,
        "clause_bins": list(prediction.clause_bins),
        "clause_predictions": [
            {
                "clause_index": item.clause_index,
                "bin": item.bin,
                "argv": list(item.argv),
                "prediction": _clause_bucket_prediction_payload(item.prediction),
                "unavailable_reason": item.unavailable_reason,
            }
            for item in prediction.clause_predictions
        ],
        "prediction": _clause_bucket_prediction_payload(clause_prediction),
        "unavailable_reason": prediction.unavailable_reason,
        "continuous_predictions": continuous_predictions or {},
        "lattice_resource_predictions": list(lattice_resource_predictions),
        "lattice_time_predictions": [
            _clause_lattice_time_predictions_payload(item)
            for item in lattice_time_predictions
        ],
        "kv_ttl_cost": kv_ttl_cost,
        "prediction_algorithms": _prediction_algorithms_payload(),
    }
    # Host NUMA busyness is only present when a sampler is configured, so
    # existing consumers (and deployments without the sampler) see no new key.
    if numa_usage is not None:
        payload["numa_usage"] = numa_usage
    # Derived compound composition: only present when the command-level
    # bucket was actually composed from per-clause medians. Kept out of the
    # payload otherwise so existing consumers see no new keys.
    if prediction.composed:
        payload["composed"] = True
        payload["composed_total_ms"] = prediction.composed_total_ms
        payload["composition"] = list(prediction.composition)
    return payload


def _clause_bucket_prediction_payload(
    prediction: ClauseLatencyBucketPrediction | None,
) -> dict[str, Any] | None:
    if prediction is None:
        return None
    return {
        "bucket_id": prediction.bucket_id,
        "probability_by_bucket": list(prediction.probability_by_bucket),
        "scope": prediction.scope,
        "key_kind": prediction.key_kind,
        "evidence_count": prediction.evidence_count,
        "fallback_path": list(prediction.fallback_path),
    }


def _clause_lattice_time_predictions_payload(
    outcome: ClauseLatticeTimePredictions,
) -> dict[str, Any]:
    return {
        "clause_index": outcome.clause_index,
        "bin": outcome.bin,
        "argv": list(outcome.argv),
        "predictions": [
            {
                "algorithm": prediction.algorithm,
                "prediction_ms": prediction.prediction_ms,
                "selected_features": list(prediction.selected_features),
                "evidence_count": prediction.evidence_count,
                "selected_risk": prediction.selected_risk,
                "exact_match": prediction.exact_match,
                "fallback": prediction.fallback,
                "unavailable_reason": prediction.unavailable_reason,
            }
            for prediction in outcome.predictions
        ],
    }


def _unavailable_lattice_time_predictions(
    clauses: Sequence[Mapping[str, Any]],
    *,
    reason: str,
    shell_command: bool,
) -> tuple[ClauseLatticeTimePredictions, ...]:
    outcomes: list[ClauseLatticeTimePredictions] = []
    for clause_index, clause in enumerate(clauses):
        bin_ = str(clause["bin"])
        argv = tuple(str(value) for value in clause["argv"])
        if shell_command and not shell_bin_requires_exec_evidence(
            bin_, argv[0] if argv else None
        ):
            continue
        if not bin_ or not argv:
            continue
        outcomes.append(
            ClauseLatticeTimePredictions(
                clause_index=clause_index,
                bin=bin_,
                argv=argv,
                predictions=tuple(
                    LatticeTimePrediction(
                        algorithm=algorithm,
                        prediction_ms=None,
                        selected_features=(),
                        evidence_count=0,
                        selected_risk=None,
                        exact_match=None,
                        fallback=None,
                        unavailable_reason=reason,
                    )
                    for algorithm in LATTICE_TIME_ALGORITHMS
                ),
            )
        )
    return tuple(outcomes)


def _unavailable_prediction_for_request(
    request: ToolBeforeRequest,
    *,
    repo: str,
    command: str | None,
    reason: str,
) -> CommandLatencyBucketPrediction:
    clauses, parse_failed = clauses_from_tool_request(
        request.tool_name,
        request.raw_params,
    )
    return CommandLatencyBucketPrediction(
        repo=repo,
        command=command or request.tool_name,
        parse_failed=parse_failed,
        clause_bins=tuple(str(clause["bin"]) for clause in clauses),
        prediction=None,
        unavailable_reason=reason,
        clause_predictions=tuple(
            ClauseLatencyBucketOutcome(
                clause_index=index,
                bin=str(clause["bin"]),
                argv=tuple(clause["argv"]),
                prediction=None,
                unavailable_reason=reason,
            )
            for index, clause in enumerate(clauses)
            if request.tool_name != "exec"
            or shell_bin_requires_exec_evidence(
                str(clause["bin"]),
                str(clause["argv"][0]) if clause.get("argv") else None,
            )
        ),
    )


def _prediction_error_reason(exc: Exception) -> str:
    message = str(exc)
    if "no public global clause latency node" in message:
        return "no_clause_latency_evidence"
    return f"prediction_error:{type(exc).__name__}"


_KNOWN_KB_SNAPSHOT_FILENAMES: frozenset[str] = frozenset(
    {
        "clause-resource-kb.json",
        "runtime-tool-resource-kb.json",
        "clause-lattice-time-kb.json",
        "edge-kappa-kb.json",
    }
)


def _clause_kb_snapshot_path(artifact_dir: Path | None) -> Path | None:
    if artifact_dir is None:
        return None
    return artifact_dir / "clause-resource-kb.json"


def _runtime_kb_snapshot_path(artifact_dir: Path | None) -> Path | None:
    if artifact_dir is None:
        return None
    return artifact_dir / "runtime-tool-resource-kb.json"


def _lattice_kb_snapshot_path(artifact_dir: Path | None) -> Path | None:
    if artifact_dir is None:
        return None
    return artifact_dir / "clause-lattice-time-kb.json"


def _discover_artifact_call_files(artifact_dir: Path) -> list[Path]:
    """Return eBPF call artifact paths found in *artifact_dir*.

    Scans ``*.json`` files excluding the three known KB snapshot filenames.
    A quick structural check (``version: 2``, ``mode: "clause"``) avoids
    feeding unrelated JSON files into the validation pipeline.
    """

    discovered: list[Path] = []
    try:
        for entry in sorted(artifact_dir.iterdir()):
            if not entry.is_file() or entry.suffix != ".json":
                continue
            if entry.name in _KNOWN_KB_SNAPSHOT_FILENAMES:
                continue
            try:
                candidate = json.loads(entry.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            if (
                isinstance(candidate, dict)
                and candidate.get("version") == 2
                and candidate.get("mode") == "clause"
            ):
                discovered.append(entry)
    except OSError:
        pass
    return discovered


def _load_clause_kb_snapshot(
    path: Path | None,
    rejections: list[str],
) -> ClauseResourceKB | None:
    if path is None or not path.is_file():
        return None
    try:
        return ClauseResourceKB.from_json_obj(json.loads(path.read_text(encoding="utf-8")))
    except Exception as exc:
        rejections.append(f"{path}: clause KB snapshot rejected: {exc}")
        return None


def _load_runtime_kb_snapshot(
    path: Path | None,
    rejections: list[str],
) -> RuntimeToolResourceKB | None:
    if path is None or not path.is_file():
        return None
    try:
        return RuntimeToolResourceKB.from_json_obj(json.loads(path.read_text(encoding="utf-8")))
    except Exception as exc:
        rejections.append(f"{path}: runtime KB snapshot rejected: {exc}")
        return None


def _load_lattice_kb_snapshot(
    path: Path | None,
    rejections: list[str],
) -> LatticeTimeKB | None:
    if path is None or not path.is_file():
        return None
    try:
        return LatticeTimeKB.from_json_obj(json.loads(path.read_text(encoding="utf-8")))
    except Exception as exc:
        rejections.append(f"{path}: lattice KB snapshot rejected: {exc}")
        return None


def _write_json_atomic(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    tmp.write_text(
        json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, path)


def _has_public_clause_latency(kb: ClauseResourceKB) -> bool:
    public = getattr(kb, "_public", {})
    latency = public.get("latency_ms", {}) if isinstance(public, dict) else {}
    return bool(latency.get(("global", "")))


def _target_prediction_payload(prediction: TargetPrediction) -> dict[str, Any]:
    return {
        "target": prediction.target,
        "conditional_p90": prediction.conditional_p90,
        "scope": prediction.scope,
        "key_kind": prediction.key_kind,
        "evidence_count": prediction.evidence_count,
        "fallback_path": list(prediction.fallback_path),
        "note": prediction.note,
    }


def _continuous_unavailable_note(target: str, exc: Exception) -> str:
    message = str(exc)
    if message == f"no public global node for target {target!r}":
        return "no continuous evidence for target"
    return f"unavailable: {message}"


def _prediction_algorithms_payload() -> dict[str, Any]:
    return {
        "enabled": [
            {
                "name": "clause_latency_bucket",
                "family": "empirical_bucket",
                "source": "ClauseResourceKB",
                "targets": ["latency_ms"],
                "outputs": [
                    "bucket_id",
                    "probability_by_bucket",
                    "duration_p50_ms",
                    "duration_p90_ms",
                    "resource_class",
                ],
            },
            {
                "name": "lattice_shrinkage",
                "family": "context_lattice",
                "source": "LatticeTimeKB",
                "targets": ["latency_ms", "cpu_time_seconds", "cpu_avg_cores", "cpu_peak_cores", "sampled_peak_rss_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["clause_point_prediction_ms", "resource_p50", "resource_p90"],
            },
            {
                "name": "lattice_loso",
                "family": "context_lattice",
                "source": "LatticeTimeKB",
                "targets": ["latency_ms", "cpu_time_seconds", "cpu_avg_cores", "cpu_peak_cores", "sampled_peak_rss_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["clause_point_prediction_ms", "resource_p50", "resource_p90"],
            },
            {
                "name": "lattice_max_cardinality",
                "family": "context_lattice",
                "source": "LatticeTimeKB",
                "targets": ["latency_ms", "cpu_time_seconds", "cpu_avg_cores", "cpu_peak_cores", "sampled_peak_rss_bytes", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["clause_point_prediction_ms", "resource_p50", "resource_p90"],
            },
            {
                "name": "runtime_tool_resource_conditional_p90",
                "family": "empirical_ecdf",
                "source": "RuntimeToolResourceKB",
                "targets": ["latency_ms", "cpu_peak_cores", "memory_total_peak_bytes", "memory_extra_peak_bytes"],
                "outputs": ["conditional_p90"],
            },
        ],
        "excluded": [
            {
                "name": "quantile_mlp",
                "source": "tool_resource.mlp",
                "reason": "not enabled by the sidecar; this integration uses non-MLP empirical predictors only",
            }
        ],
    }


def _expand_trace_paths(paths: Iterable[Path]) -> Iterable[Path]:
    for path in paths:
        if path.is_dir():
            yield from sorted(path.rglob("*.jsonl"))
        else:
            yield path


def _safe_artifact_name(value: str) -> str:
    safe = "".join(char if char.isalnum() or char in "._-" else "_" for char in value)
    if safe == value and len(safe) <= 128:
        return safe or "execution"
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]
    return f"{safe[:96] or 'execution'}__{digest}"


def _execution_owners_compatible(
    expected: tuple[str | None, str | None],
    actual: tuple[str | None, str | None],
) -> bool:
    return all(
        left is None or right is None or left == right
        for left, right in zip(expected, actual, strict=True)
    )


def _execution_owner_matches_runtime(
    owner: tuple[str | None, str | None] | None,
    *,
    runtime_id: str,
    gateway_id: str | None,
) -> bool:
    if owner is None or owner[1] != runtime_id:
        return False
    return gateway_id is None or owner[0] is None or owner[0] == gateway_id
