# Install an experiment host

Scope: a dedicated ARM64 Linux host with KVM, systemd, cgroup v2, and Docker.
Package commands below target Ubuntu 24.04 ARM64 and install standalone CubeSandbox.
Commands must finish successfully before proceeding.

## Required artifacts

| Input | Required contents |
| --- | --- |
| Guest image archive | ARM64 Runtime image with OpenClaw, ClawTune and the SSH launcher; Tool image with its workspace, dependencies, SSH service and telemetry collectors |
| Guest kernel | `vmlinux-bm`, `version`, `version.json`, with the required eBPF/kprobe support |
| Registry | A registry reachable from the new host, with permission to push the images |

These guest artifacts are not published with this repository. The existing
Dockerfiles reference private base images; cloning the repository alone cannot
rebuild them. Obtain an image/kernel bundle from an existing compatible deployment
or supply equivalent artifacts with the same entrypoints. Task repositories live
in the Tool image; no particular benchmark trace is an installation dependency.

On an existing deployment whose `machine.env` identifies the image digests:

```bash
bash scripts/export-machine-assets.sh /data/clawbox-transfer
```

## 1. Install host tools and Python package

```bash
sudo apt-get update
sudo apt-get install -y python3.12 python3.12-venv python3-dev git docker.io \
  build-essential curl jq rsync numactl e2fsprogs util-linux
sudo systemctl enable --now docker
sudo usermod -aG docker "$USER"
```

Log out and back in to activate Docker group membership. Then:

```bash
test "$(uname -m)" = aarch64
test -c /dev/kvm
test "$(stat -fc %T /sys/fs/cgroup)" = cgroup2fs
docker info >/dev/null
python3.12 --version
mkdir -p "$HOME/src"
cd "$HOME/src"
git clone https://github.com/w20chen/ClawBox.git
git clone https://github.com/w20chen/ClawTune.git
cd ClawBox
python3.12 -m venv .venv
.venv/bin/python -m pip install -e '.[dev]'
source .venv/bin/activate
clawbox experiment --help
```

Expected: ARM64, accessible KVM, `cgroup2fs`, a working Docker daemon, and the
experiment command list. Use fresh checkout directories for the clone commands.

### Build with the current ClawTune source

Before rebuilding guest images, export the sibling ClawTune working tree into a
new directory. This includes the plugin's LatticeKB execution-envelope selection
and records source provenance without changing the sibling checkout:

```bash
python scripts/prepare-clawtune.py --working-tree --output /data/clawtune-build-source
export CLAWTUNE_ROOT=/data/clawtune-build-source
export CLAWTUNE_SIDECAR_SRC="$CLAWTUNE_ROOT/services/sidecar/src"
python -m pip install --upgrade "$CLAWTUNE_ROOT/services/sidecar"
python scripts/validate_clawtune_integration.py --clawtune-root "$CLAWTUNE_ROOT"
export CLAWTUNE_REVISION="$(cat "$CLAWTUNE_ROOT/CLAWTUNE_REVISION")"
docker buildx build --load --platform linux/arm64 \
  --build-context "clawtune=$CLAWTUNE_ROOT" --build-arg "CLAWTUNE_REVISION=$CLAWTUNE_REVISION" \
  -f docker/Dockerfile.runtime-cube -t clawbox/runtime-cube:main .
docker buildx build --load --platform linux/arm64 \
  --build-context "clawtune=$CLAWTUNE_ROOT" --build-arg "CLAWTUNE_REVISION=$CLAWTUNE_REVISION" \
  -f docker/Dockerfile.tool-cube -t clawbox/tool-cube:main .
```

Use the same export for both images, then push and register their new immutable
digests as described below. A clean checkout records its commit; local edits
record a content-derived revision. Use a new export directory for each update. The SWE-ReBench overlay
rebuild script exports the current ClawTune working tree too.

Each Runtime initializes an independent working KB through ClawTune's native
seed/state API. Use new run directories after upgrading from an older KB layout.
`CLAWTUNE_COLD_START_DIR` can select a complete native seed bundle, including its
manifest and all required native snapshots. ClawBox retains the seed's native
repository layers. Older ToolKB/Lattice snapshot schemas are not relabeled or
converted; retain the old state separately and ingest raw artifacts into a new
tuning database after upgrading. Guest eBPF uses ClawTune's unmodified collector;
the running guest kernel and its BCC build headers must match.

## 2. Build and install patched CubeSandbox

Copy the supplied bundle to the destination, then prepare the server from
`$HOME/src/ClawBox`:

```bash
read -r -p 'Source SSH address (user@host): ' ASSET_HOST
sudo install -d -o "$USER" -g "$(id -gn)" /data/clawbox-transfer
rsync -a "$ASSET_HOST:/data/clawbox-transfer/" /data/clawbox-transfer/
test -s /data/clawbox-transfer/guest-images.tar
test -s /data/clawbox-transfer/kernel/vmlinux-bm
test -s /data/clawbox-transfer/kernel/version.json
export CUBE_SOURCE_DIR="$HOME/src/CubeSandbox"
bash deploy/cubesandbox/prepare-semantic-source.sh
python -m pip install -e "$CUBE_SOURCE_DIR/sdk/python"
cd "$CUBE_SOURCE_DIR"
cp deploy/one-click/build.env.example deploy/one-click/build.env
make builder-image
ONE_CLICK_BUILD_JOBS=1 \
ONE_CLICK_CUBE_KERNEL_VMLINUX=/data/clawbox-transfer/kernel/vmlinux-bm \
bash deploy/one-click/build-release-bundle-builder.sh
```

The preparation script pins v0.7.0 and applies the repository's endpoint,
networking, image-provenance, and snapshot patches. Use its matching SDK.
Build variables are defined in the pinned [upstream build configuration](https://github.com/TencentCloud/CubeSandbox/blob/v0.7.0/deploy/one-click/build.env.example).

Select the exact archive printed by the build; do not extract a wildcard of old
archives. The installer uses `/usr/local/services/cubetoolbox`:

```bash
read -r -p 'Absolute path of newly built release archive: ' RELEASE_ARCHIVE
test -s "$RELEASE_ARCHIVE"
INSTALL_STAGE=$(mktemp -d /tmp/clawbox-install.XXXXXX)
tar -xzf "$RELEASE_ARCHIVE" -C "$INSTALL_STAGE"
cd "$INSTALL_STAGE"/cube-sandbox-one-click-*
cp env.example .env
read -r -p 'Host IPv4 address reachable from guests: ' HOST_IP
printf '\nCUBE_SANDBOX_NODE_IP=%s\n' "$HOST_IP" >> .env
sudo bash install.sh
sudo bash smoke.sh
systemctl list-units 'cube-sandbox-*' --no-pager
```

Before running `install.sh`, review `.env` for storage devices and conflicting
ports on this host. The commands follow the pinned [standalone installer](https://github.com/TencentCloud/CubeSandbox/blob/v0.7.0/deploy/one-click/README.md#target-machine-installation).
If your Cubelet storage uses S3lvol, set `ONE_CLICK_ENABLE_S3LVOL=1` before
installation and configure its S3/MinIO backend using the supplied environment
file. The upstream default is disabled; an active Cubelet alone does not prove
that storage is ready.
Expected: the smoke command succeeds and services are active. A failed smoke
check must be resolved before template registration.

## 3. Import images and write machine settings

```bash
cd "$HOME/src/ClawBox"
source .venv/bin/activate
docker load -i /data/clawbox-transfer/guest-images.tar
read -r -p 'Registry namespace (host[:port]/namespace): ' REGISTRY
docker tag clawbox-transfer/runtime:research "$REGISTRY/runtime:experiment"
docker tag clawbox-transfer/tool:research "$REGISTRY/tool:experiment"
docker push "$REGISTRY/runtime:experiment"
docker push "$REGISTRY/tool:experiment"
docker image inspect --format '{{json .RepoDigests}}' "$REGISTRY/runtime:experiment"
docker image inspect --format '{{json .RepoDigests}}' "$REGISTRY/tool:experiment"
mkdir -p "$HOME/.config/clawbox"
cp examples/clawbox-machine.env.example "$HOME/.config/clawbox/machine.env"
chmod 600 "$HOME/.config/clawbox/machine.env"
sudo install -d -o "$USER" -g "$(id -gn)" /data/clawbox-results /data/clawbox-specs
```

Authenticate with `docker login` first if required by your registry. Edit
`machine.env` using the values from this installation:

| Variable | Value to supply |
| --- | --- |
| `CUBE_API_URL` | CubeAPI URL; `http://127.0.0.1:3000` for a local default installation |
| `CUBE_NODE` | Actual compute-node registration name, not an old experiment's hostname |
| `CUBE_PROXY_NODE_IP`, `CUBE_PROXY_PORT_HTTP` | Proxy listener address and HTTP port from the installed configuration |
| `CLAWBOX_CONTROL_HOST`, `CLAWBOX_MODEL_GATEWAY_HOST` | Host IP reachable from guest VMs; default listeners use TCP 18080 and 18081 |
| `CLAWBOX_RUNTIME_IMAGE`, `CLAWBOX_TOOL_IMAGE` | Corresponding pushed `registry/name@sha256:...` references from `RepoDigests` |
| `CLAWTUNE_ROOT` | `$HOME/src/ClawTune`, expanded to an absolute path |
| `CLAWTUNE_SIDECAR_SRC` | Absolute `ClawTune/services/sidecar/src` path |
| `CUBE_SOURCE_DIR` | Absolute patched CubeSandbox checkout path |
| `CLAWBOX_OUTPUT_ROOT` | Writable result directory outside the checkout |
| `NO_PROXY`, `no_proxy` | Control/proxy host addresses plus `localhost,127.0.0.1` |

Leave template IDs unset until registration. Snapshot paths are only used for
tiered storage. The file is a shell environment file, loaded explicitly:

```bash
set -a
source "$HOME/.config/clawbox/machine.env"
set +a
curl -fsS "$CUBE_API_URL/health"
python scripts/audit-cube-sandboxes.py --json
```

## 4. Register templates and verify SSH

BCC needs headers prepared for the **running guest kernel configuration**, not
just the same kernel version. A mismatch can produce eBPF events with invalid
CPU or memory counters. If your Tool image has the matching kernel source but
was prepared with a different configuration, build a corrected image from an
existing template on this host:

```bash
python scripts/prepare-guest-kernel-headers.py \
  --template "$CLAWBOX_TOOL_TEMPLATE" --node "$CUBE_NODE" \
  --image "$CLAWBOX_TOOL_IMAGE" --tag "$REGISTRY/tool:matching-headers" \
  --output /data/clawbox-specs/header-build-01
docker push "$REGISTRY/tool:matching-headers"
export CLAWBOX_TOOL_IMAGE=$(docker image inspect "$REGISTRY/tool:matching-headers" \
  --format '{{index .RepoDigests 0}}')
```

This reads `/proc/config.gz` from a temporary guest, prepares the headers in a
new image, and preserves the configuration and build log. Register the new image
below. On a fresh installation, register an initial template first to perform
this check; do not start experiments until the resource probe passes.

Read the installed guest-kernel component and register new aliases. The commands
match the starting example's VM sizes; disk capacity belongs to the template:

```bash
GUEST_KERNEL_COMPONENT=$(jq -er '.variants.bm.version' \
  /usr/local/services/cubetoolbox/cube-kernel-scf/version.json)
TEMPLATE_SUFFIX=$(date -u +%Y%m%d%H%M%S)
python scripts/register-cube-template.py "$CLAWBOX_RUNTIME_IMAGE" \
  --alias "runtime-$TEMPLATE_SUFFIX" --node "$CUBE_NODE" \
  --cpu-millicores 2000 --memory-mib 2048 --writable-layer-size 20G \
  --exposed-port 49983 --probe-port 49983 \
  --command /usr/local/bin/cube-runtime-entrypoint.sh \
  --expected-kernel-version "$GUEST_KERNEL_COMPONENT" > /data/clawbox-specs/runtime-template.json
python scripts/register-cube-template.py "$CLAWBOX_TOOL_IMAGE" \
  --alias "tool-$TEMPLATE_SUFFIX" --node "$CUBE_NODE" \
  --cpu-millicores 2000 --memory-mib 4096 --writable-layer-size 40G \
  --exposed-port 49983 --exposed-port 2222 --probe-port 49983 \
  --command /usr/local/bin/cube-tool-entrypoint.sh \
  --expected-kernel-version "$GUEST_KERNEL_COMPONENT" > /data/clawbox-specs/tool-template.json
export CLAWBOX_RUNTIME_TEMPLATE=$(jq -er .template_id /data/clawbox-specs/runtime-template.json)
export CLAWBOX_TOOL_TEMPLATE=$(jq -er .template_id /data/clawbox-specs/tool-template.json)
```

Save both IDs in `machine.env`. Registration waits for READY and checks kernel
binding. If it fails ambiguously, inspect the alias inventory before resubmitting.
Check the semantic TCP endpoint instead of guessing a guest IP:

```bash
python scripts/validate-cubesandbox-tcp-endpoints.py \
  --runtime-template "$CLAWBOX_RUNTIME_TEMPLATE" --tool-template "$CLAWBOX_TOOL_TEMPLATE" \
  --node "$CUBE_NODE" --control-host "$CLAWBOX_CONTROL_HOST" \
  --count 1 --output "$CLAWBOX_OUTPUT_ROOT/endpoint-one.json"
```

Expected: endpoint reachability and identity checks succeed. Repeat with
`--count 4` and a new output filename before testing higher concurrency.
Check command cancellation and telemetry across a snapshot/restore cycle too:

```bash
python scripts/smoke-cubesandbox-agent-pair.py \
  --runtime-template "$CLAWBOX_RUNTIME_TEMPLATE" --tool-template "$CLAWBOX_TOOL_TEMPLATE" \
  --node "$CUBE_NODE" --control-host "$CLAWBOX_CONTROL_HOST" --cancel-probe \
  --output "$CLAWBOX_OUTPUT_ROOT/agent-pair.json"
```

Then follow [configure and run](guide.md#5-run-on-an-installed-host).

## Optional: isolated memory and tiered snapshots

This section requires two NUMA nodes and an idle CubeSandbox VM pool. Choose
capacities from available node memory. The values below match the c16 lab
defaults and require enough physical RAM on both nodes. Inspect the nodes first:

```bash
numactl --hardware
cat /sys/fs/cgroup/cube_sandbox/sandbox/cgroup.events
```

Continue only if `populated 0`. Set paths in `machine.env` and matching values in
the experiment's `resources` section:

```yaml
pool_memory_budget_mib: 65536
local_memory_capacity_mib: 65536
warm_memory_capacity_mib: 131072
checkpoint_restore_headroom_mib: 8192
local_memory_cgroup: /sys/fs/cgroup/cube_sandbox/sandbox
local_numa_node: 0
warm_numa_node: 1
warm_snapshot_root: /data/clawbox/warm
cold_snapshot_root: /data/clawbox/cold
snapshot_mechanism: incremental-cow  # use full-copy for the baseline
```

Keep the host-specific, non-secret values in one file and run the repeatable
setup on an idle host:

```bash
cp examples/clawbox-snapshot-host.env.example "$HOME/.config/clawbox/snapshot-host.env"
# Edit paths, capacities, NUMA nodes, and CUBE_SOURCE_DIR for this machine.
source "$HOME/.config/clawbox/snapshot-host.env"
bash scripts/snapshot-host.sh "$HOME/.config/clawbox/snapshot-host.env" apply
sudo systemctl restart cube-sandbox-cubelet.service
sudo systemctl restart cube-sandbox-cube-egress.service
bash scripts/snapshot-host.sh "$HOME/.config/clawbox/snapshot-host.env" apply
bash scripts/snapshot-host.sh "$HOME/.config/clawbox/snapshot-host.env" check \
  > "$CLAWBOX_OUTPUT_ROOT/snapshot-host-check.json"
```

Expected: every `checks[].ok` is true. The check reports the configured LOCAL
limit, WARM tmpfs size and NUMA policy, COLD disk space, service flags, and source
files without printing credentials. A failed check exits 2. Repeat `apply` after
reboot or service recreation; restart services only to activate changed flags.
Never restart them during an experiment. Use the same WARM/COLD roots in the
experiment YAML and `machine.env`; otherwise Cubelet rejects the snapshot path.

Validate physical snapshot placement:

```bash
python scripts/validate-tiered-storage.py \
  --template "$CLAWBOX_TOOL_TEMPLATE" --node "$CUBE_NODE" \
  --warm "$CLAWBOX_WARM_ROOT" --cold "$CLAWBOX_COLD_ROOT" \
  --helper-image "$CLAWBOX_TOOL_IMAGE" --require-local-numa "$CLAWBOX_LOCAL_NODE" \
  --expected-memory-mib 4096 --output "$CLAWBOX_OUTPUT_ROOT/storage-check.json"
```

After installing the CubeAPI, CubeMaster, Cubelet, and template-selected shim
from the patched CubeSandbox source, compare repeated checkpoints under both
mechanisms. Use separate output files and the same template, node, and RAM size:

```bash
for mode in full-copy incremental-cow; do
  python scripts/validate-tiered-storage.py \
    --template "$CLAWBOX_TOOL_TEMPLATE" --node "$CUBE_NODE" \
    --warm "$CLAWBOX_WARM_ROOT" --cold "$CLAWBOX_COLD_ROOT" \
    --helper-image "$CLAWBOX_TOOL_IMAGE" --require-local-numa "$CLAWBOX_LOCAL_NODE" \
    --expected-memory-mib 4096 --snapshot-mechanism "$mode" --rounds 8 \
    --output "$CLAWBOX_OUTPUT_ROOT/storage-$mode.json"
done
```

The last generation spills to COLD. The JSON contains checkpoint P50/P95
both with and without the initial base, restore-ready P50/P95, first-tool
latency, host VM faults/read bytes, and each
generation's logical, allocated, dirty, and transferred bytes. The process
state token and changed Guest RAM byte must survive every restore.

This helper uses privileged Docker inspection. Memory setup, endpoint checks,
and storage checks do not establish a completed agent benchmark.

## After a reboot

On an installed host, check the API and compute services before starting work:

```bash
systemctl is-active cube-sandbox-cube-api.service cube-sandbox-cubemaster.service \
  cube-sandbox-cubelet.service cube-sandbox-cube-egress.service
```

For tiered experiments, reapply the snapshot settings on an idle pool, then
run `snapshot-host.sh HOST_ENV check` before the live storage validation. The
[kunpeng example](../deploy/hosts/kunpeng.snapshot.env.example) records its
observed non-secret paths and can be copied as `HOST_ENV`; review its capacities
before applying it.

For an S3lvol-backed installation, also check `cube-sandbox-s3lvol.service` and
`test -S /var/run/s3lvol.sock`. Restore its configured backend before restarting
Cubelet if the socket is missing. Reapply the memory setup above on an idle pool.

When using the bundled MinIO backend, start it before S3lvol:

```bash
sudo systemctl start cube-sandbox-minio.service
sudo systemctl start cube-sandbox-s3lvol.service
test -S /var/run/s3lvol.sock
```

An active S3lvol supervisor alone is not sufficient: it may be retrying while
MinIO is unavailable. Check the socket and service log before creating VMs.
If the host address changed, check that `/data/cubelet/s3.cfg` points to the
actual MinIO listener and uses credentials accepted by that server. Preserve a
copy before editing; do not print credentials into experiment logs.

Also check free disk space with `df -h /data/cubelet`. The pinned CubeSandbox
snapshot backend rejects new writes at 85% filesystem usage. This can surface
as `no more resource` even when CPU and RAM are idle; the CubeMaster log then
reports `snapshot storage unavailable`. Remove confirmed obsolete crash dumps
or unused build cache, keeping templates, recordings and experiment results.
Allow additional space for snapshots during the run, not just enough to pass
the initial check. Run the storage validation above again before experiments.

Keep interrupted results and start with a new run ID; reboot does not resume a run.
Disable the old kubelet on a dedicated host migrated from Kubernetes, after
confirming it has no unrelated workloads.

## Verification boundary

CLI examples and repository helper arguments are checked against source. The
upstream release commands are checked against the pinned v0.7.0 files. A fresh
physical-host installation has not been executed as part of this documentation
change; the VM and kernel checks above remain required on the target host.
