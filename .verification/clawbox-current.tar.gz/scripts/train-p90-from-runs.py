#!/usr/bin/env python3
"""Train a repository-level immutable P90 file from trusted prior run artifacts."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import subprocess
from pathlib import Path
from typing import Any

from clawbox.cell.p90 import AdmissionPrediction
from clawbox.replay.trace import load_trace
from clawbox.tuning.__main__ import find_run_datasets
from clawbox.tuning.dataset import build_joined_dataset, read_cgroup_artifacts
from clawbox.tuning.native import _clawtune_api, native_clause_observations
from clawbox.tuning.clawtune import predict_native_call_load


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _quantile(values: list[float], q: float) -> float:
    ordered = sorted(values)
    position = (len(ordered) - 1) * q
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def _host_increment_calibration(paths: list[Path]) -> dict[str, Any]:
    ratios: list[float] = []
    source = hashlib.sha256()
    for index, path in enumerate(paths):
        raw = path.read_bytes()
        source.update(f"calibration-{index}/{path.name}".encode() + b"\0" + raw + b"\0")
        payload = json.loads(raw)
        if isinstance(payload, dict):
            rows = (payload.get("performance") or {}).get(
                "tool_execution_observations", []
            )
        else:
            rows = payload
        for row in rows if isinstance(rows, list) else []:
            if row.get("execution_scope", "agent-tool") != "agent-tool":
                continue
            guest = row.get("actual_measured_memory_mib")
            host = row.get("actual_host_execution_increment_mib")
            if guest is None or host is None or float(guest) <= 0 or float(host) < 0:
                continue
            ratios.append(float(host) / float(guest))
    if len(ratios) < 5:
        raise ValueError(
            f"only {len(ratios)} valid guest/host calibration pairs; need at least 5"
        )
    return {
        "target": "host_vm_rss_execution_increment",
        "source_sha256": source.hexdigest(),
        "source_paths": [str(path.resolve()) for path in paths],
        "pair_count": len(ratios),
        "ratio_p50": _quantile(ratios, 0.5),
        "ratio_p90": _quantile(ratios, 0.9),
        "ratio_min": min(ratios),
        "ratio_max": max(ratios),
    }


def _evidence_paths(
    trace_dir: Path, bridge: Path, resource_dir: Path | None = None,
) -> list[Path]:
    paths = {bridge, *trace_dir.glob("*.jsonl"), *trace_dir.glob("cgroup-resource-*.json"),
             *trace_dir.glob("clause-telemetry-*.json")}
    tool_resource = trace_dir / "tool-resource"
    if tool_resource.is_dir():
        paths.update(tool_resource.glob("*.json"))
    if resource_dir is not None and resource_dir != trace_dir:
        paths.update(resource_dir.glob("*.json"))
    return sorted(paths, key=lambda path: str(path))


def _trace_tool_calls(path: Path) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    model_step = 0
    for action in load_trace(path):
        if action.kind != "llm":
            continue
        message = action.output
        if (isinstance(message, dict) and set(message) == {"content"}
                and isinstance(message["content"], dict)):
            message = message["content"]
        if not isinstance(message, dict):
            model_step += 1
            continue
        for call_index, call in enumerate(message.get("tool_calls") or []):
            function = call.get("function") or {}
            name = str(function.get("name") or "")
            arguments = function.get("arguments") or {}
            if isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except json.JSONDecodeError:
                    arguments = {}
            command = arguments.get("command") if isinstance(arguments, dict) else None
            calls.append({
                "model_step": model_step,
                "call_index": call_index,
                "tool_name": name,
                "command": command if isinstance(command, str) else None,
            })
        model_step += 1
    return calls


def _per_tool_memory_plan(
    kb: Any,
    query_type: Any,
    *,
    repository: str,
    traces: dict[str, Path],
    query_ts: float,
    idle_tool_vm_rss_mib: float,
    idle_safety_margin_fraction: float,
    command_headroom_fraction: float,
    size_classes_mib: list[int],
    host_calibration: dict[str, Any],
) -> dict[str, Any]:
    if idle_tool_vm_rss_mib <= 0:
        raise ValueError("idle Tool-VM RSS must be positive")
    if not 0 <= idle_safety_margin_fraction <= 1:
        raise ValueError("idle safety margin must be between 0 and 1")
    if not 0 <= command_headroom_fraction <= 1:
        raise ValueError("command headroom must be between 0 and 1")
    if not size_classes_mib or size_classes_mib != sorted(set(size_classes_mib)):
        raise ValueError("Tool memory size classes must be unique and increasing")
    idle_floor_mib = math.ceil(
        idle_tool_vm_rss_mib * (1 + idle_safety_margin_fraction)
    )
    workloads: dict[str, Any] = {}
    query_index = 0
    for workload, trace in sorted(traces.items()):
        reservations = []
        for call in _trace_tool_calls(trace):
            query = query_type(
                repo=repository,
                tool_name=call["tool_name"] or "exec",
                command=call["command"],
                ts_start=query_ts + query_index * 1e-6,
                memory_measurement="guest_memtotal_minus_memavailable",
            )
            prediction = predict_native_call_load(None, query, lattice=kb).targets[
                "memory_extra_peak_bytes"
            ]
            query_index += 1
            if prediction.status != "available" or prediction.p90 is None:
                raise ValueError("per-tool memory prediction is unavailable")
            command_p90_mib = float(prediction.p90) / (1024.0 * 1024.0)
            host_ratio_p90 = float(host_calibration["ratio_p90"])
            incremental_p90_kib = math.ceil(
                command_p90_mib * (1 + command_headroom_fraction) * 1024.0
            )
            host_increment_p90_kib = math.ceil(
                command_p90_mib * host_ratio_p90
                * (1 + command_headroom_fraction) * 1024.0
            )
            reservation_kib = math.ceil(
                idle_floor_mib * 1024.0 + host_increment_p90_kib
            )
            reservation_mib = reservation_kib / 1024.0
            reservations.append({
                **call,
                "command_sha256": (
                    hashlib.sha256(call["command"].encode()).hexdigest()
                    if call["command"] is not None else None
                ),
                "predicted_command_memory_p90_mib": command_p90_mib,
                "predicted_host_execution_increment_mib": (
                    command_p90_mib * host_ratio_p90
                ),
                "host_mapping_source": host_calibration["source_sha256"],
                "host_mapping_ratio_p90": host_ratio_p90,
                "incremental_p90_kib": incremental_p90_kib,
                "incremental_p90_mib": incremental_p90_kib / 1024.0,
                "host_increment_p90_kib": host_increment_p90_kib,
                "host_increment_p90_mib": host_increment_p90_kib / 1024.0,
                "reservation_kib": reservation_kib,
                "reservation_mib": reservation_mib,
                "backend": prediction.backend,
                "context": list(prediction.context),
                "evidence_count": prediction.sample_count,
            })
        if not reservations:
            raise ValueError(f"evaluation trace {workload!r} has no concrete tool calls")
        required_mib = max(item["reservation_mib"] for item in reservations)
        selected_class = next(
            (value for value in size_classes_mib if value >= required_mib), None
        )
        if selected_class is None:
            raise ValueError(
                f"{workload}: {required_mib} MiB exceeds the largest Tool size class"
            )
        workloads[workload] = {
            "trace_path": str(trace.resolve()),
            "trace_sha256": _sha256(trace),
            "tool_invocations": reservations,
            "reservation_min_mib": min(item["reservation_mib"] for item in reservations),
            "reservation_max_mib": required_mib,
            "reservation_distinct_mib": sorted({
                item["reservation_mib"] for item in reservations
            }),
            "reservation_distinct_kib": sorted({
                item["reservation_kib"] for item in reservations
            }),
            "incremental_p90_distinct_kib": sorted({
                item["incremental_p90_kib"] for item in reservations
            }),
            "selected_vm_size_class_mib": selected_class,
        }
    return {
        "semantics": (
            "admission uses live resident Tool-Firecracker RSS plus per-tool "
            "incremental P90 commitments and global safety headroom; tool completion "
            "remeasures RSS; ballooning or checkpoint eviction must be measured "
            "explicitly before reclaimed host memory is credited"
        ),
        "idle_tool_vm_rss_mib": idle_tool_vm_rss_mib,
        "idle_safety_margin_fraction": idle_safety_margin_fraction,
        "derived_idle_floor_mib": idle_floor_mib,
        "command_headroom_fraction": command_headroom_fraction,
        "size_classes_mib": size_classes_mib,
        "workloads": workloads,
    }


def _attach_oracle_working_sets(
    plan: dict[str, Any],
    oracle_runs: dict[str, Path],
) -> dict[str, Any]:
    reports: dict[str, Any] = {}
    idle_rss_mib = float(plan["idle_tool_vm_rss_mib"])
    capacity_by_workload = {
        name: int(item["selected_vm_size_class_mib"])
        for name, item in plan["workloads"].items()
    }
    for workload, run in sorted(oracle_runs.items()):
        if workload not in plan["workloads"]:
            raise ValueError(f"oracle workload {workload!r} is absent from the prediction plan")
        trusted = [
            item
            for trace_dir, bridge, resource_dir in find_run_datasets(run)
            for item in build_joined_dataset(
                trace_dir, bridge, resource_dir=resource_dir,
            )[1]
        ]
        observations = sorted(
            [item for item in trusted
             if item.command and item.rss_peak_bytes is not None and item.start_time is not None],
            key=lambda item: item.start_time,
        )
        planned = plan["workloads"][workload]["tool_invocations"]
        cursor = 0
        matched = []
        for invocation in planned:
            command = invocation.get("command")
            match = None
            for observation_index in range(cursor, len(observations)):
                candidate = observations[observation_index]
                if candidate.command == command:
                    match = candidate
                    cursor = observation_index + 1
                    break
            if match is None:
                continue
            actual_command_mib = float(match.rss_peak_bytes) / (1024.0 * 1024.0)
            predicted_command_mib = float(invocation["predicted_command_memory_p90_mib"])
            actual_working_set_mib = idle_rss_mib + actual_command_mib
            row = {
                "model_step": invocation["model_step"],
                "call_index": invocation["call_index"],
                "command_sha256": invocation["command_sha256"],
                "predicted_command_memory_p90_mib": predicted_command_mib,
                "actual_command_peak_memory_mib": actual_command_mib,
                "prediction_error_mib": predicted_command_mib - actual_command_mib,
                "prediction_covered_actual": predicted_command_mib >= actual_command_mib,
                "actual_working_set_mib": actual_working_set_mib,
                "oracle_reservation_mib": actual_working_set_mib,
            }
            invocation["oracle"] = row
            matched.append(row)
        if not matched:
            raise ValueError(f"oracle run {workload!r} did not match any planned tool call")
        capacity = capacity_by_workload[workload]
        max_working_set = max(item["actual_working_set_mib"] for item in matched)
        reports[workload] = {
            "run_path": str(run.resolve()),
            "matched_invocations": len(matched),
            "planned_invocations": len(planned),
            "coverage_fraction": sum(item["prediction_covered_actual"] for item in matched) / len(matched),
            "mean_prediction_error_mib": sum(item["prediction_error_mib"] for item in matched) / len(matched),
            "max_actual_command_peak_memory_mib": max(item["actual_command_peak_memory_mib"] for item in matched),
            "max_actual_working_set_mib": max_working_set,
            "selected_vm_capacity_mib": capacity,
            "vm_capacity_sufficient": max_working_set < capacity,
        }
    return {
        "semantics": "held-out actual command cgroup peak plus measured idle Tool-VM RSS; never used for admission",
        "workloads": reports,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("runs", nargs="+", type=Path)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--command", required=True, help="concrete command for the exported LatticeKB P90")
    parser.add_argument("--tenant", default="offline-research")
    parser.add_argument("--generation", type=int, default=1)
    parser.add_argument("--training-set-id", default="training")
    parser.add_argument(
        "--clawtune-root", type=Path,
        default=Path(os.environ.get(
            "CLAWTUNE_ROOT", Path(__file__).resolve().parents[2] / "ClawTune",
        )),
        help="exact ClawTune checkout used to interpret and fit native telemetry",
    )
    parser.add_argument(
        "--observed-repo-fingerprint",
        default=None,
        help="expected repo field in the raw agent trace when it differs from --repository",
    )
    parser.add_argument("--held-out-run", type=Path, default=None)
    parser.add_argument("--held-out-trace", type=Path, default=None)
    parser.add_argument("--held-out-workload", default=None)
    parser.add_argument(
        "--evaluation-trace", action="append", default=[], metavar="WORKLOAD=PATH",
        help="independent evaluation trace; repeat once per workload",
    )
    parser.add_argument("--evaluation-set-id", default=None)
    parser.add_argument("--idle-tool-vm-rss-mib", type=float)
    parser.add_argument("--idle-safety-margin-fraction", type=float, default=0.25)
    parser.add_argument("--command-headroom-fraction", type=float, default=0.25)
    parser.add_argument("--tool-memory-size-class-mib", type=int, action="append", default=[])
    parser.add_argument(
        "--host-calibration-observations", type=Path, action="append", default=[],
        help="recording result JSON containing guest and host execution increments",
    )
    parser.add_argument(
        "--oracle-run", action="append", default=[], metavar="WORKLOAD=PATH",
        help="held-out measured run for prediction-error/oracle analysis only",
    )
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--seed-output", type=Path,
                        help="new native seed directory with this trained LatticeKB for Runtime startup")
    args = parser.parse_args()
    if any(value is not None for value in (
        args.held_out_run, args.held_out_trace, args.held_out_workload,
    )) and not all(value is not None for value in (
        args.held_out_run, args.held_out_trace, args.held_out_workload,
    )):
        parser.error("--held-out-run, --held-out-trace, and --held-out-workload are required together")
    resolved_runs = {run.resolve() for run in args.runs}
    if args.held_out_run is not None and args.held_out_run.resolve() in resolved_runs:
        parser.error("--held-out-run must not also appear in the training runs")
    if args.evaluation_trace and any(value is not None for value in (
        args.held_out_run, args.held_out_trace, args.held_out_workload,
    )):
        parser.error("--evaluation-trace and --held-out-* modes are mutually exclusive")
    if bool(args.evaluation_trace) != bool(args.evaluation_set_id):
        parser.error("--evaluation-trace and --evaluation-set-id are required together")
    if args.clawtune_root is not None:
        sidecar_src = args.clawtune_root.resolve() / "services" / "sidecar" / "src"
        if not sidecar_src.is_dir():
            parser.error(f"ClawTune sidecar source is missing: {sidecar_src}")
        os.environ["CLAWTUNE_SIDECAR_SRC"] = str(sidecar_src)
    _, CompletedCall, RuntimeToolResourceKB, ToolCallQuery, _, validate_artifact, LatticeTimeKB = _clawtune_api()
    calls = []
    clauses = []
    source = hashlib.sha256()
    run_reports: list[dict[str, Any]] = []
    expected_observed_repo = args.observed_repo_fingerprint or args.repository
    for run_index, run in enumerate(sorted(args.runs, key=str)):
        for dataset_index, (trace_dir, bridge, resource_dir) in enumerate(
            find_run_datasets(run)
        ):
            evidence_paths = _evidence_paths(trace_dir, bridge, resource_dir)
            for path in evidence_paths:
                try:
                    relative = path.relative_to(run)
                except ValueError:
                    relative = Path(path.name)
                source.update(
                    f"run-{run_index}/dataset-{dataset_index}/{relative.as_posix()}".encode()
                    + b"\0" + path.read_bytes() + b"\0"
                )
            joined, trusted = build_joined_dataset(
                trace_dir, bridge, resource_dir=resource_dir,
            )
            native_calls = {}
            for artifact_path in _evidence_paths(trace_dir, bridge, resource_dir):
                if artifact_path.suffix != ".json":
                    continue
                artifact = json.loads(artifact_path.read_text(encoding="utf-8"))
                if not isinstance(artifact, dict) or artifact.get("version") != 2 or artifact.get("mode") != "clause":
                    continue
                validate_artifact(artifact_path, artifact, expected_repo=args.observed_repo_fingerprint or args.repository)
                for call in artifact.get("calls", []):
                    if call.get("eligible_for_kb") is True:
                        native_calls[call["tool_call_id"]] = call
            observed_repos = sorted({
                item.repo_fingerprint for item in trusted if item.repo_fingerprint
            })
            if observed_repos != [expected_observed_repo]:
                raise ValueError(
                    f"{run}/{resource_dir.name}: observed trace repositories "
                    f"{observed_repos!r}; expected exactly {expected_observed_repo!r}"
                )
            eligible_count = 0
            for item in trusted:
                if (item.start_time is None or item.end_time is None
                        or item.cpu_time_sec is None):
                    continue
                native_call = native_calls.get(item.execution_id)
                if native_call is None or item.cgroup is None:
                    continue
                if native_call.get("command") != item.command:
                    raise ValueError("native clause command does not match the joined execution")
                observations = native_clause_observations(
                    args.repository, native_call, item.cgroup.model_dump(mode="json"),
                )
                if not observations:
                    continue
                clauses.extend(observations)
                eligible_count += 1
                calls.append(CompletedCall(
                    repo=args.repository, tool_name=item.tool_name or "exec",
                    command=item.command,
                    ts_start=item.start_time.timestamp(), ts_end=item.end_time.timestamp(),
                    censored=item.exit_code not in (None, 0),
                    cpu_time_seconds=item.cpu_time_sec,
                    cpu_time_eligible=True,
                    memory_baseline_bytes=item.memory_baseline_bytes,
                    memory_total_peak_bytes=item.memory_total_peak_bytes,
                    memory_extra_peak_bytes=item.memory_extra_peak_bytes,
                    memory_measurement=item.memory_measurement,
                    memory_environment_id=item.memory_environment_id,
                    memory_eligible=item.memory_eligible,
                ))
            cgroup_files = list(resource_dir.glob("cgroup-resource-*.json"))
            cgroup_loaded = read_cgroup_artifacts(resource_dir)
            run_reports.append({
                "run_id": f"{args.training_set_id}/{run.name}/{resource_dir.name}",
                "source_path": str(run.resolve()),
                "trace_files": len(list(trace_dir.glob("*.jsonl"))),
                "bridge_records": len({item.execution_id for item in joined.unmatched_bridges})
                                  + len({item.execution_id for item in joined.joined}),
                "cgroup_files": len(cgroup_files),
                "cgroup_valid": len(cgroup_loaded),
                "cgroup_invalid_or_incomplete": len(cgroup_files) - len(cgroup_loaded),
                "spans": joined.span_count,
                "joined": len(joined.joined),
                "join_rate": joined.join_rate,
                "trusted": len(trusted),
                "trainer_eligible": eligible_count,
                "observed_repo_fingerprints": observed_repos,
            })
    if len(calls) < 5:
        raise ValueError(f"only {len(calls)} trusted completed calls; need at least 5")
    kb = LatticeTimeKB.fit(clauses)
    runtime = kb.to_json_obj()
    query = ToolCallQuery(
        repo=args.repository, tool_name="exec", command=args.command,
        # Query immediately after the newest training completion.  Using wall
        # clock time makes an otherwise frozen artifact needlessly dependent
        # on when the export command happens to run.
        ts_start=max(call.ts_end for call in calls) + 1e-6,
        memory_measurement="guest_memtotal_minus_memavailable",
    )
    call_load = predict_native_call_load(None, query, lattice=kb)
    latency = call_load.targets["duration_ms"]
    cpu = call_load.targets["cpu_avg_cores"]
    memory = call_load.targets["memory_extra_peak_bytes"]
    if latency.status != "available" or latency.p90 is None:
        raise ValueError("training corpus has no eligible native latency evidence")
    if cpu.status != "available" or cpu.p90 is None:
        raise ValueError("training corpus has no eligible native CPU-time evidence")
    if memory.status != "available" or memory.p90 is None:
        raise ValueError(
            "training corpus has no ClawTune environment extra-memory evidence; "
            "guest RSS cannot substitute for memory_extra_peak_bytes"
        )
    from clawbox.clawtune_integration import source_revision
    revision = source_revision(args.clawtune_root.resolve())
    source_digest = source.hexdigest()
    pair_digest = hashlib.sha256(
        source_digest.encode() + json.dumps(runtime, sort_keys=True).encode()
    ).hexdigest()
    training = {
        "run_count": len(args.runs),
        "completed_calls": len(calls),
        "target_repository": args.repository,
        "recording_set_id": args.training_set_id,
        "expected_observed_repo_fingerprint": expected_observed_repo,
        "runs": run_reports,
    }
    evaluation = None
    if args.held_out_run is not None:
        assert args.held_out_trace is not None and args.held_out_workload is not None
        if not args.held_out_run.is_dir():
            raise FileNotFoundError(args.held_out_run)
        if not args.held_out_trace.is_file():
            raise FileNotFoundError(args.held_out_trace)
        evaluation = {
            "protocol": "leave-one-recording-out",
            "held_out_workload": args.held_out_workload,
            "held_out_run_id": args.held_out_run.name,
            "held_out_run_path": str(args.held_out_run.resolve()),
            "held_out_trace_sha256": _sha256(args.held_out_trace),
        }
    elif args.evaluation_trace:
        traces: dict[str, dict[str, str]] = {}
        for configured in args.evaluation_trace:
            workload, separator, raw_path = configured.partition("=")
            if not separator or not workload or not raw_path:
                parser.error("--evaluation-trace must use WORKLOAD=PATH")
            if workload in traces:
                parser.error(f"duplicate evaluation workload {workload!r}")
            path = Path(raw_path)
            if not path.is_file():
                raise FileNotFoundError(path)
            traces[workload] = {"path": str(path.resolve()), "sha256": _sha256(path)}
        evaluation = {
            "protocol": "independent-recording-set",
            "recording_set_id": args.evaluation_set_id,
            "traces": traces,
        }
    payload = {
        "tenant_id": args.tenant, "repo_fingerprint": args.repository,
        "generation": args.generation, "pair_digest": pair_digest,
        "source_digest": source_digest, "artifact_count": len(calls),
        "clawtune_revision": revision,
        "call_prediction": call_load.model_dump(mode="json"),
        "command": args.command,
        "lattice_snapshot": runtime,
        "prediction": {
            "cpu_metric": "cpu_avg_cores",
            "memory_metric": "environment_memory_peak_minus_baseline",
            "latency_p90_sec": float(latency.p90) / 1000.0,
            "cpu_p90_cores": float(cpu.p90),
            "memory_p90_bytes": float(memory.p90),
            "evidence_count": min(latency.sample_count, cpu.sample_count,
                                  memory.sample_count),
            "backends": {"latency": latency.backend, "cpu": cpu.backend,
                          "memory": memory.backend},
            "contexts": {"latency": list(latency.context),
                         "cpu": list(cpu.context), "memory": list(memory.context)},
        },
        "training": training,
    }
    if evaluation is not None:
        payload["evaluation"] = evaluation
    if args.idle_tool_vm_rss_mib is not None:
        if not args.evaluation_trace:
            parser.error("per-tool memory planning requires --evaluation-trace")
        if not args.host_calibration_observations:
            parser.error(
                "per-tool memory planning requires --host-calibration-observations"
            )
        host_calibration = _host_increment_calibration(
            args.host_calibration_observations
        )
        payload["host_increment_calibration"] = host_calibration
        trace_paths = {
            configured.partition("=")[0]: Path(configured.partition("=")[2])
            for configured in args.evaluation_trace
        }
        payload["per_tool_memory"] = _per_tool_memory_plan(
            kb,
            ToolCallQuery,
            repository=args.repository,
            traces=trace_paths,
            query_ts=max(call.ts_end for call in calls) + 1.0,
            idle_tool_vm_rss_mib=args.idle_tool_vm_rss_mib,
            idle_safety_margin_fraction=args.idle_safety_margin_fraction,
            command_headroom_fraction=args.command_headroom_fraction,
            size_classes_mib=args.tool_memory_size_class_mib,
            host_calibration=host_calibration,
        )
        oracle_runs: dict[str, Path] = {}
        for configured in args.oracle_run:
            workload, separator, raw_path = configured.partition("=")
            if not separator or not workload or not raw_path:
                parser.error("--oracle-run must use WORKLOAD=PATH")
            oracle_runs[workload] = Path(raw_path)
        if oracle_runs:
            payload["oracle_evaluation"] = _attach_oracle_working_sets(
                payload["per_tool_memory"], oracle_runs,
            )
    prediction = AdmissionPrediction.from_payload(payload)
    if args.seed_output is not None:
        from clawbox.clawtune_integration import seed_directory
        from clawtune_kb import create_seed, validate_seed
        base = seed_directory()
        manifest = validate_seed(base)
        snapshots = {name: json.loads((base / name).read_text(encoding="utf-8"))
                     for name in manifest["snapshots"]}
        snapshots["clause-lattice-time-kb.json"] = runtime
        create_seed(args.seed_output, snapshots, provenance={
            "source": "clawbox_native_clause_training", "source_digest": source_digest,
            "clawtune_revision": revision,
        })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    temporary = args.output.with_name(args.output.name + ".next")
    payload.update(prediction.as_payload())
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(args.output)


if __name__ == "__main__":
    main()
