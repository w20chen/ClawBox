from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml
from pydantic import ValidationError

from clawbox.experiments import ExperimentSpec, expand_matrix, load_experiment, spec_digest
from clawbox.experiments.audit import audit_experiments
from clawbox.experiments.baselines import BASELINES, resolve_baseline
from clawbox.replay.trace import load_trace
from clawbox.experiments.worker import (
    EventWriter, ExperimentWorker, _execute_idempotent, _runtime_network_deny_out, build_time_spans,
    policy_operation_headroom_mib, session_case_for,
)
from clawbox.replay.lifecycle import CommandResult


def test_explicit_null_disables_arm_deadline() -> None:
    from clawbox.experiments.spec import ExecutionSpec
    with pytest.raises(ValueError):
        ExecutionSpec(arm_timeout_seconds=None)
    assert ExecutionSpec().arm_timeout_seconds == 1800


def test_incremental_snapshot_is_default() -> None:
    from clawbox.experiments.spec import ResourcesSpec
    resources = ResourcesSpec(target_node="node-a", pool_memory_budget_mib=8192,
                              emergency_free_memory_mib=512)
    assert resources.snapshot_mechanism == "incremental-cow"
    assert resources.model_copy(update={"snapshot_mechanism": "full-copy"}).snapshot_mechanism == "full-copy"


@pytest.mark.parametrize("root", [None, "", "   "])
def test_incremental_reclamation_requires_cold_destination(root) -> None:
    raw = raw_spec()
    raw["resources"]["cold_snapshot_root"] = root
    with pytest.raises(ValidationError, match="incremental-cow reclamation requires"):
        ExperimentSpec.model_validate(raw)
    raw["resources"]["snapshot_mechanism"] = "full-copy"
    assert ExperimentSpec.model_validate(raw).resources.snapshot_mechanism == "full-copy"


def test_policy_drain_reports_already_completed_failure() -> None:
    from concurrent.futures import Future
    from threading import Lock
    from clawbox.experiments.worker import drain_policy_futures
    success, failed = Future(), Future()
    success.set_result(None)
    failed.set_exception(RuntimeError("model wait policy failed"))
    with pytest.raises(RuntimeError, match="model wait policy failed"):
        drain_policy_futures([success, failed], Lock(), 1)


def test_policy_drain_observes_work_submitted_by_pending_event() -> None:
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event, Lock
    from clawbox.experiments.worker import drain_policy_futures
    pending, lock, release = [], Lock(), Event()
    with ThreadPoolExecutor(max_workers=2) as executor:
        def fail():
            raise RuntimeError("follow-up failed")
        def submit_followup():
            release.wait(2)
            with lock:
                pending.append(executor.submit(fail))
        pending.append(executor.submit(submit_followup))
        release.set()
        with pytest.raises(RuntimeError, match="follow-up failed"):
            drain_policy_futures(pending, lock, 2)


def test_runtime_network_policy_honors_explicit_internet_access() -> None:
    allowlist = ["192.0.2.10/32"]

    assert _runtime_network_deny_out(True, allowlist) is None
    assert _runtime_network_deny_out(False, allowlist) == ["0.0.0.0/0"]
    assert _runtime_network_deny_out(False, []) is None


def raw_spec() -> dict:
    return {
        "schema_version": 2,
        "experiment_id": "unit",
        "workload": {
            "source": "recorded_trace", "input": "trace.jsonl", "repetitions": 2,
            "cases": [{"case_id": "case-a", "source": "recorded_trace",
                       "source_reference": "trace.jsonl", "replay_trace_reference": "trace.jsonl"}],
        },
        "agent": {"driver": "openclaw"},
        "inference": {"backend": "replay", "configuration": {
            "model_wait_prediction_seconds": 1.0,
            "model_wait_prediction_source": "separate-recording-fixed",
        }},
        "runtime": {"template_alias": "runtime-arm64", "vcpu": 1, "memory_mib": 2048},
        "sandbox": {"template_alias": "task-arm64", "vcpu": 2, "memory_mib": 4096},
        "execution": {"concurrency_levels": [1, 4], "random_seed": 17},
        "resources": {
            "target_node": "node-a", "pool_memory_budget_mib": 100000,
            "emergency_free_memory_mib": 10000,
            "cold_snapshot_root": "/cold",
        },
        "policies": [
            {"name": "resident", "admission": "lifetime_full", "reclamation": "resident",
             "eviction": "none", "restore": "none"},
            {"name": "proposed", "admission": "tool_p50", "reclamation": "snapshot_pause",
             "eviction": "wait_aware_pressure", "restore": "proactive",
             "prefetch_lead_seconds": 0.5},
        ],
    }


def test_v2_matrix_is_complete_stable_and_randomized() -> None:
    spec = ExperimentSpec.model_validate(raw_spec())
    first = expand_matrix(spec)
    second = expand_matrix(spec)
    assert len(first) == 2 * 2 * 2
    assert [arm.arm_id for arm in first] == [arm.arm_id for arm in second]
    assert all(arm.spec_digest == spec_digest(spec) for arm in first)
    assert {arm.policy.name for arm in first} == {"resident", "proposed"}


def test_checkpoint_headroom_is_only_charged_to_snapshot_policy() -> None:
    arms = expand_matrix(ExperimentSpec.model_validate(raw_spec()))
    effective = {
        arm.policy.name: policy_operation_headroom_mib(arm)
        for arm in arms if arm.concurrency == 1 and arm.repetition == 0
    }
    assert effective == {"resident": 0, "proposed": 1024}


def test_warm_capacity_is_disabled_for_non_tiered_arms() -> None:
    raw = raw_spec()
    raw["resources"].update(warm_memory_capacity_mib=65536,
                            local_memory_capacity_mib=65536,
                            warm_snapshot_root="/warm", cold_snapshot_root="/cold",
                            local_numa_node=0, warm_numa_node=1)
    raw["policies"].append({"name": "tiered", "admission": "tool_p50",
                            "reclamation": "snapshot_pause", "restore": "reactive",
                            "eviction": "tiered_time_oracle"})
    arms = expand_matrix(ExperimentSpec.model_validate(raw))
    for arm in arms:
        assert arm.resources.warm_memory_capacity_mib == (
            65536 if arm.policy.name == "tiered" else 0)


def test_round_robin_workload_builds_one_arm_and_stable_session_mix() -> None:
    raw = raw_spec()
    raw["workload"]["repetitions"] = 1
    raw["workload"]["session_assignment"] = "round_robin"
    raw["workload"]["cases"].append({
        "case_id": "case-b", "source": "recorded_trace",
        "source_reference": "trace-b.jsonl",
        "replay_trace_reference": "trace-b.jsonl",
    })
    spec = ExperimentSpec.model_validate(raw)
    arms = expand_matrix(spec)
    assert len(arms) == 2 * 2  # concurrency levels x policies, not x cases
    arm = arms[0]
    assert [item.case_id for item in arm.session_cases] == ["case-a", "case-b"]
    assert [session_case_for(arm, index).case_id for index in range(5)] == [
        "case-a", "case-b", "case-a", "case-b", "case-a",
    ]


def test_round_robin_requires_multiple_explicit_cases() -> None:
    raw = raw_spec()
    raw["workload"]["session_assignment"] = "round_robin"
    with pytest.raises(ValidationError, match="at least two cases"):
        ExperimentSpec.model_validate(raw)


def test_arrival_schedule_is_explicit_and_validated() -> None:
    raw = raw_spec()
    assert ExperimentSpec.model_validate(raw).execution.arrival_schedule.value == "burst"
    raw["execution"].update({
        "arrival_schedule": "fixed_stagger", "stagger_interval_seconds": 0.25,
    })
    assert ExperimentSpec.model_validate(raw).execution.stagger_interval_seconds == 0.25
    raw["execution"]["stagger_interval_seconds"] = 0
    with pytest.raises(ValidationError, match="positive stagger"):
        ExperimentSpec.model_validate(raw)


def test_build_time_spans_reports_agent_and_sandbox_durations() -> None:
    spans = build_time_spans({
        "session_started": 1.0,
        "sandbox_create_start": 2.0,
        "tool_create_start": 2.0,
        "tool_ready": 3.5,
        "runtime_create_start": 3.0,
        "runtime_ready": 4.0,
        "sandbox_ready": 4.0,
        "agent_execution_start": 4.5,
        "final_agent_completion": 9.0,
        "validation_start": 9.0,
        "validation_end": 9.5,
        "output_hash_start": 9.5,
        "output_hash_end": 10.0,
        "sandbox_cleanup_start": 10.0,
        "sandbox_cleanup_end": 11.0,
        "session_finished": 11.0,
        "sandbox_create_gate_wait_start": 1.0,
        "sandbox_create_gate_acquired": 2.0,
        "recorded_time_spans": [{
            "name": "tool.operation", "role": "tool", "operation": "exec",
            "start_unix_s": 4.6, "end_unix_s": 4.8,
            "duration_seconds": 0.2,
        }],
        "lifecycle_timings": [{
            "role": "runtime", "operation": "checkpoint",
            "started_unix_s": 6.0, "completed_unix_s": 6.25,
            "started_monotonic_s": 100.0, "completed_monotonic_s": 100.25,
            "service_seconds": 0.25, "state_before": "running",
            "state_after": "swapped", "status": "ok",
        }],
    })
    by_name = {item["name"]: item for item in spans}
    assert by_name["agent"]["duration_seconds"] == 4.5
    assert by_name["sandbox.create"]["duration_seconds"] == 2.0
    assert by_name["sandbox.create.queue"]["duration_seconds"] == 1.0
    assert by_name["sandbox.cleanup"]["duration_seconds"] == 1.0
    assert by_name["tool.operation"]["role"] == "tool"
    checkpoint = by_name["sandbox.runtime.checkpoint"]
    assert checkpoint["duration_seconds"] == 0.25
    assert checkpoint["start_monotonic_s"] == 100.0
    assert checkpoint["end_monotonic_s"] == 100.25
    assert checkpoint["service_seconds"] == 0.25
    assert checkpoint["state_before"] == "running"
    assert checkpoint["state_after"] == "swapped"


def test_worker_provenance_separates_runtime_and_tool_artifacts(monkeypatch) -> None:
    monkeypatch.delenv("CUBE_SOURCE_DIR", raising=False)
    raw = raw_spec()
    raw["runtime"].update({
        "template_id": "runtime-id", "template_alias": None,
        "source_image_reference": "registry/runtime",
        "image_digest": "sha256:" + "a" * 64,
    })
    raw["sandbox"].update({
        "template_id": "tool-id", "template_alias": None,
        "source_image_reference": "registry/tool",
        "image_digest": "sha256:" + "b" * 64,
    })
    worker = object.__new__(ExperimentWorker)
    worker.spec = ExperimentSpec.model_validate(raw)
    provenance = worker._provenance()
    assert provenance["runtime_template_reference"] == "runtime-id"
    assert provenance["runtime_template_image_digest"] == "sha256:" + "a" * 64
    assert provenance["tool_template_reference"] == "tool-id"
    assert provenance["tool_template_image_digest"] == "sha256:" + "b" * 64
    assert provenance["template_reference"] == "tool-id"  # legacy key
    assert provenance["cubesandbox_deployment"] == "standalone"
    assert provenance["cubesandbox_commit"] == "unknown"
    assert "kubernetes_version" not in provenance


def test_arm_provenance_records_clawbox_memory_overcommit() -> None:
    raw = raw_spec()
    raw["execution"]["concurrency_levels"] = [60]
    raw["runtime"]["memory_mib"] = 2048
    raw["sandbox"]["memory_mib"] = 4096
    raw["resources"]["pool_memory_budget_mib"] = 16384
    spec = ExperimentSpec.model_validate(raw)
    arm = expand_matrix(spec)[0]

    scope = ExperimentWorker._arm_provenance(arm)["resource_scope"]

    assert scope["pair_memory_mib_per_agent"] == 6144
    assert scope["offered_provisioned_memory_mib"] == 368640
    assert scope["offered_to_policy_pool_ratio"] == 22.5
    assert scope["clawbox_memory_overcommit_enabled"] is True


def test_event_writer_assigns_joinable_wall_and_monotonic_timestamps(tmp_path: Path) -> None:
    path = tmp_path / "events.jsonl"
    writer = EventWriter(path)
    writer.write({"event": "agent_started", "session_id": "session-a"})
    writer.write({"event": "agent_finished", "session_id": "session-a"})
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines()]
    assert [row["sequence_no"] for row in rows] == [0, 1]
    assert all(row["schema_version"] == 1 for row in rows)
    assert all(row["session_id"] == "session-a" for row in rows)
    assert all(int(row["wall_time_ns"]) > 0 for row in rows)
    assert rows[0]["monotonic_time_ns"] <= rows[1]["monotonic_time_ns"]


def test_idempotent_cube_command_retries_transport_failure(monkeypatch) -> None:
    monkeypatch.setattr("clawbox.experiments.worker.time.sleep", lambda _: None)

    class Executor:
        calls = 0

        def execute(self, command: str, timeout_s: float) -> CommandResult:
            self.calls += 1
            if self.calls < 3:
                raise ConnectionError("transient")
            return CommandResult(0, command, "", timeout_s)

    executor = Executor()
    result = _execute_idempotent(executor, "test -f result.txt", 12)

    assert executor.calls == 3
    assert result.exit_code == 0


def test_formal_openclaw_replay_c40_artifact_is_loadable() -> None:
    spec = load_experiment(Path("examples/experiments/openclaw-cube-replay-c40.yaml"))
    actions = load_trace(Path("examples/traces/openclaw-cube-replay.jsonl"))
    assert spec.agent.driver.value == "openclaw"
    assert spec.execution.concurrency_levels == (40,)
    assert [policy.name for policy in spec.policies] == ["resident", "eager-reactive"]
    assert actions[0].output["tool_calls"][0]["function"]["name"] == "exec"
    assert json.loads(actions[0].output["tool_calls"][0]["function"]["arguments"])[
        "command"
    ].startswith("printf openclaw-cube-replay-ok")


def test_checked_in_baseline_matrices_are_schema_v2_and_plan_c40() -> None:
    paths = list(Path("examples/experiments").glob("openclaw*.yaml"))
    audits = audit_experiments(paths)
    assert len(audits) == len(paths)
    by_id = {str(item["experiment_id"]): item for item in audits}
    assert by_id["openclaw-cube-replay-c40"]["concurrency_levels"] == [40]
    assert by_id["openclaw-cube-replay-c60-overcommit"]["concurrency_levels"] == [60]
    assert all(item["tool_template"] != "sandbox-code" for item in audits)
    openclaw = by_id["openclaw-cube-replay-c40"]["artifact_provenance"]
    assert openclaw["runtime"]["template_id"] == "tpl-ec97143fa76e409981055c2f"
    assert openclaw["tool"]["template_id"] == "tpl-72f8a42d8fe746279d0bb80a"
    assert openclaw["runtime"]["image_digest"].startswith("sha256:")
    assert openclaw["tool"]["image_digest"].startswith("sha256:")


def test_openclaw_matrix_requires_immutable_runtime_and_tool_provenance(
    tmp_path: Path,
) -> None:
    raw = raw_spec()
    raw["agent"] = {"driver": "openclaw"}
    raw["inference"] = {
        "backend": "replay", "configuration": {"model": "recorded-model"},
    }
    path = tmp_path / "openclaw.yaml"
    path.write_text(yaml.safe_dump(raw), encoding="utf-8")
    with pytest.raises(ValueError, match="immutable template_id"):
        audit_experiments([path])

    raw["runtime"] = {
        "template_id": "runtime-id", "source_image_reference": "registry/runtime",
        "image_digest": "sha256:" + "a" * 64,
    }
    raw["sandbox"] = {
        "template_id": "tool-id", "source_image_reference": "registry/tool",
    }
    path.write_text(yaml.safe_dump(raw), encoding="utf-8")
    with pytest.raises(ValueError, match="missing image_digest"):
        audit_experiments([path])


def test_baseline_catalog_materializes_only_current_policy_tuples() -> None:
    from clawbox.experiments.baselines import ACTIVE_BASELINES
    assert BASELINES
    assert ACTIVE_BASELINES == (
        "tool-static-resident", "tool-p50-resident", "tool-p50-wait-reactive",
    )
    assert {name for name, baseline in BASELINES.items()
            if baseline.implementation_status == "implemented"} == set(ACTIVE_BASELINES)
    assert all(BASELINES[name].implementation_status == "deprecated"
               for name in BASELINES if name not in ACTIVE_BASELINES)
    for name, baseline in BASELINES.items():
        policy = baseline.as_policy()
        assert policy.name == name
        assert policy.admission == baseline.admission_policy
        assert policy.reclamation == baseline.reclamation_policy
    assert resolve_baseline("p90-elastic-pressure-checkpoint").as_policy().eviction.value == (
        "wait_aware_pressure"
    )
    oracle = resolve_baseline("tool-static-time-oracle-reactive").as_policy()
    assert oracle.eviction.value == "time_oracle"
    assert oracle.checkpoint_break_even_seconds == 4.0


def test_time_oracle_is_replay_only_and_requires_break_even() -> None:
    raw = raw_spec()
    raw["policies"] = [{
        "name": "time-oracle", "admission": "tool_static",
        "reclamation": "snapshot_pause", "eviction": "time_oracle",
        "restore": "reactive", "checkpoint_break_even_seconds": 4.0,
    }]
    raw["resources"]["static_tool_memory_mib"] = 256
    assert ExperimentSpec.model_validate(raw).policies[0].eviction.value == "time_oracle"

    raw["inference"]["backend"] = "api"
    with pytest.raises(ValidationError, match="time_oracle.*replay"):
        ExperimentSpec.model_validate(raw)

    raw["inference"]["backend"] = "replay"
    del raw["policies"][0]["checkpoint_break_even_seconds"]
    with pytest.raises(ValidationError, match="checkpoint_break_even_seconds"):
        ExperimentSpec.model_validate(raw)


def test_openclaw_cube_example_uses_native_tool_names() -> None:
    spec = load_experiment(Path("examples/experiments/openclaw-cube.yaml"))
    assert "cube_shell" not in spec.workload.cases[0].prompt
    assert "sandboxed exec" in spec.workload.cases[0].prompt


def test_worker_bounds_pair_creation_for_high_concurrency(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("CLAWBOX_SANDBOX_CREATE_CONCURRENCY", "3")
    assert ExperimentWorker._sandbox_create_limit(40) == 3
    assert ExperimentWorker._sandbox_create_limit(2) == 2
    monkeypatch.setenv("CLAWBOX_SANDBOX_CREATE_CONCURRENCY", "0")
    with pytest.raises(ValueError, match="positive integer"):
        ExperimentWorker._sandbox_create_limit(40)


def test_vm_startup_headroom_matches_the_arm_admission_policy() -> None:
    raw = raw_spec()
    raw["workload"]["repetitions"] = 1
    raw["execution"]["concurrency_levels"] = [1]
    raw["resources"].update(
        static_tool_memory_mib=512,
        non_command_tool_memory_mib=16,
        full_tool_memory_mib=4096,
        prediction_artifact="p50.json",
    )
    raw["policies"] = [{
        "name": "static", "admission": "tool_static", "reclamation": "resident",
        "eviction": "none", "restore": "none",
    }]
    static_arm, = expand_matrix(ExperimentSpec.model_validate(raw))
    assert ExperimentWorker._startup_headroom_mib(static_arm, None) == 512

    raw["policies"][0].update(name="p50", admission="tool_p50")
    p50_arm, = expand_matrix(ExperimentSpec.model_validate(raw))
    provider = SimpleNamespace(max_incremental_memory_mib=201.3)
    assert ExperimentWorker._startup_headroom_mib(p50_arm, provider) == 202


def test_v2_rejects_backend_transport_and_invalid_policy() -> None:
    raw = raw_spec()
    raw["sandbox"]["backend"] = "kubernetes"
    with pytest.raises(ValidationError, match="backend"):
        ExperimentSpec.model_validate(raw)
    raw = raw_spec()
    raw["policies"][0]["eviction"] = "eager"
    with pytest.raises(ValidationError, match="resident requires"):
        ExperimentSpec.model_validate(raw)


def test_openclaw_allows_managed_api_or_replay_and_keeps_secret_credentials_out_of_spec() -> None:
    raw = raw_spec()
    raw["agent"] = {"driver": "openclaw"}
    assert ExperimentSpec.model_validate(raw).inference.backend.value == "replay"
    raw["inference"] = {"backend": "api", "configuration": {"api_key": "do-not-store"}}
    with pytest.raises(ValidationError, match="environment variable"):
        ExperimentSpec.model_validate(raw)


def test_yaml_loader_and_v1_error(tmp_path: Path) -> None:
    path = tmp_path / "experiment.yaml"
    import yaml
    path.write_text(yaml.safe_dump(raw_spec()), encoding="utf-8")
    assert load_experiment(path).schema_version == 2
    path.write_text(json.dumps({"schema_version": 1}), encoding="utf-8")
    with pytest.raises(ValueError, match="migrate schema v1"):
        load_experiment(path)


def test_worker_only_reuses_successful_complete_arm(tmp_path: Path) -> None:
    result = tmp_path / "arm.json"
    marker = tmp_path / "arm.complete"
    marker.write_text("digest\n", encoding="ascii")
    result.write_text(json.dumps({"arm": {"spec_digest": "digest"}, "status": "failed"}))
    assert not ExperimentWorker._completed(result, marker, "digest")
    result.write_text(json.dumps({"arm": {"spec_digest": "digest"}, "status": "succeeded"}))
    assert ExperimentWorker._completed(result, marker, "digest")
