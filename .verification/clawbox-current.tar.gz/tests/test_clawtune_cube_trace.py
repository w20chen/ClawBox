from __future__ import annotations

import hashlib
import json

from clawbox.experiments.clawtune_trace import ClawTuneTraceWriter
from clawbox.replay.lifecycle import CommandResult
from clawbox.tuning.dataset import build_joined_dataset


def test_cube_trace_is_exactly_joinable_and_trusted(tmp_path):
    writer = ClawTuneTraceWriter(
        tmp_path, run_id="run-1", session_id="session-1",
        repo_fingerprint="github.com/acme/repo",
    )
    execution_id = writer.record(
        "pytest -q", CommandResult(0, "ok\n", "", 1.25), execution_id="call-123",
        bridge_record={
            "execution_id": "call-123",
            "command_sha256": hashlib.sha256(b"pytest -q").hexdigest(),
            "duration_ms": 1250, "exit_code": 0, "telemetry_state": "complete",
        },
        artifacts={"cgroup_resource_v1": json.dumps({
            "schema": "cgroup_resource_v1", "execution_id": "call-123",
            "source": "cgroup-v2", "cpu_time_s": 0.5,
            "cgroup_path": "/sys/fs/cgroup/clawbox/call-123", "sampling_quality": "valid",
            "cpu_utilization_avg_cores": 0.4,
            "memory_rss_peak_bytes": 4096, "memory_rss_after_bytes": 2048,
            "memory_baseline_bytes": 8192, "memory_total_peak_bytes": 12288,
            "memory_extra_peak_bytes": 4096,
            "memory_measurement": "guest_memtotal_minus_memavailable",
            "memory_environment_id": "cube:task:boot", "memory_eligible": True,
        })},
    )

    writer.close()
    assert writer.trace_path.is_file()
    assert list((tmp_path / "traces").glob("*.jsonl")) == [writer.trace_path]
    joined, trusted = build_joined_dataset(
        tmp_path / "traces", tmp_path / "tool-bridge.jsonl",
    )
    assert joined.join_rate == 1.0
    assert len(trusted) == 1
    assert trusted[0].execution_id == execution_id
    assert trusted[0].tool_name == "exec"
    assert trusted[0].command == "pytest -q"
    assert trusted[0].duration_sec == 1.25
    assert trusted[0].rss_peak_bytes == 4096
    assert trusted[0].cgroup is not None
    assert trusted[0].cgroup.source == "cgroup-v2"
    assert trusted[0].memory_extra_peak_bytes == 4096
    assert trusted[0].memory_measurement == "guest_memtotal_minus_memavailable"
    assert trusted[0].memory_eligible is True
    assert execution_id == "call-123"

    bridge = json.loads((tmp_path / "tool-bridge.jsonl").read_text().strip())
    assert bridge["execution_id"] == trusted[0].execution_id


def test_worker_preserves_original_clause_artifact(tmp_path):
    raw = '{ "schema_version": 2, "calls": [{"tool_call_id": "exec-a"}] }\n'
    writer = ClawTuneTraceWriter(tmp_path, run_id="run", session_id="session")
    try:
        writer.record("true", CommandResult(0, "", "", 0.1), execution_id="exec-a",
                      artifacts={"clause_telemetry_v2": raw})
    finally:
        writer.close()
    assert (tmp_path / "traces/tool-resource/clause-telemetry-exec-a.json").read_bytes() == raw.encode()
