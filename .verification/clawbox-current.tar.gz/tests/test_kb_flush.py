"""Cross-check the runtime kb-flush.py against the canonical tuning pipeline.

The runtime flush script must ship observations the control-plane projector
accepts: same normalized fields, same HMAC canonical payload.  This test feeds
the same synthetic span/bridge JSONL through both paths and asserts they agree.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
import pytest

from clawbox.tuning.join import join_trace_and_bridge
from clawbox.tuning.schema import BridgeRecord, span_end_to_observation
from clawbox.tuning.validate import sign_observation
from clawbox.tuning.native import NativeTelemetryManifest, sign_native_manifest

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"


def load_kb_flush():
    spec = importlib.util.spec_from_file_location("kb_flush", SCRIPTS / "kb-flush.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def span_end(execution_id, *, command="python -m pytest -q", duration_sec=5.0,
             exit_code=0, coverage=1.0, seq=0, repo="github.com/acme/foo"):
    wall_ns = int(1_700_000_000_000_000_000)
    return {
        "schema_version": 6,
        "record_type": "span_end",
        "trace_id": f"trace-{execution_id}",
        "span_id": f"span-{execution_id}",
        "parent_span_id": None,
        "session_id": None,
        "run_id": f"run-{execution_id}",
        "agent_id": "agent-1",
        "sequence_no": seq,
        "kind": "tool",
        "name": "exec",
        "wall_time_ns": str(wall_ns),
        "monotonic_time_ns": "0",
        "duration_ns": str(int(duration_sec * 1e9)),
        "duration_sec": str(duration_sec),
        "repo": repo,
        "status": {"code": "ok", "message": None},
        "output": {"exit_code": exit_code, "result": None},
        "execution": {
            "mode": "in_process_or_runtime_managed",
            "execution_id": execution_id,
            "requested_command": command,
            "payload_command": command,
            "command_digest": f"sha256-{execution_id[-8:]}",
        },
        "resources": {
            "attribution_status": "attributed",
            "scope": "cgroup",
            "quality": "complete",
            "monitor_start_wall_time_ns": str(wall_ns - int(duration_sec * 1e9)),
            "monitor_end_wall_time_ns": str(wall_ns),
            "coverage_ratio": coverage,
            "coverage_reason": "full_window",
            "action_duration_ns": str(int(duration_sec * 1e9)),
            "cpu_time_s": duration_sec * 1.5,
            "cpu_utilization_avg_cores": 1.5,
            "rss_peak_bytes": 1024**2,
            "memory_rss_bytes_after": 1024**2,
            "sampling_interval_ms": 100,
        },
    }


def bridge(execution_id, *, duration_ms=5000, exit_code=0, stdout_bytes=128,
           stderr_bytes=0):
    return {
        "timestamp": "2026-08-19T00:00:00Z",
        "cell_id": None,
        "task_id": None,
        "execution_id": execution_id,
        "execution_source": "runtime-envelope",
        "command_sha256": f"sha256-{execution_id[-8:]}",
        "command_bytes": 64,
        "duration_ms": duration_ms,
        "exit_code": exit_code,
        "timed_out": False,
        "stdout_bytes": stdout_bytes,
        "stderr_bytes": stderr_bytes,
        "output_truncated": False,
    }


def reliable_pmu(execution_id: str) -> dict:
    values = {
        "cycles": ("PERF_COUNT_HW_CPU_CYCLES", 2_000_000),
        "instructions": ("PERF_COUNT_HW_INSTRUCTIONS", 1_000_000),
        "llc_read_misses": ("PERF_COUNT_HW_CACHE_LL:READ:MISS", 1_000),
        "llc_read_accesses": ("PERF_COUNT_HW_CACHE_LL:READ:ACCESS", 10_000),
    }
    events = {
        name: {
            "supported": True, "semantics": semantics, "raw_count": raw,
            "scaled_count": float(raw), "time_enabled_ns": 1_000_000,
            "time_running_ns": 1_000_000, "running_ratio": 1.0, "error": None,
        }
        for name, (semantics, raw) in values.items()
    }
    return {
        "schema": "pmu_profile_v1", "execution_id": execution_id,
        "source": "perf_event_open", "mode": "counting",
        "scope": "task-inherit-enable-on-exec", "root_pid": 42,
        "started_at": 1.0, "ended_at": 2.0, "architecture": "aarch64",
        "pmu_devices": ["armv8_pmuv3_0"], "llc_semantics": "LL read",
        "llc_semantics_confirmed": True, "events": events,
        "derived": {"ipc": 0.5, "llc_mpki": 1.0, "llc_miss_rate": 0.1},
        "coverage": {
            "status": "reliable", "reason": "execution_exited",
            "running_ratio": 1.0, "multiplexed": False,
            "kernel_included": True, "root_and_future_descendants": True,
            "eligible_for_kb": True,
        },
        "collector_errors": [],
    }


def test_join_matches_canonical_pipeline(tmp_path):
    kb_flush = load_kb_flush()
    span_records = [span_end("exec-0001"), span_end("exec-0002", exit_code=1)]
    bridge_records = [bridge("exec-0001"), bridge("exec-0002", exit_code=1)]

    # Canonical path (clawbox.tuning).
    canonical = join_trace_and_bridge(span_records, [BridgeRecord.model_validate(b) for b in bridge_records])
    canonical_ids = {obs.execution_id for obs in canonical.joined}
    assert canonical.join_rate == 1.0

    # Runtime script path.
    trace_dir = tmp_path / "traces"
    trace_dir.mkdir()
    (trace_dir / "run.jsonl").write_text(
        "\n".join(__import__("json").dumps(r) for r in span_records) + "\n", encoding="utf-8"
    )
    (trace_dir / "tool-bridge.jsonl").write_text(
        "\n".join(__import__("json").dumps(b) for b in bridge_records) + "\n", encoding="utf-8"
    )
    joined = kb_flush.join_observations(trace_dir, trace_dir / "tool-bridge.jsonl", repo="github.com/acme/foo")
    joined_ids = {obs["execution_id"] for obs in joined}
    assert joined_ids == canonical_ids
    assert len(joined) == 2
    by_id = {obs["execution_id"]: obs for obs in joined}
    assert by_id["exec-0002"]["exit_code"] == 1
    assert by_id["exec-0002"]["status_code"] == "error"
    assert by_id["exec-0001"]["status_code"] == "ok"


def test_runtime_and_canonical_duration_fallback_use_nanoseconds(tmp_path):
    kb_flush = load_kb_flush()
    record = span_end("exec-duration-fallback", duration_sec=5.0)
    record.pop("duration_sec")
    record.pop("duration_ns")

    canonical = span_end_to_observation(record)
    runtime = kb_flush.span_end_to_obs(record)

    assert canonical is not None
    assert runtime is not None
    assert canonical.duration_sec == 5.0
    assert runtime["duration_sec"] == 5.0


def test_cgroup_artifact_overrides_span_estimates(tmp_path):
    """The Tool-VM collector artifact must replace the span-side proxy values
    (cpu/rss/quality) before the observation is signed and trusted."""
    kb_flush = load_kb_flush()
    execution_id = "exec-0001"
    span_records = [span_end(execution_id, duration_sec=5.0)]
    bridge_records = [bridge(execution_id)]

    trace_dir = tmp_path / "traces"
    trace_dir.mkdir()
    (trace_dir / "run.jsonl").write_text(
        "\n".join(__import__("json").dumps(r) for r in span_records) + "\n", encoding="utf-8"
    )
    (trace_dir / "tool-bridge.jsonl").write_text(
        "\n".join(__import__("json").dumps(b) for b in bridge_records) + "\n", encoding="utf-8"
    )
    resource_dir = trace_dir / "tool-resource"
    resource_dir.mkdir()
    (resource_dir / f"cgroup-resource-{execution_id}.json").write_text(
        __import__("json").dumps({
            "schema": "cgroup_resource_v1",
            "execution_id": execution_id,
            "source": "cgroup-v2",
            "monitor_source": "cgroup-v2",
            "attribution_source": "tool-bridge-pgid",
            "cpu_time_s": 0.123,
            "cpu_utilization_avg_cores": 0.12,
            "memory_rss_peak_bytes": 42 * 1024 * 1024,
            "sampling_interval_ms": 100,
            "sampling_point_count": 7,
            "sampling_quality": "valid",
        }) + "\n", encoding="utf-8"
    )
    joined = kb_flush.join_observations(trace_dir, trace_dir / "tool-bridge.jsonl", repo="github.com/acme/foo")
    assert len(joined) == 1
    obs = joined[0]
    assert obs["cpu_time_sec"] == 0.123  # real value, not the span's 7.5
    assert obs["rss_peak_bytes"] == 42 * 1024 * 1024  # not the span's 1 MiB
    assert obs["source"] == "cgroup-v2"
    assert obs["resource_source"] == "cgroup-v2"
    assert obs["collection_quality"] == "valid"
    assert obs["trusted"] is True
    # Signing happens over the final (real) values, so the HMAC must match
    # a canonical payload built from those same values.
    canonical = {key: obs.get(key) for key in kb_flush.SIGNED_FIELDS}
    assert kb_flush.canonical_payload(canonical) == kb_flush.canonical_payload(obs)
    assert kb_flush.sign_observation(obs, "secret") == kb_flush.sign_observation(
        {**obs, "cpu_time_sec": 0.123, "rss_peak_bytes": 42 * 1024 * 1024,
         "collection_quality": "valid"}, "secret")


def test_read_cgroup_artifacts_both_layouts(tmp_path):
    kb_flush = load_kb_flush()
    trace_dir = tmp_path / "traces"
    resource_dir = trace_dir / "tool-resource"
    resource_dir.mkdir(parents=True)
    (resource_dir / "cgroup-resource-exec-a.json").write_text(
        '{"schema":"cgroup_resource_v1","execution_id":"exec-a","source":"process-tree","cpu_time_s":1.5}\n',
        encoding="utf-8",
    )
    (trace_dir / "cgroup-resource-exec-b.json").write_text(
        '{"schema":"cgroup_resource_v1","execution_id":"exec-b","source":"process-tree","cpu_time_s":2.5}\n',
        encoding="utf-8",
    )
    (trace_dir / "cgroup-resource-bad.json").write_text("{not json\n", encoding="utf-8")
    (resource_dir / "pmu-profile-exec-a.json").write_text(
        '{"schema":"pmu_profile_v1","execution_id":"exec-a"}\n',
        encoding="utf-8",
    )
    artifacts = kb_flush.read_cgroup_artifacts(trace_dir)
    assert set(artifacts) == {"exec-a", "exec-b"}
    assert artifacts["exec-a"]["cpu_time_s"] == 1.5
    assert artifacts["exec-b"]["source"] == "process-tree"


def test_resource_diagnostics_counts_sources_quality_and_fallback(tmp_path):
    kb_flush = load_kb_flush()
    resource_dir = tmp_path / "tool-resource"
    resource_dir.mkdir()
    (resource_dir / "cgroup-resource-a.json").write_text(
        '{"execution_id":"a","source":"cgroup-v2","sampling_quality":"valid",'
        '"network_source":"unavailable","fallback_used":false,"collector_errors":[]}\n',
        encoding="utf-8",
    )
    (resource_dir / "cgroup-resource-b.json").write_text(
        '{"execution_id":"b","source":"process-tree","sampling_quality":"degraded",'
        '"network_source":"unavailable","fallback_used":true,'
        '"collector_errors":["cgroup setup failed"]}\n',
        encoding="utf-8",
    )

    assert kb_flush.resource_diagnostics(tmp_path) == {
        "artifacts": 2,
        "sources": {"cgroup-v2": 1, "process-tree": 1},
        "qualities": {"degraded": 1, "valid": 1},
        "network_sources": {"unavailable": 2},
        "fallback_count": 1,
        "collector_error_count": 1,
    }


def test_signature_matches_canonical(tmp_path):
    kb_flush = load_kb_flush()
    record = span_end("exec-0003")
    obs_dict = kb_flush.span_end_to_obs(record)
    assert obs_dict is not None
    # The runtime signature must equal the control-plane sign_observation over
    # the same observation parsed as a ToolObservation.
    canonical_obs = span_end_to_observation(record)
    assert canonical_obs is not None
    secret = "ingest-secret"
    runtime_sig = kb_flush.sign_observation(obs_dict, secret)
    canonical_sig = sign_observation(canonical_obs, secret)
    assert runtime_sig == canonical_sig


def test_reliable_pmu_signature_matches_canonical_online_path() -> None:
    kb_flush = load_kb_flush()
    record = span_end("exec-pmu")
    record["resources"]["pmu"] = reliable_pmu("exec-pmu")

    runtime = kb_flush.span_end_to_obs(record)
    canonical = span_end_to_observation(record)

    assert runtime is not None and canonical is not None
    assert runtime["pmu_eligible_for_kb"] is True
    assert (runtime["ipc"], runtime["llc_mpki"], runtime["llc_miss_rate"]) == (
        0.5, 1.0, 0.1,
    )
    assert kb_flush.sign_observation(runtime, "secret") == sign_observation(
        canonical, "secret"
    )


@pytest.mark.parametrize("mutation", ["multiplexed", "kernel", "counter", "identity"])
def test_runtime_and_online_reject_invalid_pmu_consistently(mutation):
    record = span_end("exec-pmu")
    pmu = reliable_pmu("exec-pmu")
    if mutation == "multiplexed":
        pmu["coverage"]["multiplexed"] = True
    elif mutation == "kernel":
        pmu["coverage"]["kernel_included"] = False
    elif mutation == "counter":
        pmu["events"]["cycles"]["time_running_ns"] = 500_000
    else:
        pmu["execution_id"] = "another-execution"
    record["resources"]["pmu"] = pmu
    runtime = load_kb_flush().span_end_to_obs(record)
    canonical = span_end_to_observation(record)
    assert runtime["pmu_eligible_for_kb"] is canonical.pmu_eligible_for_kb is False
    assert runtime["ipc"] is canonical.ipc is None


def test_reliable_pmu_reaches_native_clawtune_snapshot():
    from clawbox.tuning.clawtune import build_clawtune_kb_snapshot
    record = span_end("exec-pmu")
    record["resources"]["pmu"] = reliable_pmu("exec-pmu")
    observation = span_end_to_observation(record)
    snapshot = build_clawtune_kb_snapshot([observation], "github.com/acme/foo")
    assert snapshot["schema"] == "runtime_tool_resource_kb_v4"
    for target, expected in {"pmu_ipc": 0.5, "pmu_llc_mpki": 1.0, "pmu_llc_miss_rate": 0.1}.items():
        nodes = snapshot["public"][target]
        assert nodes and all(values == [expected] for _, _, values in nodes)
    observation.pmu_eligible_for_kb = False
    excluded = build_clawtune_kb_snapshot([observation], "github.com/acme/foo")
    assert not excluded["public"]["pmu_ipc"]


def test_post_batch_binds_signature_to_tenant_and_repo(monkeypatch):
    kb_flush = load_kb_flush()
    observation = kb_flush.span_end_to_obs(span_end("exec-scoped"))
    assert observation is not None
    captured = {}

    class Response:
        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return False

        @staticmethod
        def read():
            return b'{"accepted":1}'

    def fake_urlopen(request, timeout):
        captured["request"] = request
        captured["timeout"] = timeout
        return Response()

    monkeypatch.setattr(kb_flush.urllib.request, "urlopen", fake_urlopen)
    result = kb_flush.post_batch(
        "http://kb.example",
        "service-token",
        "tenant-a",
        "github.com/acme/foo",
        [observation],
        "ingest-secret",
    )

    body = __import__("json").loads(captured["request"].data)
    assert result == {"accepted": 1}
    assert captured["timeout"] == 30.0
    assert body["tenant_id"] == "tenant-a"
    assert body["repo_fingerprint"] == "github.com/acme/foo"
    assert body["observations"][0]["signature"] == kb_flush.sign_observation(
        observation,
        "ingest-secret",
        "tenant-a",
        "github.com/acme/foo",
    )


def test_unmatched_span_is_dropped(tmp_path):
    kb_flush = load_kb_flush()
    trace_dir = tmp_path / "traces"
    trace_dir.mkdir()
    # Span has no bridge record -> not joinable -> dropped, never trusted.
    (trace_dir / "run.jsonl").write_text(__import__("json").dumps(span_end("orphan-0001")) + "\n", encoding="utf-8")
    (trace_dir / "tool-bridge.jsonl").write_text("", encoding="utf-8")
    joined = kb_flush.join_observations(trace_dir, trace_dir / "tool-bridge.jsonl", repo="github.com/acme/foo")
    assert joined == []


def test_native_manifest_preserves_and_signs_raw_artifacts(tmp_path):
    kb_flush = load_kb_flush()
    root = tmp_path / "tool-resource"
    root.mkdir()
    clause = {
        "version": 2,
        "mode": "clause",
        "calls": [{
            "tool_call_id": "exec-a",
            "eligible_for_kb": True,
            "clauses": [{"availability": {"latency": "ok"}}],
        }],
    }
    cgroup = {"schema": "cgroup_resource_v1", "execution_id": "exec-a"}
    clause_raw = (__import__("json").dumps(clause, indent=2) + "\n").encode()
    cgroup_raw = (__import__("json").dumps(cgroup, separators=(",", ":")) + "\n").encode()
    (root / "telemetry-exec-a.json").write_bytes(clause_raw)
    (root / "cgroup-resource-exec-a.json").write_bytes(cgroup_raw)

    raw = kb_flush.build_native_manifest(
        tmp_path,
        tenant="tenant-a",
        repo="github.com/acme/foo",
        run_id="run-a",
        attempt_id="attempt-a",
        cell_id="cell-a",
        collector_version="guest-collector-v1",
        clawtune_revision="76eab6fa5c6333f4e80901c030f10cab0e4ce605",
    )
    assert raw is not None
    manifest = NativeTelemetryManifest.model_validate(raw)
    assert {item.raw_bytes() for item in manifest.artifacts} == {clause_raw, cgroup_raw}
    assert kb_flush.sign_native_manifest(raw, "secret") == sign_native_manifest(
        manifest, "secret"
    )

    # An unpaired fail-open cgroup artifact remains in the trace archive but
    # must not poison the valid native training batch.
    orphan = {"schema": "cgroup_resource_v1", "execution_id": "exec-failopen"}
    (root / "cgroup-resource-exec-failopen.json").write_text(
        __import__("json").dumps(orphan), encoding="utf-8"
    )
    rebuilt = kb_flush.build_native_manifest(
        tmp_path, tenant="tenant-a", repo="github.com/acme/foo", run_id="run-a",
        attempt_id="attempt-a", cell_id="cell-a", collector_version="guest-collector-v1",
        clawtune_revision="76eab6fa5c6333f4e80901c030f10cab0e4ce605",
    )
    assert {item["execution_id"] for item in rebuilt["artifacts"]} == {"exec-a"}
    audit = kb_flush.build_native_manifest(
        tmp_path, tenant="tenant-a", repo="github.com/acme/foo", run_id="run-a",
        attempt_id="attempt-a", cell_id="cell-a", collector_version="guest-collector-v1",
        clawtune_revision="76eab6fa5c6333f4e80901c030f10cab0e4ce605", eligible_only=False,
    )
    assert {item["execution_id"] for item in audit["artifacts"]} == {
        "exec-a", "exec-failopen"
    }

    ineligible = {
        "version": 2,
        "mode": "clause",
        "calls": [{
            "tool_call_id": "exec-no-latency",
            "eligible_for_kb": True,
            "clauses": [{"availability": {"latency": "unavailable"}}],
        }],
    }
    (root / "clause-telemetry-exec-no-latency.json").write_text(
        __import__("json").dumps(ineligible), encoding="utf-8"
    )
    (root / "cgroup-resource-exec-no-latency.json").write_text(
        __import__("json").dumps({
            "schema": "cgroup_resource_v1", "execution_id": "exec-no-latency"
        }), encoding="utf-8"
    )
    rebuilt = kb_flush.build_native_manifest(
        tmp_path, tenant="tenant-a", repo="github.com/acme/foo", run_id="run-a",
        attempt_id="attempt-a", cell_id="cell-a", collector_version="guest-collector-v1",
        clawtune_revision="76eab6fa5c6333f4e80901c030f10cab0e4ce605",
    )
    assert {item["execution_id"] for item in rebuilt["artifacts"]} == {"exec-a"}
    audit = kb_flush.build_native_manifest(
        tmp_path, tenant="tenant-a", repo="github.com/acme/foo", run_id="run-a",
        attempt_id="attempt-a", cell_id="cell-a", collector_version="guest-collector-v1",
        clawtune_revision="76eab6fa5c6333f4e80901c030f10cab0e4ce605", eligible_only=False,
    )
    assert {item["execution_id"] for item in audit["artifacts"]} == {
        "exec-a", "exec-failopen", "exec-no-latency"
    }
