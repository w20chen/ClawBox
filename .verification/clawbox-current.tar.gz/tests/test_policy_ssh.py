from __future__ import annotations

import base64
import hashlib
import io
import importlib.util
import json
import subprocess
import sys
import threading
import time
from pathlib import Path

import pytest


_SPEC = importlib.util.spec_from_file_location(
    "clawbox_policy_ssh", Path(__file__).parents[1] / "scripts" / "clawbox-policy-ssh.py",
)
assert _SPEC is not None and _SPEC.loader is not None
policy_ssh = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(policy_ssh)


def test_post_accepts_sanitizer_safe_policy_auth(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_AUTH", "auth-token")
    monkeypatch.delenv("CLAWBOX_POLICY_CONTROL_TOKEN", raising=False)
    requests = []

    def urlopen(request, timeout):
        requests.append((request, timeout))
        return io.BytesIO(b'{"status":"ok"}')

    monkeypatch.setattr(policy_ssh.urllib.request, "urlopen", urlopen)

    assert policy_ssh._post("/v1/tool/admit", {"x": 1}, attempts=1) == {"status": "ok"}
    assert requests[0][0].get_header("Authorization") == "Bearer auth-token"


def _argv(tool_name: str = "exec") -> list[str]:
    metadata = json.dumps(
        {"v": 1, "execution_id": "exec-a", "tool_name": tool_name},
        separators=(",", ":"),
    )
    return [
        "-F", "/state/openclaw/ssh/config", "openclaw-sandbox",
        policy_ssh.PREFIX + metadata + "\nprintf /run/identity",
    ]


def test_clawtune_prediction_crosses_ssh_envelope(monkeypatch: pytest.MonkeyPatch) -> None:
    prediction = {"schema_version": "call_load.v2", "scope": "tool_call",
                  "targets": {"memory_extra_peak_bytes": {"status": "available", "p90": 1024}}}
    header = {"v": 1, "execution_id": "exec-a", "tool_name": "exec",
              "call_prediction": prediction}
    encoded = base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip("=")
    argv = ["tool-a", policy_ssh.PREFIX + "b64:" + encoded + "\ntrue"]
    parsed, _command, profile = policy_ssh._envelope(argv)
    assert profile == "true"
    assert parsed["call_prediction"] == prediction


def test_policy_route_is_injected_per_invocation_without_replacing_ssh_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_AUTH", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[tuple[str, dict]] = []

    def post(path: str, body: dict, *, attempts: int) -> dict:
        posted.append((path, body))
        if path.endswith("/admit"):
            return {
                "decision": "ADMIT", "sandbox_id": "tool-a", "epoch": 9,
                "container_port": 2222, "host": "192.0.2.20", "port": 20020,
            }
        return {"status": "COMPLETED"}

    class Child:
        def wait(self) -> int:
            return 0

    launched: list[list[str]] = []
    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", lambda argv, **_kwargs: (launched.append(argv) or Child()))
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", *_argv()])

    assert policy_ssh.main() == 0
    assert len(launched) == 1
    command = launched[0]
    assert command[0] == "/fake/ssh"
    assert "-F" in command and "/state/openclaw/ssh/config" in command
    assert "-o" in command
    assert "HostName=192.0.2.20" in command
    assert "Port=20020" in command
    assert "HostKeyAlias=clawbox-tool-tool-a" in command
    assert command[-2] == "openclaw-sandbox"
    assert command[-1].endswith("\nprintf /run/identity\n} 2>&1")
    assert [path for path, _body in posted] == ["/v1/tool/admit", "/v1/tool/complete"]
    completion = posted[-1][1]
    assert completion["endpoint_sandbox_id"] == "tool-a"
    assert completion["endpoint_epoch"] == 9
    assert completion["ssh_reaped_at"] <= completion["execution_completed_at"]


def test_policy_route_replaces_stale_explicit_port_and_route_options() -> None:
    argv = [
        "-i", "/state/id", "-p", "20009",
        "-o", "StrictHostKeyChecking=yes",
        "-o", "HostName=192.0.2.9",
        "-oPort=20009",
        "-o", "HostKeyAlias=stale-tool",
        "executor@192.0.2.9", "true",
    ]
    route = {
        "host": "192.0.2.20", "port": 20020,
        "host_key_alias": "clawbox-tool-tool-a",
    }

    command = policy_ssh._ssh_args_for_route(argv, route)

    assert "-p" not in command
    assert "20009" not in command
    assert "HostName=192.0.2.9" not in command
    assert "Port=20009" not in command
    assert "HostKeyAlias=stale-tool" not in command
    assert "StrictHostKeyChecking=yes" in command
    assert "HostName=192.0.2.20" in command
    assert "Port=20020" in command
    assert "HostKeyAlias=clawbox-tool-tool-a" in command
    assert command[-2:] == ["executor@192.0.2.9", "true"]


@pytest.mark.parametrize(
    "tool_name", ("exec", "process", "read", "write", "edit", "apply_patch"),
)
def test_each_tool_vm_operation_keeps_its_native_policy_operation(
    monkeypatch: pytest.MonkeyPatch, tool_name: str,
) -> None:
    """Every OpenClaw Tool-VM operation must carry the execution envelope."""
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[tuple[str, dict]] = []

    def post(path: str, body: dict, *, attempts: int) -> dict:
        posted.append((path, body))
        if path.endswith("/admit"):
            return {
                "decision": "ADMIT", "sandbox_id": "tool-a", "epoch": 1,
                "container_port": 2222, "host": "192.0.2.20", "port": 20020,
            }
        return {"status": "COMPLETED"}

    class Child:
        def wait(self) -> int:
            return 0

    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", lambda _argv, **_kwargs: Child())
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", *_argv(tool_name)])

    assert policy_ssh.main() == 0
    assert posted[0][1]["operation"] == tool_name
    assert posted[1][1]["operation"] == tool_name


def test_unrecognized_unenveloped_ssh_is_rejected_before_subprocess(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_POLICY_REQUIRE_ENVELOPE", "1")
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", "tool-a", "true"])

    def fail_spawn(_argv: list[str]):
        raise AssertionError("unenveloped Agent operation reached OpenSSH")

    monkeypatch.setattr(policy_ssh.subprocess, "call", fail_spawn)
    assert policy_ssh.main() == 125


def test_openclaw_filesystem_ssh_gets_admission_and_bridge_envelope(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_POLICY_REQUIRE_ENVELOPE", "1")
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[tuple[str, dict]] = []
    launched: list[list[str]] = []

    def post(path: str, body: dict, *, attempts: int) -> dict:
        posted.append((path, body))
        if path.endswith("/admit"):
            return {
                "decision": "ADMIT", "sandbox_id": "tool-a", "epoch": 3,
                "container_port": 2222, "host": "192.0.2.20", "port": 20020,
            }
        return {"status": "COMPLETED"}

    class Child:
        def wait(self) -> int:
            return 0

    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(
        policy_ssh.subprocess, "Popen", lambda argv, **_kwargs: (launched.append(argv) or Child()),
    )
    remote = "/bin/sh -c 'printf data' openclaw-sandbox-fs /workspace/a"
    monkeypatch.setattr(sys, "argv", [
        "clawbox-policy-ssh.py", "-F", "/tmp/config", "-T",
        "openclaw-sandbox", remote,
    ])

    assert policy_ssh.main() == 0
    request = posted[0][1]
    assert request["operation"] == "filesystem"
    assert request["execution_scope"] == "agent-tool"
    assert request["runtime_trace_expected"] is False
    assert request["execution_id"]
    assert launched[0][-1].startswith(policy_ssh.PREFIX + "b64:")
    assert launched[0][-1].endswith(remote)
    header = launched[0][-1].split("\n", 1)[0].removeprefix(policy_ssh.PREFIX + "b64:")
    bridge_metadata = json.loads(base64.urlsafe_b64decode(header + "=" * (-len(header) % 4)))
    encoded_profile = bridge_metadata["profile_command_b64"]
    assert base64.urlsafe_b64decode(
        encoded_profile + "=" * (-len(encoded_profile) % 4)
    ).decode() == remote
    assert posted[1][1]["execution_id"] == request["execution_id"]


def test_openclaw_backend_preparation_is_admitted_but_not_counted_as_agent_tool(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    argv = ["-F", "/tmp/config", "-T", "openclaw-sandbox", "pwd"]
    parsed = policy_ssh._openclaw_unenveloped(argv)
    assert parsed is not None
    metadata, command, profile_command = parsed
    assert command == "pwd"
    assert profile_command == "pwd"
    assert metadata["tool_name"] == "ssh_backend_maintenance"
    assert metadata["execution_scope"] == "backend-maintenance"
    assert argv[-1].startswith(policy_ssh.PREFIX)


def test_wrapped_exec_admits_logical_digest_and_preserves_effective_command(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[tuple[str, dict]] = []
    launched: list[list[str]] = []

    def post(path: str, body: dict, *, attempts: int) -> dict:
        posted.append((path, body))
        if path.endswith("/admit"):
            return {
                "decision": "ADMIT", "sandbox_id": "tool-a", "epoch": 4,
                "container_port": 2222, "host": "192.0.2.20", "port": 20020,
            }
        return {"status": "COMPLETED"}

    class Child:
        def wait(self) -> int:
            return 0

    logical = "printf logical"
    logical_b64 = base64.urlsafe_b64encode(logical.encode()).decode().rstrip("=")
    metadata = base64.urlsafe_b64encode(json.dumps({
        "v": 1,
        "execution_id": "exec-wrapped",
        "tool_name": "exec",
        "profile_command_b64": logical_b64,
    }, separators=(",", ":")).encode()).decode().rstrip("=")
    wrapper = (
        "env PATH=/state/session-a/bin CLAWTUNE_EXECUTION_ID=exec-wrapped "
        "/bin/sh -c 'cd /workspace && "
    )
    remote = wrapper + policy_ssh.PREFIX + "b64:" + metadata + "\n" + logical + "'"
    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(
        policy_ssh.subprocess, "Popen", lambda argv, **_kwargs: (launched.append(argv) or Child()),
    )
    monkeypatch.setattr(sys, "argv", [
        "clawbox-policy-ssh.py", "-F", "/tmp/config", "openclaw-sandbox", remote,
    ])

    assert policy_ssh.main() == 0
    request = posted[0][1]
    effective = "{\n" + wrapper + logical + "'\n} 2>&1"
    assert request["command_sha256"] == hashlib.sha256(logical.encode()).hexdigest()
    assert request["effective_command_sha256"] == hashlib.sha256(effective.encode()).hexdigest()
    launched_remote = launched[0][-1]
    assert launched_remote.startswith("{\n" + wrapper + policy_ssh.PREFIX + "b64:")
    header = launched_remote.split(policy_ssh.PREFIX + "b64:", 1)[1].split("\n", 1)[0]
    bridge_metadata = json.loads(base64.urlsafe_b64decode(header + "=" * (-len(header) % 4)))
    encoded_profile = bridge_metadata["profile_command_b64"]
    assert base64.urlsafe_b64decode(
        encoded_profile + "=" * (-len(encoded_profile) % 4)
    ).decode() == logical
    assert launched_remote.endswith("\n" + logical + "'\n} 2>&1")


def test_policy_rejects_cross_tool_endpoint_before_spawning_ssh(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[str] = []

    def post(path: str, _body: dict, *, attempts: int) -> dict:
        posted.append(path)
        return {
            "decision": "ADMIT", "sandbox_id": "tool-b", "epoch": 1,
            "container_port": 2222, "host": "192.0.2.21", "port": 20021,
        }

    def fail_spawn(_argv: list[str]):
        raise AssertionError("cross-Tool route reached subprocess")

    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", fail_spawn)
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", *_argv()])

    assert policy_ssh.main() == 125
    assert posted == ["/v1/tool/admit"]


def test_policy_rejects_duplicate_admission_before_spawning_ssh(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Idempotent admission must not duplicate the Tool side effect."""
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[str] = []

    def post(path: str, _body: dict, *, attempts: int) -> dict:
        posted.append(path)
        return {
            "decision": "ADMIT", "duplicate": True, "sandbox_id": "tool-a",
            "epoch": 1, "container_port": 2222,
            "host": "192.0.2.20", "port": 20020,
        }

    def fail_spawn(_argv: list[str]):
        raise AssertionError("duplicate admission reached subprocess")

    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", fail_spawn)
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", *_argv()])

    assert policy_ssh.main() == 125
    assert posted == ["/v1/tool/admit"]


def test_policy_rejects_non_ssh_container_port_before_spawning_ssh(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[str] = []

    def post(path: str, _body: dict, *, attempts: int) -> dict:
        posted.append(path)
        return {
            "decision": "ADMIT", "sandbox_id": "tool-a", "epoch": 1,
            "container_port": 49983, "host": "192.0.2.20", "port": 20020,
        }

    def fail_spawn(_argv: list[str]):
        raise AssertionError("non-SSH container port reached subprocess")

    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", fail_spawn)
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", *_argv()])

    assert policy_ssh.main() == 125
    assert posted == ["/v1/tool/admit"]


@pytest.mark.skipif(sys.platform == "win32", reason="native commands use a POSIX shell")
@pytest.mark.parametrize("tool_name", ["exec", "filesystem"])
def test_output_order_is_merged_only_for_exec(tool_name):
    logical = "printf 'first\\n' >&2; printf 'second\\n'; cat <<'EOF'\nthird\nEOF"
    args = [policy_ssh.PREFIX + json.dumps({
        "v": 1, "execution_id": "exec-order", "tool_name": tool_name,
    }) + "\n" + logical]
    _, effective, profile = policy_ssh._envelope(args)
    assert profile == logical
    for _ in range(10):
        result = subprocess.run(["/bin/sh", "-c", effective], capture_output=True, text=True)
        assert result.returncode == 0
        if tool_name == "exec":
            assert result.stdout == "first\nsecond\nthird\n"
            assert result.stderr == ""
        else:
            assert result.stdout == "second\nthird\n"
            assert result.stderr == "first\n"


def test_cancellation_keeps_ssh_alive_until_remote_cleanup(monkeypatch):
    handlers = {}
    events = []

    def install(sig, handler):
        previous = handlers.get(sig)
        handlers[sig] = handler
        return previous

    class Child:
        def wait(self):
            handlers[policy_ssh.signal.SIGTERM](None, None)
            events.append("reaped")
            return 130

    def spawn(argv, **kwargs):
        assert kwargs["start_new_session"] is True
        return Child()

    def cancel(argv, **kwargs):
        assert argv[-1] == "__CLAWBOX_CANCEL__ exec-a"
        events.append("cancel sent")
        return type("Result", (), {"returncode": 0})()

    monkeypatch.setattr(policy_ssh.signal, "signal", install)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", spawn)
    monkeypatch.setattr(policy_ssh.subprocess, "run", cancel)
    assert policy_ssh._wait_for_ssh(["ssh", "target", "command"], "exec-a") == 130
    assert events == ["cancel sent", "reaped"]
    assert all(value is None for value in handlers.values())


def test_policy_does_not_complete_while_ssh_child_is_active(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("CLAWBOX_REAL_SSH", "/fake/ssh")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_URL", "http://policy.test")
    monkeypatch.setenv("CLAWBOX_POLICY_CONTROL_TOKEN", "token")
    monkeypatch.setenv("CLAWBOX_POLICY_SESSION_ID", "session-a")
    monkeypatch.setenv("CLAWBOX_TOOL_SANDBOX_ID", "tool-a")
    monkeypatch.setenv("CLAWBOX_SSH_HOST_KEY_ALIAS", "clawbox-tool-tool-a")
    posted: list[tuple[str, dict]] = []
    child_started = threading.Event()
    release_child = threading.Event()

    def post(path: str, body: dict, *, attempts: int) -> dict:
        posted.append((path, body))
        if path.endswith("/admit"):
            return {
                "decision": "ADMIT", "sandbox_id": "tool-a", "epoch": 10,
                "container_port": 2222, "host": "192.0.2.20", "port": 20020,
            }
        return {"status": "COMPLETED"}

    class Child:
        def wait(self) -> int:
            child_started.set()
            if not release_child.wait(timeout=2):
                raise AssertionError("test child was not released")
            return 0

    monkeypatch.setattr(policy_ssh, "_post", post)
    monkeypatch.setattr(policy_ssh.subprocess, "Popen", lambda _argv, **_kwargs: Child())
    monkeypatch.setattr(sys, "argv", ["clawbox-policy-ssh.py", *_argv()])

    result: list[int] = []
    thread = threading.Thread(target=lambda: result.append(policy_ssh.main()))
    thread.start()
    assert child_started.wait(timeout=2)
    time.sleep(0.02)
    assert [path for path, _body in posted] == ["/v1/tool/admit"]
    release_child.set()
    thread.join(timeout=2)
    assert not thread.is_alive()
    assert result == [0]
    assert [path for path, _body in posted] == ["/v1/tool/admit", "/v1/tool/complete"]
    completion = posted[-1][1]
    assert completion["ssh_reaped_at"] <= completion["execution_completed_at"]

def test_frozen_p50_manifest_overrides_runtime_envelope(monkeypatch):
    for key, value in {'CLAWBOX_REAL_SSH': '/fake/ssh', 'CLAWBOX_POLICY_CONTROL_URL': 'http://policy.test',
        'CLAWBOX_POLICY_CONTROL_AUTH': 'token', 'CLAWBOX_POLICY_SESSION_ID': 'session-a',
        'CLAWBOX_TOOL_SANDBOX_ID': 'tool-a', 'CLAWBOX_SSH_HOST_KEY_ALIAS': 'clawbox-tool-tool-a'}.items():
        monkeypatch.setenv(key, value)
    frozen = {'prediction_source': 'frozen_clawbox_p50', 'raw_command_sha256': 'identity'}
    monkeypatch.setattr(policy_ssh, '_prediction', lambda _: frozen)
    posted = []
    def post(path, body, **kwargs):
        posted.append(body)
        return {'decision': 'ADMIT', 'sandbox_id': 'tool-a', 'epoch': 1,
                'container_port': 2222, 'host': '192.0.2.20', 'port': 20020}
    monkeypatch.setattr(policy_ssh, '_post', post)
    class Child:
        def wait(self): return 0
    monkeypatch.setattr(policy_ssh.subprocess, 'Popen', lambda *a, **k: Child())
    header = {'v': 1, 'execution_id': 'exec-a', 'tool_name': 'exec',
              'call_prediction': {'schema_version': 'call_load.v2', 'targets': {}}}
    argv = _argv()
    argv[-1] = policy_ssh.PREFIX + 'b64:' + base64.urlsafe_b64encode(json.dumps(header).encode()).decode().rstrip('=') + '\nprintf /run/identity'
    monkeypatch.setattr(sys, 'argv', ['clawbox-policy-ssh.py', *argv])
    assert policy_ssh.main() == 0
    assert posted[0]['prediction'] == frozen
