from __future__ import annotations

import json
from pathlib import Path

import pytest

from clawbox.experiments.qualification import qualification_spec, validate_receipt
from clawbox.experiments.spec import load_experiment, spec_digest


EXAMPLE = Path("examples/experiments/getting-started.yaml")


def _receipt(spec, *, concurrency: int | None = None) -> dict:
    qualified = qualification_spec(spec, concurrency=concurrency)
    return {
        "schema_version": 1,
        "source_spec_digest": spec_digest(spec),
        "qualification_spec_digest": spec_digest(qualified),
        "qualified_unix_s": 1.0,
        "concurrency": max(qualified.execution.concurrency_levels),
        "policy_names": [policy.name for policy in qualified.policies],
        "target_node": spec.resources.target_node,
        "runtime_image_digest": spec.runtime.image_digest,
        "tool_image_digest": spec.sandbox.image_digest,
        "run_root": "/results/qualification-test",
        "supervision_fault_test": {"passed": True},
        "cleanup_verified": True,
        "status": "succeeded",
    }


def test_qualification_uses_all_policies_at_target_concurrency() -> None:
    spec = load_experiment(EXAMPLE)
    qualified = qualification_spec(spec, concurrency=3)

    assert qualified.inference.configuration["max_model_steps"] == 1
    assert qualified.execution.concurrency_levels == (3,)
    assert qualified.execution.randomized_order is False
    assert qualified.workload.repetitions == 1
    assert qualified.validation.command == "true"
    assert [item.name for item in qualified.policies] == [
        item.name for item in spec.policies
    ]


def test_receipt_is_bound_to_exact_spec_and_required_concurrency(tmp_path: Path) -> None:
    spec = load_experiment(EXAMPLE)
    path = tmp_path / "qualification.json"
    path.write_text(json.dumps(_receipt(spec)), encoding="utf-8")

    assert validate_receipt(spec, path)["status"] == "succeeded"

    changed = spec.model_copy(update={
        "execution": spec.execution.model_copy(update={
            "concurrency_levels": (1, 2),
        }),
    })
    with pytest.raises(ValueError, match="source_spec_digest|concurrency"):
        validate_receipt(changed, path)
