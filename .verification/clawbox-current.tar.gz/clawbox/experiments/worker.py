from __future__ import annotations

import argparse
import csv
import hashlib
import ipaddress
import importlib.metadata
import json
import math
import os
import platform
import statistics
import subprocess
import base64
import shlex
import sys
import time
import traceback
import urllib.parse
from contextlib import nullcontext
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, replace
from pathlib import Path
from threading import Lock, Semaphore, Timer
from types import SimpleNamespace
from typing import Any

from clawbox.cube import (
    CubeCommandExecutor, CubeSandboxClient, CubeSandboxLifecycle,
    OwnedSandboxJournal, Ownership,
)
from .llm_config import resolve_llm_configuration
from clawbox.replay.trace import find_recordings, load_trace
from clawbox.replay.lifecycle import CommandResult

from .memory import CgroupMemorySampler, NodeMemorySampler, NumaNodeMemorySampler, SandboxRSSSampler
from .clawtune_trace import ClawTuneTraceWriter
from .model_gateway import ManagedModelGateway, SessionGatewayState
from .native_artifacts import collect_and_validate_native_tool_artifacts
from .openclaw_driver import (
    NativeSSHConfig, NativeSSHRoute, native_ssh_host_key_alias, native_ssh_route,
    native_tool_bridge_setup_command, openclaw_shared_ssh_runtime_directory,
    run_openclaw,
)
from .policy import PolicyCoordinator, PolicyEventExecutor
from .snapshot_pool import WarmSnapshotPool
from .spec_types import InferenceBackend, SnapshotTier
from .policy_control import PolicyControlServer
from .prediction import CommandPredictionProvider, P50PredictionProvider, PredictionUnavailable, clawtune_extra_peak
from .runtime_model_relay import RELAY_CHECKPOINT_URL
from .ssh_credentials import generate_ssh_credentials
from .results import FailureCategory, ResultEnvelope, RunStatus, failure_category_for, utcnow
from .spec import (
    AdmissionPolicy, AgentDriver, EvictionPolicy, ExperimentArm, ExperimentSpec,
    ReclamationPolicy, RestorePolicy, expand_matrix, load_experiment,
)


def drain_policy_futures(pending: list[Any], lock: Any, timeout_s: float | None) -> None:
    """Observe every submitted result, including already completed failures."""
    consumed = 0
    while True:
        with lock:
            batch = pending[consumed:]
        if not batch:
            return
        for future in batch:
            future.result(timeout=timeout_s)
            consumed += 1


def session_case_for(arm: ExperimentArm, session_index: int) -> Any:
    cases = arm.session_cases or (arm.case,)
    return cases[session_index % len(cases)]


def policy_operation_headroom_mib(arm: ExperimentArm) -> int:
    """Charge checkpoint/restore workspace only to policies that use it."""
    if arm.policy.reclamation is not ReclamationPolicy.SNAPSHOT_PAUSE:
        return 0
    return arm.resources.checkpoint_restore_headroom_mib


def _network_target(endpoint: str, *, label: str) -> str:
    parsed = urllib.parse.urlsplit(endpoint)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ValueError(f"{label} must be an http(s) URL with a hostname")
    try:
        address = ipaddress.ip_address(parsed.hostname)
    except ValueError:
        return parsed.hostname
    return f"{address}/{32 if address.version == 4 else 128}"


def _runtime_network_deny_out(
    allow_internet_access: bool, allow_out: list[str],
) -> list[str] | None:
    """Deny default IPv4 egress only for explicitly closed Runtime arms."""
    return ["0.0.0.0/0"] if allow_out and not allow_internet_access else None


class RuntimeStatusPoller:
    """Poll a detached Runtime without coupling resident policy to callbacks."""

    def __init__(self, *, lifecycle: CubeSandboxLifecycle,
                 executor: CubeCommandExecutor, lifecycle_lock: Lock,
                 snapshot_enabled: bool) -> None:
        self.lifecycle = lifecycle
        self.executor = executor
        self.lifecycle_lock = lifecycle_lock
        self.snapshot_enabled = snapshot_enabled

    def __call__(self, command: str, timeout: float) -> CommandResult | None:
        if not self.snapshot_enabled:
            if not self.lifecycle.resident:
                return None
            return _execute_idempotent(self.executor, command, timeout)
        # Snapshot policies serialize a bounded status command with the state
        # transition. Resident policies have no transition to serialize and
        # must leave the lock available to the ModelGateway callback.
        with self.lifecycle_lock:
            if not self.lifecycle.resident:
                return None
            return _execute_idempotent(self.executor, command, timeout)


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, default=str)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def atomic_marker(path: Path, digest: str) -> None:
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="ascii") as stream:
        stream.write(digest + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    position = (len(ordered) - 1) * quantile
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (ordered[upper] - ordered[lower]) * (position - lower)


def _make_time_span(
    name: str, start: Any, end: Any, *, role: str | None = None,
    operation: str | None = None, execution_id: str | None = None,
    start_monotonic: Any = None, end_monotonic: Any = None,
    service_seconds: Any = None, status: str | None = None,
    state_before: str | None = None, state_after: str | None = None,
    error_type: str | None = None, predicted_wait_seconds: Any = None,
    prediction_source: str | None = None,
) -> dict[str, Any] | None:
    """Render one span with wall and, when available, monotonic timing.

    Wall-clock fields make JSONL/results easy to correlate across processes;
    monotonic fields keep durations valid when the system clock is adjusted.
    Optional lifecycle fields are retained only when they are well-typed so a
    malformed observer record cannot make a result look like valid evidence.
    """
    if (
        isinstance(start, bool) or not isinstance(start, (int, float))
        or isinstance(end, bool) or not isinstance(end, (int, float))
        or not math.isfinite(float(start)) or not math.isfinite(float(end))
    ):
        return None
    start_wall = float(start)
    end_wall = float(end)
    start_mono = (
        float(start_monotonic)
        if isinstance(start_monotonic, (int, float))
        and not isinstance(start_monotonic, bool)
        and math.isfinite(float(start_monotonic))
        else None
    )
    end_mono = (
        float(end_monotonic)
        if isinstance(end_monotonic, (int, float))
        and not isinstance(end_monotonic, bool)
        and math.isfinite(float(end_monotonic))
        else None
    )
    duration = (
        max(0.0, end_mono - start_mono)
        if start_mono is not None and end_mono is not None
        else max(0.0, end_wall - start_wall)
    )
    span: dict[str, Any] = {
        "name": str(name),
        "start_unix_s": start_wall,
        "end_unix_s": end_wall,
        "duration_seconds": duration,
    }
    optional = {
        "role": role,
        "operation": operation,
        "execution_id": execution_id,
        "start_monotonic_s": start_mono,
        "end_monotonic_s": end_mono,
        "service_seconds": service_seconds,
        "status": status,
        "state_before": state_before,
        "state_after": state_after,
        "error_type": error_type,
        "predicted_wait_seconds": predicted_wait_seconds,
        "prediction_source": prediction_source,
    }
    for key, value in optional.items():
        if value is not None:
            span[key] = value
    return span


def _record_time_span(timeline: dict[str, Any], name: str, start: Any, end: Any,
                      **kwargs: Any) -> None:
    span = _make_time_span(name, start, end, **kwargs)
    if span is not None:
        timeline.setdefault("recorded_time_spans", []).append(span)


def _execute_idempotent(executor: Any, command: str, timeout_s: float,
                        *, attempts: int = 8) -> CommandResult:
    """Retry read-only/setup Cube command streams during high fan-out.

    Agent Tool commands never use this helper: retrying those could duplicate a
    workspace mutation.  It is reserved for idempotent readiness, validation,
    hashing, PID observation, and artifact-copy operations.
    """
    last_error: Exception | None = None
    for attempt in range(1, attempts + 1):
        try:
            return executor.execute(command, timeout_s)
        except Exception as exc:
            last_error = exc
            if attempt < attempts:
                time.sleep(min(0.1 * (2 ** (attempt - 1)), 1.0))
    raise RuntimeError(
        f"idempotent Cube command transport failed after {attempts} attempts"
    ) from last_error


def build_time_spans(timeline: dict[str, Any]) -> list[dict[str, Any]]:
    """Build stable, machine-readable spans from session lifecycle markers."""
    pairs = (
        ("session", "session_started", "session_finished"),
        ("sandbox.create.queue", "sandbox_create_gate_wait_start",
         "sandbox_create_gate_acquired"),
        ("sandbox.create", "sandbox_create_start", "sandbox_ready"),
        ("sandbox.tool.create", "tool_create_start", "tool_ready"),
        ("sandbox.runtime.create", "runtime_create_start", "runtime_ready"),
        ("agent", "agent_execution_start", "final_agent_completion"),
        ("validation", "validation_start", "validation_end"),
        ("output_hash", "output_hash_start", "output_hash_end"),
        ("sandbox.cleanup", "sandbox_cleanup_start", "sandbox_cleanup_end"),
    )
    spans: list[dict[str, float | str]] = []
    for name, start_key, end_key in pairs:
        start = timeline.get(start_key)
        end = timeline.get(end_key)
        if not isinstance(start, (int, float)) or not isinstance(end, (int, float)):
            continue
        span = _make_time_span(name, start, end)
        if span is not None:
            spans.append(span)
    for item in timeline.get("recorded_time_spans", []):
        if isinstance(item, dict) and item.get("name"):
            spans.append(dict(item))
    for item in timeline.get("lifecycle_timings", []):
        if not isinstance(item, dict):
            continue
        operation = str(item.get("operation") or "").strip()
        if not operation:
            continue
        role = str(item.get("role") or "sandbox").strip() or "sandbox"
        span = _make_time_span(
            f"sandbox.{role}.{operation}",
            item.get("started_unix_s"), item.get("completed_unix_s"),
            role=role, operation=operation,
            start_monotonic=item.get("started_monotonic_s"),
            end_monotonic=item.get("completed_monotonic_s"),
            service_seconds=item.get("service_seconds"),
            status=item.get("status"), state_before=item.get("state_before"),
            state_after=item.get("state_after"), error_type=item.get("error_type"),
        )
        if span is not None:
            for key in (
                "host_memory_before", "host_memory_after",
                "host_observed_reclaimed_bytes", "host_observed_growth_bytes",
            ):
                if item.get(key) is not None:
                    span[key] = item[key]
            spans.append(span)
    return spans


def enrich_tool_execution_observations(
    records: list[dict[str, Any]],
    cgroup_artifacts: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Attach validated guest execution measurements to admission records."""
    expected_ids = {str(item.get("execution_id") or "") for item in records}
    if "" in expected_ids or expected_ids != set(cgroup_artifacts):
        raise RuntimeError(
            "prediction/cgroup execution identity mismatch: "
            f"predictions={sorted(expected_ids)!r} "
            f"cgroups={sorted(cgroup_artifacts)!r}"
        )
    enriched: list[dict[str, Any]] = []
    for item in records:
        execution_id = str(item["execution_id"])
        cgroup = cgroup_artifacts[execution_id]
        actual_mib = float(cgroup["memory_rss_peak_bytes"]) / (1024.0 * 1024.0)
        duration = max(0.0, float(cgroup["ts_end"]) - float(cgroup["ts_start"]))
        row = dict(item)
        row.update({
            "actual_measured_memory_mib": actual_mib,
            "actual_memory_metric": "tool_guest_cgroup_v2_memory_rss_peak_bytes",
            "actual_execution_duration_seconds": duration,
            "actual_cpu_utilization_avg_cores": float(
                cgroup["cpu_utilization_avg_cores"]
            ),
            "telemetry_validity": "valid",
            "telemetry_eligible_for_kb": True,
        })
        if cgroup.get("memory_eligible") is True and cgroup.get("memory_measurement") == "guest_memtotal_minus_memavailable":
            extra = cgroup.get("memory_extra_peak_bytes")
            if isinstance(extra, (int, float)) and math.isfinite(extra) and extra >= 0:
                row["actual_extra_memory_mib"] = extra / 1024**2
                if row.get("prediction_quantile") == 0.5:
                    value = row.get("predicted_incremental_memory_mib")
                    if value is not None:
                        row["p50_extra_memory_error_mib"] = float(value) - extra / 1024**2
        row["memory_unavailable_reason"] = cgroup.get("memory_unavailable_reason")
        predicted_guest = row.get("predicted_guest_memory_p90_mib")
        if predicted_guest is not None:
            predicted_mib = float(predicted_guest)
            signed_error = predicted_mib - actual_mib
            row.update({
                "prediction_error_mib": signed_error,
                "prediction_absolute_error_mib": abs(signed_error),
                "prediction_underestimate_mib": max(0.0, -signed_error),
                "prediction_covered_actual": predicted_mib >= actual_mib,
            })
        predicted_host = row.get("predicted_incremental_memory_mib")
        actual_host = row.get("actual_host_execution_increment_mib")
        if (predicted_host is not None and actual_host is not None
                and row.get("admission_prediction_target") == "host_vm_rss_execution_increment"):
            host_error = float(predicted_host) - float(actual_host)
            row.update({
                "host_increment_prediction_error_mib": host_error,
                "host_increment_prediction_absolute_error_mib": abs(host_error),
                "host_increment_prediction_covered_actual": host_error >= 0,
            })
        enriched.append(row)
    records[:] = enriched
    return enriched


def summarize_tool_execution_observations(
    records: list[dict[str, Any]],
) -> dict[str, Any]:
    """Produce paper-facing prediction and telemetry aggregates."""
    # Backend probes are admitted and measured, but are not logical Agent Tool
    # calls and must not dilute command-prediction statistics.
    records = [
        item for item in records
        if item.get("execution_scope", "agent-tool") == "agent-tool"
    ]
    errors = [
        float(item["prediction_error_mib"])
        for item in records if item.get("prediction_error_mib") is not None
    ]
    absolute_errors = [
        float(item["prediction_absolute_error_mib"])
        for item in records if item.get("prediction_absolute_error_mib") is not None
    ]
    underestimates = [
        float(item["prediction_underestimate_mib"])
        for item in records if item.get("prediction_underestimate_mib") is not None
    ]
    prediction_records = [
        item for item in records
        if item.get("prediction_source") == "runtime_clawtune_immutable_kb"
    ]
    fallback_records = [
        item for item in prediction_records
        if item.get("fallback_level") != "exact_command"
    ]
    covered = [
        bool(item["prediction_covered_actual"])
        for item in records if item.get("prediction_covered_actual") is not None
    ]
    relative_errors = [
        float(item["prediction_absolute_error_mib"])
        / float(item["actual_measured_memory_mib"])
        for item in records
        if item.get("prediction_absolute_error_mib") is not None
        and float(item.get("actual_measured_memory_mib") or 0) > 0
    ]
    over_reservation_ratios = [
        float(item["admitted_reservation_mib"])
        / float(item["actual_host_execution_increment_mib"])
        for item in records
        if item.get("admitted_reservation_mib") is not None
        and float(item.get("actual_host_execution_increment_mib") or 0) > 0
    ]
    pinball_losses = []
    for item in records:
        predicted = item.get("predicted_guest_memory_p90_mib")
        actual = item.get("actual_measured_memory_mib")
        if predicted is None or actual is None:
            continue
        residual = float(actual) - float(predicted)
        pinball_losses.append(0.9 * residual if residual >= 0 else -0.1 * residual)
    host_coverage = [
        bool(item["host_increment_prediction_covered_actual"])
        for item in records
        if item.get("host_increment_prediction_covered_actual") is not None
    ]

    def distribution(field: str) -> dict[str, int]:
        result: dict[str, int] = {}
        for item in records:
            value = str(item.get(field) or "unknown")
            result[value] = result.get(value, 0) + 1
        return result

    return {
        "p50_extra_memory_measured_count": sum(r.get("p50_extra_memory_error_mib") is not None for r in records),
        "p50_extra_memory_mae_mib": (statistics.fmean(abs(r["p50_extra_memory_error_mib"]) for r in records
            if r.get("p50_extra_memory_error_mib") is not None) if any(r.get("p50_extra_memory_error_mib") is not None for r in records) else None),
        "p50_source_counts": distribution("fallback_level"),
        "tool_execution_observation_count": len(records),
        "telemetry_valid_count": sum(
            item.get("telemetry_validity") == "valid" for item in records
        ),
        "telemetry_invalid_count": sum(
            item.get("telemetry_validity") != "valid" for item in records
        ),
        "prediction_observation_count": len(prediction_records),
        "prediction_fallback_count": len(fallback_records),
        "prediction_fallback_rate": (
            len(fallback_records) / len(prediction_records)
            if prediction_records else None
        ),
        "prediction_error_mean_mib": statistics.fmean(errors) if errors else None,
        "prediction_error_p90_mib": percentile(errors, 0.90),
        "prediction_absolute_error_p90_mib": percentile(absolute_errors, 0.90),
        "prediction_underestimate_p90_mib": percentile(underestimates, 0.90),
        "prediction_coverage_fraction": (
            sum(covered) / len(covered) if covered else None
        ),
        "prediction_exceedance_rate": (
            1.0 - sum(covered) / len(covered) if covered else None
        ),
        "prediction_relative_absolute_error_mean": (
            statistics.fmean(relative_errors) if relative_errors else None
        ),
        "reservation_over_actual_mean_ratio": (
            statistics.fmean(over_reservation_ratios)
            if over_reservation_ratios else None
        ),
        "prediction_p90_pinball_loss_mean_mib": (
            statistics.fmean(pinball_losses) if pinball_losses else None
        ),
        "host_increment_prediction_coverage_fraction": (
            sum(host_coverage) / len(host_coverage) if host_coverage else None
        ),
        "host_increment_prediction_exceedance_rate": (
            1.0 - sum(host_coverage) / len(host_coverage)
            if host_coverage else None
        ),
        "prediction_source_distribution": distribution("prediction_source"),
        "prediction_fallback_level_distribution": distribution("fallback_level"),
    }


class EventWriter:
    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.lock = Lock()
        self.sequence = 0

    def write(self, event: dict[str, Any]) -> None:
        with self.lock, self.path.open("a", encoding="utf-8") as stream:
            row = {
                "schema_version": 1,
                "sequence_no": self.sequence,
                "wall_time": utcnow().isoformat(),
                "wall_time_ns": str(time.time_ns()),
                "monotonic_time_ns": str(time.monotonic_ns()),
                **event,
            }
            self.sequence += 1
            stream.write(json.dumps(row, sort_keys=True, separators=(",", ":")) + "\n")
            stream.flush()


class ExperimentWorker:
    def __init__(self, spec: ExperimentSpec, *, run_id: str, attempt_id: str,
                 task_uid: str, output_root: Path | None = None,
                 client: CubeSandboxClient | None = None) -> None:
        self.spec = spec
        self.run_id = run_id
        self.attempt_id = attempt_id
        self.task_uid = task_uid
        output_base = Path(os.environ.get("CLAWBOX_OUTPUT_ROOT", spec.output.directory))
        self.output_root = output_root or output_base / run_id
        journal = OwnedSandboxJournal(self.output_root / "owned-sandboxes.jsonl")
        self.client = client or CubeSandboxClient(journal=journal)
        if self.client.journal is None:
            self.client.journal = journal
        self.results: list[ResultEnvelope] = []
        self.policy_control: PolicyControlServer | None = None
        self.model_gateway: ManagedModelGateway | None = None

    @staticmethod
    def _sandbox_create_limit(concurrency: int) -> int:
        """Bound pair creation so c40 does not stampede Cubelet/containerd."""
        raw = os.environ.get("CLAWBOX_SANDBOX_CREATE_CONCURRENCY", "8")
        try:
            limit = int(raw)
        except ValueError as exc:
            raise ValueError(
                "CLAWBOX_SANDBOX_CREATE_CONCURRENCY must be a positive integer"
            ) from exc
        if limit < 1:
            raise ValueError(
                "CLAWBOX_SANDBOX_CREATE_CONCURRENCY must be a positive integer"
            )
        return min(concurrency, limit)

    @staticmethod
    def _startup_headroom_mib(
        arm: ExperimentArm,
        prediction_provider: CommandPredictionProvider | None,
    ) -> int:
        """Leave room for one in-policy Tool call while another pair starts."""
        if arm.policy.admission is AdmissionPolicy.LIFETIME_FULL:
            return 0
        if arm.policy.admission is AdmissionPolicy.TOOL_FULL:
            return int(arm.resources.full_tool_memory_mib or arm.sandbox.memory_mib)
        if arm.policy.admission is AdmissionPolicy.TOOL_STATIC:
            return int(arm.resources.static_tool_memory_mib or 1)
        if prediction_provider is not None:
            return max(
                int(arm.resources.non_command_tool_memory_mib
                    or arm.resources.static_tool_memory_mib or 1),
                int(math.ceil(prediction_provider.max_incremental_memory_mib)),
            )
        # Live Runtime predictions are not frozen on the worker, so their
        # maximum is unknown before VM creation. Preserve the capacity guard.
        return int(arm.resources.full_tool_memory_mib or arm.sandbox.memory_mib)

    def run(self, *, arm_ids: set[str] | None = None,
            write_summary: bool = True) -> list[ResultEnvelope]:
        self.output_root.mkdir(parents=True, exist_ok=True)
        control_host = os.environ.get("CLAWBOX_CONTROL_HOST", "").strip()
        policy_port = int(os.environ.get("CLAWBOX_POLICY_PORT", "18080"))
        gateway_host = os.environ.get("CLAWBOX_MODEL_GATEWAY_HOST", control_host).strip()
        gateway_port = int(os.environ.get("CLAWBOX_MODEL_GATEWAY_PORT", "18081"))
        arms = list(expand_matrix(self.spec))
        if arm_ids is not None:
            known = {arm.arm_id for arm in arms}
            unknown = arm_ids - known
            if unknown:
                raise ValueError(f"unknown experiment arm ids: {sorted(unknown)}")
            arms = [arm for arm in arms if arm.arm_id in arm_ids]
            if not arms:
                raise ValueError("at least one experiment arm must be selected")
        requires_control = any(arm.agent.driver is AgentDriver.OPENCLAW for arm in arms)
        if requires_control and not control_host:
            raise RuntimeError("native SSH policy control requires CLAWBOX_CONTROL_HOST")
        if requires_control and not gateway_host:
            raise RuntimeError(
                "managed ModelGateway requires CLAWBOX_MODEL_GATEWAY_HOST and "
                "CLAWBOX_MODEL_GATEWAY_NODE_PORT"
            )
        policy_context = (
            PolicyControlServer(advertise_host=control_host, advertised_port=policy_port,
                                bind_port=policy_port)
            if control_host else nullcontext(None)
        )
        gateway_context = (
            ManagedModelGateway(advertise_host=gateway_host, advertised_port=gateway_port,
                                bind_port=gateway_port)
            if gateway_host else nullcontext(None)
        )
        with policy_context as policy_control, gateway_context as model_gateway:
            self.policy_control = policy_control
            self.model_gateway = model_gateway
            if model_gateway is not None:
                model_gateway.wait_ready()
            for arm in arms:
                result_path = self.output_root / "arms" / f"{arm.arm_id}.json"
                marker_path = self.output_root / "arms" / f"{arm.arm_id}.complete"
                if self._completed(result_path, marker_path, arm.spec_digest):
                    self.results.append(ResultEnvelope.model_validate_json(result_path.read_text()))
                    continue
                self.results.append(self._run_arm(arm, result_path, marker_path))
            self.policy_control = None
            self.model_gateway = None
        if write_summary:
            self._write_summary()
        return self.results

    @staticmethod
    def _completed(result_path: Path, marker_path: Path, digest: str) -> bool:
        if not result_path.exists() or not marker_path.exists():
            return False
        try:
            previous = json.loads(result_path.read_text(encoding="utf-8"))
            return marker_path.read_text(encoding="ascii").strip() == digest and \
                previous["arm"]["spec_digest"] == digest and \
                previous["status"] == RunStatus.SUCCEEDED
        except (OSError, ValueError, KeyError):
            return False

    def _run_arm(self, arm: ExperimentArm, result_path: Path, marker_path: Path) -> ResultEnvelope:
        started_at = utcnow()
        started = time.monotonic()
        for role, sandbox in (("runtime", arm.runtime), ("tool", arm.sandbox)):
            if sandbox.image_digest:
                self.client.validate_template_image(
                    sandbox.template, sandbox.image_digest,
                )
        events = EventWriter(self.output_root / "events" / f"{arm.arm_id}.jsonl")
        sampler = (
            CgroupMemorySampler(
                Path(arm.resources.local_memory_cgroup),
                capacity_bytes=(arm.resources.local_memory_capacity_mib or
                                arm.resources.pool_memory_budget_mib) * 1024 * 1024,
                numa_node=arm.resources.local_numa_node,
                interval_s=arm.execution.memory_sample_interval_seconds,
            )
            if arm.resources.local_memory_cgroup else
            NumaNodeMemorySampler(
                arm.resources.local_numa_node,
                interval_s=arm.execution.memory_sample_interval_seconds,
            )
            if arm.resources.local_numa_node is not None and os.name != "nt"
            else NodeMemorySampler(interval_s=arm.execution.memory_sample_interval_seconds)
        )
        def record_pressure_pause(
            state: Any, tool_elapsed: float | None,
            runtime_elapsed: float | None, reason: str,
        ) -> None:
            for role, lifecycle, elapsed in (
                ("tool", state.lifecycle, tool_elapsed),
                ("runtime", state.runtime_lifecycle, runtime_elapsed),
            ):
                if elapsed is None or lifecycle is None:
                    continue
                timings = lifecycle.timings
                events.write({
                    "event": "sandbox_paused",
                    "session_id": state.session_id,
                    "role": role,
                    "service_seconds": elapsed,
                    "reason": reason,
                    "lifecycle_timing": timings[-1] if timings else None,
                })
        def reclaim_local_cache() -> None:
            events.write({"event": "local_cache_reclaim_started"})
            try:
                observation = sampler.reclaim_file_cache()
            except OSError as exc:
                # memory.reclaim is root-owned on the host cgroup.  A worker
                # may be intentionally unprivileged; failure to request
                # cache reclaim must remain observable and let normal
                # lifecycle eviction make progress instead of invalidating
                # the arm.
                events.write({
                    "event": "local_cache_reclaim",
                    "status": "unavailable",
                    "error": f"{type(exc).__name__}: {exc}",
                })
                return
            events.write({"event": "local_cache_reclaim", **observation})

        prediction_provider = None
        if (arm.agent.driver is AgentDriver.OPENCLAW
                and arm.policy.admission is AdmissionPolicy.TOOL_ORACLE):
            source = arm.resources.oracle_measurements
            if not source:
                raise ValueError(
                    f"{arm.policy.admission.value} requires an immutable command artifact"
                )
            prediction_provider = CommandPredictionProvider(
                Path(source),
                repository=arm.case.repository or arm.case.case_id,
                prediction_source="runtime_tool_oracle_heldout",
            )
        if arm.policy.admission is AdmissionPolicy.TOOL_P50 and arm.resources.prediction_artifact:
            prediction_provider = P50PredictionProvider(
                Path(arm.resources.prediction_artifact),
                repository=arm.case.repository or arm.case.case_id,
                sandbox_identity={k: getattr(arm.sandbox, k) for k in ("image_digest", "vcpu", "memory_mib", "architecture")},
            )
        coordinator = PolicyCoordinator(
            arm.policy, budget_mib=arm.resources.pool_memory_budget_mib,
            emergency_free_mib=arm.resources.emergency_free_memory_mib,
            operation_headroom_mib=policy_operation_headroom_mib(arm),
            startup_headroom_mib=self._startup_headroom_mib(arm, prediction_provider),
            physical_sample=sampler.current,
            reclaim_cache=reclaim_local_cache if isinstance(sampler, CgroupMemorySampler) else None,
            on_pressure_pause=record_pressure_pause,
        )
        snapshot_pool = WarmSnapshotPool(
            arm.resources.warm_memory_capacity_mib * 1024 * 1024
        )
        if arm.resources.local_memory_cgroup:
            def record_memory_sample(used: int, available: int) -> None:
                pool = snapshot_pool.snapshot()
                warm_physical = None
                if arm.resources.warm_snapshot_root:
                    stat = os.statvfs(arm.resources.warm_snapshot_root)
                    warm_physical = (stat.f_blocks - stat.f_bfree) * stat.f_frsize
                events.write({
                    "event": "memory_sample", "local_used_bytes": used,
                    "host_available_bytes": available,
                    "warm_allocated_bytes": warm_physical,
                    "warm_reserved_bytes": pool["reserved_bytes"],
                    "warm_committed_bytes": pool["committed_bytes"],
                })
            sampler.sample_hook = record_memory_sample
        policy_events = PolicyEventExecutor(workers=max(4, arm.concurrency * 2))
        sandbox_create_gate = Semaphore(self._sandbox_create_limit(arm.concurrency))
        sampler.start()
        sessions: list[dict[str, Any]] = []
        failure: Exception | None = None
        interrupted = False
        arm_started_wall = time.time()
        arm_started_monotonic = time.monotonic()
        pool = ThreadPoolExecutor(
            max_workers=arm.concurrency, thread_name_prefix="agent"
        )
        futures: dict[Any, int] = {}
        try:
            futures = {
                pool.submit(
                    self._run_session, arm, index, coordinator, events,
                    policy_events, prediction_provider, sandbox_create_gate,
                    sampler.observe, arm_started_wall, arm_started_monotonic,
                    snapshot_pool,
                ): index
                for index in range(arm.concurrency)
            }
            for future in as_completed(
                futures, timeout=arm.execution.arm_timeout_seconds,
            ):
                try:
                    sessions.append(future.result())
                except Exception as exc:  # one failed session fails the whole arm
                    index = futures[future]
                    events.write({
                        "event": "session_failed",
                        "session_id": f"{arm.arm_id}-{index:04d}",
                        "error": str(exc),
                        "error_type": type(exc).__name__,
                    })
                    failure = failure or exc
                    # Fail the arm immediately.  Destroying its owned VMs
                    # unblocks sibling Cube calls; the process supervisor is
                    # the final hard boundary if a third-party call ignores
                    # cancellation.
                    for pending in futures:
                        pending.cancel()
                    try:
                        self.client.kill_owned_sandboxes(self.task_uid)
                    except Exception as cleanup_exc:
                        exc.add_note(
                            "early arm cleanup failed: "
                            f"{type(cleanup_exc).__name__}: {cleanup_exc}"
                        )
                    interrupted = True
                    break
            pool.shutdown(wait=not interrupted, cancel_futures=interrupted)
            if failure is not None:
                raise failure
        except (KeyboardInterrupt, SystemExit):
            # ThreadPoolExecutor's context manager waits for every running
            # session before unwinding. On SIGTERM/KeyboardInterrupt that can
            # strand the CLI behind blocked VM calls and prevent lab cleanup.
            # Destroy this run's VMs first so those calls unblock, and cancel
            # sessions that have not started.
            for future in futures:
                future.cancel()
            pool.shutdown(wait=False, cancel_futures=True)
            try:
                self.client.kill_owned_sandboxes(self.task_uid)
            except Exception:
                pass
            interrupted = True
            raise
        except Exception as exc:
            for future in futures:
                future.cancel()
            pool.shutdown(wait=False, cancel_futures=True)
            try:
                self.client.kill_owned_sandboxes(self.task_uid)
            except Exception:
                pass
            failure = exc
            events.write({"event": "arm_failed", "error": str(exc), "type": type(exc).__name__})
        finally:
            policy_events.close(wait=not interrupted)
            # Isolation barrier: all session threads have ended, then kill and
            # verify every task-owned sandbox before the next arm can begin.
            cleanup_error = None
            try:
                self.client.kill_owned_sandboxes(self.task_uid)
            except Exception as exc:
                cleanup_error = exc
            time.sleep(arm.execution.stabilization_seconds)
            memory = sampler.stop()
            events.write({"event": "memory_sampling", "observation": sampler.observe(),
                          "interval_seconds": sampler.interval_s,
                          "samples": sampler.samples()})
            if cleanup_error is not None:
                failure = failure or cleanup_error
            if memory.host_oom_kill_events:
                failure = failure or RuntimeError(
                    "host OOM kill observed during arm: "
                    f"{memory.host_oom_kill_events}"
                )
            pool_budget_bytes = arm.resources.pool_memory_budget_mib * 1024 * 1024
            if memory.peak_used_delta_bytes > pool_budget_bytes:
                failure = failure or RuntimeError(
                    "execution pool budget exceeded: "
                    f"peak={memory.peak_used_delta_bytes} budget={pool_budget_bytes}"
                )
        status = RunStatus.SUCCEEDED if failure is None else RunStatus.FAILED
        duration = time.monotonic() - started
        session_durations = [float(item.get("agent_jct_seconds", item["duration_seconds"]))
                             for item in sessions]
        tool_latencies = [float(value) for item in sessions for value in item["tool_latencies"]]
        tool_steps = sum(int(item["tool_steps"]) for item in sessions)
        model_steps = sum(int(item["model_steps"]) for item in sessions)
        tool_execution_observations = [
            dict(record)
            for item in sessions for record in item.get("prediction_records", [])
        ]
        observation_summary = summarize_tool_execution_observations(
            tool_execution_observations
        )
        workload_starts = [float(item["timeline"]["agent_execution_start"])
                           for item in sessions if item.get("timeline", {}).get("agent_execution_start")]
        workload_ends = [float(item["timeline"]["final_agent_completion"])
                         for item in sessions if item.get("timeline", {}).get("final_agent_completion")]
        workload_window = (max(workload_ends) - min(workload_starts)
                           if workload_starts and workload_ends else None)
        provenance = self._provenance()
        provenance.update(self._arm_provenance(arm))
        if prediction_provider is not None:
            provenance["prediction_artifact"] = prediction_provider.provenance(
                [item for item in tool_execution_observations
                 if item.get("execution_scope", "agent-tool") == "agent-tool"]
            )
        peak_over_budget_bytes = max(0, memory.peak_used_delta_bytes - pool_budget_bytes)
        result = ResultEnvelope(
            run_id=self.run_id, attempt_id=self.attempt_id,
            sandbox_task_uid=self.task_uid,
            experiment_id=self.spec.experiment_id, arm=arm,
            provenance=provenance, status=status,
            failure_category=failure_category_for(status, "" if failure is None else str(failure)),
            started_at=started_at, completed_at=utcnow(),
            correctness={
                "completed_sessions": sum(item.get("valid", False) for item in sessions),
                "failed_sessions": arm.concurrency - sum(item.get("valid", False) for item in sessions),
                "validation_passed": failure is None and all(item.get("valid", False) for item in sessions),
                "native_tool_exact_id_join_rate": (
                    min(
                        float((item.get("native_tool_artifact_validation") or {})
                             .get("exact_id_join_rate", 0.0))
                        for item in sessions
                        if item.get("native_tool_artifact_validation") is not None
                    )
                    if any(item.get("native_tool_artifact_validation") is not None for item in sessions)
                    else None
                ),
                "native_tool_telemetry_loss_total": sum(
                    int((item.get("native_tool_artifact_validation") or {})
                        .get("telemetry_loss_total", 0))
                    for item in sessions
                ),
                "failure": None if failure is None else str(failure),
                "session_output_hashes": [item.get("output_hash") for item in sessions],
            },
            performance={
                "duration_seconds": duration,
                "infrastructure_inclusive_duration_seconds": duration,
                "workload_window_seconds": workload_window,
                "agents_per_minute": len(sessions) / max(workload_window or duration, 1e-9) * 60,
                "steps_per_minute": (tool_steps + model_steps) / max(workload_window or duration, 1e-9) * 60,
                "tool_steps": tool_steps, "model_steps": model_steps,
                "jct_mean_seconds": statistics.fmean(session_durations) if session_durations else None,
                "jct_p50_seconds": percentile(session_durations, 0.50),
                "jct_p90_seconds": percentile(session_durations, 0.90),
                "jct_p95_seconds": percentile(session_durations, 0.95),
                "tool_latency_mean_seconds": statistics.fmean(tool_latencies) if tool_latencies else None,
                "tool_latency_p50_seconds": percentile(tool_latencies, 0.50),
                "tool_latency_p90_seconds": percentile(tool_latencies, 0.90),
                "tool_latency_p95_seconds": percentile(tool_latencies, 0.95),
                "sandbox_create_mean_seconds": statistics.fmean(
                    [float(item["create_seconds"]) for item in sessions]) if sessions else None,
                "pause_count": coordinator.pause_count,
                "pause_service_seconds": coordinator.pause_service_seconds,
                "resume_count": coordinator.resume_count,
                "resume_service_seconds": coordinator.resume_service_seconds,
                "blocked_admission_seconds": coordinator.blocked_seconds,
                "admission_control": coordinator.admission_metrics(),
                "tool_execution_observations": tool_execution_observations,
                **observation_summary,
                "session_trace_assignment": [
                    {
                        "session_id": item.get("session_id"),
                        "case_id": item.get("case_id"),
                        "trace_reference": item.get("trace_reference"),
                    }
                    for item in sorted(sessions, key=lambda value: value["session_id"])
                ],
                "session_timelines": [item.get("timeline") for item in sessions],
                "session_time_spans": [
                    item.get("timeline", {}).get("time_spans", []) for item in sessions
                ],
            },
            memory={
                **asdict(memory),
                "pool_budget_bytes": pool_budget_bytes,
                "pool_budget_exceeded": peak_over_budget_bytes > 0,
                "peak_over_budget_bytes": peak_over_budget_bytes,
                "peak_commitment_bytes": coordinator.peak_commitment_bytes,
            },
            artifacts={
                "events": str(events.path),
                **{
                    f"native_tool_artifacts:{item['session_id']}": str(item["native_tool_artifact_root"])
                    for item in sessions
                    if item.get("native_tool_artifact_root")
                },
                **{
                    f"policy_control:{item['session_id']}": str(item["policy_control_path"])
                    for item in sessions
                    if item.get("policy_control_path")
                },
                **{
                    f"runtime_traces:{item['session_id']}": str(item["runtime_trace_root"])
                    for item in sessions
                    if item.get("runtime_trace_root")
                },
            },
        )
        # Result first, complete marker second. A crash between them retries the
        # entire arm, never treating a partial result as complete.
        atomic_json(result_path, result.model_dump(mode="json"))
        if result.status is RunStatus.SUCCEEDED:
            atomic_marker(marker_path, arm.spec_digest)
        else:
            marker_path.unlink(missing_ok=True)
        return result

    def _run_session(self, arm: ExperimentArm, index: int, coordinator: PolicyCoordinator,
                     events: EventWriter, policy_events: PolicyEventExecutor,
                     prediction_provider: CommandPredictionProvider | None = None,
                     sandbox_create_gate: Semaphore | None = None,
                     physical_observation: Any = None,
                     arm_started_wall: float | None = None,
                     arm_started_monotonic: float | None = None,
                     snapshot_pool: WarmSnapshotPool | None = None) -> dict[str, Any]:
        session_case = session_case_for(arm, index)
        if session_case != arm.case:
            arm = arm.model_copy(update={"case": session_case})
        offered_offset = (
            index * arm.execution.stagger_interval_seconds
            if arm.execution.arrival_schedule.value == "fixed_stagger" else 0.0
        )
        if arm_started_monotonic is not None:
            time.sleep(max(0.0, arm_started_monotonic + offered_offset - time.monotonic()))
        session_id = f"{arm.arm_id}-{index:04d}"
        session_started = time.monotonic()
        session_started_wall = time.time()
        timeline: dict[str, Any] = {
            "session_started": session_started_wall,
            "offered_start_offset_seconds": offered_offset,
            "offered_start_unix_s": (
                arm_started_wall + offered_offset
                if arm_started_wall is not None else session_started_wall
            ),
        }
        runtime_ownership = Ownership(
            self.run_id, self.attempt_id, self.task_uid, self.spec.experiment_id,
            f"{session_id}-runtime", arm.policy.name,
        )
        tool_ownership = Ownership(
            self.run_id, self.attempt_id, self.task_uid, self.spec.experiment_id,
            f"{session_id}-tool", arm.policy.name,
        )
        inference_configuration, credential = resolve_llm_configuration(
            arm.inference.configuration, live=arm.inference.backend.value == "api",
        )
        runtime_env: dict[str, str] = {}
        runtime_allow_out: list[str] = []
        route_epoch = 0
        ssh_config: NativeSSHConfig | None = None
        if arm.agent.driver is AgentDriver.OPENCLAW:
            runtime_env.update({
                # Runtime talks only to the Worker-owned node-routed gateway;
                # the upstream API key stays in the Worker process.
                "OPENAI_BASE_URL": "",
                "OPENCLAW_MODEL": str(inference_configuration.get("model") or ""),
                "CLAWBOX_RUN_ID": self.run_id,
                "CLAWBOX_ATTEMPT_ID": self.attempt_id,
                "CLAWBOX_TENANT_ID": os.environ.get("CLAWBOX_TENANT_ID", "default"),
                "CLAWBOX_REPO_KEY": (
                    arm.case.repository
                    or str(inference_configuration.get("repo_fingerprint") or arm.case.case_id)
                ),
            })
            for optional in ("CLAWBOX_KB_ENDPOINT", "CLAWBOX_KB_TOKEN"):
                if value := os.environ.get(optional):
                    runtime_env[optional] = value
            control_host = os.environ.get("CLAWBOX_CONTROL_HOST", "").strip()
            try:
                control_address = ipaddress.ip_address(control_host)
            except ValueError as exc:
                raise ValueError(
                    "CLAWBOX_CONTROL_HOST must be a host IP reachable from Runtime VMs"
                ) from exc
            runtime_allow_out.append(
                f"{control_address}/{32 if control_address.version == 4 else 128}"
            )
            # ModelGateway and PolicyControl share the host address and have
            # distinct direct listeners; Kubernetes/NodePort is not involved.
            if self.model_gateway is None:
                raise RuntimeError("managed ModelGateway is not active")
            if kb_endpoint := runtime_env.get("CLAWBOX_KB_ENDPOINT"):
                runtime_allow_out.append(_network_target(
                    kb_endpoint, label="CLAWBOX_KB_ENDPOINT",
                ))
            runtime_allow_out = list(dict.fromkeys(runtime_allow_out))
        runtime_lifecycle = CubeSandboxLifecycle(
            self.client, template=arm.runtime.template,
            node_name=os.environ.get("CLAWBOX_WORKER_NODE", arm.resources.target_node),
            ownership=runtime_ownership,
            allow_internet_access=arm.runtime.allow_internet_access,
            env_vars=runtime_env,
            network_allow_out=runtime_allow_out,
            network_deny_out=_runtime_network_deny_out(
                arm.runtime.allow_internet_access, runtime_allow_out,
            ),
            physical_observation=physical_observation,
            role="runtime",
            warm_snapshot_root=arm.resources.warm_snapshot_root,
            snapshot_mechanism=arm.resources.snapshot_mechanism,
            snapshot_storage=arm.resources.snapshot_storage,
            lazy_restore=True,
            cold_snapshot_root=arm.resources.cold_snapshot_root,
            snapshot_pool=snapshot_pool,
            snapshot_reservation_bytes=(arm.runtime.memory_mib + 256) * 1024 * 1024,
        )
        ssh_credentials = generate_ssh_credentials()
        tool_env = {
            "TOOL_BRIDGE_LOG_PATH": "/var/lib/clawtune/artifacts/tool-bridge.jsonl",
            "TOOL_BRIDGE_WORKDIR": arm.sandbox.workspace,
            "TOOL_MAX_CONCURRENCY": "1",
            # Each experiment Tool VM runs one OpenClaw execution at a time.
            # The guest reports time_running/time_enabled instead of hiding
            # visible PMU multiplexing. Host VM admission remains the separate
            # system-wide concurrency bound.
            "CLAWTUNE_PMU_ENABLED": "true",
            "CLAWTUNE_PMU_MAX_ACTIVE": "1",
            "CLAWBOX_TOOL_HOST_KEY_B64": base64.b64encode(
                ssh_credentials.host_private.encode()
            ).decode(),
            "CLAWBOX_TOOL_AUTHORIZED_KEY_B64": base64.b64encode(
                (ssh_credentials.client_public + "\n").encode()
            ).decode(),
            "TASK_ID": session_id,
            "CELL_ID": self.task_uid,
            "CLAWBOX_REPOSITORY": arm.case.repository or arm.case.case_id,
        }
        lifecycle = CubeSandboxLifecycle(
            self.client, template=arm.sandbox.template,
            node_name=os.environ.get("CLAWBOX_WORKER_NODE", arm.resources.target_node),
            ownership=tool_ownership, allow_internet_access=arm.sandbox.allow_internet_access,
            env_vars=tool_env,
            physical_observation=physical_observation,
            role="tool",
            warm_snapshot_root=arm.resources.warm_snapshot_root,
            snapshot_mechanism=arm.resources.snapshot_mechanism,
            snapshot_storage=arm.resources.snapshot_storage,
            lazy_restore=True,
            cold_snapshot_root=arm.resources.cold_snapshot_root,
            snapshot_pool=snapshot_pool,
            snapshot_reservation_bytes=(arm.sandbox.memory_mib + 256) * 1024 * 1024,
        )
        lifetime = (arm.runtime.memory_mib + arm.sandbox.memory_mib
                    if arm.policy.admission is AdmissionPolicy.LIFETIME_FULL else 0)
        gateway_session: SessionGatewayState | None = None
        policy_session = None
        policy_drained = True
        lifetime_acquired = False
        wait_lock = Lock()
        wait_timer: Timer | None = None
        restore_timer: Timer | None = None
        wait_state: dict[str, Any] = {}
        completed_model_requests: set[str] = set()
        generated_model_requests: set[str] = set()
        generated_model_requests_lock = Lock()
        policy_event_errors: list[str] = []
        pending_policy_events: list[Any] = []
        pending_policy_events_lock = Lock()
        finalization_active = False

        def submit_policy_event(operation: Any, *args: Any) -> None:
            future = policy_events.submit(operation, *args)
            with pending_policy_events_lock:
                pending_policy_events.append(future)

        def drain_policy_events() -> None:
            """Finish this session's queued lifecycle work before validation."""
            drain_policy_futures(pending_policy_events, pending_policy_events_lock,
                                 arm.execution.arm_timeout_seconds)

        if arm.agent.driver is AgentDriver.OPENCLAW:
            if self.model_gateway is None:
                raise RuntimeError("managed ModelGateway is not active")
            # Native OpenClaw can keep its long-lived Agent process in a VM
            # snapshot.  During a model wait, snapshot both VMs for a
            # snapshot_pause policy; Runtime is restored before the gateway
            # response is released, while Tool may stay swapped until the
            # next SSH admission.
            runtime_snapshot_enabled = (
                arm.policy.reclamation is ReclamationPolicy.SNAPSHOT_PAUSE
            )
            prediction_wait = inference_configuration.get("model_wait_prediction_seconds")
            prediction_source = inference_configuration.get(
                "model_wait_prediction_source"
            )
            if prediction_wait is not None:
                try:
                    prediction_wait = float(prediction_wait)
                except (TypeError, ValueError) as exc:
                    raise ValueError("model_wait_prediction_seconds must be finite") from exc
                if not math.isfinite(prediction_wait) or prediction_wait < 0:
                    raise ValueError("model_wait_prediction_seconds must be non-negative")

            def pause_for_model_wait(event: dict[str, Any]) -> None:
                nonlocal wait_timer
                try:
                    with wait_lock:
                        wait_timer = None
                        request_id = str(event.get("request_id"))
                        with generated_model_requests_lock:
                            response_generated = request_id in generated_model_requests
                        if (
                            request_id in completed_model_requests
                            or response_generated
                            or not lifecycle.resident
                            or coordinator.tool_active(session_id)
                        ):
                            return
                        if gateway_session is None:
                            raise RuntimeError("model wait has no gateway session")
                        agent_pid_before = observe_openclaw_agent_pid("before_tool_pause")
                        started = time.time()
                        target_tier = (
                            SnapshotTier(str(wait_state["target_tier"]))
                            if wait_state.get("target_tier") else None
                        )
                        tool_elapsed = lifecycle.checkpoint_and_evict(tier=target_tier)
                        agent_pid_after = observe_openclaw_agent_pid("after_tool_pause")
                        if agent_pid_before != agent_pid_after:
                            raise RuntimeError(
                                "OpenClaw agent PID changed across Tool pause: "
                                f"{agent_pid_before} -> {agent_pid_after}"
                            )
                        finished = time.time()
                        wait_state.update({
                            "pause_started_at": started,
                            "pause_completed_at": finished,
                            "pause_request_id": event.get("request_id"),
                            "openclaw_agent_pid": agent_pid_after,
                        })
                        runtime_elapsed = None
                        runtime_pause_timing = None
                        if runtime_snapshot_enabled and runtime_lifecycle.resident:
                            runtime_pid_before = observe_openclaw_agent_pid(
                                "before_runtime_pause"
                            )
                            runtime_started = time.time()
                            gateway_session.invalidate_pending_delivery()
                            runtime_elapsed = runtime_lifecycle.checkpoint_and_evict(
                                tier=target_tier
                            )
                            runtime_pause_timing = dict(runtime_lifecycle.timings[-1])
                            runtime_finished = time.time()
                            wait_state.update({
                                "runtime_pause_started_at": runtime_started,
                                "runtime_pause_completed_at": runtime_finished,
                                "runtime_pause_request_id": event.get("request_id"),
                                "runtime_agent_pid_before_pause": runtime_pid_before,
                            })
                    if tool_elapsed is not None:
                        coordinator.pause_count += 1
                        coordinator.pause_service_seconds += tool_elapsed
                        events.write({
                            "event": "sandbox_paused", "session_id": session_id,
                            "role": "tool", "service_seconds": tool_elapsed,
                            "reason": "model_request_wait",
                            "request_id": event.get("request_id"),
                            "snapshot_tier": lifecycle.tier.value,
                            "lifecycle_timing": lifecycle.timings[-1],
                        })
                    if runtime_elapsed is not None:
                        coordinator.pause_count += 1
                        coordinator.pause_service_seconds += runtime_elapsed
                        events.write({
                            "event": "sandbox_paused", "session_id": session_id,
                            "role": "runtime", "service_seconds": runtime_elapsed,
                            "reason": "model_request_wait",
                            "request_id": event.get("request_id"),
                            "snapshot_tier": runtime_lifecycle.tier.value,
                            "lifecycle_timing": runtime_pause_timing,
                        })
                except Exception as exc:
                    policy_event_errors.append(f"pause: {type(exc).__name__}: {exc}")
                    events.write({"event": "policy_event_failed", "session_id": session_id,
                                  "operation": "pause", "error": str(exc),
                                  "error_type": type(exc).__name__})

            def restore_runtime_for_model_wait_locked(
                event: dict[str, Any], *, phase: str,
            ) -> None:
                """Restore Runtime while the caller holds ``wait_lock``."""
                if not runtime_snapshot_enabled:
                    return
                if runtime_lifecycle.resident:
                    return
                started = time.time()
                agent_pid_before = wait_state.get(
                    "runtime_agent_pid_before_pause"
                )
                self._restore_with_one_victim(
                    arm, session_id, runtime_lifecycle, coordinator, events,
                    role="runtime",
                )
                relay_started = time.time()
                relay_result = _execute_idempotent(
                    runtime_executor,
                    f"curl -fsS -X POST {shlex.quote(RELAY_CHECKPOINT_URL)}",
                    10,
                )
                if relay_result.exit_code:
                    raise RuntimeError(
                        "Runtime model relay checkpoint notification failed: "
                        f"{relay_result.stderr[-1000:]}"
                    )
                relay_finished = time.time()
                _record_time_span(
                    timeline, "model.relay_reconnect",
                    relay_started, relay_finished,
                    role="runtime", operation="model_relay_reconnect",
                    execution_id=str(event.get("request_id") or ""),
                )
                events.write({
                    "event": "model_relay_reconnected",
                    "session_id": session_id,
                    "request_id": event.get("request_id"),
                    "service_seconds": max(0.0, relay_finished - relay_started),
                })
                agent_pid_after = observe_openclaw_agent_pid(
                    f"after_runtime_restore_{phase}"
                )
                if agent_pid_before is not None and agent_pid_before != agent_pid_after:
                    raise RuntimeError(
                        "OpenClaw agent PID changed across Runtime pause/restore: "
                        f"{agent_pid_before} -> {agent_pid_after}"
                    )
                finished = time.time()
                wait_state.update({
                    "runtime_restore_started_at": started,
                    "runtime_restore_completed_at": finished,
                    "runtime_restore_request_id": event.get("request_id"),
                    "runtime_agent_pid_after_restore": agent_pid_after,
                })

            def restore_for_model_wait(event: dict[str, Any]) -> None:
                nonlocal restore_timer
                try:
                    with wait_lock:
                        restore_timer = None
                        if str(event.get("request_id")) in completed_model_requests:
                            return
                        restore_runtime_for_model_wait_locked(
                            event, phase="scheduled",
                        )
                except Exception as exc:
                    policy_event_errors.append(f"restore: {type(exc).__name__}: {exc}")

            def on_model_request_started(event: dict[str, Any]) -> None:
                """Enqueue lifecycle work; never checkpoint in the gateway callback."""
                submit_policy_event(handle_model_request_started, event)

            def handle_model_request_started(event: dict[str, Any]) -> None:
                nonlocal wait_timer, restore_timer
                timeline.setdefault("first_model_request", float(event["request_started_at"]))
                request_id = str(event.get("request_id"))
                with wait_lock:
                    with generated_model_requests_lock:
                        response_generated = request_id in generated_model_requests
                    # A zero-scaled replay response can arrive before the
                    # executor gets scheduled. Never create a late checkpoint
                    # for an already completed model request.
                    if request_id in completed_model_requests or response_generated:
                        return
                coordinator.set_eviction_eligible(session_id, True)
                oracle_wait = event.get("oracle_model_wait_seconds")
                if arm.policy.eviction is EvictionPolicy.WAIT_AWARE_PRESSURE:
                    if prediction_wait is None:
                        raise RuntimeError(
                            "wait-aware policy is missing model wait prediction"
                        )
                    coordinator.begin_model_wait(
                        session_id, request_id, prediction_wait,
                    )
                elif arm.policy.eviction in {
                    EvictionPolicy.TIERED_LRU_ORACLE,
                    EvictionPolicy.TIERED_TIME_ORACLE,
                }:
                    if oracle_wait is None:
                        raise RuntimeError("tiered oracle wait is missing frozen replay duration")
                    coordinator.begin_model_wait(
                        session_id, request_id, float(oracle_wait),
                    )
                if arm.policy.reclamation is ReclamationPolicy.RESIDENT:
                    return
                target_tier = None
                if arm.policy.eviction is EvictionPolicy.EAGER:
                    delay = 0.0
                elif arm.policy.eviction is EvictionPolicy.FIXED_DELAY:
                    delay = float(arm.policy.fixed_delay_seconds or 0.0)
                elif arm.policy.eviction is EvictionPolicy.WAIT_AWARE_PRESSURE:
                    delay = 0.0 if coordinator.blocked_demand_pressure() else None
                elif arm.policy.eviction is EvictionPolicy.TIME_ORACLE:
                    break_even = float(
                        arm.policy.checkpoint_break_even_seconds or 0.0
                    )
                    delay = (
                        0.0
                        if oracle_wait is not None
                        and float(oracle_wait) >= break_even
                        else None
                    )
                elif arm.policy.eviction is EvictionPolicy.TIERED_TIME_ORACLE:
                    target_tier = coordinator.oracle_tier(float(oracle_wait))
                    delay = 0.0 if target_tier is not SnapshotTier.LOCAL else None
                elif arm.policy.eviction is EvictionPolicy.TIERED_LRU_ORACLE:
                    target_tier = None
                    delay = None
                else:
                    delay = None
                with wait_lock:
                    wait_state.clear()
                    wait_state.update({
                        "request_id": event.get("request_id"),
                        "request_started_at": event.get("request_started_at"),
                        "predicted_wait_seconds": prediction_wait,
                        "prediction_source": prediction_source,
                        "oracle_wait_seconds": event.get(
                            "oracle_model_wait_seconds"
                        ),
                        "oracle_wait_source": event.get(
                            "oracle_model_wait_source"
                        ),
                        "checkpoint_break_even_seconds": (
                            arm.policy.checkpoint_break_even_seconds
                        ),
                        "target_tier": target_tier.value if target_tier is not None else None,
                    })
                    elapsed_since_request = max(
                        0.0, time.time() - float(event["request_started_at"])
                    )
                    restore_target = None
                    if prediction_wait is not None and arm.policy.restore is RestorePolicy.PROACTIVE:
                        restore_target = (
                            float(event["request_started_at"])
                            + prediction_wait
                            - float(arm.policy.prefetch_lead_seconds or 0.0)
                        )
                        wait_state["scheduled_restore_time"] = restore_target
                    if delay is not None:
                        wait_timer = Timer(
                            max(0.0, float(delay) - elapsed_since_request),
                            lambda: submit_policy_event(pause_for_model_wait, event),
                        )
                        wait_timer.daemon = True
                        wait_timer.start()
                    if prediction_wait is not None and arm.policy.restore is RestorePolicy.PROACTIVE:
                        lead = float(arm.policy.prefetch_lead_seconds or 0.0)
                        restore_timer = Timer(
                            max(0.0, prediction_wait - lead - elapsed_since_request),
                            lambda: submit_policy_event(restore_for_model_wait, event),
                        )
                        restore_timer.daemon = True
                        restore_timer.start()

            def before_model_response_ready(step: int | None, message: dict[str, Any],
                                            event: dict[str, Any]) -> dict[str, Any]:
                nonlocal wait_timer, restore_timer
                request_id = str(event.get("request_id"))
                coordinator.complete_model_wait(session_id, request_id)
                # Publish generation before waiting for lifecycle serialization.
                # A queued eager-pause callback must not start checkpointing a
                # Runtime after its model response already exists.
                with generated_model_requests_lock:
                    generated_model_requests.add(request_id)
                # A paused Runtime cannot receive the pending HTTP response.
                # Restore it synchronously in the gateway producer before the
                # response becomes visible to OpenClaw. Tool restore remains
                # admission-scoped and happens on the next SSH invocation.
                with wait_lock:
                    # Claim completion before checking residency. Otherwise a
                    # queued eager pause can run between a resident check and
                    # this marker, snapshotting Runtime after the response is
                    # ready and leaving no callback able to restore it.
                    completed_model_requests.add(request_id)
                    if wait_timer is not None:
                        wait_timer.cancel()
                        wait_timer = None
                    if restore_timer is not None:
                        restore_timer.cancel()
                        restore_timer = None
                    restore_runtime_for_model_wait_locked(
                        event, phase="response",
                    )
                    started = float(event["request_started_at"])
                    generated = float(event["model_generated_at"])
                    actual_wait = max(0.0, generated - started)
                    request_state = (
                        dict(wait_state)
                        if str(wait_state.get("request_id")) == request_id
                        else {}
                    )
                    if request_state:
                        wait_state["model_generated_at"] = generated
                    admission = {
                        "request_id": event.get("request_id"),
                        "model_step": step,
                        "runtime_snapshot_enabled": runtime_snapshot_enabled,
                        "tool_snapshot_performed": (
                            str(request_state.get("pause_request_id")) == request_id
                        ),
                        "runtime_snapshot_performed": (
                            str(request_state.get("runtime_pause_request_id")) == request_id
                        ),
                        "predicted_wait_seconds": prediction_wait,
                        "prediction_source": prediction_source,
                        "oracle_wait_seconds": request_state.get(
                            "oracle_wait_seconds"
                        ),
                        "oracle_wait_source": request_state.get(
                            "oracle_wait_source"
                        ),
                        "checkpoint_break_even_seconds": request_state.get(
                            "checkpoint_break_even_seconds"
                        ),
                        "actual_wait_seconds": actual_wait,
                        "prediction_error_seconds": (
                            None if prediction_wait is None else actual_wait - prediction_wait
                        ),
                        "scheduled_restore_time": request_state.get("scheduled_restore_time"),
                        "tool_pause_started_at": request_state.get("pause_started_at"),
                        "tool_pause_completed_at": request_state.get("pause_completed_at"),
                        "restore_started_at": request_state.get("restore_started_at"),
                        "restore_completed_at": request_state.get("restore_completed_at"),
                        "runtime_pause_started_at": request_state.get(
                            "runtime_pause_started_at"
                        ),
                        "runtime_pause_completed_at": request_state.get(
                            "runtime_pause_completed_at"
                        ),
                        "runtime_restore_started_at": request_state.get(
                            "runtime_restore_started_at"
                        ),
                        "runtime_restore_completed_at": request_state.get(
                            "runtime_restore_completed_at"
                        ),
                        "runtime_agent_pid_before_pause": request_state.get(
                            "runtime_agent_pid_before_pause"
                        ),
                        "runtime_agent_pid_after_restore": request_state.get(
                            "runtime_agent_pid_after_restore"
                        ),
                        "tool_call_count": len(message.get("tool_calls") or []),
                    }
                    return admission

            trace_path = (
                Path(arm.case.replay_trace_reference)
                if arm.inference.backend.value == "replay"
                and arm.case.replay_trace_reference else None
            )
            gateway_session = self.model_gateway.register(
                session_id=session_id,
                store_path=self.output_root / "model-gateway" / f"{session_id}.json",
                mode=arm.inference.backend.value,
                trace=trace_path,
                time_scale=float(inference_configuration.get("time_scale", 1.0)),
                max_model_steps=inference_configuration.get("max_model_steps"),
                upstream_base_url=str(inference_configuration.get("base_url") or "") or None,
                upstream_api_key=credential or None,
                upstream_model=str(inference_configuration.get("model") or "") or None,
                on_request_started=on_model_request_started,
                before_response_ready=before_model_response_ready,
            )
            runtime_env["CLAWBOX_MODEL_GATEWAY_TOKEN"] = gateway_session.token
            # CubeSandboxLifecycle snapshots env_vars at construction time.
            # The per-session gateway token is created later so callbacks can
            # capture both lifecycles; copy it into the lifecycle payload
            # before the Runtime VM is materialized.
            runtime_lifecycle.env_vars["CLAWBOX_MODEL_GATEWAY_TOKEN"] = (
                gateway_session.token
            )
        # Delay coordinator registration until every pre-VM validation and
        # per-session gateway registration has succeeded.  Otherwise a bad
        # replay path or gateway setup error can leave a non-existent session
        # occupying policy state even though the main cleanup block was never
        # entered.
        coordinator.register(session_id, lifecycle)
        coordinator.register_runtime(
            session_id, runtime_lifecycle,
            before_pause=(
                gateway_session.invalidate_pending_delivery
                if gateway_session is not None else None
            ),
        )
        try:
            if lifetime:
                coordinator.acquire_capacity(
                    session_id, lifetime, arm.execution.arm_timeout_seconds,
                )
                lifetime_acquired = True
            if sandbox_create_gate is not None:
                timeline["sandbox_create_gate_wait_start"] = time.time()
                sandbox_create_gate.acquire()
                timeline["sandbox_create_gate_acquired"] = time.time()
                events.write({
                    "event": "sandbox_create_gate_acquired", "session_id": session_id,
                    "wait_seconds": max(
                        0.0,
                        timeline["sandbox_create_gate_acquired"]
                        - timeline["sandbox_create_gate_wait_start"],
                    ),
                })
            pair_reservation = 0
            try:
                if not lifetime:
                    pair_amount = arm.sandbox.memory_mib + arm.runtime.memory_mib
                    pair_wait = coordinator.acquire(
                        session_id, pair_amount, arm.execution.arm_timeout_seconds,
                        wait_class="create",
                    )
                    pair_reservation = pair_amount
                timeline["sandbox_create_start"] = time.time()
                timeline["tool_create_start"] = time.time()
                if lifetime:
                    tool_create_s, tool_create_reservation_wait = lifecycle.start(), 0.0
                else:
                    tool_create_s, tool_create_reservation_wait = lifecycle.start(), pair_wait
                    coordinator.release(session_id, arm.sandbox.memory_mib)
                    pair_reservation -= arm.sandbox.memory_mib
                timeline["tool_ready"] = time.time()
                events.write({"event": "sandbox_created", "session_id": session_id,
                              "role": "tool", "service_seconds": tool_create_s,
                              "materialization_reservation_mib": arm.sandbox.memory_mib,
                              "materialization_reservation_wait_seconds": tool_create_reservation_wait,
                              "lifecycle_timing": lifecycle.timings[-1],
                              "sandbox_id": self.client.sandbox_id(lifecycle.sandbox)})
                setup_route = None
                if arm.agent.driver is AgentDriver.OPENCLAW:
                    tool_endpoint = self.client.get_tcp_endpoint(lifecycle.sandbox, 2222)
                    route_epoch += 1
                    setup_route = native_ssh_route(tool_endpoint, epoch=route_epoch)
                    try:
                        endpoint_address = ipaddress.ip_address(setup_route.host)
                    except ValueError as exc:
                        raise RuntimeError(
                            f"CubeSandbox returned a non-IP TCP endpoint host: {setup_route.host!r}"
                        ) from exc
                    runtime_lifecycle.ensure_network_allow_out(
                        f"{endpoint_address}/{32 if endpoint_address.version == 4 else 128}"
                    )
                timeline["runtime_create_start"] = time.time()
                if lifetime:
                    runtime_create_s, runtime_create_reservation_wait = runtime_lifecycle.start(), 0.0
                else:
                    runtime_create_s, runtime_create_reservation_wait = runtime_lifecycle.start(), 0.0
                    coordinator.release(session_id, arm.runtime.memory_mib)
                    pair_reservation -= arm.runtime.memory_mib
                timeline["runtime_ready"] = time.time()
                timeline["sandbox_ready"] = timeline["runtime_ready"]
                events.write({"event": "sandbox_created", "session_id": session_id,
                              "role": "runtime", "service_seconds": runtime_create_s,
                              "materialization_reservation_mib": arm.runtime.memory_mib,
                              "materialization_reservation_wait_seconds": runtime_create_reservation_wait,
                              "lifecycle_timing": runtime_lifecycle.timings[-1],
                              "sandbox_id": self.client.sandbox_id(runtime_lifecycle.sandbox)})
            finally:
                if pair_reservation:
                    coordinator.release(session_id, pair_reservation)
                if sandbox_create_gate is not None:
                    sandbox_create_gate.release()
            create_s = runtime_create_s + tool_create_s
            runtime_executor = CubeCommandExecutor(
                self.client, lambda: runtime_lifecycle.sandbox, cwd=arm.runtime.workspace,
            )
            executor = CubeCommandExecutor(self.client, lambda: lifecycle.sandbox, cwd=arm.sandbox.workspace)
            if arm.sandbox.preflight_command:
                preflight = executor.execute(arm.sandbox.preflight_command, arm.execution.command_timeout_seconds)
                events.write({"event": "task_environment_checked", "session_id": session_id,
                              "exit_code": preflight.exit_code,
                              "stdout": preflight.stdout[-16000:], "stderr": preflight.stderr[-16000:]})
                if preflight.exit_code != 0:
                    raise RuntimeError("Task environment preflight failed: " +
                                       (preflight.stderr or preflight.stdout)[-2000:])
            agent_pid_file = f"/state/openclaw/{session_id}/agent.pid"
            agent_pid_observations: list[dict[str, Any]] = []

            def observe_openclaw_agent_pid(phase: str) -> int | None:
                """Prove the long-lived Runtime agent remains alive across Tool lifecycle work."""
                if arm.agent.driver is not AgentDriver.OPENCLAW:
                    return None
                result = _execute_idempotent(runtime_executor,
                    "pid=$(cat " + shlex.quote(agent_pid_file) + ") && "
                    "case $pid in ''|*[!0-9]*) exit 1;; esac && "
                    "kill -0 $pid && printf '%s' $pid",
                    15,
                )
                if result.exit_code:
                    raise RuntimeError(
                        f"OpenClaw agent PID is not alive during {phase}: {result.stderr[-500:]}"
                    )
                try:
                    pid = int(result.stdout.strip())
                except ValueError as exc:
                    raise RuntimeError(
                        f"OpenClaw agent PID was invalid during {phase}: {result.stdout!r}"
                    ) from exc
                agent_pid_observations.append({"phase": phase, "pid": pid})
                events.write({
                    "event": "openclaw_agent_pid_observed", "session_id": session_id,
                    "phase": phase, "pid": pid, "alive": True,
                })
                return pid

            def resolve_native_ssh_route(phase: str) -> NativeSSHRoute:
                """Resolve CubeSandbox's current route at an operation boundary."""
                nonlocal route_epoch, ssh_config
                if lifecycle.sandbox is None:
                    raise RuntimeError("native SSH route requested before Tool start")
                endpoint = self.client.get_tcp_endpoint(lifecycle.sandbox, 2222)
                route_epoch += 1
                route = native_ssh_route(endpoint, epoch=route_epoch)
                try:
                    endpoint_address = ipaddress.ip_address(route.host)
                except ValueError as exc:
                    raise RuntimeError(
                        f"CubeSandbox returned a non-IP TCP endpoint host: {route.host!r}"
                    ) from exc
                endpoint_cidr = (
                    f"{endpoint_address}/{32 if endpoint_address.version == 4 else 128}"
                )
                added_endpoint_host = runtime_lifecycle.ensure_network_allow_out(endpoint_cidr)
                if ssh_config is not None:
                    # OpenClaw captured its SSH target when run_openclaw was
                    # constructed. This local descriptor is updated only for
                    # the later Worker-owned artifact collection SSH call;
                    # per-admission Agent routing comes from the shim response.
                    ssh_config = replace(ssh_config, target=route.target)
                events.write({
                    "event": "native_ssh_endpoint_resolved", "session_id": session_id,
                    "sandbox_id": route.sandbox_id, "container_port": route.container_port,
                    "endpoint_epoch": route.epoch, "host": route.host, "port": route.port,
                    "tcp_endpoint": endpoint.address, "phase": phase,
                    "runtime_endpoint_host_allowlisted": endpoint_cidr,
                    "runtime_endpoint_host_allowlist_added": added_endpoint_host,
                    "source": "cubesandbox_tcp_endpoint",
                })
                return route

            exit_mismatches = 0
            model_steps = 0
            tool_latencies: list[float] = []
            prediction_records: list[dict[str, Any]] = []
            observed_by_execution: dict[str, Any] = {}
            trace_writer = ClawTuneTraceWriter(
                self.output_root, run_id=self.run_id, session_id=session_id,
                repo_fingerprint=(arm.case.repository or str(
                    inference_configuration.get("repo_fingerprint") or ""
                ) or None),
            )

            def execute_observed(command: str, timeout_s: float,
                                 execution_id: str, *, tool_name: str = "exec",
                                 prediction: dict[str, Any] | None = None,
                                 phase: str = "agent"):
                lifecycle.claim_first_tool_after_restore(execution_id)
                started_wall, started_mono = time.time(), time.monotonic()
                try:
                    observed = executor.execute_observed(
                        command, min(timeout_s, arm.execution.command_timeout_seconds),
                        execution_id=execution_id,
                    )
                except Exception:
                    report = lifecycle.complete_first_tool_after_restore(
                        execution_id, tool_seconds=time.monotonic() - started_mono, status="error")
                    if report is not None:
                        events.write({"event": "first_tool_after_restore", "session_id": session_id, **report})
                    _record_time_span(
                        timeline, "tool.operation", started_wall, time.time(),
                        role="tool", operation=tool_name, execution_id=execution_id,
                        start_monotonic=started_mono, end_monotonic=time.monotonic(),
                        status="error",
                    )
                    raise
                _record_time_span(
                    timeline, "tool.operation", started_wall, time.time(),
                    role="tool", operation=tool_name, execution_id=execution_id,
                    start_monotonic=started_mono, end_monotonic=time.monotonic(),
                    status="ok" if observed.result.exit_code == 0 else "error",
                )
                report = lifecycle.complete_first_tool_after_restore(
                    execution_id, tool_seconds=time.monotonic() - started_mono,
                    status="ok" if observed.result.exit_code == 0 else "error")
                if report is not None:
                    events.write({"event": "first_tool_after_restore", "session_id": session_id, **report})
                observed_by_execution[execution_id] = observed
                trace_writer.record(
                    command, observed.result, execution_id=execution_id,
                    bridge_record=observed.bridge_record, artifacts=observed.artifacts,
                    prediction=prediction, tool_name=tool_name, phase=phase,
                )
                events.write({
                    "event": "clawtune_observation", "session_id": session_id,
                    "execution_id": execution_id, "tool": tool_name,
                    "phase": phase,
                    "prediction": prediction,
                    "telemetry_state": observed.bridge_record.get("telemetry_state"),
                    "telemetry_unavailable_reason": observed.telemetry_unavailable_reason,
                    "artifact_kinds": sorted(observed.artifacts),
                })
                return observed.result

            timeline["agent_execution_start"] = time.time()
            model_trace_path: Path | None = None
            native_artifacts = None
            policy_control_path: Path | None = None
            if arm.agent.driver is AgentDriver.OPENCLAW:
                active_reservations: dict[str, int] = {}
                admitted_routes: dict[str, NativeSSHRoute] = {}
                host_rss_samplers: dict[str, SandboxRSSSampler] = {}
                reservation_lock = Lock()

                def admit_openclaw_tool(request: dict[str, Any]) -> dict[str, Any]:
                    execution_id = str(request["execution_id"])
                    execution_scope = str(
                        request.get("execution_scope") or "agent-tool"
                    )
                    managed_command = (execution_scope == "agent-tool"
                                       and request.get("operation") != "filesystem")
                    if (managed_command and arm.policy.admission is AdmissionPolicy.TOOL_P50
                            and prediction_provider is None):
                        metadata = request.get("prediction")
                        if (not isinstance(metadata, dict)
                                or metadata.get("raw_command_sha256") != request["command_sha256"]):
                            raise PredictionUnavailable("ClawTune prediction command identity mismatch")
                        prediction = clawtune_extra_peak(metadata.get("call_prediction"))
                    elif managed_command and prediction_provider is not None:
                        prediction = prediction_provider.resolve_digest(
                            str(request["command_sha256"]), request.get("prediction")
                        )
                    else:
                        prediction = request.get("prediction")
                    if (arm.policy.admission in {AdmissionPolicy.TOOL_P50, AdmissionPolicy.TOOL_ORACLE}
                            and not managed_command):
                        # File bridge operations have no shell-command KB entry.
                        # Charge their configured static budget explicitly.
                        filesystem_tool = request.get("operation") == "filesystem"
                        prediction = {
                            "canonical_prediction_key": (
                                "filesystem" if filesystem_tool else "ssh-backend-maintenance"
                            ),
                            "prediction_source": (
                                "filesystem_static" if filesystem_tool else "backend_maintenance_static"
                            ),
                            "fallback_level": "not_applicable",
                            "predicted_incremental_memory_mib": int(
                                arm.resources.non_command_tool_memory_mib
                                or arm.resources.static_tool_memory_mib or 1
                            ),
                        }
                    amount = self._tool_reservation_mib(arm, prediction=prediction)
                    reservation_acquired = False
                    with wait_lock:
                        try:
                            admission_wait = coordinator.begin_tool_admission(
                                session_id, amount, arm.execution.arm_timeout_seconds
                            )
                            reservation_acquired = True
                            restored_tool = not lifecycle.resident
                            if restored_tool:
                                self._restore_with_one_victim(
                                    arm, session_id, lifecycle, coordinator, events,
                                )
                                bridge_ready_started = time.monotonic()
                                bridge_error: Exception | None = None
                                bridge_result = None
                                for bridge_attempt in range(1, 31):
                                    try:
                                        # A snapshot restore normally resumes
                                        # the existing bridge process. Probe it
                                        # first; killing a healthy resumed
                                        # bridge creates avoidable races at
                                        # high concurrency. Periodic restarts
                                        # remain an idempotent recovery path.
                                        candidate = executor.execute(
                                            native_tool_bridge_setup_command(
                                                restart=bridge_attempt in (2, 10, 20),
                                            ),
                                            60,
                                        )
                                        if candidate.exit_code == 0:
                                            bridge_result = candidate
                                            break
                                        bridge_error = RuntimeError(
                                            "bridge setup exited "
                                            f"{candidate.exit_code}: {candidate.stderr[-1000:]}"
                                        )
                                    except Exception as exc:
                                        bridge_error = exc
                                    if bridge_attempt < 30:
                                        time.sleep(0.5)
                                if bridge_result is None:
                                    raise RuntimeError(
                                        "Tool telemetry bridge did not recover after restore "
                                        "within 30 readiness attempts; last error: "
                                        f"{type(bridge_error).__name__}: {bridge_error}"
                                    ) from bridge_error
                                events.write({
                                    "event": "tool_restore_ready",
                                    "session_id": session_id,
                                    "execution_id": execution_id,
                                    "attempts": bridge_attempt,
                                    "service_seconds": (
                                        time.monotonic() - bridge_ready_started
                                    ),
                                })
                            # Resolve only after the active mark and memory
                            # reservation. Restore may replace the mapping.
                            route = resolve_native_ssh_route("admit")
                            # Cube may publish a restored mapping slightly
                            # before CubeProxy accepts its fresh route. Prove
                            # reachability and the stable Tool identity from
                            # the Runtime before returning ADMIT; the Agent's
                            # actual SSH subprocess has not started yet.
                            identity_file = f"/state/openclaw/{session_id}/ssh/id_ed25519"
                            known_hosts_file = f"/state/openclaw/{session_id}/ssh/known_hosts"
                            endpoint_host = (
                                f"[{route.host}]" if ":" in route.host else route.host
                            )
                            identity_command = shlex.join([
                                "/usr/bin/ssh", "-i", identity_file,
                                "-o", f"UserKnownHostsFile={known_hosts_file}",
                                "-o", "StrictHostKeyChecking=yes",
                                "-o", "UpdateHostKeys=no",
                                "-o", f"HostKeyAlias={native_ssh_host_key_alias(route.sandbox_id)}",
                                "-o", "BatchMode=yes", "-o", "ConnectTimeout=2",
                                "-p", str(route.port), f"executor@{endpoint_host}",
                                "printf %s \"$TASK_ID\"",
                            ])
                            identity_started = time.monotonic()
                            identity_result = None
                            identity_error: Exception | None = None
                            for identity_attempt in range(1, 31):
                                try:
                                    candidate = runtime_executor.execute(identity_command, 30)
                                except Exception as exc:
                                    identity_error = exc
                                    if identity_attempt < 30:
                                        time.sleep(0.5)
                                    continue
                                if (candidate.exit_code == 0
                                        and candidate.stdout.strip() == session_id):
                                    identity_result = candidate
                                    break
                                if identity_attempt < 30:
                                    time.sleep(0.5)
                            if identity_result is None:
                                raise RuntimeError(
                                    "native SSH endpoint did not present the intended Tool "
                                    f"identity for {session_id} after {identity_attempt} attempts"
                                ) from identity_error
                            events.write({
                                "event": "native_ssh_identity_ready",
                                "session_id": session_id,
                                "execution_id": execution_id,
                                "sandbox_id": route.sandbox_id,
                                "endpoint_epoch": route.epoch,
                                "attempts": identity_attempt,
                                "service_seconds": time.monotonic() - identity_started,
                            })
                            host_sampler = SandboxRSSSampler(route.sandbox_id)
                            host_sampler.start()
                            with reservation_lock:
                                active_reservations[execution_id] = amount
                                admitted_routes[execution_id] = route
                                host_rss_samplers[execution_id] = host_sampler
                                if execution_scope == "agent-tool":
                                    lifecycle.claim_first_tool_after_restore(execution_id)
                        except Exception as exc:
                            events.write({
                                "event": "tool_admission_failed",
                                "session_id": session_id,
                                "execution_id": execution_id,
                                "error_type": type(exc).__name__,
                                "error": str(exc),
                                "reservation_acquired": reservation_acquired,
                            })
                            if reservation_acquired:
                                coordinator.release(session_id, amount)
                            coordinator.set_tool_active(session_id, False)
                            raise
                    prediction_record = dict(prediction or {})
                    prediction_record.setdefault(
                        "canonical_prediction_key",
                        f"sha256:{request['command_sha256']}",
                    )
                    prediction_record.setdefault(
                        "prediction_source", f"policy_{arm.policy.admission.value}"
                    )
                    prediction_record.setdefault("fallback_level", "not_applicable")
                    prediction_record.setdefault(
                        "predicted_incremental_memory_mib", float(amount)
                    )
                    prediction_record.update({
                                 "session_id": session_id,
                                 "execution_id": execution_id,
                                 "command_sha256": request["command_sha256"],
                                 "operation": request.get("operation"),
                                 "execution_scope": execution_scope,
                                 "actual_measured_memory_mib": None,
                                 "admitted_reservation_mib": amount,
                                 "admission_blocked_seconds": admission_wait,
                    })
                    prediction_records.append(prediction_record)
                    events.write({
                        "event": "tool_admitted", "session_id": session_id,
                        "execution_id": execution_id,
                        "command_sha256": request["command_sha256"],
                        "prediction_key": prediction_record.get("canonical_prediction_key"),
                        "prediction_source": prediction_record.get("prediction_source"),
                        "fallback_level": prediction_record.get("fallback_level"),
                        "predicted_memory_mib": prediction_record.get(
                            "predicted_incremental_memory_mib"
                        ),
                        "admitted_memory_mib": amount,
                        "admission_blocked_seconds": admission_wait,
                        "endpoint_sandbox_id": route.sandbox_id,
                        "endpoint_epoch": route.epoch,
                        "endpoint_host": route.host,
                        "endpoint_port": route.port,
                    })
                    return {
                        "decision": "ADMIT", "admitted_memory_mib": amount,
                        "admission_blocked_seconds": admission_wait,
                        "sandbox_id": route.sandbox_id, "epoch": route.epoch,
                        "container_port": route.container_port,
                        "host": route.host, "port": route.port,
                    }

                def complete_openclaw_tool(request: dict[str, Any]) -> dict[str, Any]:
                    execution_id = str(request["execution_id"])
                    timestamp_names = (
                        "execution_started_at", "ssh_reaped_at", "execution_completed_at",
                    )
                    timestamps: dict[str, float] = {}
                    for name in timestamp_names:
                        value = request.get(name)
                        if isinstance(value, bool) or not isinstance(value, (int, float)):
                            raise RuntimeError(f"completion is missing numeric {name}")
                        rendered = float(value)
                        if not math.isfinite(rendered):
                            raise RuntimeError(f"completion has non-finite {name}")
                        timestamps[name] = rendered
                    if not (
                        timestamps["execution_started_at"]
                        <= timestamps["ssh_reaped_at"]
                        <= timestamps["execution_completed_at"]
                    ):
                        raise RuntimeError(
                            "completion timestamps do not prove SSH reaped before complete"
                        )
                    # A concurrent admission holds wait_lock while waiting for
                    # memory. Completion must release its finished command's
                    # reservation without that lock, or both requests deadlock.
                    with reservation_lock:
                        amount = active_reservations.get(execution_id)
                        admitted_route = admitted_routes.get(execution_id)
                        host_sampler = host_rss_samplers.get(execution_id)
                        if amount is None or admitted_route is None or host_sampler is None:
                            raise RuntimeError(f"completion has no active admission for {execution_id}")
                        completion_route = (
                            request.get("endpoint_sandbox_id"),
                            request.get("endpoint_epoch"),
                            request.get("endpoint_host"),
                            request.get("endpoint_port"),
                        )
                        expected_route = (
                            admitted_route.sandbox_id, admitted_route.epoch,
                            admitted_route.host, admitted_route.port,
                        )
                        if completion_route != expected_route:
                            raise RuntimeError(
                                "completion endpoint does not match its admission: "
                                f"expected={expected_route!r} got={completion_route!r}"
                            )
                        active_reservations.pop(execution_id)
                        admitted_routes.pop(execution_id)
                        host_rss_samplers.pop(execution_id)
                        host_observation = host_sampler.stop()
                        report = lifecycle.complete_first_tool_after_restore(
                            execution_id,
                            tool_seconds=timestamps["execution_completed_at"] - timestamps["execution_started_at"],
                            status="ok" if int(request.get("exit_code", 1)) == 0 else "error")
                        for prediction_record in prediction_records:
                            if prediction_record.get("execution_id") == execution_id:
                                prediction_record.update(host_observation)
                                increment = host_observation.get(
                                    "actual_host_execution_increment_bytes"
                                )
                                prediction_record["actual_host_execution_increment_mib"] = (
                                    float(increment) / (1024.0 * 1024.0)
                                    if isinstance(increment, int) else None
                                )
                                break
                        coordinator.release(session_id, amount)
                        _record_time_span(
                            timeline, "tool.operation",
                            timestamps["execution_started_at"],
                            timestamps["execution_completed_at"],
                            role="tool", operation=str(request.get("operation") or "exec"),
                            execution_id=execution_id,
                            service_seconds=(
                                timestamps["execution_completed_at"]
                                - timestamps["execution_started_at"]
                            ),
                            status=(
                                "ok" if int(request.get("exit_code", 1)) == 0
                                else "error"
                            ),
                        )

                    # Keep lifecycle/idle transitions serialized with admission.
                    # Never hold reservation_lock while waiting for wait_lock.
                    with wait_lock, reservation_lock:
                        coordinator.set_tool_active(session_id, bool(active_reservations))
                    if report is not None:
                        events.write({"event": "first_tool_after_restore", "session_id": session_id, **report})
                    events.write({"event": "tool_completed", "session_id": session_id,
                                  "execution_id": execution_id,
                                  "exit_code": request.get("exit_code"),
                                  "ssh_reaped_at": timestamps["ssh_reaped_at"],
                                  "endpoint_epoch": expected_route[1]})
                    return {"status": "COMPLETED"}

                if self.policy_control is None:
                    raise RuntimeError("PolicyControlServer is not active")
                policy_session = self.policy_control.register(
                    session_id, admit=admit_openclaw_tool,
                    complete=complete_openclaw_tool,
                )
                # The Tool VM is authoritative for mutable state. Mark the
                # installed shared SSH runtime as initialized so OpenClaw does
                # not copy its Runtime-local workspace into the Tool.
                remote_runtime_dir = openclaw_shared_ssh_runtime_directory(
                    arm.sandbox.workspace
                )
                workspace_result = executor.execute(
                    f"mkdir -p -- {shlex.quote(remote_runtime_dir)}", 30,
                )
                if workspace_result.exit_code != 0:
                    raise RuntimeError(
                        "Tool setup could not initialize OpenClaw SSH workspace: "
                        + workspace_result.stderr[-1000:]
                    )
                tool_bridge_result = executor.execute(native_tool_bridge_setup_command(), 60)
                if tool_bridge_result.exit_code != 0:
                    raise RuntimeError(
                        "Tool setup could not start native SSH bridge: "
                        + tool_bridge_result.stderr[-1000:]
                    )
                if setup_route is None:
                    raise RuntimeError("OpenClaw Tool endpoint was not resolved")
                ssh_target = setup_route.target
                events.write({
                    "event": "native_ssh_endpoint_resolved", "session_id": session_id,
                    "sandbox_id": setup_route.sandbox_id,
                    "endpoint_epoch": setup_route.epoch,
                    "target": ssh_target, "container_port": setup_route.container_port,
                    "host": setup_route.host, "port": setup_route.port,
                    "phase": "setup", "source": "cubesandbox_tcp_endpoint",
                })
                ssh_config = NativeSSHConfig(
                    target=ssh_target,
                    identity_private_key=ssh_credentials.client_private,
                    host_public_key=ssh_credentials.host_public,
                    workspace_root=arm.sandbox.workspace,
                    sandbox_id=setup_route.sandbox_id,
                    host_key_alias=native_ssh_host_key_alias(setup_route.sandbox_id),
                )

                poll_resident_runtime = RuntimeStatusPoller(
                    lifecycle=runtime_lifecycle,
                    executor=runtime_executor,
                    lifecycle_lock=wait_lock,
                    snapshot_enabled=runtime_snapshot_enabled,
                )

                outcome = run_openclaw(
                    prompt=arm.case.prompt, session_id=session_id,
                    configuration=inference_configuration,
                    ssh=ssh_config,
                    policy_control=policy_session, runtime_executor=runtime_executor,
                    output_dir=self.output_root,
                    timeout_seconds=arm.execution.arm_timeout_seconds,
                    model_gateway=gateway_session,
                    prediction_manifest=(prediction_provider.manifest
                                         if prediction_provider is not None else None),
                    resident_poll=poll_resident_runtime,
                    checkpoint_relay=runtime_snapshot_enabled,
                )
                if outcome.get("agent_pid_file") != agent_pid_file:
                    raise RuntimeError("OpenClaw agent PID witness path was not initialized")
                coordinator.set_tool_active(session_id, True)
                finalization_active = True
                # No Agent SSH process remains after run_openclaw returns.
                # Drain callbacks already queued by model/tool completions so
                # none can pause a VM underneath collection or validation.
                with wait_lock:
                    if wait_timer is not None:
                        wait_timer.cancel()
                        wait_timer = None
                    if restore_timer is not None:
                        restore_timer.cancel()
                        restore_timer = None
                drain_policy_events()
                timeline["openclaw_agent_pid_observations"] = list(agent_pid_observations)
                tool_latencies.extend(float(item) for item in outcome["tool_latencies"])
                policy_control_path = self.output_root / "policy-control" / f"{session_id}.json"
                atomic_json(policy_control_path, outcome["policy_control_records"])
                # A completed Agent call may have triggered eager Tool eviction.
                # Serialize restore and collection with delayed model-wait and
                # eager-pause callbacks so the Tool cannot disappear halfway
                # through the artifact stream.
                with wait_lock:
                    if not lifecycle.resident:
                        self._restore_with_one_victim(
                            arm, session_id, lifecycle, coordinator, events,
                        )
                    resolve_native_ssh_route("collection")
                    if ssh_config is None:
                        raise RuntimeError("native SSH config was not initialized")
                    native_artifacts = collect_and_validate_native_tool_artifacts(
                        runtime_executor=runtime_executor, ssh=ssh_config,
                        session_id=session_id, output_dir=self.output_root,
                        policy_records=outcome["policy_control_records"],
                        runtime_trace_paths=outcome["runtime_traces"],
                    )
                    predicted_execution_ids = {
                        str(item.get("execution_id") or "")
                        for item in prediction_records
                    }
                    enrich_tool_execution_observations(
                        prediction_records, {
                            execution_id: artifact
                            for execution_id, artifact
                            in native_artifacts.cgroup_artifacts.items()
                            if execution_id in predicted_execution_ids
                        },
                    )
                events.write({
                    "event": "native_tool_artifacts_collected",
                    "session_id": session_id,
                    "root": str(native_artifacts.root),
                    "validation": native_artifacts.validation,
                })
                if gateway_session is None:
                    raise RuntimeError("managed OpenClaw session has no ModelGateway state")
                model_steps = gateway_session.gateway.logical_model_steps()
                completeness = gateway_session.replay_completeness()
                if not completeness["complete"]:
                    raise RuntimeError(
                        "managed ModelGateway session incomplete: "
                        + json.dumps(completeness, sort_keys=True)
                    )
                if not tool_latencies:
                    raise RuntimeError(
                        "OpenClaw completed without using a required native Tool operation"
                    )
                if arm.inference.backend.value == "api":
                    recordings = find_recordings(outcome["runtime_traces"], session_id)
                    if len(recordings) != 1:
                        raise RuntimeError("live agent must produce one complete native model recording")
                    if len(load_trace(recordings[0])) != len(gateway_session.records()):
                        raise RuntimeError("native recording does not cover every model call")
                    events.write({
                        "event": "model_trace_recorded",
                        "session_id": session_id,
                        "paths": [str(path) for path in recordings],
                        "format": "clawtune-schema-6",
                    })
                for gateway_record in gateway_session.records():
                    request_id = str(gateway_record.get("request_id") or "")
                    _record_time_span(
                        timeline, "model.wait",
                        gateway_record.get("request_started_at"),
                        gateway_record.get("model_generated_at"),
                        role="runtime", operation="model_wait",
                        execution_id=request_id,
                    )
                    _record_time_span(
                        timeline, "model.response_hold",
                        gateway_record.get("model_generated_at"),
                        gateway_record.get("response_released_at"),
                        role="runtime", operation="response_hold",
                        execution_id=request_id,
                    )
                    _record_time_span(
                        timeline, "model.response_delivery",
                        gateway_record.get("response_released_at"),
                        gateway_record.get("response_delivered_at"),
                        role="runtime", operation="response_delivery",
                        execution_id=request_id,
                    )
                timeline["final_agent_completion"] = time.time()
            validation = arm.validation.command or (
                arm.case.validation if isinstance(arm.case.validation, str) else None)
            valid = exit_mismatches == 0
            if not finalization_active:
                coordinator.set_tool_active(session_id, True)
                finalization_active = True
            timeline.setdefault("agent_execution_start", timeline.get("sandbox_ready", time.time()))
            # A delayed eager-pause callback from the final Tool completion
            # must not swap the Tool between collection and validation. Keep
            # restore, validation, and hashing in the same lifecycle critical
            # section; Agent commands have already terminated at this point.
            with wait_lock:
                if not lifecycle.resident:
                    self._restore_with_one_victim(
                        arm, session_id, lifecycle, coordinator, events,
                    )
                timeline["validation_start"] = time.time()
                if validation:
                    validation_result = _execute_idempotent(
                        executor, validation, arm.execution.command_timeout_seconds,
                    )
                    valid = valid and validation_result.exit_code == 0
                timeline["validation_end"] = time.time()
                timeline["output_hash_start"] = time.time()
                hash_result = _execute_idempotent(
                    executor,
                    "find . -type f -exec sha256sum {} \\; | LC_ALL=C sort | sha256sum",
                    arm.execution.command_timeout_seconds,
                )
                timeline["output_hash_end"] = time.time()
            timeline["output_hash_overhead_seconds"] = max(
                0.0, timeline["output_hash_end"] - timeline["validation_end"]
            )
            output_hash = (hash_result.stdout.split()[0] if hash_result.exit_code == 0
                           and hash_result.stdout.split() else hashlib.sha256(
                               json.dumps({"valid": valid, "mismatches": exit_mismatches},
                                          sort_keys=True).encode()).hexdigest())
            coordinator.set_tool_active(session_id, False)
            finalization_active = False
            events.write({"event": "session_complete", "session_id": session_id, "valid": valid})
            if not valid:
                raise RuntimeError(f"validation failed for {session_id}")
            events.write({
                "event": "managed_session_measurement",
                "session_id": session_id,
                "model_steps": model_steps,
                "tool_steps": len(tool_latencies),
                "model_gateway_records": (
                    gateway_session.records() if gateway_session is not None else []
                ),
                "model_gateway_completeness": (
                    gateway_session.replay_completeness()
                    if gateway_session is not None else None
                ),
                "prediction_records": prediction_records,
                "prediction_provenance": (
                    prediction_provider.provenance(prediction_records)
                    if prediction_provider is not None else None
                ),
            })
            if policy_event_errors:
                raise RuntimeError("policy event executor failed: " + "; ".join(policy_event_errors))
            return {"session_id": session_id, "case_id": arm.case.case_id,
                    "trace_reference": (
                        arm.case.replay_trace_reference or arm.case.source_reference
                    ),
                    "valid": valid, "create_seconds": create_s,
                    "runtime_create_seconds": runtime_create_s,
                    "tool_create_seconds": tool_create_s,
                    "duration_seconds": time.monotonic() - session_started,
                    "agent_jct_seconds": max(
                        0.0, timeline["final_agent_completion"] - timeline["agent_execution_start"]
                    ),
                    "provisioning_inclusive_jct_seconds": max(
                        0.0, timeline["final_agent_completion"] - timeline["sandbox_create_start"]
                    ),
                    "validation_overhead_seconds": max(
                        0.0, timeline["validation_end"] - timeline["final_agent_completion"]
                    ),
                    "tool_steps": len(tool_latencies), "model_steps": model_steps,
                    "tool_latencies": tool_latencies, "output_hash": output_hash,
                    "prediction_records": prediction_records,
                    "prediction_provenance": (
                        prediction_provider.provenance(prediction_records)
                        if prediction_provider is not None else None
                    ),
                    "model_gateway_records": (
                        gateway_session.records() if gateway_session is not None else []
                    ),
                    "model_gateway_completeness": (
                        gateway_session.replay_completeness()
                        if gateway_session is not None else None
                    ),
                     "model_trace_path": str(model_trace_path) if model_trace_path else None,
                     "policy_control_path": (
                         str(policy_control_path) if policy_control_path else None
                     ),
                     "runtime_trace_root": (
                         str(self.output_root / "runtime-traces" / session_id)
                         if arm.agent.driver is AgentDriver.OPENCLAW else None
                     ),
                     "native_tool_artifact_root": (
                         str(native_artifacts.root)
                         if arm.agent.driver is AgentDriver.OPENCLAW and native_artifacts
                         else None
                     ),
                     "native_tool_artifact_validation": (
                         native_artifacts.validation
                         if arm.agent.driver is AgentDriver.OPENCLAW and native_artifacts
                         else None
                     ),
                     "timeline": timeline}
        finally:
            cleanup_errors: list[str] = []

            def cleanup_step(label: str, operation: Any) -> Any:
                try:
                    return operation()
                except Exception as exc:
                    cleanup_errors.append(f"{label}: {type(exc).__name__}: {exc}")
                    return None

            if locals().get("trace_writer") is not None:
                cleanup_step("trace writer", trace_writer.close)
            if finalization_active:
                cleanup_step(
                    "tool active flag",
                    lambda: coordinator.set_tool_active(session_id, False),
                )
                finalization_active = False
            timeline["sandbox_cleanup_start"] = time.time()
            # Timer.cancel is thread-safe.  Cleanup must not wait for a policy
            # callback that may itself be blocked in external Cube I/O.
            if wait_timer is not None:
                wait_timer.cancel()
            if restore_timer is not None:
                restore_timer.cancel()
            if gateway_session is not None and self.model_gateway is not None:
                gateway_drained = cleanup_step(
                    "model gateway session",
                    lambda: self.model_gateway.unregister(
                        gateway_session.token, timeout=30,
                    ),
                )
                if gateway_drained is False:
                    cleanup_errors.append("model gateway session did not drain")
            if policy_session is not None:
                policy_drained = cleanup_step(
                    "policy session", lambda: policy_session.close(timeout=30),
                )
                if policy_drained is False:
                    cleanup_errors.append(f"policy session did not drain: {session_id}")
            for host_sampler in tuple(locals().get("host_rss_samplers", {}).values()):
                cleanup_step("host RSS sampler", host_sampler.stop)
            tool_destroy_s = cleanup_step("Tool sandbox", lifecycle.close)
            if tool_destroy_s is not None:
                cleanup_step("Tool destroy event", lambda: events.write({
                    "event": "sandbox_destroyed", "session_id": session_id,
                    "role": "tool", "service_seconds": tool_destroy_s,
                    "lifecycle_timing": lifecycle.timings[-1],
                }))
            runtime_destroy_s = cleanup_step("Runtime sandbox", runtime_lifecycle.close)
            if runtime_destroy_s is not None:
                cleanup_step("Runtime destroy event", lambda: events.write({
                    "event": "sandbox_destroyed", "session_id": session_id,
                    "role": "runtime", "service_seconds": runtime_destroy_s,
                    "lifecycle_timing": runtime_lifecycle.timings[-1],
                }))
            timeline["lifecycle_timings"] = [
                {"role": "tool", **timing}
                for timing in lifecycle.timings
            ] + [
                {"role": "runtime", **timing}
                for timing in runtime_lifecycle.timings
            ]
            timeline["sandbox_cleanup_end"] = time.time()
            timeline["session_finished"] = timeline["sandbox_cleanup_end"]
            timeline["time_spans"] = build_time_spans(timeline)
            cleanup_step("session timing event", lambda: events.write({
                "event": "session_timing", "session_id": session_id,
                "time_spans": timeline["time_spans"],
            }))
            if timeline.get("validation_end"):
                timeline["cleanup_overhead_seconds"] = max(
                    0.0, timeline["sandbox_cleanup_end"] - timeline["validation_end"]
                )
            if lifetime and lifetime_acquired:
                cleanup_step(
                    "lifetime capacity",
                    lambda: coordinator.release_capacity(session_id, lifetime),
                )
            cleanup_step("coordinator session", lambda: coordinator.unregister(session_id))
            if cleanup_errors:
                failure = RuntimeError(
                    f"session cleanup incomplete for {session_id}: "
                    + "; ".join(cleanup_errors)
                )
                active_exception = sys.exception()
                if active_exception is not None:
                    active_exception.add_note(str(failure))
                else:
                    raise failure


    def _restore_with_one_victim(self, arm: ExperimentArm, session_id: str,
                                 lifecycle: CubeSandboxLifecycle,
                                 coordinator: PolicyCoordinator, events: EventWriter,
                                 *, role: str = "tool") -> float:
        reservation_mib = (
            arm.runtime.memory_mib if role == "runtime" else arm.sandbox.memory_mib
        )
        elapsed, reservation_wait = coordinator.restore(
            session_id, reservation_mib, lifecycle.restore,
            arm.execution.arm_timeout_seconds,
        )
        events.write({"event": "sandbox_restored", "session_id": session_id,
                      "role": role, "service_seconds": elapsed,
                      "materialization_reservation_mib": reservation_mib,
                      "materialization_reservation_wait_seconds": reservation_wait,
                      "lifecycle_timing": lifecycle.timings[-1]})
        return elapsed

    def _tool_reservation_mib(self, arm: ExperimentArm, *,
                              prediction: dict[str, Any] | None = None) -> int:
        policy = arm.policy.admission
        if policy is AdmissionPolicy.LIFETIME_FULL:
            return 0
        if policy is AdmissionPolicy.TOOL_FULL:
            return int(arm.resources.full_tool_memory_mib or arm.sandbox.memory_mib)
        if policy is AdmissionPolicy.TOOL_STATIC:
            return int(arm.resources.static_tool_memory_mib or 1)
        if (policy in {AdmissionPolicy.TOOL_P50, AdmissionPolicy.TOOL_ORACLE}
                and prediction is None
                and arm.agent.driver is AgentDriver.OPENCLAW):
            raise PredictionUnavailable(
                f"managed {policy.value} cannot admit without Runtime command metadata"
            )
        if prediction is not None:
            value = prediction.get("predicted_incremental_memory_mib")
            if value is None:
                raise PredictionUnavailable("prediction metadata has no memory reservation")
            return max(1, int(math.ceil(float(value))))
        raise PredictionUnavailable("command prediction metadata is required")

    def _provenance(self) -> dict[str, Any]:
        def command(*args: str) -> str:
            try:
                return subprocess.check_output(args, text=True, stderr=subprocess.DEVNULL).strip()
            except (OSError, subprocess.CalledProcessError):
                return "unknown"
        try:
            sdk = importlib.metadata.version("cubesandbox")
        except importlib.metadata.PackageNotFoundError:
            sdk = "unavailable"
        cube_source = os.environ.get("CUBE_SOURCE_DIR", "")
        return {
            "cubesandbox_deployment": "standalone",
            "cubesandbox_source_directory": cube_source or None,
            "cubesandbox_tag": command("git", "-C", cube_source, "describe", "--tags", "--exact-match") if cube_source else "unknown",
            "cubesandbox_commit": command("git", "-C", cube_source, "rev-parse", "HEAD") if cube_source else "unknown",
            "cubesandbox_sdk": sdk,
            "clawbox_commit": os.environ.get("CLAWBOX_REVISION", command("git", "rev-parse", "HEAD")),
            "os_release": platform.platform(), "kernel": platform.release(),
            "architecture": platform.machine(), "cpu_model": platform.processor(),
            "template_reference": self.spec.sandbox.template,
            "template_source_image": self.spec.sandbox.source_image_reference or "unknown",
            "template_image_digest": self.spec.sandbox.image_digest or os.environ.get("CLAWBOX_TEMPLATE_IMAGE_DIGEST", "unknown"),
            # Keep the historical generic/template keys above for consumers
            # that treated them as Tool provenance, but make the two VM
            # artifacts unambiguous for new result readers.
            "runtime_template_reference": self.spec.runtime.template,
            "runtime_template_source_image": (
                self.spec.runtime.source_image_reference or "unknown"
            ),
            "runtime_template_image_digest": (
                self.spec.runtime.image_digest or "unknown"
            ),
            "tool_template_reference": self.spec.sandbox.template,
            "tool_template_source_image": (
                self.spec.sandbox.source_image_reference or "unknown"
            ),
            "tool_template_image_digest": (
                self.spec.sandbox.image_digest
                or os.environ.get("CLAWBOX_TEMPLATE_IMAGE_DIGEST", "unknown")
            ),
            "measurement_scope": "node-level physical memory, baseline-subtracted per arm",
            "cube_runtime_settings": {
                "cpu_overcommit_ratio": 1.0, "memory_overcommit_ratio": 1.0,
                "paused_resource_release_ratio": 1.0,
            },
        }

    @staticmethod
    def _arm_provenance(arm: ExperimentArm) -> dict[str, Any]:
        if arm.agent.driver is AgentDriver.OPENCLAW:
            evidence_class = (
                "real-llm" if arm.inference.backend.value == "api"
                else "deterministic-managed-replay"
            )
        else:
            evidence_class = "synthetic-stress"
        cases = arm.session_cases or (arm.case,)
        configured_traces = []
        for case in cases:
            trace_reference = case.replay_trace_reference or case.source_reference
            trace_path = Path(trace_reference)
            configured_traces.append({
                "case_id": case.case_id,
                "reference": trace_reference,
                "sha256": (
                    hashlib.sha256(trace_path.read_bytes()).hexdigest()
                    if trace_path.is_file() else None
                ),
            })
        configuration = arm.inference.configuration
        pair_memory_mib = arm.runtime.memory_mib + arm.sandbox.memory_mib
        offered_provisioned_memory_mib = pair_memory_mib * arm.concurrency
        pool_memory_budget_mib = arm.resources.pool_memory_budget_mib
        return {
            "evidence_class": evidence_class,
            "workload_case_ids": [case.case_id for case in cases],
            "configured_traces": configured_traces,
            "configured_trace_reference": (
                configured_traces[0]["reference"] if len(configured_traces) == 1 else None
            ),
            "configured_trace_sha256": (
                configured_traces[0]["sha256"] if len(configured_traces) == 1 else None
            ),
            "session_assignment": arm.session_assignment.value,
            "random_seed": arm.execution.random_seed,
            "arrival_schedule": {
                "kind": arm.execution.arrival_schedule.value,
                "stagger_interval_seconds": arm.execution.stagger_interval_seconds,
            },
            "resource_scope": {
                "target_node": arm.resources.target_node,
                "pool_memory_budget_mib": pool_memory_budget_mib,
                "emergency_free_memory_mib": arm.resources.emergency_free_memory_mib,
                "configured_checkpoint_restore_headroom_mib": (
                    arm.resources.checkpoint_restore_headroom_mib
                ),
                "effective_checkpoint_restore_headroom_mib": (
                    policy_operation_headroom_mib(arm)
                ),
                "runtime_memory_mib_per_agent": arm.runtime.memory_mib,
                "tool_memory_mib_per_agent": arm.sandbox.memory_mib,
                "pair_memory_mib_per_agent": pair_memory_mib,
                "offered_provisioned_memory_mib": offered_provisioned_memory_mib,
                "offered_to_policy_pool_ratio": (
                    offered_provisioned_memory_mib / pool_memory_budget_mib
                ),
                "clawbox_memory_overcommit_enabled": (
                    offered_provisioned_memory_mib > pool_memory_budget_mib
                ),
            },
            "model_provenance": {
                "backend": arm.inference.backend.value,
                "model": configuration.get("model"),
                "base_url": configuration.get("base_url"),
                "time_scale": configuration.get("time_scale"),
                "credential_environment": configuration.get("api_key_env"),
            },
        }

    def _write_summary(self) -> None:
        write_summary(
            self.output_root, run_id=self.run_id,
            attempt_id=self.attempt_id, task_uid=self.task_uid,
            experiment_id=self.spec.experiment_id, results=self.results,
        )


def write_summary(output_root: Path, *, run_id: str, attempt_id: str,
                  task_uid: str, experiment_id: str,
                  results: list[ResultEnvelope]) -> None:
        summary = {"run_id": run_id, "attempt_id": attempt_id,
                   "experiment_id": experiment_id,
                   "arms": [item.model_dump(mode="json") for item in results]}
        atomic_json(output_root / "summary.json", summary)
        path = output_root / "summary.csv"
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=["arm_id", "policy", "concurrency",
                                                        "repetition", "status", "duration_seconds"])
            writer.writeheader()
            for item in results:
                writer.writerow({"arm_id": item.arm.arm_id, "policy": item.arm.policy.name,
                                 "concurrency": item.arm.concurrency, "repetition": item.arm.repetition,
                                 "status": item.status, "duration_seconds": item.performance.get("duration_seconds")})
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        lines = [
            f"# Experiment {experiment_id}", "",
            f"Run: `{run_id}`  ",
            f"Attempt: `{attempt_id}`  ",
            f"SandboxTask UID: `{task_uid}`", "",
            "| Arm | Policy | Agents | Status | Duration (s) | Pauses | Resumes |",
            "|---|---|---:|---|---:|---:|---:|",
        ]
        for item in results:
            lines.append(
                f"| `{item.arm.arm_id}` | {item.arm.policy.name} | {item.arm.concurrency} | "
                f"{item.status.value} | {item.performance.get('duration_seconds', 0):.3f} | "
                f"{item.performance.get('pause_count', 0)} | {item.performance.get('resume_count', 0)} |"
            )
        markdown = output_root / "summary.md"
        markdown_tmp = markdown.with_name(markdown.name + ".tmp")
        markdown_tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        os.replace(markdown_tmp, markdown)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run one ClawBox experiment attempt")
    parser.add_argument("--spec", type=Path, default=Path(os.environ.get("CLAWBOX_EXPERIMENT_SPEC", "/config/experiment.yaml")))
    parser.add_argument("--run-id", default=os.environ.get("CLAWBOX_RUN_ID"), required=os.environ.get("CLAWBOX_RUN_ID") is None)
    parser.add_argument("--attempt-id", default=os.environ.get("CLAWBOX_ATTEMPT_ID"), required=os.environ.get("CLAWBOX_ATTEMPT_ID") is None)
    parser.add_argument("--task-uid", default=os.environ.get("CLAWBOX_TASK_UID"), required=os.environ.get("CLAWBOX_TASK_UID") is None)
    parser.add_argument("--output-root", type=Path)
    parser.add_argument("--arm-id")
    parser.add_argument("--no-summary", action="store_true")
    args = parser.parse_args(argv)
    try:
        results = ExperimentWorker(
            load_experiment(args.spec), run_id=args.run_id,
            attempt_id=args.attempt_id, task_uid=args.task_uid,
            output_root=args.output_root,
        ).run(
            arm_ids={args.arm_id} if args.arm_id else None,
            write_summary=not args.no_summary,
        )
    except Exception as exc:
        # Preserve a useful diagnostic when a pre-arm infrastructure gate
        # fails. Keep the log useful without
        # printing credentials, prompts, request bodies, or bearer tokens.
        print(
            "experiment worker failed before completion: "
            f"run_id={args.run_id} attempt_id={args.attempt_id} "
            f"task_uid={args.task_uid} error_type={type(exc).__name__} "
            f"error={exc}",
            file=sys.stderr,
            flush=True,
        )
        traceback.print_exc(file=sys.stderr)
        return 1
    return 0 if all(result.status is RunStatus.SUCCEEDED for result in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
