"""Immutable command-specific prediction provenance for managed Tool calls."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from threading import Lock
from typing import Any

from clawbox.tuning.clawtune import shell_command_prefix_tokens


class PredictionUnavailable(RuntimeError):
    """Raised when a managed Tool call has no command-specific prediction."""


def clawtune_extra_peak(prediction: dict[str, Any] | None) -> dict[str, Any]:
    """Convert ClawTune's tool-call memory increment to a reservation."""
    if not isinstance(prediction, dict):
        raise PredictionUnavailable("ClawTune call prediction is missing")
    if (prediction.get("schema_version") != "call_load.v2"
            or prediction.get("scope") != "tool_call"):
        raise PredictionUnavailable("ClawTune call prediction has an incompatible schema")
    measurement = prediction.get("memory_measurement")
    if measurement != "guest_memtotal_minus_memavailable":
        raise PredictionUnavailable(
            "ClawTune memory prediction does not use the Cube guest environment measurement"
        )
    targets = prediction.get("targets")
    target = targets.get("memory_extra_peak_bytes") if isinstance(targets, dict) else None
    if isinstance(target, dict) and target.get("backend") not in {"lattice", "runtime"}:
        raise PredictionUnavailable("ClawBox scheduling requires a LatticeKB or ToolKB memory prediction")
    if (not isinstance(target, dict) or target.get("status") != "available"
            or target.get("unit") != "bytes"
            or target.get("metric_definition") != "environment_memory_peak_minus_baseline"):
        reason = target.get("unavailable_reason") if isinstance(target, dict) else "missing target"
        raise PredictionUnavailable(
            f"ClawTune extra memory peak is unavailable ({reason}); "
            "provide Cube environment-memory observations or select a fixed/capacity baseline"
        )
    value = target.get("p50")
    if isinstance(value, bool) or not isinstance(value, (int, float)) \
            or not math.isfinite(value) or value < 0:
        raise PredictionUnavailable("ClawTune extra memory peak has no valid estimate")
    return {
        "prediction_source": f"clawtune_{target.get('backend')}_p50",
        "prediction_quantile": 0.5,
        "admission_prediction_target": "environment_memory_peak_minus_baseline",
        # Preserve the canonical prediction for the ClawTune trace writer;
        # the derived fields below are the admission-facing projection.
        "call_prediction": prediction,
        "predicted_incremental_memory_mib": value / (1024 * 1024),
        "clawtune_memory_extra_peak_bytes": value,
        "clawtune_memory_backend": target.get("backend"),
        "clawtune_memory_method": target.get("method"),
        "clawtune_memory_sample_count": target.get("sample_count"),
        "clawtune_memory_measurement": measurement,
    }


def command_sha256(command: str) -> str:
    return hashlib.sha256(command.encode()).hexdigest()


def select_p50(models: dict[str, Any], *, short_call_evidence: dict | None = None) -> dict:
    """ClawBox's admission policy; never change ClawTune's model outputs."""
    missing = {}
    for name in ("lattice", "tool"):
        try:
            result = clawtune_extra_peak(models.get(name))
        except PredictionUnavailable as exc:
            missing[name] = str(exc)
            continue
        expected_backend = "lattice" if name == "lattice" else "runtime"
        if result["clawtune_memory_backend"] != expected_backend:
            raise PredictionUnavailable(f"{name} prediction backend mismatch")
        return {**result, "fallback_level": name, "unavailable_models": missing}
    evidence = short_call_evidence or {}
    count = evidence.get("count", 0)
    maximum = evidence.get("max_duration_ms")
    if (isinstance(count, int) and not isinstance(count, bool) and count > 0
            and isinstance(maximum, (int, float)) and not isinstance(maximum, bool)
            and math.isfinite(maximum) and 0 <= maximum <= 20
            and evidence.get("reason") == "no_in_execution_memory_sample"):
        return {"prediction_source": "short_call_assumption", "prediction_quantile": None,
                "fallback_level": "short_call_assumption", "unavailable_models": missing,
                "short_call_evidence": evidence, "predicted_incremental_memory_mib": 0,
                "admission_prediction_target": "environment_memory_peak_minus_baseline"}
    raise PredictionUnavailable(f"No P50 memory estimate or measured short-call evidence: {missing}")


class CommandPredictionProvider:
    """Load one immutable P90 artifact once and resolve exact commands."""

    def __init__(self, path: Path, *, repository: str | None = None,
                 prediction_source: str = "runtime_clawtune_immutable_kb") -> None:
        self.path = path
        self.repository = repository
        self.prediction_source = prediction_source
        self.sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            raise ValueError("Prediction artifact must be an object")
        self.payload = payload
        self._by_digest: dict[str, dict[str, Any]] = {}
        self._load_entries(payload)
        self._fallback_counts: dict[str, int] = {}
        self._lock = Lock()

    def _load_entries(self, payload: dict[str, Any]) -> None:
        candidates: list[dict[str, Any]] = []
        per_tool = payload.get("per_tool_memory")
        if isinstance(per_tool, dict):
            workloads = per_tool.get("workloads") or {}
            if isinstance(workloads, dict):
                for workload in workloads.values():
                    if isinstance(workload, dict):
                        candidates.extend(
                            item for item in workload.get("tool_invocations", [])
                            if isinstance(item, dict)
                        )
        for key in ("predictions", "tool_invocations", "commands"):
            value = payload.get(key)
            if isinstance(value, list):
                candidates.extend(item for item in value if isinstance(item, dict))
            elif isinstance(value, dict):
                for command, item in value.items():
                    if isinstance(item, dict):
                        candidates.append({"command": command, **item})
        for item in candidates:
            command = item.get("command")
            if not isinstance(command, str) or not command.strip():
                continue
            digest = str(item.get("command_sha256") or command_sha256(command))
            metadata = self._metadata(item, command, digest)
            previous = self._by_digest.get(digest)
            if previous is not None and previous != metadata:
                raise ValueError(f"Prediction artifact has conflicting entries for command {digest}")
            self._by_digest[digest] = metadata

    def _metadata(self, item: dict[str, Any], command: str,
                  digest: str) -> dict[str, Any]:
        guest_value = item.get("predicted_command_memory_p90_mib")
        if guest_value is None:
            guest_value = item.get("incremental_p90_mib")
        if guest_value is None and item.get("incremental_p90_kib") is not None:
            guest_value = float(item["incremental_p90_kib"]) / 1024.0
        if guest_value is None or not math.isfinite(float(guest_value)) \
                or float(guest_value) <= 0:
            raise ValueError(f"P90 entry for {digest} has no positive command prediction")
        host_value = item.get("predicted_host_execution_increment_mib")
        if host_value is None or not math.isfinite(float(host_value)) \
                or float(host_value) <= 0:
            raise ValueError(
                f"P90 entry for {digest} has no calibrated positive host increment"
            )
        normalized = " ".join(shell_command_prefix_tokens(command))
        return {
            "raw_command_sha256": digest,
            "canonical_prediction_key": normalized,
            "prediction_source": self.prediction_source,
            "fallback_level": item.get("key_kind") or item.get("scope") or "unknown",
            "fallback_path": list(item.get("fallback_path") or []),
            "predicted_guest_memory_p90_mib": float(guest_value),
            "predicted_incremental_memory_mib": float(host_value),
            "admission_prediction_target": "host_vm_rss_execution_increment",
            "host_mapping_source": item.get("host_mapping_source"),
            "host_mapping_ratio_p90": item.get("host_mapping_ratio_p90"),
            "evidence_count": int(item.get("evidence_count") or 0),
            "kb_generation": item.get("kb_generation") or item.get("generation"),
        }

    @property
    def manifest(self) -> dict[str, dict[str, Any]]:
        return {key: dict(value) for key, value in self._by_digest.items()}

    @property
    def max_incremental_memory_mib(self) -> float:
        """Largest frozen reservation this artifact can request."""
        values = [
            float(item["predicted_incremental_memory_mib"])
            for item in self._by_digest.values()
        ]
        if not values:
            raise ValueError("Prediction artifact contains no command reservations")
        return max(values)

    def resolve(self, command: str, runtime_metadata: dict[str, Any] | None) -> dict[str, Any]:
        return self.resolve_digest(command_sha256(command), runtime_metadata)

    def resolve_digest(self, digest: str,
                       runtime_metadata: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve metadata without moving raw command text off the SSH path."""
        expected = self._by_digest.get(digest)
        if expected is None:
            with self._lock:
                self._fallback_counts["missing_command"] = self._fallback_counts.get("missing_command", 0) + 1
            raise PredictionUnavailable(
                f"no command-specific Runtime prediction for command sha256 {digest}"
            )
        if not isinstance(runtime_metadata, dict):
            with self._lock:
                self._fallback_counts["runtime_metadata_missing"] = self._fallback_counts.get("runtime_metadata_missing", 0) + 1
            raise PredictionUnavailable("Runtime did not provide command prediction metadata")
        if runtime_metadata.get("raw_command_sha256") != digest:
            raise PredictionUnavailable("Runtime prediction command identity mismatch")
        if runtime_metadata.get("canonical_prediction_key") != expected["canonical_prediction_key"]:
            raise PredictionUnavailable("Runtime prediction canonical key mismatch")
        if runtime_metadata.get("prediction_source") != expected["prediction_source"]:
            raise PredictionUnavailable("Runtime prediction source mismatch")
        return {
            **expected,
            "session_runtime_metadata": dict(runtime_metadata),
        }

    def provenance(self, observed: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        observed = observed or []
        levels: dict[str, int] = {}
        for item in observed:
            level = str(item.get("fallback_level") or "unknown")
            levels[level] = levels.get(level, 0) + 1
        with self._lock:
            fallback_counts = dict(self._fallback_counts)
        return {
            "path": str(self.path),
            "sha256": self.sha256,
            "entry_count": len(self._by_digest),
            "fallback_counts": fallback_counts,
            "observed_prediction_count": len(observed),
            "observed_fallback_levels": levels,
            "observed_fallback_rate": (
                sum(value for key, value in levels.items() if key != "exact_command")
                / len(observed) if observed else None
            ),
        }


class P50PredictionProvider(CommandPredictionProvider):
    """Frozen, pre-evaluation native model predictions, keyed by exact command."""

    def __init__(self, path: Path, *, repository: str, sandbox_identity: dict | None = None) -> None:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if payload.get("schema") != "clawbox_p50_v1" or payload.get("repository") != repository:
            raise ValueError("P50 artifact schema or repository mismatch")
        if payload.get("training_validated") is not True:
            raise ValueError("P50 artifact requires a validated Cube training run")
        if sandbox_identity is not None and payload.get("sandbox_identity") != sandbox_identity:
            raise ValueError("P50 training and evaluation Tool environments differ")
        super().__init__(path, repository=repository, prediction_source="frozen_clawbox_p50")

    def provenance(self, observed: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        selected = [row for row in observed or []
                    if row.get("prediction_source") == self.prediction_source]
        result = super().provenance(selected)
        result["observed_fallback_rate"] = (
            sum(row.get("fallback_level") != "lattice" for row in selected) / len(selected)
            if selected else None
        )
        return result

    def resolve_digest(self, digest: str,
                       runtime_metadata: dict[str, Any] | None) -> dict[str, Any]:
        """Use Runtime only as the raw-command identity witness.

        Current ClawTune attaches its live ``call_prediction`` plus the raw
        command digest.  The frozen model choice and reservation remain host
        artifact data; requiring Runtime to echo host-only provenance fields
        rejects valid current OpenClaw requests.
        """
        expected = self._by_digest.get(digest)
        if expected is None:
            with self._lock:
                self._fallback_counts["missing_command"] = (
                    self._fallback_counts.get("missing_command", 0) + 1
                )
            raise PredictionUnavailable(
                f"no command-specific P50 prediction for command sha256 {digest}"
            )
        if not isinstance(runtime_metadata, dict):
            with self._lock:
                self._fallback_counts["runtime_metadata_missing"] = (
                    self._fallback_counts.get("runtime_metadata_missing", 0) + 1
                )
            raise PredictionUnavailable("Runtime did not provide command identity metadata")
        if runtime_metadata.get("raw_command_sha256") != digest:
            raise PredictionUnavailable("Runtime prediction command identity mismatch")
        canonical = runtime_metadata.get("canonical_prediction_key")
        if canonical is not None and canonical != expected["canonical_prediction_key"]:
            raise PredictionUnavailable("Runtime prediction canonical key mismatch")
        source = runtime_metadata.get("prediction_source")
        if source is not None and source != expected["prediction_source"]:
            raise PredictionUnavailable("Runtime prediction source mismatch")
        return {**expected, "session_runtime_metadata": dict(runtime_metadata)}

    @property
    def manifest(self) -> dict[str, dict[str, Any]]:
        # The Runtime witnesses command identity; model evidence stays on the
        # host. Avoid sending a large KB/prediction body through guest exec args.
        return {key: {field: value[field] for field in
                      ("raw_command_sha256", "canonical_prediction_key", "prediction_source")}
                for key, value in self._by_digest.items()}

    def _metadata(self, item: dict, command: str, digest: str) -> dict:
        if digest != command_sha256(command):
            raise ValueError("P50 artifact command digest mismatch")
        selected = select_p50(item.get("models") or {},
                              short_call_evidence=item.get("short_call_evidence"))
        return {**selected, "model_prediction_source": selected["prediction_source"],
                "prediction_source": self.prediction_source,
                "raw_command_sha256": digest, "canonical_prediction_key": digest,
                "models": item.get("models"), "kb_sha256": self.payload.get("kb_sha256")}
