from __future__ import annotations

import time
from contextlib import contextmanager, nullcontext
from dataclasses import asdict, dataclass
from enum import Enum
from threading import RLock
from collections.abc import Callable
from typing import Any, Mapping

from clawbox.replay.lifecycle import LifecycleError

from .client import CubeSandboxClient, Ownership
from clawbox.experiments.snapshot_pool import SnapshotKey, SnapshotManifest, WarmSnapshotPool, WarmCapacityError
from clawbox.experiments.spec_types import SnapshotTier


class SandboxState(str, Enum):
    NEW = "new"
    CREATING = "creating"
    RUNNING = "running"
    CHECKPOINTING = "checkpointing"
    UNKNOWN = "unknown"
    SWAPPED = "swapped"
    RESTORING = "restoring"
    DESTROYING = "destroying"
    CLOSED = "closed"


@dataclass(frozen=True, slots=True)
class LifecycleTiming:
    operation: str
    started_unix_s: float
    completed_unix_s: float
    started_monotonic_s: float
    completed_monotonic_s: float
    service_seconds: float
    state_before: str
    state_after: str
    status: str = "ok"
    error_type: str | None = None
    host_memory_before: dict[str, Any] | None = None
    host_memory_after: dict[str, Any] | None = None
    host_observed_reclaimed_bytes: int | None = None
    host_observed_growth_bytes: int | None = None
    host_observed_net_change_bytes: int | None = None
    host_reclamation_evidence: str = "unavailable"
    lifecycle_mechanism: str | None = None
    tier_from: str | None = None
    tier_to: str | None = None
    snapshot_generation: int | None = None
    snapshot_path: str | None = None
    snapshot_metrics: dict[str, Any] | None = None


class CubeSandboxLifecycle:
    """Concurrency-safe policy layer over official CubeSandbox lifecycle calls."""

    def __init__(self, client: CubeSandboxClient, *, template: str,
                 node_name: str, ownership: Ownership,
                 allow_internet_access: bool = True,
                 env_vars: Mapping[str, str] | None = None,
                 network_allow_out: list[str] | None = None,
                 network_deny_out: list[str] | None = None,
                 physical_observation: Callable[[], Mapping[str, Any]] | None = None,
                 role: str = "tool", warm_snapshot_root: str | None = None,
                 cold_snapshot_root: str | None = None,
                 snapshot_pool: WarmSnapshotPool | None = None,
                 snapshot_reservation_bytes: int | None = None,
                 snapshot_mechanism: str = "incremental-cow", lazy_restore: bool = True,
                 snapshot_storage: str = "tiered") -> None:
        if snapshot_storage not in {"tiered", "warm-only"}:
            raise ValueError("invalid snapshot storage")
        self.snapshot_storage = snapshot_storage
        if snapshot_mechanism not in {"full-copy", "incremental-cow"}:
            raise ValueError("invalid snapshot mechanism")
        if snapshot_mechanism == "incremental-cow" and not lazy_restore:
            raise ValueError("incremental-cow requires lazy restore")
        self.snapshot_mechanism = snapshot_mechanism
        self.lazy_restore = lazy_restore
        self._snapshot_tier: SnapshotTier | None = None
        self.client = client
        self.template = template
        self.node_name = node_name
        self.ownership = ownership
        self.allow_internet_access = allow_internet_access
        self.env_vars = dict(env_vars or {})
        self.network_allow_out = list(network_allow_out or [])
        self.network_deny_out = list(network_deny_out or [])
        self.physical_observation = physical_observation
        self.role = role
        self.warm_snapshot_root = warm_snapshot_root
        self.cold_snapshot_root = cold_snapshot_root
        self.snapshot_pool = snapshot_pool
        self.snapshot_reservation_bytes = snapshot_reservation_bytes
        self.sandbox = None
        self.sandbox_id: str | None = None
        self._state = SandboxState.NEW
        self._lock = RLock()
        self._timings: list[LifecycleTiming] = []
        self._tier = SnapshotTier.LOCAL
        self._generation = 0
        self._snapshot_key: SnapshotKey | None = None
        self._first_tool_restore: dict[str, Any] | None = None
        self._restore_fault_sampler = None

    def claim_first_tool_after_restore(self, execution_id: str) -> None:
        """Claim at admission, so concurrent completion order cannot relabel it."""
        with self._lock:
            marker = self._first_tool_restore
            if marker is not None and marker.get("execution_id") is None:
                marker["execution_id"] = execution_id

    def complete_first_tool_after_restore(self, execution_id: str, *,
                                         tool_seconds: float, status: str) -> dict[str, Any] | None:
        with self._lock:
            marker = self._first_tool_restore
            if marker is None or marker.get("execution_id") != execution_id:
                return None
            completed = time.monotonic()
            faults = self._restore_fault_sampler.stop() if self._restore_fault_sampler else {}
            self._restore_fault_sampler = None
            self._first_tool_restore = None
            return {
                **marker,
                "first_tool_after_restore_seconds": max(0.0, tool_seconds),
                "restore_ready_to_first_tool_complete_seconds": max(
                    0.0, completed - marker["restore_ready_monotonic_s"]),
                "status": status,
                **{key: value for key, value in faults.items()
                   if key in {"host_vm_minor_faults_delta", "host_vm_major_faults_delta",
                              "host_vm_disk_read_bytes_delta"}},
                "fault_counter_scope": "host_vm_processes_restore_ready_to_first_tool_complete",
            }

    @property
    def state(self) -> SandboxState:
        with self._lock:
            return self._state

    @property
    def resident(self) -> bool:
        return self.state is SandboxState.RUNNING

    @property
    def tier(self) -> SnapshotTier:
        with self._lock:
            return self._tier

    @property
    def timings(self) -> list[dict[str, object]]:
        with self._lock:
            return [asdict(item) for item in self._timings]

    def _record(self, operation: str, before: SandboxState, after: SandboxState,
                started_wall: float, started_mono: float, *,
                status: str = "ok", error_type: str | None = None,
                host_memory_before: Mapping[str, Any] | None = None,
                tier_from: str | None = None, tier_to: str | None = None,
                snapshot_generation: int | None = None,
                snapshot_path: str | None = None,
                snapshot_metrics: Mapping[str, Any] | None = None) -> float:
        completed_wall = time.time()
        completed_mono = time.monotonic()
        duration = max(0.0, completed_mono - started_mono)
        host_memory_after = self._observe_physical()
        before_used = self._host_used(host_memory_before)
        after_used = self._host_used(host_memory_after)
        reclaimed = growth = net_change = None
        evidence = "unavailable"
        if before_used is not None and after_used is not None:
            reclaimed = max(0, before_used - after_used)
            growth = max(0, after_used - before_used)
            net_change = after_used - before_used
            if operation == "checkpoint":
                scope = ("local_cgroup" if host_memory_before is not None and
                         "local_used_bytes" in host_memory_before else "whole_host")
                evidence = (
                    f"observed_{scope}_reclamation"
                    if reclaimed > 0
                    else f"not_observed_{scope}_reclamation"
                )
        self._timings.append(LifecycleTiming(
            operation, started_wall, completed_wall, started_mono,
            completed_mono, duration, before.value, after.value,
            status, error_type,
            dict(host_memory_before) if host_memory_before is not None else None,
            dict(host_memory_after) if host_memory_after is not None else None,
            reclaimed, growth, net_change, evidence,
            "cubesandbox_pause_snapshot_destroy" if operation == "checkpoint" else None,
            tier_from, tier_to, snapshot_generation, snapshot_path,
            dict(snapshot_metrics) if snapshot_metrics is not None else None,
        ))
        return duration

    def _observe_physical(self) -> Mapping[str, Any] | None:
        return self.physical_observation() if self.physical_observation is not None else None

    @staticmethod
    def _host_used(sample: Mapping[str, Any] | None) -> int | None:
        if sample is None:
            return None
        value = sample.get("local_used_bytes", sample.get("host_used_bytes"))
        return int(value) if isinstance(value, int) and not isinstance(value, bool) else None

    def start(self) -> float:
        with self._lock:
            if self._state is not SandboxState.NEW:
                raise LifecycleError("CubeSandbox lifecycle already started")
            before = self._state
            self._state = SandboxState.CREATING
            started_wall, started_mono = time.time(), time.monotonic()
            host_memory_before = self._observe_physical()
            try:
                self.sandbox = self.client.create_sandbox(
                    template=self.template, node_name=self.node_name,
                    ownership=self.ownership, env_vars=self.env_vars or None,
                    allow_internet_access=self.allow_internet_access,
                    network_allow_out=self.network_allow_out or None,
                    network_deny_out=self.network_deny_out or None,
                )
                self.sandbox_id = self.client.sandbox_id(self.sandbox)
                self._state = SandboxState.RUNNING
                return self._record("create", before, self._state,
                                    started_wall, started_mono,
                                    host_memory_before=host_memory_before)
            except Exception as exc:
                self._state = before
                self._record(
                    "create", before, before, started_wall, started_mono,
                    status="error", error_type=type(exc).__name__,
                    host_memory_before=host_memory_before,
                )
                raise

    def checkpoint_and_evict(self, *, tier: SnapshotTier | None = None) -> float | None:
        """Ask CubeSandbox to snapshot the VM and destroy its live runtime.

        CubeSandbox commit 64102d9 implements its pause API as
        ``PauseToSnapshot`` followed by a keep-tombstone destroy. The API
        completion is still not, by itself, physical-memory evidence; the
        before/after host observations below remain explicit in every record.
        """
        with self._lock:
            # Pressure eviction and the session's delayed eager callback can
            # converge on the same idle VM. The lifecycle lock serializes the
            # calls; the loser observes the already-swapped state and treats
            # the desired state as satisfied instead of failing an unrelated
            # Tool admission.
            if self._state is SandboxState.SWAPPED:
                return None
            if self.sandbox is None or self._state is not SandboxState.RUNNING:
                raise LifecycleError("CubeSandbox is not resident")
            if self.snapshot_storage == "warm-only":
                if tier is SnapshotTier.COLD:
                    raise ValueError("COLD snapshots are disabled by warm-only storage")
                tier = SnapshotTier.WARM
            if tier is None and self.snapshot_mechanism == "incremental-cow":
                tier = SnapshotTier.COLD
            if tier is SnapshotTier.COLD and not self.cold_snapshot_root:
                raise ValueError("COLD checkpoint requires cold_snapshot_root")
            before = self._state
            self._state = SandboxState.CHECKPOINTING
            started_wall, started_mono = time.time(), time.monotonic()
            host_memory_before = self._observe_physical()
            key = None
            pause_attempted = False
            predecessor = (self._snapshot_key if self._snapshot_tier is SnapshotTier.WARM
                           and self._tier is SnapshotTier.LOCAL else None)
            try:
                manifest = None
                # A disabled or undersized WARM pool is the SSD-only ablation,
                # not a failed checkpoint. Keep the same placement policy but
                # materialize this generation in COLD when it cannot fit WARM.
                if (tier is SnapshotTier.WARM and self.snapshot_pool is not None
                        and self.snapshot_reservation_bytes is not None
                        and self.snapshot_reservation_bytes > self.snapshot_pool.capacity_bytes):
                    if self.snapshot_storage == "warm-only":
                        raise WarmCapacityError("WARM pool is too small; disk fallback is disabled")
                    tier = SnapshotTier.COLD
                if tier is None:
                    pause_attempted = True
                    self.client.pause_sandbox(
                        self.sandbox, snapshot_mechanism=self.snapshot_mechanism,
                    )
                else:
                    if tier is SnapshotTier.LOCAL:
                        raise ValueError("cannot checkpoint a sandbox to LOCAL")
                    self._generation += 1
                    key = SnapshotKey(self.ownership.session_id, self.role, self._generation)
                    if tier is SnapshotTier.WARM:
                        if self.snapshot_pool is None or self.snapshot_reservation_bytes is None:
                            raise RuntimeError("WARM snapshot accounting is not configured")
                        try:
                            self.snapshot_pool.reserve_for_admission(
                                key, self.snapshot_reservation_bytes,
                                timeout_s=0 if predecessor is not None else 120,
                            )
                        except WarmCapacityError:
                            if predecessor is None or self.snapshot_storage == "warm-only":
                                raise
                            tier = SnapshotTier.COLD
                    root = (self.warm_snapshot_root if tier is SnapshotTier.WARM
                            else self.cold_snapshot_root)
                    if not root or self.sandbox_id is None:
                        raise RuntimeError(f"{tier.value.upper()} snapshot root is not configured")
                    path = (
                        f"{root.rstrip('/')}/{self.sandbox_id}/"
                        f"{self.role}-g{self._generation}.mem"
                    )
                    pause_attempted = True
                    manifest = self.client.pause_sandbox(
                        self.sandbox, tier=tier.value,
                        memory_snapshot_path=path, generation=self._generation,
                        snapshot_mechanism=self.snapshot_mechanism,
                    )
                    if tier is SnapshotTier.WARM:
                        self.snapshot_pool.commit(
                            key, path=path,
                            logical_bytes=int(manifest["logical_bytes"]),
                            allocated_bytes=int(manifest["allocated_bytes"]),
                            transferred_bytes=(
                                int(manifest["transferred_bytes"])
                                if manifest["transferred_bytes"] is not None else None
                            ),
                            spiller=(self._spill_to_cold if self.snapshot_storage != "warm-only" else None),
                            replaces=predecessor,
                        )
                    elif predecessor is not None and self.snapshot_pool is not None:
                        self.snapshot_pool.remove(predecessor)
                    self._snapshot_key = key
                    self._snapshot_tier = tier
                    self._tier = tier
                self._state = SandboxState.SWAPPED
                return self._record("checkpoint", before, self._state,
                                    started_wall, started_mono,
                                    host_memory_before=host_memory_before,
                                    tier_from=SnapshotTier.LOCAL.value,
                                    tier_to=tier.value if tier is not None else None,
                                    snapshot_generation=key.generation if key is not None else None,
                                    snapshot_path=manifest.get("memory_snapshot_path") if manifest else None,
                                    snapshot_metrics=manifest)
            except Exception as exc:
                if key is not None and self.snapshot_pool is not None:
                    self.snapshot_pool.abort(key)
                # A pause can commit remotely and then fail while returning or
                # validating its manifest. Do not admit commands to a VM whose
                # actual state is paused or cannot be determined.
                remote_state = None
                if pause_attempted and self.sandbox_id is not None:
                    try:
                        remote_state = self.client.get_sandbox_state(self.sandbox_id)
                    except Exception:
                        pass
                self._state = (before if not pause_attempted or remote_state == "running"
                               else SandboxState.UNKNOWN)
                self._record(
                    "checkpoint", before, self._state, started_wall, started_mono,
                    status="error", error_type=type(exc).__name__,
                    host_memory_before=host_memory_before,
                )
                raise

    def _spill_to_cold(self, manifest: SnapshotManifest) -> None:
        with self._lock:
            if (self._state is not SandboxState.SWAPPED or self.sandbox is None or
                    self._snapshot_key != manifest.key or self._tier is not SnapshotTier.WARM):
                raise LifecycleError(
                    "WARM spill target is not the authoritative swapped generation"
                )
            if not self.cold_snapshot_root or self.sandbox_id is None:
                raise RuntimeError("COLD snapshot root is not configured")
            destination = (
                f"{self.cold_snapshot_root.rstrip('/')}/{self.sandbox_id}/"
                f"{self.role}-g{manifest.key.generation}.mem"
            )
            before = self._state
            started_wall, started_mono = time.time(), time.monotonic()
            host_memory_before = self._observe_physical()
            try:
                self.client.relocate_snapshot(
                    self.sandbox, tier=SnapshotTier.COLD.value,
                    memory_snapshot_path=destination,
                    generation=manifest.key.generation,
                )
                self._tier = SnapshotTier.COLD
                self._snapshot_tier = SnapshotTier.COLD
                self._record(
                    "spill", before, before, started_wall, started_mono,
                    host_memory_before=host_memory_before,
                    tier_from=SnapshotTier.WARM.value,
                    tier_to=SnapshotTier.COLD.value,
                    snapshot_generation=manifest.key.generation,
                    snapshot_path=destination,
                )
            except Exception as exc:
                self._record(
                    "spill", before, before, started_wall, started_mono,
                    status="error", error_type=type(exc).__name__,
                    host_memory_before=host_memory_before,
                    tier_from=SnapshotTier.WARM.value,
                    tier_to=SnapshotTier.COLD.value,
                    snapshot_generation=manifest.key.generation,
                    snapshot_path=destination,
                )
                raise

    pause_and_evict = checkpoint_and_evict

    @contextmanager
    def _snapshot_access(self):
        # Do not hold this lifecycle's lock while waiting for an in-flight
        # spill: its callback acquires the same lock to publish COLD state.
        while True:
            with self._lock:
                key, pool = self._snapshot_key, self.snapshot_pool
            guard = pool.consume_guard(key) if key is not None and pool else nullcontext()
            with guard, self._lock:
                if key != self._snapshot_key:
                    continue
                yield
                return

    def restore(self) -> float:
        with self._snapshot_access():
            if self.sandbox_id is None or self._state is not SandboxState.SWAPPED:
                raise LifecycleError("CubeSandbox is not swapped out")
            before = self._state
            self._state = SandboxState.RESTORING
            started_wall, started_mono = time.time(), time.monotonic()
            host_memory_before = self._observe_physical()
            resume_attempted = False
            try:
                resume_attempted = True
                self.sandbox = self.client.connect_sandbox(
                    self.sandbox_id,
                    snapshot_mechanism=self.snapshot_mechanism,
                )
                if self._snapshot_key is not None and self._tier is SnapshotTier.WARM:
                    if self.snapshot_pool is None:
                        raise RuntimeError("WARM snapshot accounting disappeared before restore")
                    if self.lazy_restore:
                        self.snapshot_pool.retain_for_vm(self._snapshot_key)
                    else:
                        self.snapshot_pool.remove(self._snapshot_key, consume_pinned=True)
                if not self.lazy_restore:
                    self._snapshot_key = None
                    self._snapshot_tier = None
                self._tier = SnapshotTier.LOCAL
                self._state = SandboxState.RUNNING
                elapsed = self._record("restore", before, self._state,
                                    started_wall, started_mono,
                                    host_memory_before=host_memory_before,
                                    tier_from=self._snapshot_tier.value if self._snapshot_tier else None,
                                    tier_to=SnapshotTier.LOCAL.value,
                                    snapshot_generation=self._generation)
                self._first_tool_restore = {
                    "restore_ready_monotonic_s": self._timings[-1].completed_monotonic_s,
                    "restore_ready_service_seconds": elapsed,
                    "snapshot_generation": self._generation,
                    "snapshot_tier": self._snapshot_tier.value if self._snapshot_tier else None,
                }
                from pathlib import Path
                from clawbox.experiments.memory import SandboxRSSSampler
                try:
                    self._restore_fault_sampler = (
                        SandboxRSSSampler(self.sandbox_id) if Path("/proc").is_dir() else None
                    )
                except OSError:
                    self._restore_fault_sampler = None
                return elapsed
            except Exception as exc:
                remote_state = None
                if resume_attempted:
                    try:
                        remote_state = self.client.get_sandbox_state(self.sandbox_id)
                    except Exception:
                        pass
                self._state = (before if not resume_attempted or remote_state == "paused"
                               else SandboxState.UNKNOWN)
                self._record(
                    "restore", before, self._state, started_wall, started_mono,
                    status="error", error_type=type(exc).__name__,
                    host_memory_before=host_memory_before,
                )
                raise

    def ensure_network_allow_out(self, cidr: str) -> bool:
        """Allow one additional destination CIDR, updating a running VM.

        CubeSandbox treats an update as a replacement policy.  Keep the
        complete desired policy on this lifecycle object and send it only when
        the new CIDR is not already present.  This lets endpoint ports change
        freely while still allowing a Tool to move to a different
        deployment-owned endpoint host after restore.
        """
        value = str(cidr or "").strip()
        if not value:
            raise ValueError("network allowlist CIDR must not be empty")
        with self._lock:
            if value in self.network_allow_out:
                return False
            desired = [*self.network_allow_out, value]
            if self._state is SandboxState.RUNNING:
                before = self._state
                started_wall, started_mono = time.time(), time.monotonic()
                host_memory_before = self._observe_physical()
                try:
                    self.client.update_network(
                        self.sandbox, allow_internet_access=self.allow_internet_access,
                        network_allow_out=desired,
                        network_deny_out=self.network_deny_out,
                    )
                except Exception as exc:
                    self._record(
                        "network_update", before, before, started_wall, started_mono,
                        status="error", error_type=type(exc).__name__,
                        host_memory_before=host_memory_before,
                    )
                    raise
                self._record("network_update", before, self._state,
                             started_wall, started_mono,
                             host_memory_before=host_memory_before)
            self.network_allow_out = desired
            return True

    def close(self) -> float:
        with self._snapshot_access():
            if self._state is SandboxState.CLOSED:
                return 0.0
            before = self._state
            self._state = SandboxState.DESTROYING
            started_wall, started_mono = time.time(), time.monotonic()
            host_memory_before = self._observe_physical()
            try:
                if self.sandbox_id is not None:
                    self.client.kill_sandbox(self.sandbox_id)
                if (self._snapshot_key is not None and
                        self._snapshot_tier is SnapshotTier.WARM and
                        self.snapshot_pool is not None):
                    self.snapshot_pool.remove(self._snapshot_key, consume_pinned=True)
                self._snapshot_key = None
                self.sandbox = None
                self.sandbox_id = None
                self._state = SandboxState.CLOSED
                return self._record("destroy", before, self._state,
                                    started_wall, started_mono,
                                    host_memory_before=host_memory_before)
            except Exception as exc:
                self._state = before
                self._record(
                    "destroy", before, before, started_wall, started_mono,
                    status="error", error_type=type(exc).__name__,
                    host_memory_before=host_memory_before,
                )
                raise
