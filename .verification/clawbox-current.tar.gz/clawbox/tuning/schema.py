"""Normalized tool-execution observation schema (ADR-008 / ADR-007).

Two raw sources feed the pipeline:

1. **ClawTune v6 span JSONL** (runtime side, written by the plugin): one record
   per line, ``record_type`` in {``trace_metadata``, ``span_start``,
   ``span_end``}.  The ``span_end`` record carries the tool resources
   (cpu/rss/coverage) and ``execution.execution_id``.
2. **Tool-bridge execution JSONL** (tool VM side, ``tool-bridge.jsonl``): one
   record per shell command with exit code, wall duration, stdout/stderr byte
   counts and the same ``execution_id`` (carried through the SSH envelope).

``ToolObservation`` is the joined, normalized unit that flows into the dataset
and the KB.  It is deliberately immutable (frozen) and extra-forbidden.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from enum import StrEnum
import math
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class CollectionQuality(StrEnum):
    VALID = "valid"
    DEGRADED = "degraded"
    INVALID = "invalid"


class ObservationSource(StrEnum):
    CLAWTUNE_SPAN = "clawtune_span"
    TOOL_BRIDGE = "tool_bridge"


#: Trace schema version the ClawTune plugin emits (trace v6).
CLAWTUNE_TRACE_SCHEMA_VERSION = 6

#: Schema version of the normalized ToolObservation.
OBSERVATION_SCHEMA_VERSION = 1

#: Allowed duration buckets, aligned with the legacy KB bucket helper.
DURATION_BUCKETS = ("short", "medium", "long")


def duration_bucket(seconds: float | None) -> str | None:
    if seconds is None:
        return None
    if seconds <= 1.0:
        return "short"
    if seconds <= 30.0:
        return "medium"
    return "long"


class BridgeRecord(StrictModel):
    """One line of the tool-bridge execution JSONL."""

    timestamp: str
    cell_id: str | None = None
    task_id: str | None = None
    execution_id: str
    phase: Literal["agent", "validation"] = "agent"
    prediction: dict[str, Any] | None = None
    execution_source: Literal["bridge-local", "runtime-envelope"] | None = None
    command_sha256: str | None = None
    command_bytes: int | None = None
    effective_command_sha256: str | None = None
    effective_command_bytes: int | None = None
    duration_ms: int
    exit_code: int
    timed_out: bool = False
    cancelled: bool = False
    stdout_bytes: int | None = None
    stderr_bytes: int | None = None
    output_truncated: bool = False
    user_cpu_ms: int | None = None
    system_cpu_ms: int | None = None
    max_rss_kib: int | None = None
    telemetry_state: str | None = None
    telemetry_error: str | None = None
    telemetry_artifact: str | None = None
    telemetry_eligible_for_kb: bool | None = None
    telemetry_quality: str | None = None
    telemetry_collection_validity: str | None = None
    telemetry_cleanup: str | None = None
    telemetry_loss_total: int | None = None
    pmu_state: str | None = None
    pmu_quality: str | None = None
    pmu_error: str | None = None
    pmu_artifact: str | None = None


class PmuEvent(StrictModel):
    supported: bool
    semantics: str
    raw_count: int | None = Field(default=None, ge=0)
    scaled_count: float | None = Field(default=None, ge=0)
    time_enabled_ns: int | None = Field(default=None, ge=0)
    time_running_ns: int | None = Field(default=None, ge=0)
    running_ratio: float | None = Field(default=None, ge=0, le=1)
    error: str | None = None


class PmuCoverage(StrictModel):
    status: Literal["reliable", "multiplexed", "partial", "unavailable"]
    reason: str
    running_ratio: float | None = Field(default=None, ge=0, le=1)
    multiplexed: bool
    kernel_included: bool
    root_and_future_descendants: bool
    eligible_for_kb: bool


class PmuProfile(StrictModel):
    model_config = ConfigDict(
        extra="forbid", populate_by_name=True, serialize_by_alias=True
    )
    schema_name: Literal["pmu_profile_v1"] = Field(
        validation_alias="schema", serialization_alias="schema"
    )
    execution_id: str = Field(min_length=1, max_length=128)
    source: Literal["perf_event_open"]
    mode: Literal["counting"]
    scope: Literal["task-inherit-enable-on-exec"]
    root_pid: int | None = Field(default=None, ge=1)
    started_at: float | None = Field(default=None, ge=0)
    ended_at: float | None = Field(default=None, ge=0)
    architecture: str
    pmu_devices: list[str]
    llc_semantics: str
    llc_semantics_confirmed: bool
    events: dict[Literal[
        "cycles", "instructions", "llc_read_misses", "llc_read_accesses"
    ], PmuEvent]
    derived: dict[Literal["ipc", "llc_mpki", "llc_miss_rate"], float | None]
    coverage: PmuCoverage
    collector_errors: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _complete_event_set(self) -> "PmuProfile":
        required = {"cycles", "instructions", "llc_read_misses", "llc_read_accesses"}
        if set(self.events) != required:
            raise ValueError("PMU profile requires the complete named event set")
        semantics = {
            "cycles": "PERF_COUNT_HW_CPU_CYCLES",
            "instructions": "PERF_COUNT_HW_INSTRUCTIONS",
            "llc_read_misses": "PERF_COUNT_HW_CACHE_LL:READ:MISS",
            "llc_read_accesses": "PERF_COUNT_HW_CACHE_LL:READ:ACCESS",
        }
        if any(self.events[name].semantics != value for name, value in semantics.items()):
            raise ValueError("PMU event semantics do not match the public contract")
        if set(self.derived) != {"ipc", "llc_mpki", "llc_miss_rate"}:
            raise ValueError("PMU profile requires all derived metrics")
        reliable = self.coverage.status == "reliable"
        if self.coverage.eligible_for_kb != reliable:
            raise ValueError("PMU KB eligibility must exactly match reliable coverage")
        if reliable and not self.llc_semantics_confirmed:
            raise ValueError("reliable PMU coverage requires confirmed LLC semantics")
        if reliable and not self.coverage.root_and_future_descendants:
            raise ValueError("reliable PMU coverage requires inherited root scope")
        if reliable and self.coverage.multiplexed:
            raise ValueError("reliable PMU coverage cannot be multiplexed")
        if reliable and (
            not self.coverage.kernel_included
            or self.coverage.running_ratio != 1.0
            or any(
                not event.supported or event.error
                or event.raw_count is None or event.scaled_count is None
                or not math.isfinite(event.scaled_count)
                or not event.time_enabled_ns
                or event.time_running_ns != event.time_enabled_ns
                or event.running_ratio != 1.0
                for event in self.events.values()
            )
        ):
            raise ValueError("reliable PMU coverage requires complete, unmultiplexed counters including kernel")
        if any(value is not None and (not math.isfinite(value) or value < 0)
               for value in self.derived.values()):
            raise ValueError("PMU derived metrics must be finite and nonnegative")
        if self.coverage.status == "multiplexed" and not self.coverage.multiplexed:
            raise ValueError("multiplexed PMU coverage requires multiplexed=true")
        return self


class CgroupResource(StrictModel):
    """Independent per-execution cgroup/procfs resource artifact.

    Mirrors ClawTune's ``CgroupResourceResult``
    (``services/sidecar/src/clawtune_sidecar/telemetry/cgroup_resource.py``,
    schema ``cgroup_resource_v1``) so both repositories parse the same
    independent resource artifact. It does not prove that eBPF was active.
    ``source`` distinguishes the measurement path:

    * ``cgroup-v2`` -- CPU/memory/disk use guest cgroup counters; network is
      unavailable here and its fields remain null.
    * ``process-tree`` -- best-effort guest procfs process-tree sampling.
    """

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    # ``schema_name`` avoids shadowing pydantic's ``BaseModel.schema``; the
    # JSON key stays ``schema`` (the ClawTune artifact field name).
    schema_name: str = Field(
        default="cgroup_resource_v1",
        validation_alias="schema",
        serialization_alias="schema",
    )
    execution_id: str | None = None
    tool_call_id: str | None = None
    tool_name: str = ""
    source: str = "cgroup-v2"
    cgroup_path: str | None = None
    monitor_source: str | None = None
    attribution_source: str | None = None
    ts_start: float | None = None
    ts_end: float | None = None
    duration_ms: int | None = None
    cpu_time_s: float | None = None
    cpu_utilization_avg_cores: float | None = None
    memory_rss_before_bytes: int | None = None
    memory_rss_after_bytes: int | None = None
    memory_rss_peak_bytes: int | None = None
    disk_read_bytes_delta: int | None = None
    disk_write_bytes_delta: int | None = None
    network_rx_bytes_delta: int | None = None
    network_tx_bytes_delta: int | None = None
    sampling_interval_ms: int | None = None
    sampling_point_count: int | None = None
    sampling_quality: str | None = None
    sampling_coverage_ms: int | None = None
    cpu_source: str | None = None
    memory_source: str | None = None
    memory_baseline_bytes: int | None = Field(default=None, ge=0)
    memory_total_peak_bytes: int | None = Field(default=None, ge=0)
    memory_extra_peak_bytes: int | None = Field(default=None, ge=0)
    memory_measurement: str | None = None
    memory_environment_id: str | None = None
    memory_eligible: bool = False
    memory_unavailable_reason: str | None = None
    memory_timeline: list[tuple[float, float]] | None = None
    disk_source: str | None = None
    network_source: str | None = None
    fallback_used: bool = False
    cgroup_setup_error: str | None = None
    cgroup_read_error: str | None = None
    collector_errors: list[str] = Field(default_factory=list)
    independence: str | None = None
    pmu: PmuProfile | None = None


def cgroup_artifact_to_resource(
    data: dict[str, Any],
) -> CgroupResource | None:
    """Parse one ClawTune ``cgroup-resource-<execution_id>.json`` artifact.

    Returns ``None`` when the payload is not a cgroup_resource_v1 record or
    lacks an execution_id (so no dangling reference is attached).
    """
    if not isinstance(data, dict):
        return None
    if data.get("schema") not in (None, "cgroup_resource_v1"):
        return None
    if not data.get("execution_id"):
        return None
    if isinstance(data.get("pmu"), dict) and data["pmu"].get("execution_id") != data["execution_id"]:
        data = {key: value for key, value in data.items() if key != "pmu"}
    try:
        return CgroupResource.model_validate(data)
    except (ValueError, TypeError):
        # PMU is optional and fail-open. A malformed/partially written PMU
        # member must not discard otherwise authoritative cgroup accounting.
        if "pmu" not in data:
            return None
        without_pmu = dict(data)
        without_pmu.pop("pmu", None)
        try:
            return CgroupResource.model_validate(without_pmu)
        except (ValueError, TypeError):
            return None


class ToolObservation(StrictModel):
    """Normalized, joined, validated unit fed to the dataset and KB.

    ``trusted`` is set by the validator: complete + valid quality + exit 0.
    Only trusted observations train the active KB.
    """

    schema_version: int = OBSERVATION_SCHEMA_VERSION
    execution_id: str = Field(min_length=1, max_length=128)
    tool_name: str = Field(default="exec", max_length=128)
    command: str | None = Field(default=None, max_length=4096)
    command_digest: str | None = Field(default=None, max_length=64)
    repo_fingerprint: str | None = Field(default=None, max_length=256)
    run_id: str | None = Field(default=None, max_length=128)
    session_id: str | None = Field(default=None, max_length=128)
    sequence_no: int = 0
    start_time: datetime | None = None
    end_time: datetime | None = None
    duration_sec: float | None = Field(default=None, ge=0)
    status_code: str | None = Field(default=None, max_length=32)
    exit_code: int | None = None
    complete: bool = False
    collection_quality: CollectionQuality = CollectionQuality.INVALID
    coverage_ratio: float | None = Field(default=None, ge=0, le=1)
    coverage_reason: str | None = Field(default=None, max_length=64)
    cpu_time_sec: float | None = Field(default=None, ge=0)
    cpu_utilization_avg_cores: float | None = Field(default=None, ge=0)
    rss_peak_bytes: int | None = Field(default=None, ge=0)
    memory_rss_bytes_after: int | None = Field(default=None, ge=0)
    memory_baseline_bytes: int | None = Field(default=None, ge=0)
    memory_total_peak_bytes: int | None = Field(default=None, ge=0)
    memory_extra_peak_bytes: int | None = Field(default=None, ge=0)
    memory_measurement: str | None = None
    memory_environment_id: str | None = None
    memory_eligible: bool = False
    stdout_bytes: int | None = Field(default=None, ge=0)
    stderr_bytes: int | None = Field(default=None, ge=0)
    output_truncated: bool = False
    source: ObservationSource = ObservationSource.CLAWTUNE_SPAN
    # Independent cgroup v2/procfs resource artifact, when the Tool-VM
    # collector produced one for this execution (ClawTune cgroup_resource_v1).
    cgroup: CgroupResource | None = None
    pmu: PmuProfile | None = None
    ipc: float | None = Field(default=None, ge=0)
    llc_mpki: float | None = Field(default=None, ge=0)
    llc_miss_rate: float | None = Field(default=None, ge=0)
    pmu_eligible_for_kb: bool = False
    trusted: bool = False
    created_at: datetime = Field(default_factory=utcnow)

    @property
    def latency_bucket(self) -> str | None:
        return duration_bucket(self.duration_sec)

    @model_validator(mode="after")
    def _valid_interval(self) -> "ToolObservation":
        if self.start_time is not None and self.end_time is not None:
            if self.end_time < self.start_time:
                raise ValueError("end_time precedes start_time")
        if self.collection_quality == CollectionQuality.VALID and self.duration_sec is None:
            raise ValueError("valid observation requires duration_sec")
        return self


# ── Span-end extraction helpers ─────────────────────────────────────────

def _as_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _as_int(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def span_end_to_observation(record: dict[str, Any]) -> ToolObservation | None:
    """Build a normalized observation from a ClawTune v6 ``span_end`` record.

    Returns ``None`` when the record is not a tool span or lacks an
    execution_id (unjoinable in hook-only mode before the envelope fix).
    """
    if record.get("record_type") != "span_end":
        return None
    if record.get("schema_version") != CLAWTUNE_TRACE_SCHEMA_VERSION:
        return None
    if record.get("kind") != "tool":
        return None
    execution = record.get("execution") or {}
    execution_id = execution.get("execution_id")
    if not execution_id:
        return None
    resources = record.get("resources") or {}
    output = record.get("output") or {}
    status = record.get("status") or {}
    try:
        end_time = datetime.fromtimestamp(int(record["wall_time_ns"]) / 1e9, tz=timezone.utc)
    except (KeyError, TypeError, ValueError):
        end_time = None
    duration_sec = _as_float(record.get("duration_sec"))
    if duration_sec is None:
        action_duration_ns = _as_float(resources.get("action_duration_ns"))
        if action_duration_ns is not None:
            duration_sec = action_duration_ns / 1e9
    if duration_sec is None:
        duration_ns = _as_float(record.get("duration_ns"))
        if duration_ns is not None:
            duration_sec = duration_ns / 1e9
    start_time = None
    monitor_start_ns = _as_int(resources.get("monitor_start_wall_time_ns"))
    if monitor_start_ns is not None:
        try:
            candidate = datetime.fromtimestamp(monitor_start_ns / 1e9, tz=timezone.utc)
            if end_time is None or candidate < end_time:
                start_time = candidate
        except (OverflowError, OSError, ValueError):
            pass
    if start_time is None and end_time is not None and duration_sec is not None:
        start_time = end_time - timedelta(seconds=duration_sec)
    if start_time is None:
        start_time = end_time
    coverage_ratio = _as_float(resources.get("coverage_ratio"))
    status_code = status.get("code")
    exit_code = output.get("exit_code")
    exit_code = _as_int(exit_code) if exit_code is not None else None
    if exit_code is None:
        exit_code = 0 if status_code == "ok" else 1
    quality: CollectionQuality
    if status_code == "ok" and coverage_ratio is not None and coverage_ratio >= 0.9:
        quality = CollectionQuality.VALID
    elif status_code in ("ok", "error", "timeout") and coverage_ratio is not None and coverage_ratio >= 0.5:
        quality = CollectionQuality.DEGRADED
    else:
        quality = CollectionQuality.INVALID
    complete = status_code in ("ok", "error", "timeout", "cancelled")
    requested_command = execution.get("requested_command") or execution.get("payload_command")
    command_digest = execution.get("command_digest")
    cpu_time_sec = _as_float(resources.get("cpu_time_s"))
    cpu_cores = _as_float(resources.get("cpu_utilization_avg_cores"))
    rss_peak = _as_int(resources.get("rss_peak_bytes"))
    rss_after = _as_int(resources.get("memory_rss_bytes_after"))
    pmu = None
    try:
        if isinstance(resources.get("pmu"), dict):
            pmu = PmuProfile.model_validate(resources["pmu"])
            if pmu.execution_id != execution_id:
                pmu = None
    except (ValueError, TypeError):
        pmu = None
    pmu_eligible = bool(
        pmu is not None
        and pmu.coverage.status == "reliable"
        and pmu.coverage.eligible_for_kb
    )
    try:
        return ToolObservation(
            execution_id=execution_id,
            tool_name=record.get("name") or "exec",
            command=requested_command,
            command_digest=command_digest,
            repo_fingerprint=record.get("repo"),
            run_id=record.get("run_id"),
            session_id=record.get("session_id"),
            sequence_no=int(record.get("sequence_no") or 0),
            start_time=start_time,
            end_time=end_time,
            duration_sec=duration_sec,
            status_code=status_code,
            exit_code=exit_code,
            complete=complete,
            collection_quality=quality,
            coverage_ratio=coverage_ratio,
            coverage_reason=resources.get("coverage_reason"),
            cpu_time_sec=cpu_time_sec,
            cpu_utilization_avg_cores=cpu_cores,
            rss_peak_bytes=rss_peak,
            memory_rss_bytes_after=rss_after,
            memory_baseline_bytes=_as_int(resources.get("memory_baseline_bytes")),
            memory_total_peak_bytes=_as_int(resources.get("memory_total_peak_bytes")),
            memory_extra_peak_bytes=_as_int(resources.get("memory_extra_peak_bytes")),
            memory_measurement=resources.get("memory_measurement"),
            memory_environment_id=resources.get("memory_environment_id"),
            memory_eligible=resources.get("memory_eligible") is True,
            pmu=pmu,
            ipc=(pmu.derived.get("ipc") if pmu_eligible else None),
            llc_mpki=(pmu.derived.get("llc_mpki") if pmu_eligible else None),
            llc_miss_rate=(pmu.derived.get("llc_miss_rate") if pmu_eligible else None),
            pmu_eligible_for_kb=pmu_eligible,
            source=ObservationSource.CLAWTUNE_SPAN,
        )
    except (ValueError, TypeError):
        return None


def bridge_record_to_observation(record: dict[str, Any]) -> BridgeRecord:
    """Parse one tool-bridge JSONL line into a validated BridgeRecord."""
    return BridgeRecord.model_validate(record)
